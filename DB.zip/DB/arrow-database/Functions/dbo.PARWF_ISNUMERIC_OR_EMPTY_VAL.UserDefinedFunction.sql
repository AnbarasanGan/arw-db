DROP FUNCTION [dbo].[PARWF_ISNUMERIC_OR_EMPTY_VAL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 01/09/2020
-- Description:	Checks if a value is Numeric or Not Numeric. An empty value is returned as Numeric
-- Example: PBOM depth must be numeric or an empty string('').  When this is true a 1 is returned, otherwise a 0 is returned.  
-- Not_numeric = 0
-- Numeric = 1
-- Empty String is evaluated as Numeric
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- Asolosky   10/12/2020 US1989948  Isnumeric function didn't handle values that appeared to be scientific like 5e07. Changed to use NOT LIKE '%[^0-9]%'
-- =============================================
CREATE FUNCTION [dbo].[PARWF_ISNUMERIC_OR_EMPTY_VAL]
(
  @STAGING_CHAR  VARCHAR(5000)
)
RETURNS INT
AS
Begin
 Declare @Numeric_f    INT;
 Declare @STAGING_Len  INT = len(@STAGING_CHAR);

 SELECT @Numeric_f =
        case When @STAGING_CHAR = ''                Then 1
		         when @STAGING_CHAR NOT LIKE '%[^.0123456789]%' Then
			       Case When Substring(@STAGING_CHAR,1,1) = '.' and @STAGING_Len = 1  
				          Then 0 --When there's only 1 character and its a '.' then non-numeric
					        Else 1
				     End --Inner Case
		 	   Else 0 
        End --Outer Case
 Return @Numeric_f
End;

GO
