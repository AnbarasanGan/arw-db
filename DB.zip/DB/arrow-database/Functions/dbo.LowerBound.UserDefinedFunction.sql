DROP FUNCTION [dbo].[LowerBound]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[LowerBound] (
        @Lower_bound_pct DECIMAL(5,3)  
		                    )
RETURNS DECIMAL(9,7)
AS
BEGIN
   RETURN (1-(@lower_bound_pct/100));
END;

GO
