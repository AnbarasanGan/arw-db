DROP FUNCTION [dbo].[PARWF_ARWA57_TYPE_X]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 01/09/2020
-- Description:	Function to return ARWA57_END_ITM_MAP_TYPE_K based on the input value for ARWA57_END_ITM_MAP_TYPE_X 
-- Input @ARWA57_END_ITM_MAP_TYPE_X
-- Return: ARWA57_END_ITM_MAP_TYPE_K  --The A57 primary key 
-- =============================================
-- Changes
-- =============================================
-- Author     Date       User Story Description
-- ------     -----      ---------- ----------
-- =============================================
CREATE FUNCTION [dbo].[PARWF_ARWA57_TYPE_X]
(
  @ARWA57_END_ITM_MAP_TYPE_X  VARCHAR(MAX)
)
RETURNS INT
AS
Begin
Declare @ARWA57_END_ITM_MAP_TYPE_K INT;
 Select @ARWA57_END_ITM_MAP_TYPE_K=(select ARWA57_END_ITM_MAP_TYPE_K 
                                      from PARWA57_END_ITM_MAP_TYPE A57
									 where A57.ARWA57_END_ITM_MAP_TYPE_X = @ARWA57_END_ITM_MAP_TYPE_X
								   );

 Return @ARWA57_END_ITM_MAP_TYPE_K;
End;

GO
