DROP FUNCTION [dbo].[PARWF_ISNUMERIC_AND_NOTEMPTY_VAL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 01/09/2020
-- Description:	Checks if a value is Numeric or Not Numeric. An empty value is Not Numeric
-- Example: PBOM quantity must be numeric and must have a value.  When this is true a 1 is returned, otherwise a 0 is returned.  
-- Not_numeric = 0
-- Numeric = 1
-- Empty String is evaluated as Not Numeric
-- =============================================
-- Changes
-- =============================================
-- Author     Date       User Story Description
-- ------     -----      ---------- ----------
-- Asolosky   10/12/2020 US1989948  Isnumeric function didn't handle values that appeared to be scientific like 5e07. Changed to use NOT LIKE '%[^0-9]%'
-- Asolosky   02/11/2021 US2284375  Add zero as a value that will cause the return value to be false. Changed @STAGING_CHAR = '' to @STAGING_CHAR in ('','0')
-- =============================================
CREATE FUNCTION [dbo].[PARWF_ISNUMERIC_AND_NOTEMPTY_VAL]
(
  @STAGING_CHAR  VARCHAR(5000)
)
RETURNS INT
AS
Begin
 Declare @Numeric_f   INT
 Declare @STAGING_Len INT = len(@STAGING_CHAR);

 SELECT @Numeric_f = 
        case When @STAGING_CHAR in ('','0') Then 0
             When @STAGING_CHAR NOT LIKE '%[^.0123456789]%' Then
			      Case When Substring(@STAGING_CHAR,1,1) = '.' and @STAGING_Len = 1  
				       Then 0 --When there's only 1 character and its a '.' then non-numeric
					   Else 1
				  End --Inner Case
		 	 Else 0 
        End --Outer Case

 Return @Numeric_f
End;

GO
