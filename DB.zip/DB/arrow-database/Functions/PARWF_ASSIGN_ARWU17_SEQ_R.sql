DROP FUNCTION [dbo].[PARWF_ASSIGN_ARWU17_SEQ_R]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		asolosky
-- Create date: 05/25/2021
-- Description:	Table PARWU17_BOM_SUB_ASSY has the column ARWU17_BOM_SUB_ASSY_SEQ_R which is used for sorting in the UI.
--              This function will assign a number based on the ARWU17_BOM_SUB_ASSY_IX_C so DP will be last
-- Input Parameter: Sub-Assembly code 
-- Return: A number related to the Sub-Assembly code which will be used to insert in to the ARWU17_BOM_SUB_ASSY_SEQ_R column
-- =============================================
-- Changes
-- =============================================
-- Author     Date       User Story Description
-- ------     -----      ---------- ----------
-- =============================================
CREATE FUNCTION [dbo].[PARWF_ASSIGN_ARWU17_SEQ_R]
(
  @SUB_ASSY_IX_C  VARCHAR(MAX)
)
RETURNS VARCHAR(MAX)
AS
Begin
 Declare @ARWU17_SEQ_R   SMALLINT

 SELECT @ARWU17_SEQ_R = 
        case When @SUB_ASSY_IX_C = 'A'  Then 1 
             When @SUB_ASSY_IX_C = 'B'  Then 2 
             When @SUB_ASSY_IX_C = 'C'  Then 3
             When @SUB_ASSY_IX_C = 'D'  Then 4 
             When @SUB_ASSY_IX_C = 'E'  Then 5 
             When @SUB_ASSY_IX_C = 'F'  Then 6 
             When @SUB_ASSY_IX_C = 'G'  Then 7 
             When @SUB_ASSY_IX_C = 'H'  Then 8 
             When @SUB_ASSY_IX_C = 'I'  Then 9 
             When @SUB_ASSY_IX_C = 'J'  Then 10 
             When @SUB_ASSY_IX_C = 'K'  Then 11
             When @SUB_ASSY_IX_C = 'L'  Then 12
             When @SUB_ASSY_IX_C = 'M'  Then 13
             When @SUB_ASSY_IX_C = 'N'  Then 14
             When @SUB_ASSY_IX_C = 'O'  Then 15
             When @SUB_ASSY_IX_C = 'P'  Then 16
             When @SUB_ASSY_IX_C = 'Q'  Then 17
             When @SUB_ASSY_IX_C = 'R'  Then 18
             When @SUB_ASSY_IX_C = 'S'  Then 19
             When @SUB_ASSY_IX_C = 'T'  Then 20
             When @SUB_ASSY_IX_C = 'U'  Then 21
             When @SUB_ASSY_IX_C = 'V'  Then 22
             When @SUB_ASSY_IX_C = 'W'  Then 23
             When @SUB_ASSY_IX_C = 'X'  Then 24
             When @SUB_ASSY_IX_C = 'Y'  Then 25
             When @SUB_ASSY_IX_C = 'DP' Then 32767
             Else 32766
         end; 

 Return @ARWU17_SEQ_R
End;

GO


