DROP FUNCTION [dbo].[PARWF_CCS_RAWMaterial_RECLAIM_REVENUE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2021
-- Description:	Formula to calculate the CCS/GCS raw material reclaim revenue.  This is to mimic the Excel file formula for reclaim revenue.
--              The formula was being copied from one procedure to another so it was determined to place the logic in a single function.
-- =============================================
-- Changes
-- Date        CDSID     Feature    Description
-- ----------  --------  -------    -----------
-- 01/21/2021  Asolosky  US2209131  Used the ARWA10_COST_EST_PERFD_F instead of ARWA10_CCTSS_METHD_N 
-- =============================================

CREATE FUNCTION [dbo].[PARWF_CCS_RAWMaterial_RECLAIM_REVENUE]
(
 @ARWA10_COST_EST_PERFD_F     BIT
,@ARWA53_LGCY_CCS_PGM_N       Varchar(MAX)
,@ARWU25_GRS_USG_PER_PCE_Q    DECIMAL(38,9)
,@ARWU25_RCLMTN_P             DECIMAL(38,9)
,@ARWU25_SCRAP_PRCE_PER_UOM_A DECIMAL(38,9)
,@ARWU19_DSGN_PART_MTRL_USG_Q DECIMAL(38,9)
)
RETURNS DECIMAL(38,9)
AS
BEGIN
 Declare @RECLAIM_REVENUE  DECIMAL(38,9)

 SELECT @RECLAIM_REVENUE =
   CASE WHEN @ARWA10_COST_EST_PERFD_F = 1 and @ARWA53_LGCY_CCS_PGM_N is NULL
   	    THEN (@ARWU25_GRS_USG_PER_PCE_Q) * @ARWU25_RCLMTN_P * @ARWU25_SCRAP_PRCE_PER_UOM_A
   	    ELSE (@ARWU25_GRS_USG_PER_PCE_Q - @ARWU19_DSGN_PART_MTRL_USG_Q) * @ARWU25_RCLMTN_P * @ARWU25_SCRAP_PRCE_PER_UOM_A 
   END 
   RETURN (@RECLAIM_REVENUE);
END;


GO
