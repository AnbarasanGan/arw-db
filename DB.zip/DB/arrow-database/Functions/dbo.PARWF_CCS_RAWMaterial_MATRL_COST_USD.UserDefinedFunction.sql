DROP FUNCTION [dbo].[PARWF_CCS_RAWMaterial_MATRL_COST_USD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2021
-- Description:	Formula to calculate the CCS/GCS raw material cost in USD.  This is the total line (in green) for each part in the Excel file
--              The formula was being copied from one procedure to another so it was determined to place the logic in a single function.
-- =============================================
-- Changes
-- Date        CDSID     Feature    Description
-- ----------  --------  -------    -----------
-- 01/21/2021  Asolosky  US2209131  Used the ARWA10_COST_EST_PERFD_F instead of ARWA10_CCTSS_METHD_N 
-- 08/13/2021  Asolosky  US2786543  Added the convert to float because of the weird situation with CX748NA Moonroof CCS upload
--                                  It appears SQL Server can truncate data when multiplying or dividing with two large precisions of 18. 
-- =============================================

CREATE FUNCTION [dbo].[PARWF_CCS_RAWMaterial_MATRL_COST_USD]
(
 @ARWA10_COST_EST_PERFD_F        BIT
,@ARWA53_LGCY_CCS_PGM_N          Varchar(MAX)
,@ARWU19_DSGN_PART_Q             DECIMAL(38,9)
,@ARWU25_GRS_USG_PER_PCE_Q       DECIMAL(38,9)
,@ARWU25_INPROC_SCRAP_P          DECIMAL(38,9)
,@ARWU25_MTRL_PEL_RATE_PER_UOM_A DECIMAL(38,9)
,@ARWU25_INBND_LGSTCS_COST_UOM_A DECIMAL(38,9) 
,@ARWU25_INBND_PKNG_COST_UOM_A   DECIMAL(38,9) 
,@ARWU25_TAX_AND_DUTY_PER_UOM_A  DECIMAL(38,9)
,@ARWU25_RCLMTN_P                DECIMAL(38,9)
,@ARWU25_SCRAP_PRCE_PER_UOM_A    DECIMAL(38,9)
,@ARWU19_DSGN_PART_MTRL_USG_Q    DECIMAL(38,9)
,@ARWU22_CRCY_PER_SUPL_CRCY_R    DECIMAL(38,9)
)
RETURNS DECIMAL(38,9)
AS
BEGIN
 Declare @MATRL_COST_USD  DECIMAL(38,9)

 SELECT @MATRL_COST_USD =
   CASE WHEN @ARWA10_COST_EST_PERFD_F = 1 and @ARWA53_LGCY_CCS_PGM_N is NULL    
		THEN (@ARWU19_DSGN_PART_Q *
		         ( @ARWU25_GRS_USG_PER_PCE_Q * convert(FLOAT, (1 + @ARWU25_INPROC_SCRAP_P) )
                   * (@ARWU25_MTRL_PEL_RATE_PER_UOM_A + @ARWU25_INBND_LGSTCS_COST_UOM_A + @ARWU25_INBND_PKNG_COST_UOM_A + @ARWU25_TAX_AND_DUTY_PER_UOM_A)
				 -
                  (@ARWU25_GRS_USG_PER_PCE_Q * @ARWU25_RCLMTN_P * @ARWU25_SCRAP_PRCE_PER_UOM_A)
				 )
             ) * @ARWU22_CRCY_PER_SUPL_CRCY_R  
	    ELSE ((@ARWU19_DSGN_PART_Q * @ARWU25_GRS_USG_PER_PCE_Q 
               * (@ARWU25_MTRL_PEL_RATE_PER_UOM_A + @ARWU25_INBND_LGSTCS_COST_UOM_A + @ARWU25_INBND_PKNG_COST_UOM_A + @ARWU25_TAX_AND_DUTY_PER_UOM_A)
              )
              -
              (@ARWU19_DSGN_PART_Q*((@ARWU25_GRS_USG_PER_PCE_Q - @ARWU19_DSGN_PART_MTRL_USG_Q) * @ARWU25_RCLMTN_P * @ARWU25_SCRAP_PRCE_PER_UOM_A))
             ) * @ARWU22_CRCY_PER_SUPL_CRCY_R
	 END;

 RETURN (@MATRL_COST_USD);
END;

GO
