DROP FUNCTION [dbo].[RemoveASCIISpecialChars]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE function [dbo].[RemoveASCIISpecialChars] (@orig_strng varchar(256)) returns varchar(256)

begin
   if @orig_strng is null
      return null
   declare @new_strng varchar(256)
   set @new_strng = ''
   declare @lngth int
   set @lngth = len(@orig_strng)
   declare @pntr int
   set @pntr = 1
   while @pntr <= @lngth begin
      declare @ASCII_char int
      set @ASCII_char = ascii(substring(@orig_strng, @pntr, 1))
      if @ASCII_char not in (10,13,39) -- removed 34 
         set @new_strng = @new_strng + char(@ASCII_char)
      set @pntr = @pntr + 1
      end
   if len(@new_strng) = 0
      return null
   return @new_strng

   end
GO
