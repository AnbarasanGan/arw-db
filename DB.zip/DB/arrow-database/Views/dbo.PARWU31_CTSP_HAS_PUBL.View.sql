DROP VIEW IF EXISTS PARWU31_CTSP_HAS_PUBL
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[PARWU31_CTSP_HAS_PUBL] AS
select 
 U31.ARWU31_CTSP_K
,case when has_publ.ARWU31_CTSP_K is null then 'No' else 'Yes' end as HAS_PUBL
from PARWU31_CTSP as U31
left join (
	select ARWU31_CTSP_K
	from PARWU01_CCTSS_FLAT
	where ARWA11_CCTSS_STAT_N in ('Pre-Published','Published')
	group by ARWU31_CTSP_K
) as has_publ
on U31.ARWU31_CTSP_K = has_publ.ARWU31_CTSP_K
GO


