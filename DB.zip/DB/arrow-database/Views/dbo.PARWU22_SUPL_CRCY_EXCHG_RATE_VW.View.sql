DROP VIEW [dbo].[PARWU22_SUPL_CRCY_EXCHG_RATE_VW]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 10/07/2019
-- Description:	View to bring the U21 and U22 tables together, along with their lookup tables
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   10/17/2019  Changed the last update columns to use from U22 instead of U21
-- Ashaik12   04/02/2020  Adding ARWA29_CRCY_K to select statement
-- =============================================

CREATE VIEW [dbo].[PARWU22_SUPL_CRCY_EXCHG_RATE_VW] AS
select 
A17.ARWA17_SUPL_N, 
U21.ARWU07_CCTSS_SUPL_K, 
U22_A29.ARWA29_CRCY_K AS U22_ARWA29_CRCY_K,
U21_A29.ARWA29_CRCY_C as U21_ARWA29_CRCY_C, 
ARWU22_LAST_UPDT_USER_C, 
convert(varchar,ARWU22_LAST_UPDT_S) as ARWU22_LAST_UPDT_S,
U22_A29.ARWA29_CRCY_C as U22_ARWA29_CRCY_C, 
U22.ARWU22_CRCY_PER_SUPL_CRCY_R

from PARWU21_CCTSS_SUPL_CRCY U21
JOIN
PARWU22_SUPL_CRCY_EXCHG_RATE U22
ON U21.ARWU07_CCTSS_SUPL_K = U22.ARWU07_CCTSS_SUPL_K
JOIN PARWA29_CRCY U21_A29
ON U21.ARWA29_CRCY_K = U21_A29.ARWA29_CRCY_K
JOIN PARWA29_CRCY U22_A29
ON U22.ARWA29_CRCY_K = U22_A29.ARWA29_CRCY_K
JOIN PARWU07_CCTSS_SUPL U07
ON U21.ARWU07_CCTSS_SUPL_K = U07.ARWU07_CCTSS_SUPL_K
JOIN PARWA17_SUPL A17
ON U07.ARWA17_SUPL_K = A17.ARWA17_SUPL_K



GO
