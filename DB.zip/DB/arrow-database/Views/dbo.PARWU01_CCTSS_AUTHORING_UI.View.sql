/****** Object:  View [dbo].[PARWU01_CCTSS_AUTHORING_UI]    Script Date: 7/5/2022 8:50:35 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==============================================================================================
--Date:  Apr/06/2020
--CDSID: kvijayab
--Description:
--The view is used in the *BOB Authoring Summary Screen* to get all the cctss records.
--It also finds the status of variant, design, supplier, tradeoff, risks data entry.
--==============================================================================================
--Change Log
-- 2020/04/17	btemkow		Removed logic to populate ARWA11_CCTSS_STAT_N with current BoB Status
--							because that logic/column has been added to PARWU01_CCTSS_FLAT
-- 2020/06/19	kvijayab	Added Ford Part Status flag by checking U63 table
-- 2020/06/19	kvijayab	Added all columns from U01 flat to use ARWA46_CCTSS_IMPT_VER_N
-- 2020/12/18	kvijayab	Added TYGRA_MAP_STAT
-- 2021/04/09	kvijayab	Added COST_ALLOC_STAT
-- 2021/04/29	kvijayab	Removed * and added specific columns
-- 2021/11/04   btemkow     Added UB6_SCOPE_TYGRA_FILE_K for US3034759
-- 2021/11/17	btemkow		Added Conway columns for US3061235
-- 2022/01/11   ashaik12    Added new columns for Arrow universal BoB 
-- 2022/03/25   btemkow     US3458379 - added U01.ARWU01_MANL_VRNT_TYGRA_FLD_F
-- 2022/04/06   btemkow     US3501500 - split DC2.0 type into: With Benchmarking / Without Benchmarking
-- 2022-05-14	btemkow		US3619811 - changed from U90 to UD1 for "Risk Stat check"
-- 2022-06-27   ashaik12    Added pending counts for VAII
--==============================================================================================

CREATE OR ALTER VIEW [dbo].[PARWU01_CCTSS_AUTHORING_UI] AS 

--this CTE produces a comma-separated list of Deviation Approvers for every BoB/DEA
with CCTSS_DVNT_APRVR (ARWU01_CCTSS_K, CDSIDS) as (
select
 ARWU01_CCTSS_K
,stuff((select ', ' + ARWU10_TO4_MBR_USER_C
	from (
		select
		 ARWU01_CCTSS_K
		,ARWU10_TO4_MBR_USER_C
		from PARWU11_CCTSS_TO4_MBR as U11
		join PARWU10_TO4_MBR as U10
			on U11.ARWU10_TO4_MBR_K = U10.ARWU10_TO4_MBR_K
		join PARWA21_TO4_MBR_ROLE as A21
			on U11.ARWA21_TO4_MBR_ROLE_K = A21.ARWA21_TO4_MBR_ROLE_K
			and A21.ARWA21_TO4_MBR_ROLE_N = 'Deviation Approver') as t2
	where t2.ARWU01_CCTSS_K = t1.ARWU01_CCTSS_K
	for xml path('')),1,1,'')
from (
	select
	 ARWU01_CCTSS_K
	from PARWU11_CCTSS_TO4_MBR as U11
	join PARWU10_TO4_MBR as U10
		on U11.ARWU10_TO4_MBR_K = U10.ARWU10_TO4_MBR_K
	join PARWA21_TO4_MBR_ROLE as A21
		on U11.ARWA21_TO4_MBR_ROLE_K = A21.ARWA21_TO4_MBR_ROLE_K
		and A21.ARWA21_TO4_MBR_ROLE_N = 'Deviation Approver'
	group by ARWU01_CCTSS_K)  as t1
)

, CCTSS_PENDING_COUNT (ARWU01_CCTSS_K ,BOB_PNDNG_APPRVL,DA_PNDNG_APPRVL ,II_PNDNG_APPRVL ) as
(
select X.ARWU01_CCTSS_K,SUM(COALESCE(u95_p_count,0) +COALESCE(u96_p_count,0) +COALESCE(u97_p_count,0)+COALESCE(u98_p_count,0)+ COALESCE(u99_p_count,0)) as BOB_PNDNG_APPRVL
,SUM( COALESCE(a0_p_count,0) + COALESCE(a1_p_count,0) + COALESCE(a2_p_count,0)) AS DA_PNDNG_APPRVL
,SUM( IIF(u01_flat.ARWA10_CCTSS_METHD_N in ('DC 2.0 Without Benchmarking','DC 2.0 With Benchmarking'), 0, COALESCE(a3_p_count,0) + COALESCE(a4_p_count,0) + COALESCE(a5_p_count,0))) AS II_PNDNG_APPRVL
 from
 (select  
 U06.ARWU01_CCTSS_K
 ,count(*) as u95_p_count
 ,0 as u96_p_count
 ,0 as u97_p_count
 ,0 as u98_p_count 
 ,0 as u99_p_count
 ,0 a0_p_count
 ,0 a1_p_count   
 ,0 a2_p_count
 ,0 a3_p_count
 ,0 a4_p_count
 ,0 a5_p_count 
 from PARWU95_MNLSLCT_DSGN_PART_STAT u95
   join PARWU19_DSGN_PART u19 on u95.[ARWU19_DSGN_PART_K]=u19.[ARWU19_DSGN_PART_K]
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = U95.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  U19.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   Union
   select U06.ARWU01_CCTSS_K
   , 0 AS u95_p_count
   , count(*) u96_p_count
   , 0 as u97_p_count
   ,0 as u98_p_count 
   ,0 as u99_p_count
   ,0 a0_p_count
   ,0 a1_p_count  
   ,0 a2_p_count
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from PARWU96_MNLSLCT_SUB_ASSY_STAT u96
   join PARWU57_CCTSS_DSGN_SUB_ASSY u57 on u96.ARWU57_CCTSS_DSGN_SUB_ASSY_K=u57.ARWU57_CCTSS_DSGN_SUB_ASSY_K
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = U96.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  u57.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   , 0 AS u96_p_count
   , count(*) u97_p_count
   ,0 as u98_p_count 
   ,0 as u99_p_count
   ,0 a0_p_count
   ,0 a1_p_count 
   ,0 a2_p_count 
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWU97_MNLSLCT_SUBASSYMKRP_STAT] u97
   join PARWU57_CCTSS_DSGN_SUB_ASSY u57 on u97.ARWU57_CCTSS_DSGN_SUB_ASSY_K=u57.ARWU57_CCTSS_DSGN_SUB_ASSY_K
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = U97.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  u57.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   , 0 AS u96_p_count
   ,0 as u97_p_count
   ,count(*) u98_p_count
   ,0 as u99_p_count
   ,0 a0_p_count
   ,0 a1_p_count  
   ,0 a2_p_count
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWU98_MNLSLCT_FNL_ASSY_STAT] u98
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = U98.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  u98.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   , 0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,count(*) u99_p_count
   ,0 a0_p_count
   ,0 a1_p_count 
   ,0 a2_p_count
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWU99_MNLSLCT_FNLASSYMKRP_STAT] u99
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = U99.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  u99.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   , 0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,0 u99_p_count 
   ,count(*) a0_p_count
   ,0 a1_p_count 
   ,0 a2_p_count
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWUA0_DA_MNLSLCT_BOM_PART_STAT] A0
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A0.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  A0.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   , 0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,0 u99_p_count 
   ,0 a0_p_count
   ,count(*) a1_p_count 
   ,0 a2_p_count
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWUA1_DA_MNLSLCT_SUB_ASSY_STAT] A1
   join PARWU57_CCTSS_DSGN_SUB_ASSY u57 on A1.ARWU57_CCTSS_DSGN_SUB_ASSY_K=u57.ARWU57_CCTSS_DSGN_SUB_ASSY_K
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A1.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  U57.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   ,0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,0 u99_p_count 
   ,0 a0_p_count
   ,0 a1_p_count
   ,count(*) a2_p_count 
   ,0 a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWUA2_DA_MNLSLCT_FNL_ASSY_STAT] A2
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A2.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  A2.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   ,0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,0 u99_p_count 
   ,0 a0_p_count
   ,0 a1_p_count
   ,0 a2_p_count
   ,count(*) a3_p_count
   ,0 a4_p_count
   ,0 a5_p_count 
   from [dbo].[PARWUA3_II_MNLSLCT_BOM_PART_STAT] A3
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A3.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  A3.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   ,0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,0 u99_p_count 
   ,0 a0_p_count
   ,0 a1_p_count
   ,0 a2_p_count
   ,0 a3_p_count
   ,count(*) a4_p_count 
   ,0 a5_p_count 
   from [dbo].[PARWUA4_II_MNLSLCT_SUB_ASSY_STAT] A4
   join PARWU57_CCTSS_DSGN_SUB_ASSY u57 on A4.ARWU57_CCTSS_DSGN_SUB_ASSY_K=u57.ARWU57_CCTSS_DSGN_SUB_ASSY_K
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A4.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  u57.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K
   union
   select U06.ARWU01_CCTSS_K
   ,0 AS u95_p_count
   ,0 AS u96_p_count
   ,0 as u97_p_count
   ,0 as u98_p_count
   ,0 u99_p_count 
   ,0 a0_p_count
   ,0 a1_p_count
   ,0 a2_p_count
   ,0 a3_p_count
   ,0 a4_p_count 
   ,count(*) a5_p_count 
   from [dbo].[PARWUA5_II_MNLSLCT_FNL_ASSY_STAT] A5
   join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A5.ARWA48_MNLSLCT_STAT_K
   join PARWU06_CCTSS_DSGN U06 ON  a5.ARWU06_CCTSS_DSGN_K=U06.ARWU06_CCTSS_DSGN_K
   where A48.ARWA48_MNLSLCT_STAT_C='P'
   group by U06.ARWU01_CCTSS_K

   ) X
   JOIN PARWU01_CCTSS_FLAT u01_flat ON u01_flat.ARWU01_CCTSS_K=X.ARWU01_CCTSS_K
   group by X.ARWU01_CCTSS_K

)

, VA_PENDING_COUNT (ARWU01_CCTSS_K ,VA_PNDNG_APPRVL, VAII_PNDNG_APPRVL) as (

select X.[ARWU01_CCTSS_K] 
,SUM(COALESCE(a6_p_count,0)+ COALESCE(a7_p_count,0) + COALESCE(a8_p_count,0)) as VA_PNDNG_APPRVL
,SUM(COALESCE(e3_p_count,0) + +COALESCE(e4_p_count,0) + +COALESCE(e5_p_count,0)) as VAII_PNDNG_APPRVL
from
(
	select 
	u04.[ARWU01_CCTSS_K]
	,count(*) as a6_p_count
	,0 as a7_p_count
	,0 as a8_p_count 
	,0 as e3_p_count
	,0 as e4_p_count
	,0 as e5_p_count
	from [dbo].[PARWUA6_VA_MNLSLCT_BOM_PART_STAT] A6
    join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A6.ARWA48_MNLSLCT_STAT_K
    join [dbo].[PARWU04_CCTSS_VRNT] u04 on u04.[ARWU04_CCTSS_VRNT_K]=A6.[ARWU04_CCTSS_VRNT_K]
    where A48.ARWA48_MNLSLCT_STAT_C='P'
    group by u04.[ARWU01_CCTSS_K]

	union
	select 
	u04.[ARWU01_CCTSS_K]
	,0 as a6_p_count
	,count(*) as a7_p_count
	,0 as a8_p_count 
	,0 as e3_p_count
	,0 as e4_p_count
	,0 as e5_p_count
	from [dbo].[PARWUA7_VA_MNLSLCT_SUB_ASSY_STAT] A7
    join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A7.ARWA48_MNLSLCT_STAT_K
    join [dbo].[PARWU04_CCTSS_VRNT] u04 on u04.[ARWU04_CCTSS_VRNT_K]=A7.[ARWU04_CCTSS_VRNT_K]
    where A48.ARWA48_MNLSLCT_STAT_C='P'
    group by u04.[ARWU01_CCTSS_K]

	union
	select 
	u04.[ARWU01_CCTSS_K]
	,0 as a6_p_count
	,0 as a7_p_count
	,count(*) as a8_p_count 
	,0 as e3_p_count
	,0 as e4_p_count
	,0 as e5_p_count
	from [dbo].[PARWUA8_VA_MNLSLCT_FNL_ASSY_STAT] A8
    join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K = A8.ARWA48_MNLSLCT_STAT_K
    join [dbo].[PARWU04_CCTSS_VRNT] u04 on u04.[ARWU04_CCTSS_VRNT_K]=A8.[ARWU04_CCTSS_VRNT_K]
    where A48.ARWA48_MNLSLCT_STAT_C='P'
    group by u04.[ARWU01_CCTSS_K]

	union
	select 
	u04.[ARWU01_CCTSS_K]
	,0 as a6_p_count
	,0 as a7_p_count
	,0 as a8_p_count
	,count(*) as e3_p_count
	,0 as e4_p_count
	,0 as e5_p_count
	from [dbo].[PARWUE3_VII_MNLSLCT_BOM_PART_STAT] E3
    join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K     = E3.ARWA48_MNLSLCT_STAT_K
    join [dbo].[PARWU04_CCTSS_VRNT] u04 on u04.[ARWU04_CCTSS_VRNT_K]=E3.[ARWU04_CCTSS_VRNT_K]
    where A48.ARWA48_MNLSLCT_STAT_C='P'
    group by u04.[ARWU01_CCTSS_K]

	union
	select 
	u04.[ARWU01_CCTSS_K]
	,0 as a6_p_count
	,0 as a7_p_count
	,0 as a8_p_count
	,0 as e3_p_count
	,count(*) as e4_p_count
	,0 as e5_p_count
	from [dbo].[PARWUE4_VII_MNLSLCT_SUB_ASSY_STAT] E4
    join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K     = E4.ARWA48_MNLSLCT_STAT_K
    join [dbo].[PARWU04_CCTSS_VRNT] u04 on u04.[ARWU04_CCTSS_VRNT_K]=E4.[ARWU04_CCTSS_VRNT_K]
    where A48.ARWA48_MNLSLCT_STAT_C='P'
    group by u04.[ARWU01_CCTSS_K]

	union
	select 
	u04.[ARWU01_CCTSS_K]
	,0 as a6_p_count
	,0 as a7_p_count
	,0 as a8_p_count
	,0 as e3_p_count
	,0 as e4_p_count
	,count(*) as e5_p_count
	from [dbo].[PARWUE5_VII_MNLSLCT_FNL_ASSY_STAT] E5
    join PARWA48_MNLSLCT_STAT A48 on A48.ARWA48_MNLSLCT_STAT_K     = E5.ARWA48_MNLSLCT_STAT_K
    join [dbo].[PARWU04_CCTSS_VRNT] u04 on u04.[ARWU04_CCTSS_VRNT_K]=E5.[ARWU04_CCTSS_VRNT_K]
    where A48.ARWA48_MNLSLCT_STAT_C='P'
    group by u04.[ARWU01_CCTSS_K]

   ) X
   JOIN PARWU01_CCTSS_FLAT u01_flat ON u01_flat.ARWU01_CCTSS_K=X.ARWU01_CCTSS_K
   group by X.ARWU01_CCTSS_K

)

SELECT 
U01.ARWU01_CCTSS_K, ARWU31_CTSP_N, ARWA06_RGN_C, ARWA02_ENRG_CMMDTY_X, ARWA15_PCHSNG_CMMDTY_C, ARWA15_PCHSNG_CMMDTY_X, 
ARWA03_ENRG_SUB_CMMDTY_X, ARWA10_CCTSS_METHD_ABBR_N, ARWU34_CTSP_RGN_K, ARWU31_CTSP_K, ARWA02_ENRG_CMMDTY_K, ARWA11_CCTSS_STAT_N, 
ARWA46_CCTSS_IMPT_VER_N, ARWA45_PBOM_STAT_N, ARWA10_COST_EST_PERFD_F,
LTRIM(CONCAT(
	U01.BNCHMK_VRNT_PGMS, 
	' ', 
	COALESCE(NULLIF(ARWU01_BNCHMK_VRNT_N, ''), '[Blank/Empty Variant]')
 )
) AS BM_PGMS_VRNT_NM,
IIF(U07.ARWU01_CCTSS_K IS NULL, 'Started', 'Completed') AS BOB_INIT_STAT,
IIF(U04.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS VRNT_STAT,
IIF(U06.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS DSGN_STAT,
IIF(U07.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS SUPP_STAT,
IIF(UD1.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS RISK_STAT,
IIF(U85.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS TRDOFF_STAT,
IIF(U63.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS FORD_PART_STAT,
IIF(UB5.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS TYGRA_MAP_STAT,
IIF(UA9.ARWU01_CCTSS_K IS NULL, 'Yet to Start', 'Started') AS COST_ALLOC_STAT
,UB6.ARWUB6_CCTSS_TYGRA_FILE_K as UB6_SCOPE_TYGRA_FILE_K
,ARWA60_CNWY_LVL1_C
,ARWA60_CNWY_LVL1_X
,CNWY_LVL1_DSPLY_N
,CCTSS_DVNT_APRVR.CDSIDS AS DVTN_APPRVR
,BOB_PNDNG_APPRVL
,DA_PNDNG_APPRVL 
,II_PNDNG_APPRVL 
,VA_PNDNG_APPRVL
,U01.ARWA01_PMT_C AS PMT
,U01.ARWA03_ENRG_SUB_CMMDTY_K
,U01.ARWU31_CTSP_N + ' ' + U01.ARWA06_RGN_C as BC@J1_PGM_RGN
,U01.BNCHMK_VRNT_PGMS
,U01.ARWU01_MANL_VRNT_TYGRA_FLD_F
,VAII_PNDNG_APPRVL
FROM PARWU01_CCTSS_FLAT U01
LEFT JOIN (SELECT ARWU01_CCTSS_K FROM PARWU07_CCTSS_SUPL GROUP BY ARWU01_CCTSS_K) U07 ON U07.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (SELECT ARWU01_CCTSS_K FROM PARWU04_CCTSS_VRNT GROUP BY ARWU01_CCTSS_K) U04 ON U04.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (SELECT ARWU01_CCTSS_K FROM PARWU06_CCTSS_DSGN GROUP BY ARWU01_CCTSS_K) U06 ON U06.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (SELECT ARWU01_CCTSS_K FROM PARWU04_CCTSS_VRNT AS U04	JOIN PARWUD1_CCTSS_VRNT_RISK AS UD1
			ON U04.ARWU04_CCTSS_VRNT_K = UD1.ARWU04_CCTSS_VRNT_K GROUP BY ARWU01_CCTSS_K
		) UD1 ON UD1.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (SELECT ARWU01_CCTSS_K FROM PARWU85_CCTSS_TRDOFF GROUP BY ARWU01_CCTSS_K) U85 ON U85.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (
	SELECT ARWU01_CCTSS_K 
	FROM PARWU63_VRNT_BOM_PART_END_ITM U63 
	JOIN PARWU18_BOM_PART U18 ON U63.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K 
	GROUP BY ARWU01_CCTSS_K
) U63 ON U63.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (SELECT ARWU01_CCTSS_K FROM PARWUB5_CCTSS_TYGRA_FILE_REC GROUP BY ARWU01_CCTSS_K) UB5 ON UB5.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
LEFT JOIN (
	SELECT ARWU01_CCTSS_K 
	FROM PARWUA9_VRNT_END_ITM UA9 
	JOIN PARWU04_CCTSS_VRNT U04 ON U04.ARWU04_CCTSS_VRNT_K = UA9.ARWU04_CCTSS_VRNT_K
	GROUP BY ARWU01_CCTSS_K
) UA9 ON UA9.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
left join PARWUB6_CCTSS_TYGRA_FILE as UB6
	on U01.ARWU01_CCTSS_K = UB6.ARWU01_CCTSS_K
	and UB6.ARWA54_TYGRA_FILE_TYPE_K = (
		select ARWA54_TYGRA_FILE_TYPE_K
		from PARWA54_TYGRA_FILE_TYPE
		where ARWA54_TYGRA_FILE_TYPE_N = 'Scope'
	)

LEFT JOIN CCTSS_DVNT_APRVR
ON U01.ARWU01_CCTSS_K=CCTSS_DVNT_APRVR.ARWU01_CCTSS_K

LEFT JOIN CCTSS_PENDING_COUNT p_count
ON U01.ARWU01_CCTSS_K=p_count.ARWU01_CCTSS_K


LEFT JOIN VA_PENDING_COUNT GET_VA_DEVIATION_INFO
ON U01.ARWU01_CCTSS_K=GET_VA_DEVIATION_INFO.ARWU01_CCTSS_K




GO
