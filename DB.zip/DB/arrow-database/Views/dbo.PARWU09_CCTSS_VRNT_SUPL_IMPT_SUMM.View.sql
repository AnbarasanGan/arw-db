DROP VIEW IF EXISTS [dbo].[PARWU09_CCTSS_VRNT_SUPL_IMPT_SUMM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==============================================================================================================================================
--Date:  2021-08-11
--CDSID: btemkow
--Description:
--This view provides a file import summary at the Variant-Supplier level. To be used for the 'BoB Load Summary' and the 'Program-Region Load 
--Summary.' Replaces PARWU09_CCTSS_VRNT_SUPL_SUMM.
--==============================================================================================================================================
-- Change Log
-- CDSID      DATE         Change Description
-- btemkow    2021-09-22   Added ARWA52_VA_FILE_VER_N
--==============================================================================================================================================

CREATE VIEW [dbo].[PARWU09_CCTSS_VRNT_SUPL_IMPT_SUMM] AS
WITH
QUOTED_VRNT_ADJ_AGG (ARWU09_CCTSS_VRNT_SUPL_K, QUOTED_VRNT_ADJ_Q) as (
	select 
		 U09.ARWU09_CCTSS_VRNT_SUPL_K
		,count(*)
	from PARWU09_CCTSS_VRNT_SUPL as U09
	join PARWU81_SUPL_VRNT_ADJ as U81
		on U09.ARWU09_CCTSS_VRNT_SUPL_K = U81.ARWU09_CCTSS_VRNT_SUPL_K
	group by  U09.ARWU09_CCTSS_VRNT_SUPL_K
),
VRNT_ADJ_AGG (ARWU04_CCTSS_VRNT_K, VRNT_ADJ_Q) as (
	select
		 U04.ARWU04_CCTSS_VRNT_K
		,count(*)
	from PARWU04_CCTSS_VRNT as U04
	join PARWU65_CCTSS_VRNT_ADJ as U65
		on U04.ARWU04_CCTSS_VRNT_K = U65.ARWU04_CCTSS_VRNT_K
	group by  U04.ARWU04_CCTSS_VRNT_K
)
SELECT
	 ARWU34_CTSP_RGN_K
	,ARWU01_CCTSS_K
	,ARWA03_ENRG_SUB_CMMDTY_X
	,ARWU01_BNCHMK_VRNT_N
	,ARWA11_CCTSS_STAT_N
	,U09_FLAT.ARWU09_CCTSS_VRNT_SUPL_K
	,ARWU04_VRNT_N
	,ARWU13_CCTSS_SUPL_DSPLY_N
	,coalesce(QUOTED_VRNT_ADJ_AGG.QUOTED_VRNT_ADJ_Q,0) as QUOTED_VRNT_ADJUSTMENTS
	,coalesce(VRNT_ADJ_AGG.VRNT_ADJ_Q,0) as VRNT_ADJUSTMENTS
	,ARWA22_VRNT_SUPL_QTE_STAT_N
	,ARWU09_VA_LAST_IMPT_FILE_N
	,case when ARWU09_VA_LAST_IMPT_S = '9999-12-31' then '' else convert(varchar,ARWU09_VA_LAST_IMPT_S) end as VA_IMPORTED
	,ARWU09_VA_LAST_IMPT_USER_C
	,ARWA52_VA_FILE_VER_N
FROM PARWU09_CCTSS_VRNT_SUPL_FLAT AS U09_FLAT
LEFT JOIN QUOTED_VRNT_ADJ_AGG
	ON U09_FLAT.ARWU09_CCTSS_VRNT_SUPL_K = QUOTED_VRNT_ADJ_AGG.ARWU09_CCTSS_VRNT_SUPL_K
LEFT JOIN VRNT_ADJ_AGG
	ON U09_FLAT.ARWU04_CCTSS_VRNT_K = VRNT_ADJ_AGG.ARWU04_CCTSS_VRNT_K
WHERE U09_FLAT.ARWU04_BNCHMK_F = 0
GO


