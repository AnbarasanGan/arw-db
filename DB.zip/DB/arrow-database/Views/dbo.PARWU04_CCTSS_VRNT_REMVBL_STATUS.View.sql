SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



--====================================================================================================
--Date:  SEP/24/2020
--CDSID: btemkow
--Description:
--The view is used in the variant screen 
-- to delete the variant it will get all the variant removal status information for showing error message in UI.
--====================================================================================================
--Change Log
--2021-03-17 changed U63 reference to new U63: PARWU63_VRNT_BOM_PART_END_ITM
--2022-06-06 US3697583 added HAS_RISKS
--2022-07-15 US3809152 added check on VII tables
--====================================================================================================

CREATE OR ALTER VIEW [dbo].[PARWU04_CCTSS_VRNT_REMVBL_STATUS] AS
with
HAS_CCTSS_VRNT_ADJ (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWU65_CCTSS_VRNT_ADJ
group by ARWU04_CCTSS_VRNT_K
),
HAS_BOM_PART_END_ITM (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWU63_VRNT_BOM_PART_END_ITM
group by ARWU04_CCTSS_VRNT_K
),
HAS_VA_MNLSLCT (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWU82_VA_MNLSLCT_BOM_PART
where ARWU09_CCTSS_VRNT_SUPL_K is not null --don't include overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
union
select ARWU04_CCTSS_VRNT_K
from PARWU83_VA_MNLSLCT_SUB_ASSY
where ARWU09_CCTSS_VRNT_SUPL_K is not null --don't include overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
union
select ARWU04_CCTSS_VRNT_K
from PARWU84_VA_MNLSLCT_FNL_ASSY
where ARWU09_CCTSS_VRNT_SUPL_K is not null --don't include overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
),
HAS_VII_MNLSLCT (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWUE0_VII_MNLSLCT_BOM_PART
where ARWU09_CCTSS_VRNT_SUPL_K is not null --don't include overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
union
select ARWU04_CCTSS_VRNT_K
from PARWUE1_VII_MNLSLCT_SUB_ASSY
where ARWU09_CCTSS_VRNT_SUPL_K is not null --don't include overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
union
select ARWU04_CCTSS_VRNT_K
from PARWUE2_VII_MNLSLCT_FNL_ASSY
where ARWU09_CCTSS_VRNT_SUPL_K is not null --don't include overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
),
HAS_VA_MNLSLCT_AUTOPICK (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWU82_VA_MNLSLCT_BOM_PART
where ARWU09_CCTSS_VRNT_SUPL_K is null --overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
union
select ARWU04_CCTSS_VRNT_K
from PARWU83_VA_MNLSLCT_SUB_ASSY
where ARWU09_CCTSS_VRNT_SUPL_K is null --overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
union
select ARWU04_CCTSS_VRNT_K
from PARWU84_VA_MNLSLCT_FNL_ASSY
where ARWU09_CCTSS_VRNT_SUPL_K is null --overrides "rejected to autopick"
group by ARWU04_CCTSS_VRNT_K
),
HAS_RISK (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWUD1_CCTSS_VRNT_RISK
group by ARWU04_CCTSS_VRNT_K
),
HAS_CCTSS_VRNT_II (ARWU04_CCTSS_VRNT) as (
select ARWU04_CCTSS_VRNT_K
from PARWUD2_CCTSS_VRNT_IMPRV
group by ARWU04_CCTSS_VRNT_K
)
select U04.ARWU04_CCTSS_VRNT_K
,IIF(HAS_CCTSS_VRNT_ADJ.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_ADJS
,IIF(HAS_VA_MNLSLCT.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_MNL_OVRDS
,IIF(HAS_VA_MNLSLCT_AUTOPICK.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_MNL_OVRDS_RJCT_TO_AUTOPICK
,IIF(HAS_BOM_PART_END_ITM.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_FRD_PRT_ASSND
,IIF(HAS_RISK.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_RISKS
,IIF(HAS_CCTSS_VRNT_II.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_VII
,IIF(HAS_VII_MNLSLCT.ARWU04_CCTSS_VRNT is null, 'N', 'Y') as HAS_VII_MNL_OVRDS
from PARWU04_CCTSS_VRNT as U04
left join HAS_CCTSS_VRNT_ADJ on U04.ARWU04_CCTSS_VRNT_K = HAS_CCTSS_VRNT_ADJ.ARWU04_CCTSS_VRNT
left join HAS_BOM_PART_END_ITM on U04.ARWU04_CCTSS_VRNT_K = HAS_BOM_PART_END_ITM.ARWU04_CCTSS_VRNT
left join HAS_VA_MNLSLCT on U04.ARWU04_CCTSS_VRNT_K = HAS_VA_MNLSLCT.ARWU04_CCTSS_VRNT
left join HAS_VA_MNLSLCT_AUTOPICK on U04.ARWU04_CCTSS_VRNT_K = HAS_VA_MNLSLCT_AUTOPICK.ARWU04_CCTSS_VRNT
left join HAS_RISK on U04.ARWU04_CCTSS_VRNT_K = HAS_RISK.ARWU04_CCTSS_VRNT
left join HAS_CCTSS_VRNT_II on U04.ARWU04_CCTSS_VRNT_K=HAS_CCTSS_VRNT_II.ARWU04_CCTSS_VRNT
left join HAS_VII_MNLSLCT on U04.ARWU04_CCTSS_VRNT_K = HAS_VII_MNLSLCT.ARWU04_CCTSS_VRNT


GO

