DROP VIEW IF EXISTS [dbo].[PARWU01_CCTSS_IMPT_SUMM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==============================================================================================================================================
--Date:  2021-08-11
--CDSID: btemkow
--Description:
--This view provides a file import summary at the CCTSS level. To be used on the 'BoB Load Summary' screen. Replaces PARWU01_CCTSS_SUMM.
--==============================================================================================================================================
-- Change Log
-- CDSID      DATE         Change Description
-- btemkow    2021-09-17   Added ARWU01_CCTSS_K to the select list
-- btemkow    2021-09-20   Removed the EXPCT_VA_AGG cte and EXPCT_VA column. Expected VA can be calculated as VARIANTS x SUPPLIERS
-- btemkow    2022/04/06   US3501500 - split DC2.0 type into: With Benchmarking / Without Benchmarking
--==============================================================================================================================================

CREATE VIEW [dbo].[PARWU01_CCTSS_IMPT_SUMM] AS
with
DSGN_AGG (ARWU01_CCTSS_K, DSGN_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from PARWU06_CCTSS_DSGN
       group by ARWU01_CCTSS_K
),
SUPL_AGG (ARWU01_CCTSS_K, SUPL_Q) as (
       select
              ARWU01_CCTSS_K
              ,count(*)
       from PARWU07_CCTSS_SUPL
       group by ARWU01_CCTSS_K
),
VRNT_AGG (ARWU01_CCTSS_K, VRNT_Q) as (
 	   select
              ARWU01_CCTSS_K
              ,count(*)
       from PARWU04_CCTSS_VRNT_FLAT
       where ARWU04_BNCHMK_F = 0
			and ARWA10_CCTSS_METHD_N not in ('DC 2.0 Without Benchmarking','DC 2.0 With Benchmarking')
       group by ARWU01_CCTSS_K 
	   union
	   select
	           ARWU01_CCTSS_K
              ,count(*)
       from PARWU04_CCTSS_VRNT_FLAT
       where ARWU04_BNCHMK_F = 0
			and ARWU04_VARIANT_ADJ_ONLY_F = 1
			and ARWA10_CCTSS_METHD_N in ('DC 2.0 Without Benchmarking','DC 2.0 With Benchmarking')
       group by ARWU01_CCTSS_K
),
CCS_AGG (ARWU01_CCTSS_K, CCS_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from PARWU08_CCTSS_DSGN_SUPL_FLAT
	   where ARWA24_DSGN_SUPL_QTE_STAT_N = 'Imported'
       group by
              ARWU01_CCTSS_K
),
DAII_AGG (ARWU01_CCTSS_K, DAII_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from PARWU08_CCTSS_DSGN_SUPL_FLAT
	   where ARWA23_DSGNADJ_SUPL_QTE_STAT_N = 'Imported'
       group by
              ARWU01_CCTSS_K
),
VA_AGG (ARWU01_CCTSS_K, VA_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from PARWU09_CCTSS_VRNT_SUPL_FLAT
	   where ARWU04_BNCHMK_F = 0
	   and ARWA22_VRNT_SUPL_QTE_STAT_N = 'Imported'
       group by
              ARWU01_CCTSS_K
)
select 
	 ARWU34_CTSP_RGN_K
	,ARWU31_CTSP_N + ' ' + ARWA06_RGN_C as BC@J1_PGM_RGN
	,U01_FLAT.ARWU01_CCTSS_K
	,ARWA02_ENRG_CMMDTY_X
	,ARWA03_ENRG_SUB_CMMDTY_X
	,ARWU01_BNCHMK_VRNT_N
	,ARWA10_CCTSS_METHD_ABBR_N
	,ARWA11_CCTSS_STAT_N
	,coalesce(DSGN_AGG.DSGN_Q,0) as DESIGNS
	,coalesce(SUPL_AGG.SUPL_Q,0) as SUPPLIERS
	,coalesce(VRNT_AGG.VRNT_Q,0) as VARIANTS
	,case when ARWA45_PBOM_STAT_N = 'Imported' then 1 else 0 end as PBOM_LOADED
	,coalesce(CCS_AGG.CCS_Q,0) as CCS_LOADED
	,coalesce(DAII_AGG.DAII_Q,0) as DAII_LOADED
	,coalesce(VA_AGG.VA_Q,0) as VA_LOADED
from PARWU01_CCTSS_FLAT as U01_FLAT
left join DSGN_AGG
       on U01_FLAT.ARWU01_CCTSS_K = DSGN_AGG.ARWU01_CCTSS_K
left join SUPL_AGG
       on U01_FLAT.ARWU01_CCTSS_K = SUPL_AGG.ARWU01_CCTSS_K
left join VRNT_AGG
       on U01_FLAT.ARWU01_CCTSS_K = VRNT_AGG.ARWU01_CCTSS_K
left join CCS_AGG
       on U01_FLAT.ARWU01_CCTSS_K = CCS_AGG.ARWU01_CCTSS_K
left join DAII_AGG
       on U01_FLAT.ARWU01_CCTSS_K = DAII_AGG.ARWU01_CCTSS_K
left join VA_AGG
       on U01_FLAT.ARWU01_CCTSS_K = VA_AGG.ARWU01_CCTSS_K
GO
