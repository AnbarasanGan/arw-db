DROP VIEW [dbo].[PARWU01_CCTSS_SUMM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[PARWU01_CCTSS_SUMM] AS
with
DSGN_AGG (ARWU01_CCTSS_K, DSGN_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from PARWU06_CCTSS_DSGN
       group by ARWU01_CCTSS_K
),
SUPL_AGG (ARWU01_CCTSS_K, SUPL_Q) as (
       select
              ARWU01_CCTSS_K
              ,count(*)
       from PARWU07_CCTSS_SUPL
       group by ARWU01_CCTSS_K
),
VRNT_AGG (ARWU01_CCTSS_K, VRNT_Q) as (
       select
              ARWU01_CCTSS_K
              ,count(*)
       from PARWU04_CCTSS_VRNT
       where ARWU04_BNCHMK_F = 0
       group by ARWU01_CCTSS_K
),
CCS_AGG (ARWU01_CCTSS_K, CCS_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from (
       select 
               U06.ARWU01_CCTSS_K
              ,U08.ARWU08_CCTSS_DSGN_SUPL_K
       from PARWU06_CCTSS_DSGN as U06
       join PARWU08_CCTSS_DSGN_SUPL as U08
              on U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
       join PARWU55_SUPL_DSGN_PART as U55
              on U08.ARWU08_CCTSS_DSGN_SUPL_K = U55.ARWU08_CCTSS_DSGN_SUPL_K 
       group by 
               U06.ARWU01_CCTSS_K
              ,U08.ARWU08_CCTSS_DSGN_SUPL_K
       ) as DSGN_SUPL_CCS
       group by
              ARWU01_CCTSS_K
),
DAII_AGG (ARWU01_CCTSS_K, DAII_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from (
       select 
               U06.ARWU01_CCTSS_K
              ,U08.ARWU08_CCTSS_DSGN_SUPL_K
       from PARWU06_CCTSS_DSGN as U06
       join PARWU08_CCTSS_DSGN_SUPL as U08
              on U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
       join PARWU73_SUPL_DSGN_ADJ as U73
              on U08.ARWU08_CCTSS_DSGN_SUPL_K = U73.ARWU08_CCTSS_DSGN_SUPL_K 
       group by 
               U06.ARWU01_CCTSS_K
              ,U08.ARWU08_CCTSS_DSGN_SUPL_K
       union
	   select
               U06.ARWU01_CCTSS_K
              ,U08.ARWU08_CCTSS_DSGN_SUPL_K
       from PARWU06_CCTSS_DSGN as U06
       join PARWU08_CCTSS_DSGN_SUPL as U08
              on U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
       join PARWU74_SUPL_DSGN_IMPRV as U74
              on U08.ARWU08_CCTSS_DSGN_SUPL_K = U74.ARWU08_CCTSS_DSGN_SUPL_K 
       group by 
               U06.ARWU01_CCTSS_K
              ,U08.ARWU08_CCTSS_DSGN_SUPL_K              
       ) as DSGN_SUPL_DAII
       group by
              ARWU01_CCTSS_K
),
VA_AGG (ARWU01_CCTSS_K, VA_Q) as (
       select 
               ARWU01_CCTSS_K
              ,count(*)
       from (
       select 
               U04.ARWU01_CCTSS_K
              ,U09.ARWU09_CCTSS_VRNT_SUPL_K
       from PARWU04_CCTSS_VRNT as U04
       join PARWU09_CCTSS_VRNT_SUPL as U09
              on U04.ARWU04_CCTSS_VRNT_K = U09.ARWU04_CCTSS_VRNT_K
       join PARWU81_SUPL_VRNT_ADJ as U81
              on U09.ARWU09_CCTSS_VRNT_SUPL_K = U81.ARWU09_CCTSS_VRNT_SUPL_K 
       group by 
               U04.ARWU01_CCTSS_K
              ,U09.ARWU09_CCTSS_VRNT_SUPL_K
       ) as DSGN_SUPL_VA
       group by
              ARWU01_CCTSS_K
)
select 
		ARWU31_CTSP_N + ' ' + ARWA06_RGN_C as BC@J1_PGM_RGN
       ,coalesce(DSGN_AGG.DSGN_Q,0) as DESIGNS
       ,coalesce(SUPL_AGG.SUPL_Q,0) as SUPPLIERS
       ,coalesce(VRNT_AGG.VRNT_Q,0) as VARIANTS
       ,case when ARWU01_PBOM_LAST_IMPT_S = '9999-12-31' then '' else convert(varchar,ARWU01_PBOM_LAST_IMPT_S) end as PBOM_LOADED
       ,coalesce(CCS_AGG.CCS_Q,0) as CCS_LOADED
       ,coalesce(DAII_AGG.DAII_Q,0) as DAII_LOADED
       ,coalesce(VA_AGG.VA_Q,0) as VA_LOADED
	   ,U01_FLAT.*
from PARWU01_CCTSS_FLAT as U01_FLAT
left join DSGN_AGG
       on U01_FLAT.ARWU01_CCTSS_K = DSGN_AGG.ARWU01_CCTSS_K
left join SUPL_AGG
       on U01_FLAT.ARWU01_CCTSS_K = SUPL_AGG.ARWU01_CCTSS_K
left join VRNT_AGG
       on U01_FLAT.ARWU01_CCTSS_K = VRNT_AGG.ARWU01_CCTSS_K
left join CCS_AGG
       on U01_FLAT.ARWU01_CCTSS_K = CCS_AGG.ARWU01_CCTSS_K
left join DAII_AGG
       on U01_FLAT.ARWU01_CCTSS_K = DAII_AGG.ARWU01_CCTSS_K
left join VA_AGG
       on U01_FLAT.ARWU01_CCTSS_K = VA_AGG.ARWU01_CCTSS_K
GO
