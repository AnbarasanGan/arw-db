DROP VIEW [dbo].[PARWU18_BOM_PART_MTRX]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[PARWU18_BOM_PART_MTRX] as
with
design_part_matrix (ARWU18_BOM_PART_K, ARWU14_CCTSS_DSGN_DSPLY_N, DSGN_RANK) as (
	select
		 ARWU18_BOM_PART_K
		,ARWU14_CCTSS_DSGN_DSPLY_N
		,DSGN_RANK
	from (select
			 ARWU06_CCTSS_DSGN_K
			,ARWU14_CCTSS_DSGN_DSPLY_N
			,rank() over (partition by ARWU01_CCTSS_K order by ARWU14_CCTSS_DSGN_DSPLY_N asc) as DSGN_RANK
		from PARWU06_CCTSS_DSGN_FLAT
		) as dsgn_rank
	join PARWU19_DSGN_PART as U19
		on dsgn_rank.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
),
DA_part_matrix (ARWU18_BOM_PART_K, ARWU14_CCTSS_DSGN_DSPLY_N, DSGN_RANK, ARWA40_DSGN_ADJ_PART_CHG_TYP_C) as (
	select 
		 U18.ARWU18_BOM_PART_K
		,ARWU14_CCTSS_DSGN_DSPLY_N
		,DSGN_RANK
		,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
	from PARWU18_BOM_PART as U18
	join (
		select
			 ARWU18_BOM_PART_K
			,ARWU06_CCTSS_DSGN_K
			,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
		from PARWU37_CCTSS_DSGN_ADJ as U37
		join PARWA40_DSGN_ADJ_PART_CHG_TYP as A40
			on U37.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
		group by
			 ARWU18_BOM_PART_K
			,ARWU06_CCTSS_DSGN_K
			,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
	) as DA_part
	on U18.ARWU18_BOM_PART_K = DA_part.ARWU18_BOM_PART_K
	join (
		select
			 ARWU06_CCTSS_DSGN_K
			,ARWU14_CCTSS_DSGN_DSPLY_N
			,rank() over (partition by ARWU01_CCTSS_K order by ARWU14_CCTSS_DSGN_DSPLY_N asc) as DSGN_RANK
			from PARWU06_CCTSS_DSGN_FLAT
			) as dsgn_rank
	on DA_part.ARWU06_CCTSS_DSGN_K = dsgn_rank.ARWU06_CCTSS_DSGN_K
),
II_part_matrix (ARWU18_BOM_PART_K, ARWU14_CCTSS_DSGN_DSPLY_N, DSGN_RANK, ARWU46_CCTSS_DSGN_IMPRV_ORIG_X) as (
	select 
		 U18.ARWU18_BOM_PART_K
		,ARWU14_CCTSS_DSGN_DSPLY_N
		,DSGN_RANK
		,ARWU46_CCTSS_DSGN_IMPRV_ORIG_X
	from PARWU18_BOM_PART as U18
	join (
		select
			 ARWU18_BOM_PART_K
			,ARWU06_CCTSS_DSGN_K
			,ARWU46_CCTSS_DSGN_IMPRV_ORIG_X
		from PARWU46_CCTSS_DSGN_IMPRV
		group by
			 ARWU18_BOM_PART_K
			,ARWU06_CCTSS_DSGN_K
			,ARWU46_CCTSS_DSGN_IMPRV_ORIG_X		
	) as II_part
	on U18.ARWU18_BOM_PART_K = II_part.ARWU18_BOM_PART_K
	join (
		select
			 ARWU06_CCTSS_DSGN_K
			,ARWU14_CCTSS_DSGN_DSPLY_N
			,rank() over (partition by ARWU01_CCTSS_K order by ARWU14_CCTSS_DSGN_DSPLY_N asc) as DSGN_RANK
			from PARWU06_CCTSS_DSGN_FLAT
			) as dsgn_rank
	on II_part.ARWU06_CCTSS_DSGN_K = dsgn_rank.ARWU06_CCTSS_DSGN_K
),
VA_part_matrix (ARWU18_BOM_PART_K, ARWU04_VRNT_N, VRNT_RANK, ARWA40_DSGN_ADJ_PART_CHG_TYP_C) as (
	select 
		 U18.ARWU18_BOM_PART_K
		,ARWU04_VRNT_N
		,VRNT_RANK
		,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
	from PARWU18_BOM_PART as U18
	join (
		select
			 ARWU18_BOM_PART_K
			,ARWU04_CCTSS_VRNT_K
			,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
		from PARWU65_CCTSS_VRNT_ADJ as U65
		join PARWA40_DSGN_ADJ_PART_CHG_TYP as A40
			on U65.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
		group by
			 ARWU18_BOM_PART_K
			,ARWU04_CCTSS_VRNT_K
			,ARWA40_DSGN_ADJ_PART_CHG_TYP_C		
	) as VA_part
	on U18.ARWU18_BOM_PART_K = VA_part.ARWU18_BOM_PART_K
	join (
		select
			 ARWU04_CCTSS_VRNT_K
			,ARWU04_VRNT_N
			,rank() over (partition by ARWU01_CCTSS_K order by ARWU04_VRNT_N asc) as VRNT_RANK
			from PARWU04_CCTSS_VRNT_FLAT
			where ARWU04_BNCHMK_F = 0
			) as vrnt_rank
	on VA_part.ARWU04_CCTSS_VRNT_K = vrnt_rank.ARWU04_CCTSS_VRNT_K
),
orphaned_part (ARWU18_BOM_PART_K) as (
	select U18.ARWU18_BOM_PART_K
	from PARWU18_BOM_PART as U18
	join PARWU01_CCTSS_FLAT as U01_FLAT
		   on U18.ARWU01_CCTSS_K = U01_FLAT.ARWU01_CCTSS_K
	left join PARWU19_DSGN_PART as U19
		   on U18.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K
	left join PARWU37_CCTSS_DSGN_ADJ as U37
		   on U18.ARWU18_BOM_PART_K = U37.ARWU18_BOM_PART_K
	left join PARWU46_CCTSS_DSGN_IMPRV as U46
		   on U18.ARWU18_BOM_PART_K = U46.ARWU18_BOM_PART_K
	left join PARWU65_CCTSS_VRNT_ADJ as U65
		   on U18.ARWU18_BOM_PART_K = U65.ARWU18_BOM_PART_K
	where 
		   U19.ARWU18_BOM_PART_K is null
		   and U37.ARWU18_BOM_PART_K is null
		   and U46.ARWU18_BOM_PART_K is null
		   and U65.ARWU18_BOM_PART_K is null
)
select
	 U01_FLAT.ARWU01_CCTSS_K
 	,ARWU31_CTSP_N
	,ARWA06_RGN_C
	,ARWA03_ENRG_SUB_CMMDTY_X
	,ARWU01_BNCHMK_VRNT_N
	,ARWU17_BOM_SUB_ASSY_IX_C
	,ARWU17_BOM_SUB_ASSY_N
	,U18.ARWU18_BOM_PART_K
	,U18.ARWU18_BOM_PART_IX_N
	,coalesce(design_1.ARWU14_CCTSS_DSGN_DSPLY_N,'') as DSGN_1
	,coalesce(DA_1.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as DA_1
	,coalesce(II_F_1.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_F_1
	,coalesce(II_S_1.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_S_1
	,coalesce(design_2.ARWU14_CCTSS_DSGN_DSPLY_N,'') as DSGN_2
	,coalesce(DA_2.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as DA_2
	,coalesce(II_F_2.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_F_2
	,coalesce(II_S_2.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_S_2
	,coalesce(design_3.ARWU14_CCTSS_DSGN_DSPLY_N,'') as DSGN_3
	,coalesce(DA_3.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as DA_3
	,coalesce(II_F_3.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_F_3
	,coalesce(II_S_3.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_S_3
	,coalesce(design_4.ARWU14_CCTSS_DSGN_DSPLY_N,'') as DSGN_4
	,coalesce(DA_4.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as DA_4
	,coalesce(II_F_4.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_F_4
	,coalesce(II_S_4.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_S_4
	,coalesce(design_5.ARWU14_CCTSS_DSGN_DSPLY_N,'') as DSGN_5
	,coalesce(DA_5.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as DA_5
	,coalesce(II_F_5.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_F_5
	,coalesce(II_S_5.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_S_5
	,coalesce(design_6.ARWU14_CCTSS_DSGN_DSPLY_N,'') as DSGN_6
	,coalesce(DA_6.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as DA_6 
	,coalesce(II_F_6.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_F_6
	,coalesce(II_S_6.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X,'') as II_S_6
	,coalesce(VA_1.ARWU04_VRNT_N,'') as VA_1
	,coalesce(VA_1.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_1
	,coalesce(VA_2.ARWU04_VRNT_N,'') as VA_2
	,coalesce(VA_2.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_2
	,coalesce(VA_3.ARWU04_VRNT_N,'') as VA_3
	,coalesce(VA_3.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_3 
	,coalesce(VA_4.ARWU04_VRNT_N,'') as VA_4
	,coalesce(VA_4.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_4 
	,coalesce(VA_5.ARWU04_VRNT_N,'') as VA_5
	,coalesce(VA_5.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_5 
	,coalesce(VA_6.ARWU04_VRNT_N,'') as VA_6
	,coalesce(VA_6.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_6 
	,coalesce(VA_7.ARWU04_VRNT_N,'') as VA_7
	,coalesce(VA_7.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_7 
	,coalesce(VA_8.ARWU04_VRNT_N,'') as VA_8
	,coalesce(VA_8.ARWA40_DSGN_ADJ_PART_CHG_TYP_C,'') as VA_T_8 
	,case when orphaned_part.ARWU18_BOM_PART_K is not null then 'YES' else '' end as ORPHANED
	,alpha_start
	,first_int
	,second_int
from PARWU01_CCTSS_FLAT as U01_FLAT
join PARWU17_BOM_SUB_ASSY as U17
	on U01_FLAT.ARWU01_CCTSS_K = U17.ARWU01_CCTSS_K
join PARWU18_BOM_PART as U18
	on U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
join PARWU18_BOM_PART_SORT as U18_SORT
	on U18.ARWU18_BOM_PART_K = U18_SORT.ARWU18_BOM_PART_K
left join design_part_matrix as design_1
	on U18.ARWU18_BOM_PART_K = design_1.ARWU18_BOM_PART_K
	and design_1.DSGN_RANK = 1
left join design_part_matrix as design_2
	on U18.ARWU18_BOM_PART_K = design_2.ARWU18_BOM_PART_K
	and design_2.DSGN_RANK = 2
left join design_part_matrix as design_3
	on U18.ARWU18_BOM_PART_K = design_3.ARWU18_BOM_PART_K
	and design_3.DSGN_RANK = 3
left join design_part_matrix as design_4
	on U18.ARWU18_BOM_PART_K = design_4.ARWU18_BOM_PART_K
	and design_4.DSGN_RANK = 4
left join design_part_matrix as design_5
	on U18.ARWU18_BOM_PART_K = design_5.ARWU18_BOM_PART_K
	and design_5.DSGN_RANK = 5
left join design_part_matrix as design_6
	on U18.ARWU18_BOM_PART_K = design_6.ARWU18_BOM_PART_K
	and design_6.DSGN_RANK = 6
left join DA_part_matrix as DA_1
	on U18.ARWU18_BOM_PART_K = DA_1.ARWU18_BOM_PART_K
	and DA_1.DSGN_RANK = 1
left join DA_part_matrix as DA_2
	on U18.ARWU18_BOM_PART_K = DA_2.ARWU18_BOM_PART_K
	and DA_2.DSGN_RANK = 2
left join DA_part_matrix as DA_3
	on U18.ARWU18_BOM_PART_K = DA_3.ARWU18_BOM_PART_K
	and DA_3.DSGN_RANK = 3
left join DA_part_matrix as DA_4
	on U18.ARWU18_BOM_PART_K = DA_4.ARWU18_BOM_PART_K
	and DA_4.DSGN_RANK = 4
left join DA_part_matrix as DA_5
	on U18.ARWU18_BOM_PART_K = DA_5.ARWU18_BOM_PART_K
	and DA_5.DSGN_RANK = 5
left join DA_part_matrix as DA_6
	on U18.ARWU18_BOM_PART_K = DA_6.ARWU18_BOM_PART_K
	and DA_6.DSGN_RANK = 6 
left join II_part_matrix as II_F_1
	on U18.ARWU18_BOM_PART_K = II_F_1.ARWU18_BOM_PART_K
	and II_F_1.DSGN_RANK = 1
	and II_F_1.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
left join II_part_matrix as II_S_1
	on U18.ARWU18_BOM_PART_K = II_S_1.ARWU18_BOM_PART_K
	and II_S_1.DSGN_RANK = 1
	and II_S_1.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Supplier'
left join II_part_matrix as II_F_2
	on U18.ARWU18_BOM_PART_K = II_F_2.ARWU18_BOM_PART_K
	and II_F_2.DSGN_RANK = 2
	and II_F_2.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
left join II_part_matrix as II_S_2
	on U18.ARWU18_BOM_PART_K = II_S_2.ARWU18_BOM_PART_K
	and II_S_2.DSGN_RANK = 2
	and II_S_2.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Supplier'
left join II_part_matrix as II_F_3
	on U18.ARWU18_BOM_PART_K = II_F_3.ARWU18_BOM_PART_K
	and II_F_3.DSGN_RANK = 3
	and II_F_3.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
left join II_part_matrix as II_S_3
	on U18.ARWU18_BOM_PART_K = II_S_3.ARWU18_BOM_PART_K
	and II_S_3.DSGN_RANK = 3
	and II_S_3.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Supplier'
left join II_part_matrix as II_F_4
	on U18.ARWU18_BOM_PART_K = II_F_4.ARWU18_BOM_PART_K
	and II_F_4.DSGN_RANK = 4
	and II_F_4.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
left join II_part_matrix as II_S_4
	on U18.ARWU18_BOM_PART_K = II_S_4.ARWU18_BOM_PART_K
	and II_S_4.DSGN_RANK = 4
	and II_S_4.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Supplier'
left join II_part_matrix as II_F_5
	on U18.ARWU18_BOM_PART_K = II_F_5.ARWU18_BOM_PART_K
	and II_F_5.DSGN_RANK = 5
	and II_F_5.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
left join II_part_matrix as II_S_5
	on U18.ARWU18_BOM_PART_K = II_S_5.ARWU18_BOM_PART_K
	and II_S_5.DSGN_RANK = 5
	and II_S_5.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Supplier'
left join II_part_matrix as II_F_6
	on U18.ARWU18_BOM_PART_K = II_F_6.ARWU18_BOM_PART_K
	and II_F_6.DSGN_RANK = 6
	and II_F_6.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
left join II_part_matrix as II_S_6
	on U18.ARWU18_BOM_PART_K = II_S_6.ARWU18_BOM_PART_K
	and II_S_6.DSGN_RANK = 6
	and II_S_6.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Supplier'
left join VA_part_matrix as VA_1
	on U18.ARWU18_BOM_PART_K = VA_1.ARWU18_BOM_PART_K
	and VA_1.VRNT_RANK = 1
left join VA_part_matrix as VA_2
	on U18.ARWU18_BOM_PART_K = VA_2.ARWU18_BOM_PART_K
	and VA_2.VRNT_RANK = 2
left join VA_part_matrix as VA_3
	on U18.ARWU18_BOM_PART_K = VA_3.ARWU18_BOM_PART_K
	and VA_3.VRNT_RANK = 3
left join VA_part_matrix as VA_4
	on U18.ARWU18_BOM_PART_K = VA_4.ARWU18_BOM_PART_K
	and VA_4.VRNT_RANK = 4
left join VA_part_matrix as VA_5
	on U18.ARWU18_BOM_PART_K = VA_5.ARWU18_BOM_PART_K
	and VA_5.VRNT_RANK = 5
left join VA_part_matrix as VA_6
	on U18.ARWU18_BOM_PART_K = VA_6.ARWU18_BOM_PART_K
	and VA_6.VRNT_RANK = 6
left join VA_part_matrix as VA_7
	on U18.ARWU18_BOM_PART_K = VA_7.ARWU18_BOM_PART_K
	and VA_5.VRNT_RANK = 7
left join VA_part_matrix as VA_8
	on U18.ARWU18_BOM_PART_K = VA_8.ARWU18_BOM_PART_K
	and VA_6.VRNT_RANK = 8
left join orphaned_part	
	on U18.ARWU18_BOM_PART_K = orphaned_part.ARWU18_BOM_PART_K
GO
