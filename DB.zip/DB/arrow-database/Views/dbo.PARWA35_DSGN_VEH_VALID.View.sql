DROP VIEW IF EXISTS [dbo].[PARWA35_DSGN_VEH_VALID]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==============================================================================================================================================
--Date:  2021-09-03
--CDSID: btemkow
--Description:
--This view provides the list of Design Vehicles that users are allowed to select on the BoB Authoring -> Designs screen
--It filters out Design Vehicles with blank Model Names (e.g. 'Performance Level 1'), which are no longer allowed
--==============================================================================================================================================
-- Change Log
-- CDSID      DATE         Change Description
--
--==============================================================================================================================================

CREATE VIEW [dbo].[PARWA35_DSGN_VEH_VALID] AS
select 
	 A35.ARWA35_DSGN_VEH_K
	,A35.ARWA35_DSGN_VEH_MDL_YR_C
	,A35.ARWA14_VEH_MAKE_N
	,A35.ARWA34_VEH_MDL_N
	,A35.ARWA35_DSGN_VEH_MDL_VRNT_X
from PARWA35_DSGN_VEH_FLAT as A35
where ARWA34_VEH_MDL_N <> ''
GO


