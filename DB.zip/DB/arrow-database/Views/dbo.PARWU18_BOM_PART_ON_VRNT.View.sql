DROP VIEW IF EXISTS [dbo].[PARWU18_BOM_PART_ON_VRNT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==============================================================================================================================================
--Date:  2021-07-27
--CDSID: btemkow
--Description:
--This view tells if a BOM Part exists on a Variant {Yes, No, Invalid}
--Invalid occurs on Benchmark when BOM Part appearance across Designs is inconsistent
--Invalid occurs on non-Benchmark when Benchmark is Invalid or when Variant Adjustment Change Type is inconsistent with Benchmark
--==============================================================================================================================================
-- Change Log
-- CDSID      DATE         Change Description
-- btemkow    2020-09-08   BOM_PART_ON_VRNT = 'Yes' when BOM Part was only added for a Ford, Included, High-Confidence Improvement Idea
--==============================================================================================================================================

CREATE VIEW [dbo].[PARWU18_BOM_PART_ON_VRNT] AS
select 
 ARWU01_CCTSS_K
,ARWU04_CCTSS_VRNT_K
,ARWU04_BNCHMK_F
,ARWU18_BOM_PART_K
,case
	when sum(HAS_INCLD_II) > 0 and sum(PART_ON_DSGN_F) = 0 then 'Yes'
	when sum(PART_ON_DSGN_F) = 0 then 'No'
	when sum(PART_ON_DSGN_F) = count(*) then 'Yes'
	else 'Invalid' end as BOM_PART_ON_VRNT 
from (
	select
		 U06_FLAT.ARWU01_CCTSS_K
		,U04_BNCHMK.ARWU04_CCTSS_VRNT_K
		,U04_BNCHMK.ARWU04_BNCHMK_F
		,U18.ARWU18_BOM_PART_K
		,case
			when U37_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C in ('A','M') then 1
			when U37_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D' then 0
			when U19.ARWU06_CCTSS_DSGN_K is not null then 1
			else 0 end as PART_ON_DSGN_F
		,case 
			when U46_GROUP.ARWU06_CCTSS_DSGN_K is not null then 1
			else 0 end as HAS_INCLD_II
	from PARWU06_CCTSS_DSGN_FLAT as U06_FLAT
	join PARWU04_CCTSS_VRNT as U04_BNCHMK
		on U06_FLAT.ARWU01_CCTSS_K = U04_BNCHMK.ARWU01_CCTSS_K
		and U04_BNCHMK.ARWU04_BNCHMK_F = 1
	join PARWU18_BOM_PART as U18
		on U06_FLAT.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K
	left join PARWU19_DSGN_PART as U19
		on U06_FLAT.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
		and U18.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K
	left join (
		select
			 ARWU06_CCTSS_DSGN_K
			,ARWU18_BOM_PART_K
			,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
		from PARWU37_CCTSS_DSGN_ADJ as U37
		join PARWA40_DSGN_ADJ_PART_CHG_TYP as A40
			on U37.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
		group by
			 ARWU06_CCTSS_DSGN_K
			,ARWU18_BOM_PART_K
			,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
	) as U37_GROUP
		on U06_FLAT.ARWU06_CCTSS_DSGN_K = U37_GROUP.ARWU06_CCTSS_DSGN_K
		and U18.ARWU18_BOM_PART_K = U37_GROUP.ARWU18_BOM_PART_K
	left join (
		select
			 ARWU06_CCTSS_DSGN_K
			,ARWU18_BOM_PART_K
		from PARWU46_CCTSS_DSGN_IMPRV as U46
		join PARWU87_DSGN_IMPRV_TRDOFF as U87
			on U46.ARWU46_CCTSS_DSGN_IMPRV_K = U87.ARWU46_CCTSS_DSGN_IMPRV_K
		join PARWU85_CCTSS_TRDOFF as U85
			on U87.ARWU85_CCTSS_TRDOFF_K = U85.ARWU85_CCTSS_TRDOFF_K
		join PARWA31_CONFID_LVL as A31
			on U85.ARWA31_CONFID_LVL_K = A31.ARWA31_CONFID_LVL_K
		where
			U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N like '%#Ford'
			and U85.ARWU85_CCTSS_TRDOFF_INCLD_F = 1
			and A31.ARWA31_CONFID_LVL_C = 'H'
		group by
			 ARWU06_CCTSS_DSGN_K
			,ARWU18_BOM_PART_K
	) as U46_GROUP
		on U06_FLAT.ARWU06_CCTSS_DSGN_K = U46_GROUP.ARWU06_CCTSS_DSGN_K
		and U18.ARWU18_BOM_PART_K = U46_GROUP.ARWU18_BOM_PART_K
	where U06_FLAT.ARWA46_CCTSS_IMPT_VER_N <> 'Pre PBOM'
) as U06_X_U18
group by
 ARWU01_CCTSS_K
,ARWU04_CCTSS_VRNT_K
,ARWU04_BNCHMK_F
,ARWU18_BOM_PART_K
union
select
	 U04_FLAT.ARWU01_CCTSS_K
	,U04_FLAT.ARWU04_CCTSS_VRNT_K
	,U04_FLAT.ARWU04_BNCHMK_F
	,U18_ON_BNCHMK.ARWU18_BOM_PART_K
	,case
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'Invalid' then 'Invalid'
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'Yes' 
			and (U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C is null or U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'M') then 'Yes'
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'Yes' and U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D' then 'No'
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'Yes' and U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'A' then 'Invalid'
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'No' and U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'A' then 'Yes'
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'No' and U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C is null then 'No'
		when U18_ON_BNCHMK.PART_ON_BNCHMK = 'No' and U65_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C in ('M','D') then 'Invalid'
		end as BOM_PART_ON_VRNT
from PARWU04_CCTSS_VRNT_FLAT as U04_FLAT
join (
	select 
	 ARWU01_CCTSS_K
	,ARWU04_CCTSS_VRNT_K
	,ARWU04_BNCHMK_F
	,ARWU18_BOM_PART_K
	,case
		when sum(PART_ON_DSGN_F) = 0 then 'No'
		when sum(PART_ON_DSGN_F) = count(*) then 'Yes'
		else 'Invalid' end as PART_ON_BNCHMK 
	from (
		select
			 U06_FLAT.ARWU01_CCTSS_K
			,U04_BNCHMK.ARWU04_CCTSS_VRNT_K
			,U04_BNCHMK.ARWU04_BNCHMK_F
			,U18.ARWU18_BOM_PART_K
			,case
				when U37_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C in ('A','M') then 1
				when U37_GROUP.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D' then 0
				when U19.ARWU06_CCTSS_DSGN_K is not null then 1
				else 0 end as PART_ON_DSGN_F
		from PARWU06_CCTSS_DSGN_FLAT as U06_FLAT
		join PARWU04_CCTSS_VRNT as U04_BNCHMK
			on U06_FLAT.ARWU01_CCTSS_K = U04_BNCHMK.ARWU01_CCTSS_K
			and U04_BNCHMK.ARWU04_BNCHMK_F = 1
		join PARWU18_BOM_PART as U18
			on U06_FLAT.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K
		left join PARWU19_DSGN_PART as U19
			on U06_FLAT.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
			and U18.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K
		left join (
			select
				 ARWU06_CCTSS_DSGN_K
				,ARWU18_BOM_PART_K
				,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
			from PARWU37_CCTSS_DSGN_ADJ as U37
			join PARWA40_DSGN_ADJ_PART_CHG_TYP as A40
				on U37.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
			group by
				 ARWU06_CCTSS_DSGN_K
				,ARWU18_BOM_PART_K
				,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
		) as U37_GROUP
			on U06_FLAT.ARWU06_CCTSS_DSGN_K = U37_GROUP.ARWU06_CCTSS_DSGN_K
			and U18.ARWU18_BOM_PART_K = U37_GROUP.ARWU18_BOM_PART_K
		where U06_FLAT.ARWA46_CCTSS_IMPT_VER_N <> 'Pre PBOM'
	) as U06_X_U18
	group by
	 ARWU01_CCTSS_K
	,ARWU04_CCTSS_VRNT_K
	,ARWU04_BNCHMK_F
	,ARWU18_BOM_PART_K
) as U18_ON_BNCHMK
	on U04_FLAT.ARWU01_CCTSS_K = U18_ON_BNCHMK.ARWU01_CCTSS_K
left join (
	select
		 ARWU04_CCTSS_VRNT_K
		,ARWU18_BOM_PART_K
		,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
	from PARWU65_CCTSS_VRNT_ADJ as U65
	join PARWA40_DSGN_ADJ_PART_CHG_TYP as A40
		on U65.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
	group by
		 ARWU04_CCTSS_VRNT_K
		,ARWU18_BOM_PART_K
		,ARWA40_DSGN_ADJ_PART_CHG_TYP_C
) as U65_GROUP
	on U04_FLAT.ARWU04_CCTSS_VRNT_K = U65_GROUP.ARWU04_CCTSS_VRNT_K
	and U18_ON_BNCHMK.ARWU18_BOM_PART_K = U65_GROUP.ARWU18_BOM_PART_K
where U04_FLAT.ARWA46_CCTSS_IMPT_VER_N <> 'Pre PBOM'
	and U04_FLAT.ARWU04_BNCHMK_F = 0
	and U04_FLAT.ARWU04_VARIANT_ADJ_ONLY_F = 0
GO


