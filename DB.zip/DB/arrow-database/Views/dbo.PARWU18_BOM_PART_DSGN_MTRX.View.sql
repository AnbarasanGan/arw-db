DROP VIEW [dbo].[PARWU18_BOM_PART_DSGN_MTRX]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[PARWU18_BOM_PART_DSGN_MTRX] as
with
design_part_matrix (ARWU18_BOM_PART_K, DSGN_VEH, DSGN_RANK) as (
	select
		ARWU18_BOM_PART_K
		,DSGN_VEH
		,DSGN_RANK
	from (select
			 ARWU06_CCTSS_DSGN_K
			,DSGN_VEH
			,rank() over (partition by ARWU01_CCTSS_K order by DSGN_VEH asc) as DSGN_RANK
		from PARWU06_CCTSS_DSGN_SUMM
		) as dsgn_rank
	join PARWU19_DSGN_PART as U19
		on dsgn_rank.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
)
select
 	 ARWU31_CTSP_N + ' ' + ARWA06_RGN_C as BC@J1_PGM_RGN
	,ARWA03_ENRG_SUB_CMMDTY_X as BOB_SCOPE
	,ARWU01_BNCHMK_VRNT_N as BENCHMARK_VARIANT
	,ARWU17_BOM_SUB_ASSY_IX_C as SUB_ASSEMBLY_INDEX
	,ARWU17_BOM_SUB_ASSY_N as SUB_ASSEMBLY_NAME
	,U18.ARWU18_BOM_PART_IX_N as BOM_PART_INDEX
	,coalesce(design_1.DSGN_VEH,'') as DSGN_1
	,coalesce(design_2.DSGN_VEH,'') as DSGN_2
	,coalesce(design_3.DSGN_VEH,'') as DSGN_3
	,coalesce(design_4.DSGN_VEH,'') as DSGN_4
	,coalesce(design_5.DSGN_VEH,'') as DSGN_5
	,coalesce(design_6.DSGN_VEH,'') as DSGN_6
	,alpha_start
	,first_int
	,second_int
from PARWU01_CCTSS_FLAT as U01_FLAT
join PARWU17_BOM_SUB_ASSY as U17
	on U01_FLAT.ARWU01_CCTSS_K = U17.ARWU01_CCTSS_K
join PARWU18_BOM_PART as U18
	on U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
join PARWU18_BOM_PART_SORT as U18_SORT
	on U18.ARWU18_BOM_PART_K = U18_SORT.ARWU18_BOM_PART_K
left join design_part_matrix as design_1
	on U18.ARWU18_BOM_PART_K = design_1.ARWU18_BOM_PART_K
	and design_1.DSGN_RANK = 1
left join design_part_matrix as design_2
	on U18.ARWU18_BOM_PART_K = design_2.ARWU18_BOM_PART_K
	and design_2.DSGN_RANK = 2
left join design_part_matrix as design_3
	on U18.ARWU18_BOM_PART_K = design_3.ARWU18_BOM_PART_K
	and design_3.DSGN_RANK = 3
left join design_part_matrix as design_4
	on U18.ARWU18_BOM_PART_K = design_4.ARWU18_BOM_PART_K
	and design_4.DSGN_RANK = 4
left join design_part_matrix as design_5
	on U18.ARWU18_BOM_PART_K = design_5.ARWU18_BOM_PART_K
	and design_5.DSGN_RANK = 5
left join design_part_matrix as design_6
	on U18.ARWU18_BOM_PART_K = design_6.ARWU18_BOM_PART_K
	and design_6.DSGN_RANK = 6
GO
