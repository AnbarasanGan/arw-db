DROP VIEW IF EXISTS [dbo].[PARWU01_CCTSS_PBOM_STAT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==============================================================================================================================================
--Date:  2021-08-11
--CDSID: btemkow
--Description:
--This view provides the PBOM import status for the 'BoB Load Summary' and the 'Program-Region Load Summary.'
--==============================================================================================================================================
-- Change Log
-- CDSID      DATE         Change Description
-- btemkow    2021-09-21   Added some columns that might come in handy
--==============================================================================================================================================

CREATE VIEW [dbo].[PARWU01_CCTSS_PBOM_STAT] AS
select
 ARWU34_CTSP_RGN_K
,ARWU01_CCTSS_K
,ARWA03_ENRG_SUB_CMMDTY_X
,ARWU01_BNCHMK_VRNT_N
,ARWA45_PBOM_STAT_K
,ARWA45_PBOM_STAT_N
,ARWA45_PBOM_STAT_X
,case when ARWA45_PBOM_STAT_N = 'Imported' then 1 else 0 end as PBOM_IMPORTED
,ARWU01_PBOM_LAST_IMPT_FILE_N
,ARWU01_PBOM_LAST_IMPT_S
,ARWU01_PBOM_LAST_IMPT_USER_C
,ARWA49_PBOM_FILE_VER_K
,ARWA49_PBOM_FILE_VER_N
from PARWU01_CCTSS_FLAT
GO


