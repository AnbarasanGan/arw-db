SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2020
-- Description:	Master Procedure to call Tygra store procedures
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12   04/14/2021   Add call to new SP that delete's UB5 mappings when a Commodity data is refreshed.
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- rwesley2   05-21-2021  DEFECT US2555418 add @load_to_pgm_name to UB2 SP 
-- rwesley2   05-24-2021  US2559784 pass @version into PARWP_TYGRA_LOAD_FILE_REC , this is the UB3 load  
-- ashaik12   06-03-2021  Added arguments to PARWP_DELETE_REVISION_CCTSS_TYGRA
-- rwesley2   06-09-2021  US2604963 Add tygra file version number to UB2 input parameters
-- rwesley2  09-17-2021   US2891597 add branching logic for initial load and BoB refresh. For BoB refresh pass in U01 key.
--                        Manual SPs will continue to use NULL for U01 key. Only UI will use -1.
--                        moved PARWP_TYGRA_LOAD_ENRG_CMMDTY_MAPPING from pre-validation master to here.
-- rwesley2   03-29-2022  US3433185 added Begin End block to execute SP to update some variant (U04) columns based on flag on U01.  
-- rwesley2   04-05-2022  US3482265 added new validation to PARWP_TYGRA_VALIDT_MISSING_CCM_UI and need to pass in additional parameters 
-- rwesley2   04-11-2022  US3510421 added post validation SP 
-- rwesley2   04-29-2022  US3433185 Update Variant fields for Tygra studies upon load of a Current/Scope Tygra file load 
-- rwesley2   05-13-2022  US3617161 When doing a full load, the PARWP_TYGRA_UI_VRNT_CALC SP requires a NULL. Changing from -1 to NULL
-- rwesley2	  05-16-2022  US3617161	replace GETUTCDATE with @time_stamp to keep all SP dates in Synch
-- rwesley2   06-08-2022  US3704897 move execution of PARWP_TYGRA_UI_VRNT_CALC inside COMMIT for UB table load.  Remove IF statement that checks for post load errors before execution. 
-- rwesley2   06-20-2022  US3283898 DE256745 changed validation logic for post load validation SP
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_MASTER] 
	-- Add the parameters for the stored procedure here
@GUID  varchar(MAX),
@CDSID  varchar(MAX) ,    -- = 'rwesley2'
@file_name varchar(MAX),
@file_type int,
@version  int,
@ARWUB1_TYGRA_FILE_K  int,
@ARWU01_CCTSS_K int,
@program_name varchar(max),
@load_to_pgm_name varchar(MAX),
@file_source varchar(max),  -- ACT or ARROW
@Time_stamp datetime,
@result varchar(max) Output



AS
Begin  
--DECLARE @TIME_STAMP    DATETIME    = GETUTCDATE();
DECLARE @TYGRA_ERROR_TYPE varchar(MAX);
DECLARE @TYGRA_LOAD_ERROR varchar(MAX);
   

 SET @result = 0;

 SET NOCOUNT ON;
-- SET @TIME_STAMP = GETUTCDATE()
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));
 
 -- load mapping tables
 EXEC [dbo].[PARWP_TYGRA_LOAD_ENRG_CMMDTY_MAPPING]           @CDSID, @TIME_STAMP,@GUID; 

--Title Page validation
EXEC [dbo].[PARWP_TYGRA_VALIDT_TITLE_PAGE]              @GUID,  @CDSID, @TIME_STAMP; 
--Parts(detail) validation
EXEC [dbo].[PARWP_TYGRA_VALIDT_PARTS]                   @GUID,@CDSID, @TIME_STAMP; 
-- Starting point parts validation
--- EXEC [dbo].[RJW_PARWP_TYGRA_STARTING_PT_PARTS]               @CDSID, @TIME_STAMP; 
 -- Missing program validation
EXEC [dbo].[PARWP_TYGRA_VALIDT_MISSING_PROGRAM]         @GUID,@CDSID, @TIME_STAMP; 
 -- Missing CCM
EXEC [dbo].[PARWP_TYGRA_VALIDT_MISSING_CCM]            @GUID , @CDSID, @TIME_STAMP,@file_name,@load_to_pgm_name; 
 -- check for special character in parts columns
EXEC [dbo].[PARWP_TYGRA_VALIDT_PARTS_SPCL_CHARS]        @GUID, @CDSID, @TIME_STAMP; 

-- only continue to table load SPs if there are WARNING or no errors
 EXEC [dbo].[PARWP_TYGRA_GO_NO_GO]                        @GUID,  @CDSID, @TIME_STAMP, @TYGRA_ERROR_TYPE OUTPUT   



 IF @TYGRA_ERROR_TYPE = 'SYSTEM Error'  -- Capture System error. If system errors don't load tables
 Begin
    Set @result       = 'SYSTEM Error';  --The UI needs this set to 0 for an unexpected (system) error.
--	Set @IMPORT_STATUS = 'Processing_Error';
    GOTO EOJ    
 End


 IF @TYGRA_ERROR_TYPE = 'Validation Error'   -- Capture Validation error. If validation errors don't load tables
 Begin
    Set @result       = 'Validation Error';   --The UI needs this set to 1 to display validation ERRORs .
--	Set @IMPORT_STATUS = 'Validation Error';
    GOTO EOJ          
 End



 BEGIN TRY
    BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

	-- Execute the delete revision procedure to delete the mappings for a BoB when the user wants to reload the data.
	IF @ARWU01_CCTSS_K is NOT NULL 
	BEGIN
	EXEC [dbo].[PARWP_DELETE_REVISION_CCTSS_TYGRA] @ARWU01_CCTSS_K,'V',@file_type,@CDSID
	END

 
-- execute TYGRA Load UB tables stored procedures
   select 'TYGRA Load UB tables'
-- UB2 laod
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILECCM]                  @GUID, @CDSID, @load_to_pgm_name, @version, @TIME_STAMP ; 
   select count(*),'ub2' from [dbo].[PARWUB2_TYGRA_FILE_CCM]
   where [ARWUB2_LAST_UPDT_S] = @time_stamp
---- UB3 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILE_REC]                 @GUID, @CDSID, @ARWU01_CCTSS_K,@version , @TIME_STAMP;  
    select count(*),'ub3' from [dbo].[PARWUB3_TYGRA_FILE_REC] 
   where [ARWUB3_LAST_UPDT_S] = @time_stamp
-- UB4 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILE_REC_CCM]             @GUID, @CDSID, @ARWU01_CCTSS_K,@TIME_STAMP,@load_to_pgm_name;  
       select count(*),'ub4' from [dbo].[PARWUB4_TYGRA_FILE_REC_CCM] 
   where [ARWUB4_LAST_UPDT_S] = @time_stamp
-- load UB6
  EXEC [dbo].[PARWP_TYGRA_UI_LOAD_UB6]    @CDSID, @TIME_STAMP, @file_name, @file_type, @version, @ARWUB1_TYGRA_FILE_K , @ARWU01_CCTSS_K, @load_to_pgm_name ;
      select count(*),'ub6' from [dbo].[PARWUB6_CCTSS_TYGRA_FILE] 
	  where [ARWUB6_LAST_UPDT_S] = @time_stamp 
-- update U04 variant 
 DECLARE @TYGRA_U04_VRNT_UPDATE  [dbo].[PARWT01_CCTSS]
    If @ARWU01_CCTSS_K is NULL
    Begin
      insert into @TYGRA_U04_VRNT_UPDATE  
         select   ARWU01_CCTSS_K
         from PARWU01_CCTSS_FLAT where ARWU31_CTSP_N = @load_to_pgm_name
						             and ARWU01_MANL_VRNT_TYGRA_FLD_F = 0
					             and ARWU01_TYGRA_REQD_F = 1
         exec [dbo].[PARWP_TYGRA_UI_VRNT_CALC]  @TYGRA_U04_VRNT_UPDATE,@GUID,@CDSID,@time_stamp,0
    END
 If @ARWU01_CCTSS_K IS NOT NULL
    Begin
      insert into @TYGRA_U04_VRNT_UPDATE  
        select ARWU01_CCTSS_K
        from PARWU01_CCTSS_FLAT where ARWU01_CCTSS_K = @ARWU01_CCTSS_K
						            and ARWU01_MANL_VRNT_TYGRA_FLD_F = 0
					            and ARWU01_TYGRA_REQD_F = 1
        exec [dbo].[PARWP_TYGRA_UI_VRNT_CALC]  @TYGRA_U04_VRNT_UPDATE,@GUID,@CDSID,@time_stamp,0
     END
 
   COMMIT TRANSACTION;

   -- validatate UB table loads
  EXEC [dbo].[PARWP_TYGRA_VALIDT_POST_LOAD_UI]  @guid ,@CDSID ,@Program_name ,@file_name ,@version ,@file_source ,@ARWU01_CCTSS_K ,@load_to_pgm_name 
                                               ,@TIME_STAMP ,@TYGRA_LOAD_ERROR OUTPUT




 END TRY
  
 --CATCH
 BEGIN CATCH
   Rollback;
   Set @result = 'SYSTEM Error';

    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'TYGRA MASTER PROCEDURE'
        ,0                              as ARWE02_ROW_IDX	
	    ,' '                               -- part_index 
	    ,' '                               -- ARROW_VALUE
	;

  END CATCH;	

--If ERRORs display E02 error table for processing Id being loaded  
EOJ: select * from PARWE02_BATCH_ERRORS 
    where 
        (ARWE02_SOURCE_C = 'system'
         and ARWE02_PROCESSING_ID = @GUID )
      or
        (ARWE02_SOURCE_C = 'TYGRA'            --'tygra'
	     and [ARWE02_ERROR_TYPE_X] = 'error'
         and ARWE02_PROCESSING_ID = @GUID )
		 ;


END;

