DROP PROCEDURE [dbo].[PARWP_DELETE_CTSP]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- ============================================================================================
-- Author:		btemkow
-- Create date: 2020-04-22
-- Description:	This SP deletes a CTSP (BC@J1 Program). It requires that all CCTSSs (BoBs/DEAs)
--              belonging to the CTSP are deleted first.
-- Input Parameter:
--		 @ARWU31_CTSP_N
-- Output: Returns 0 if executed successfully, 1 if an error occurred
-- How to Run: First declare and set input parameter, then 
--	  EXECUTE @RC = [dbo].[PARWP_DELETE_CTSP] 
--		 @ARWU31_CTSP_N
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow	  2020-04-22  initial version
-- btemkow    2021-04-28  added step to delete from PARWU15_CCTSS_WALK_CTSP
-- ============================================================================================
--DROP PROCEDURE [dbo].[PARWP_DELETE_CTSP] 

CREATE PROCEDURE [dbo].[PARWP_DELETE_CTSP] 
 @ARWU31_CTSP_N varchar(32)

AS

SET NOCOUNT ON;

DECLARE @ARWU31_CTSP_K INT
SET @ARWU31_CTSP_K = (
		SELECT ARWU31_CTSP_K
		FROM PARWU31_CTSP
		WHERE ARWU31_CTSP_N = @ARWU31_CTSP_N
	)

IF @ARWU31_CTSP_K IS NOT NULL
BEGIN
  	IF NOT EXISTS (
		SELECT *
		FROM PARWU01_CCTSS_FLAT
		WHERE ARWU31_CTSP_N = @ARWU31_CTSP_N
	)
	BEGIN
		BEGIN TRY
			BEGIN TRANSACTION

			DECLARE @U34_delete_keys TABLE (
				ARWU34_CTSP_RGN_K INT
			)

			INSERT INTO @U34_delete_keys
			SELECT ARWU34_CTSP_RGN_K
			FROM PARWU34_CTSP_RGN
			WHERE ARWU31_CTSP_K = @ARWU31_CTSP_K

			DELETE FROM PARWU94_SLS_LOC_YR_VOL
			WHERE ARWU93_CTSP_RGN_SLS_LOC_K IN (
				SELECT ARWU93_CTSP_RGN_SLS_LOC_K
				FROM PARWU93_CTSP_RGN_SLS_LOC AS U93
				JOIN @U34_delete_keys AS U34_del
					ON U93.ARWU34_CTSP_RGN_K = U34_del.ARWU34_CTSP_RGN_K
			)

			DELETE FROM PARWU93_CTSP_RGN_SLS_LOC
			WHERE ARWU34_CTSP_RGN_K IN (
				SELECT ARWU34_CTSP_RGN_K
				FROM @U34_delete_keys
			)

			DELETE FROM PARWU92_CTSP_RGN_PEL
			WHERE ARWU34_CTSP_RGN_K IN (
				SELECT ARWU34_CTSP_RGN_K
				FROM @U34_delete_keys
			)

			DELETE FROM PARWU35_CTSP_RGN_PGM
			WHERE ARWU34_CTSP_RGN_K IN (
				SELECT ARWU34_CTSP_RGN_K
				FROM @U34_delete_keys
			)

			DELETE FROM PARWU34_CTSP_RGN
			WHERE ARWU34_CTSP_RGN_K IN (
				SELECT ARWU34_CTSP_RGN_K
				FROM @U34_delete_keys
			)

			DELETE FROM PARWU33_CTSP_CRCY_EXCHG_RATE
			WHERE ARWU31_CTSP_K = @ARWU31_CTSP_K

			DELETE FROM PARWU32_CTSP_MDUL
			WHERE ARWU31_CTSP_K = @ARWU31_CTSP_K

			DELETE FROM PARWU15_CCTSS_WALK_CTSP
			WHERE ARWU31_CTSP_K = @ARWU31_CTSP_K

			DELETE FROM PARWU31_CTSP
			WHERE ARWU31_CTSP_K = @ARWU31_CTSP_K

			COMMIT TRANSACTION
			PRINT 'PARWP_DELETE_CTSP success'
		END TRY
		BEGIN CATCH
			ROLLBACK TRANSACTION
			PRINT ERROR_PROCEDURE() + ' Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) ;
			RETURN 1
		END CATCH
		RETURN 0
	END
	ELSE
		PRINT 'CTSP not deleted because it has at least one CCTSS'
		RETURN 1
END
ELSE
	PRINT 'Input parameter does not match a CTSP'
	RETURN 1

GO
