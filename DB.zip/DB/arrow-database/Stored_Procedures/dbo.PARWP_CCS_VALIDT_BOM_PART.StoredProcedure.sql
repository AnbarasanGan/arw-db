DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_PART]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 03/18/2019
-- Description:	Validate the PARWS13_CCS_FORD_BOM_PARTS_INFO staging table
--              Verify the PARWU182 unique key (ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N).  There can't be duplicate part indexes per file and processing_id.
--              Note: there shouldn't be a file with a different processing_id but to be safe it checks for both (See partition by code below)
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- rwesley2  07/03/2019   Changed to a WARNING 
-- Asolosky  09/10/2019   Added row_idx
-- Asolosky  09/17/2019   Changing 'Duplicate part index found in file'  back to an Error
-- Ashaik12  09/17/2019   Changed Error Description on the Duplicate part index.
-- Ashaik12  01/10/2020   Added TimeStamp parameter and removed filter on Processing Status
-- Ashaik12  01/15/2020   Use Flat views
-- asolosky  07/16/2020   US1771016 Added error message for carriage return and line feed.
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  01/21/2022   US3058121 Added validation to make sure the quoted parts are in the cost sheet. If the cost sheet has 2 consecutive empty rows, the UI will stop reading.
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_BOM_PART] 
-- Input Parameter
 @Processing_ID Varchar(5000)
,@CDSID         Varchar(30)
,@TIME_STAMP DATETIME

AS
BEGIN TRY
	SET NOCOUNT ON;
	INSERT INTO PARWE02_BATCH_ERRORS
    Select 
		 STAGING.Source_c
		,STAGING.part_index 
		,'Part index found in multiple Sub-Assemblies' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,STAGING.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
		,'ERROR'
		,'BoM'+' - ' + STAGING.[part_sub_assembly_name]
	    ,row_idx                               as ARWE02_ROW_IDX
		,STAGING.part_index
		,''  --No ARROW Value
    FROM
    (	
	  SELECT
             S13.*
	        ,COUNT(part_index) OVER (PARTITION BY S13.file_name, S13.processing_ID, S13.part_index) part_index_count
	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
	    JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
	      ON S22.Processing_ID       = S13.Processing_ID
         AND S22.filename            = S13.file_name
	   Where S13.Processing_ID       = @Processing_ID
	    
	) STAGING
	Where part_index_count > 1 
;
	INSERT INTO PARWE02_BATCH_ERRORS
    Select 
		 STAGING.Source_c
		,STAGING.[part_sub_assembly_name] 
		,'The part index was found under a different sub-assembly. It can only be under one sub-assembly per Program'
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,STAGING.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
		,'ERROR'
		,'BoM'+' - '+STAGING.[part_sub_assembly_name]
	    ,row_idx                               as ARWE02_ROW_IDX
		,STAGING.part_index
		,ARWU17_BOM_SUB_ASSY_N  --ARROW value
    FROM
    (	
	  SELECT U01.ARWU01_CCTSS_K
	        ,S13.Source_c
			,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
			,S13.part_sub_assembly_name
			,S13.part_index
			,S13.part_name
			,S13.file_name
			,S13.supplier_name
			,S13.design_name
			,S22.supplier_name as supplier_nameS22
			,S22.design_Model
			,U17.ARWU17_BOM_SUB_ASSY_K
			,U17.ARWU17_BOM_SUB_ASSY_N
			,U18.ARWU18_BOM_PART_IX_N
			,s13.row_idx
	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID         = S13.Processing_ID
		 AND S22.filename              = S13.file_name
	    JOIN PARWU01_CCTSS_FLAT         U01
	      ON U01.ARWU31_CTSP_N         = S22.User_Selected_CTSP_N
         AND U01.ARWA06_RGN_C      = S22.User_Selected_CTSP_Region_C
		 AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U01.ARWU01_BNCHMK_VRNT_N               = s22.User_Selected_BNCMK_VRNT_N
   Left JOIN PARWU18_BOM_PART                 U18
		  ON U18.ARWU01_CCTSS_K        = U01.ARWU01_CCTSS_K
		 AND U18.ARWU18_BOM_PART_IX_N  = S13.part_index
   Left JOIN PARWU17_BOM_SUB_ASSY             U17
		  ON U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
	   Where S22.Processing_ID         = @Processing_ID  
		 and U17.ARWU17_BOM_SUB_ASSY_N is not null
		 and U17.ARWU17_BOM_SUB_ASSY_N != part_sub_assembly_name
	) STAGING
;

-- Line Feed validation
DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(part_index,char(10),'<LF>')          as [ARWE02_ERROR_VALUE],  --replace line feed with <LF>
	       'A part index can''t have an imbedded line feed <LF>'       as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       file_name                                    as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K             as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'            as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       part_sub_assembly_name                       as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   part_index                                   as [ARWE02_Part_Index],
		   ''                                           as [ARWE02_ARROW_Value]
      FROM PARWS13_CCS_FORD_BOM_PARTS_INFO
     WHERE Processing_ID         = @Processing_ID
       and NullIf(PATINDEX(@pat10,part_index),0) > 0  --Looking for Line Feed 
    ;

-- Carriage Return validation
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(part_index,char(13),'<CR>')          as [ARWE02_ERROR_VALUE],  --replace carriage return with <CR>
	       'A part index can''t have an imbedded carriage return <CR>' as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       file_name                                    as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K             as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'            as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       part_sub_assembly_name                       as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   part_index                                   as [ARWE02_Part_Index],
		   ''                                           as [ARWE02_ARROW_Value]
      FROM PARWS13_CCS_FORD_BOM_PARTS_INFO
     WHERE Processing_ID         = @Processing_ID
       and NullIf(PATINDEX(@pat13,part_index),0) > 0  --Looking for Carriage Return 
    ;

with Part_Quote AS
(
--Only get the Quoted parts on the cost sheet
 SELECT S13.Processing_ID, S13.file_name,S13.part_sub_assembly_name, S13.part_index, S13.quoted  
   FROM PARWS13_CCS_FORD_BOM_PARTS_INFO                 S13   
   JOIN PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14
     ON S13.Processing_ID          = S14.Processing_ID
    AND S13.file_name              = S14.filename
    AND S13.part_sub_assembly_name = S14.sub_assembly_name
    AND S13.part_index             = s14.part_index
    AND S13.quoted                 = 'YES'
  Where S13.Processing_ID          = @Processing_ID
 UNION
 SELECT S13.Processing_ID, S13.file_name,S13.part_sub_assembly_name, S13.part_index, S13.quoted  
   FROM PARWS13_CCS_FORD_BOM_PARTS_INFO                 S13   
   JOIN PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO   S15
     ON S13.Processing_ID          = S15.Processing_ID
    AND S13.file_name              = S15.filename
    AND S13.part_sub_assembly_name = S15.sub_assembly_name
    AND S13.part_index             = S15.part_index
    AND S13.quoted                 = 'YES'
  Where S13.Processing_ID          = @Processing_ID
 UNION
 SELECT S13.Processing_ID, S13.file_name,S13.part_sub_assembly_name, S13.part_index, S13.quoted  
   FROM PARWS13_CCS_FORD_BOM_PARTS_INFO                  S13   
   JOIN PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO S16
     ON S13.Processing_ID          = S16.Processing_ID
    AND S13.file_name              = S16.filename
    AND S13.part_sub_assembly_name = S16.sub_assembly_name
    AND S13.part_index             = S16.part_index
    AND S13.quoted                 = 'YES'
  Where S13.Processing_ID          = @Processing_ID
 UNION
 SELECT S13.Processing_ID, S13.file_name,S13.part_sub_assembly_name, S13.part_index, S13.quoted  
   FROM PARWS13_CCS_FORD_BOM_PARTS_INFO                  S13   
   JOIN PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO   S17
     ON S13.Processing_ID          = S17.Processing_ID
    AND S13.file_name              = S17.filename
    AND S13.part_sub_assembly_name = S17.sub_assembly_name
    AND S13.part_index             = S17.part_index
    AND S13.quoted                 = 'YES'
  Where S13.Processing_ID          = @Processing_ID
)
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select S13.Source_c
   	,S13.part_index 
   	,'The import process did not read this cost sheet part because of 2 consecutive empty rows or the BOM quoted formula was changed. Any data that comes after 2 consecutive empty rows will be ignored/not loaded. Please remove these empty rows or verify the BOM quoted formula is correct' 
      ,@Processing_ID
      ,file_name
   	,object_name(@@PROCID) AS Procedure_x
   	,@TIME_STAMP
   	,@CDSID
   	,@TIME_STAMP
   	,@CDSID
   	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
   	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
   	,'ERROR'
   	,S13.part_sub_assembly_name   as ARWE02_EXCEL_TAB_X
   	,''                           as ARWE02_ROW_IDX --Left it empty because there is no row id from the costsheet
   	,S13.part_index
   	,''  --No ARROW Value 
  From ( 
        --Left join all bom parts to the cost parts.  Any that don't join probably has 2 empty rows in the cost sheet.
        Select PQ.file_name as PQ_file_name
		        ,S13.file_name, S13.Source_c, S13.part_index
				  ,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
				  ,S13.part_sub_assembly_name,  S13.row_idx
          FROM PARWS13_CCS_FORD_BOM_PARTS_INFO  S13   
     Left JOIN Part_Quote                       PQ
            ON PQ.Processing_ID           = S13.Processing_ID
           AND PQ.file_name               = S13.file_name 
           AND PQ.part_sub_assembly_name  = S13.part_sub_assembly_name
           AND PQ.part_index              = S13.part_index     
         Where S13.Processing_ID          = @Processing_ID
           AND S13.quoted                 = 'YES'
		) S13
 Where PQ_file_name IS null
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,NULL
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''                                --[ARWE02_Part_Index],
		,''                                --[ARWE02_ARROW_Value]

;
END CATCH;


GO
