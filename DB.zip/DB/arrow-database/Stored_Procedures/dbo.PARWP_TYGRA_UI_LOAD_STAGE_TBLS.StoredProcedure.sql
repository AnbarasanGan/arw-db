SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load S61 and S62
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12   04/07/2021  Corrected column mapping for WS2_Part_Level_Commonality and WS2_Part_Level_Eff_Methodology_Calculation
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2	  04-21-2021  US2456446 add new columns to S62	
--                                  added CASE to load start point parts when FEDEBOM parts are missing 	
-- Ashaik12   04-28-2021   Fix case when statement for fede bob pia ei	
-- rwesley2	  05-06-2021  US2458193 use SYNONYM for linked server name 
-- rwesley2   06-14-2021  US2604950 add NO_CM column to S62 table and load
-- rwesley2	  07-29-2021  US2747200 replace global temp table with local temp table	
-- ashaik12   02-15-2022  US3305905 Add CM10 to CM25
-- rwesley2   04-26-2022  US3482265 removed GETUTCDATE and replace with @TIME_STAMP for S61 an dS62 loads
-- ashaik12   09-20-2022  US4066530    added Stretch_Part_Level_Target column
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_STAGE_TBLS] 
	-- Add the parameters for the stored procedure here

-- Input Parameter

@CDSID varchar(MAX)
,@TIME_STAMP datetime


AS

DECLARE @TYGRA_ID_K int
DECLARE @U41_ProgramNm varchar(MAX);
DECLARE @BCJU41_FileNameSPTygra Varchar(MAX);
DECLARE @BCJU41_WRKSHP_NUM_C  Varchar(MAX);
DECLARE @BCJU41_WRKSHP_STATUS_C Varchar(MAX)
DECLARE @guid uniqueidentifier = NEWID();
DECLARE @BCJU51_VERSION_F INT;

SELECT @guid as 'GUID'



--++++++++++++++++ start cursor stuff++++++++++++++
DECLARE @files_2_process TABLE (
BCJU41_TYGRA_ID_K INT NOT NULL
		                        )
 	;
-- get files to process  
INSERT INTO @files_2_process
select [BCJU41_TYGRA_ID_K]
 from ##file_list
where file_selected = 'Y'
;



DECLARE @cur_ProgramNm varchar(50);
DECLARE @cur_VERSION_F INT;
DECLARE @cur_TYGRA_ID_K int

DECLARE file_cur CURSOR
  FOR SELECT [BCJU41_TYGRA_ID_K]
	  from @files_2_process
;

OPEN file_cur;


FETCH NEXT FROM file_cur INTO @cur_TYGRA_ID_K;

WHILE @@FETCH_STATUS = 0
		BEGIN
set @TYGRA_ID_K = @cur_TYGRA_ID_K 
--+++++++++++++++++++++++++++++++++++++++++++++++++


-- S61 load
INSERT INTO PARWS61_TYGRA_TITLE_PAGE
select * from (
select  
@guid                as processing_id
,'TYGRA'                     as source
,fl.bcju41_programnm         as program
,[BCJU45_CCM_X]              as CCM
,a06.ACTA06_ACT_REGION_N     as region
,[BCJU45_SERIES_X]           as series 
,[BCJU45_TAKE_RATE_A]        as take_rate
,[BCJU45_ENGINE_X]           as engine
,[BCJU45_TRANS_X]            as transmission
,[BCJU45_DESC_X]             as description
,ISNULL([BCJU41_DATEOFDATAPULL_X],'1900-01-01')   as data_pull_date  ------data pull date goes here
,u41.[BCJU41_FileNameSPTygra]    as filename 
,1                           as row_indx ----row index goes here
,@TIME_STAMP                 as create_dt
,@CDSID                      as create_user
,@TIME_STAMP                 as update_dt
,@CDSID                      as update_user
,[BCJU45_CM_PGM_X]           as CM_PROGRAM
,[BCJU45_CM_NCKNM_N]         as CM_NICKNAME
,[BCJU45_CM_MDLYR_A]         as CM_MDLYR
from [dbo].[PBCJU45_TYGRA_HEADER_SYN] u45
join [dbo].[PBCJU41_TYGRA_SYN] u41
on u45.[BCJU41_TYGRA_ID_K] = u41.[BCJU41_TYGRA_ID_K]
left join [dbo].[PACTA06_ACT_REGION_SYN] a06
on u45.[ACTA06_ACT_REGION_K] = a06.[ACTA06_ACT_REGION_K]
join ##file_list  fl
on u45.[BCJU41_TYGRA_ID_K] = fl.[BCJU41_TYGRA_ID_K]
 where u45.[BCJU41_TYGRA_ID_K] =   @cur_TYGRA_ID_K
)x
 ;

 
-- s62 load
INSERT INTO PARWS62_TYGRA_SUMMARY
select * from (
select  
  @guid                       as processing_id
 ,'TYGRA'                     as source
-- , [BCJU44_fldvehnm]          as vehicle_name
 ,fl.bcju41_programnm         as vehicle_name
 ,[BCJU44_fldPMT]             as PMT  
 ,[BCJU44_fldcm1]             as CM1
 ,BCJU44_fldcm2               as CM2
 ,BCJU44_fldcm3               as CM3
 ,BCJU44_fldcm4               as CM4
 ,BCJU44_fldcm5               as CM5 
 ,[BCJU44_fldcm6]             as CM6
 ,[BCJU44_fldcm7]             as CM7
 ,[BCJU44_fldcm8]             as CM8
 ,[BCJU44_fldcm9]             as CM9
 ,[BCJU44_NO_CM_F]            as nonCM
 ,[BCJU44_fldEngCom]          as eng_commodity
 ,[BCJU44_fldPre]             as Surrogate_Part_Prefix
 ,[BCJU44_fldBase]            as Surrogate_Part_Base 
 ,[BCJU44_fldSuf]             as Surrogate_Part_Suffix 
 ,[BCJU44_fldParDes]          as Surrogate_Part_Desc
 ,[BCJU44_fldPLPre]           as Start_Point_Part_Prefix
 ,[BCJU44_fldPLBase]          as Start_Point_Part_Base
 ,[BCJU44_fldPLSuf]           as Start_Point_Part_Suffix
 ,[BCJU44_fldPartDes]         as Start_Point_Part_Desc
 ,[BCJU44_fldFinSurPrg]       as Finance_Surrogate_Program
 ,[BCJU44_fldSurrUSD]         as Surrogate_Cost  --var to dec
 ,[BCJU44_fldPLCPSC]          as Start_Point_CPSC --varchar
 ,[BCJU44_fldStPtvsVP]        as Start_Point_Vehicle_Price  --var to dec
 ,[BCJU44_fldspe]             as Start_Point_Efficiency  -- var to dec
 ,[BCJU44_fldQty]             as Finance_Surrogate_Quantity  --decimal
 ,[BCJU44_fldPrtLevQty]       as Start_Point_Quantity --dec
 ,[BCJU44_fldLAttTotal]       as Compatibilities  --dec
 ,[BCJU44_fldlatttoteff]      as Compatibilities_Efficiency
 ,[BCJU44_fldMEV]             as MEV   --var to dec
 ,[BCJU44_fldRAttTot]         as Job1_Attributes
 ,[BCJU44_fldRAttTotEff]      as Job1_Attributes_Efficiency
 ,[BCJU44_fldJ1Target]        as Job1_Target --var to dec
 ,[BCJU44_fldpartlevci]      as WS2_Part_Level_Commonality
 ,[BCJU44_fldprteffmeth]      as WS2_Part_Level_Eff_Methodology_Calculation 
 ,[BCJU44_fldprtreduct]       as Part_Level_Reduction
 ,[BCJU44_fldBoBPIAEI]        as BoB_PIA_End_Item
 ,[BCJU44_fldbobnm]           as BoB_Enrg_Sub_commodity
 ,ISNULL([BCJU44_fldctvm],0)  as Commerical_TVM  --[BCJU44_fldCommercialTVMPct] or [BCJU44_fldctvm] or fldctvmcpct
 ,ISNULL([BCJU44_flddtvm],0)  as Design_TVM  --[BCJU44_fldDesignTVMPct] or [BCJU44_flddtvm] or flddtvmpct
 ,cast([BCJU44_flduniqid] as INT)  as Tygra_Unique_ID
 ,u41.[BCJU41_FileNameSPTygra]    as filename 
 ,ISNULL(BCJU44_ROW_ID_F,1)   as row_indx 
 ,@TIME_STAMP                 as create_dt
 ,@cdsid                      as create_user
 ,@TIME_STAMP                 as update_dt
 ,@cdsid                      as update_user
 ,BCJU44_fldcm10              as NON_CM1
 ,BCJU44_fldcm11              as NON_CM2
 ,BCJU44_fldcm12              as NON_CM3
 ,BCJU44_fldcm13              as NON_CM4
 ,BCJU44_fldcm14              as NON_CM5
 ,BCJU44_fldcm15              as NON_CM6
 ,NULL                        as NON_CM7
 ,NULL                        as NON_CM8
 ,NULL                        as NON_CM9
 ,[BCJU44_sur_pgm_cmdty]      as Surrogate_Program_Used_for_Commodity_Start_Point 
 ,[BCJU44_fldwcat]            as WCAT_Category  
 ,[BCJU44_fldlatt1]           as Compatibilities1
 ,[BCJU44_fldlatt1wcat]       as Compatibilities1_WCAT
 ,[BCJU44_fldlatt1des]        as Compatibilities1_Desc
 ,[BCJU44_fldlatt2]           as Compatibilities2
 ,[BCJU44_fldlatt2wcat]       as Compatibilities2_WCAT
 ,[BCJU44_fldlatt2des]        as Compatibilities2_Desc
 ,[BCJU44_fldlatt3]           as Compatibilities3
 ,[BCJU44_fldlatt3wcat]       as Compatibilities3_WCAT 
 ,[BCJU44_fldlatt3des]        as Compatibilities3_Desc
 ,[BCJU44_fldratt1]           as Job1_Attributes1
 ,[BCJU44_fldratt1wcat]       as Job1_Attributes1_WCAT
 ,[BCJU44_fldratt1des]        as Job1_Attributes1_Desc
 ,[BCJU44_fldratt2]           as Job1_Attributes2
 ,[BCJU44_fldratt2wcat]       as Job1_Attributes2_WCAT
 ,[BCJU44_fldratt2des]        as Job1_Attributes2_Desc 
 ,[BCJU44_fldratt3]           as Job1_Attributes3
 ,[BCJU44_fldratt3wcat]       as Job1_Attributes3_WCAT
 ,[BCJU44_fldratt3des]        as Job1_Attributes3_Desc
 ,[BCJU44_fldplatth]          as Platform_Tophat
 ,[BCJU44_fldmfgreg]          as MFG_Region
 ,[BCJU44_fldstvssudes]       as ST_v_SU_Desc
 ,[BCJU44_fldcomments]        as Comments
 ,[BCJU44_FB_PN_PLN_C]        as FEDEBOM_PN_Plan
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLPre] else [BCJU44_fldnewprtpre]  END  as FEDEBOM_Planned_Prefix
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLBase] else [BCJU44_fldnewprtbase] END    as FEDEBOM_Planned_Base
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLSuf] else [BCJU44_fldnewprtsuff] END    as FEDEBOM_Planned_Suffix 
 ,[BCJU44_FB_VAR_CNT_F]       as FEDEBOM_Variant_Cnt
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldBoBPIAEI]  else [BCJU44_FB_BOB_PIA_EI_X] END   as FEDEBOM_bob_pia_ei
-- ,CASE WHEN (u44.BCJU44_NO_CM_F is NULL)  then 0  else u44.BCJU44_NO_CM_F  END             as NO_CM
,[BCJU44_FLDCM10] as [CM10]
,[BCJU44_FLDCM11] as [CM11]
,[BCJU44_FLDCM12] as [CM12]
,[BCJU44_FLDCM13] as [CM13]
,[BCJU44_FLDCM14] as [CM14]
,[BCJU44_FLDCM15] as [CM15]
,[BCJU44_FLDCM16] as [CM16]
,[BCJU44_FLDCM17] as [CM17]
,[BCJU44_FLDCM18] as [CM18]
,[BCJU44_FLDCM19] as [CM19]
,[BCJU44_FLDCM20] as [CM20]
,[BCJU44_FLDCM21] as [CM21]
,[BCJU44_FLDCM22] as [CM22]
,[BCJU44_FLDCM23] as [CM23]
,[BCJU44_FLDCM24] as [CM24]
,[BCJU44_FLDCM25] as [CM25]
,[BCJU44_J1_TARGET_ALT] as [Stretch_Part_Level_Target]
 from [dbo].[PBCJU44_TYGRA_DETAILS_SYN] u44
 join [dbo].[PBCJU41_TYGRA_SYN] u41
on u44.[BCJU41_TYGRA_ID_K] = u41.[BCJU41_TYGRA_ID_K]
join ##file_list  fl
on u44.[BCJU41_TYGRA_ID_K] = fl.[BCJU41_TYGRA_ID_K]
  where u44.BCJU41_TYGRA_ID_K = @cur_TYGRA_ID_K  -- @tygra_id_k

 )x
 ;

--++++++++++++++++ end cursor stuff++++++++++++++
   	FETCH NEXT FROM file_cur INTO  @cur_TYGRA_ID_K;
 		END;
	CLOSE file_cur;
	DEALLOCATE file_cur;
--+++++++++++++++++++++++++++++++++++++++++++++++
-- put drop for global table

drop table if exists ##file_list
