DROP PROCEDURE [dbo].[PARWP_CCS_SCRUB_PROCESSING]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 04/15/2019
-- Description:	Set Warning message that a processing cost does not have a raw material cost
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 06/25/2019  asolosky  N/A       Changed the exists query to only use the U25 and match on V08a
--                                 Removed the join on processing_id and moved to the Where clause.
-- 01/10/2020  Ashaik12            Added TimeStamp parameter
-- 09/11/2020  Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_CCS_SCRUB_PROCESSING] 
-- Input Parameter
@GUID varchar(5000) 
,@CDSID         varchar(30)
,@TIME_STAMP DATETIME

AS

	SET NOCOUNT ON;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select  
		 Err.[Source_c]
        ,Err.[ARWU18_BOM_PART_IX_N]
		,'Processing Cost does not have a Raw Materials Cost' as Error_Msg
        ,Err.[Processing_ID]
        ,Err.[Filename]
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
 		,@TIME_STAMP 
		,@CDSID
        ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
		,'Process and Raw Materials'
		--identity key place holder		
		,'WARNING'
		,'SubAssemly' + ' - ' + Err.[ARWU17_BOM_SUB_ASSY_N]
		,0 AS ARWE02_ROW_IDX
		,ARWU18_BOM_PART_IX_N
		,''  --No ARROW Value
    FROM
    (	
	  (SELECT U26.[ARWU08_CCTSS_DSGN_SUPL_K] 
	         ,u26.[ARWU19_DSGN_PART_K] as u26_ARWU19_DSGN_PART_K
			 ,v08a.[ARWU18_BOM_PART_IX_N]
			 ,v08a.[ARWU17_BOM_SUB_ASSY_N]
			 ,s22.[Source_c]
			 ,s22.[Processing_ID]
			 ,s22.[filename]
			 ,s22.[ARWS22_CCS_COVER_PAGE_INFO_K]
			 
	    FROM [dbo].[PARWU26_PROCG_COST] U26
	    JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08a
	      ON U26.[ARWU08_CCTSS_DSGN_SUPL_K] = v08a.[ARWU08_CCTSS_DSGN_SUPL_K]
		 and U26.[ARWU19_DSGN_PART_K] = V08a.[ARWU19_DSGN_PART_K]
	     JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
		   ON v08a.ARWU31_CTSP_N                   = s22.[User_Selected_CTSP_N]
             and v08a.[ARWA06_RGN_C]               = s22.[User_Selected_CTSP_Region_C]
             and v08a.[ARWA03_ENRG_SUB_CMMDTY_X]   = s22.[User_Selected_ENRG_SUB_CMMDTY_X]
	         AND v08a.ARWU01_BNCHMK_VRNT_N         = s22.[User_Selected_BNCMK_VRNT_N]
			 AND V08a.[ARWA14_VEH_MAKE_N]          = s22.[User_Selected_VEH_MAKE_N]
             and v08a.[ARWA34_VEH_MDL_N]           = s22.[User_Selected_VEH_MDL_N]
             and v08a.[ARWA35_DSGN_VEH_MDL_YR_C]   = s22.[User_Selected_VEH_MDL_YR_C]
             and v08a.[ARWA35_DSGN_VEH_MDL_VRNT_X] = s22.[User_Selected_VEH_MDL_VRNT_X]
	         and v08a.[ARWA17_SUPL_N]              = s22.[User_Selected_SUPL_N]
	         AND v08a.ARWA28_CNTRY_N               = s22.[User_Selected_SUPL_CNTRY_N]
	         AND v08a.ARWA17_SUPL_C			       = s22.[User_Selected_SUPL_C]
		 Where S22.Processing_ID  = @GUID
		   and NOT EXISTS
		  (SELECT 'X'
             FROM [dbo].[PARWU25_RAW_MTRL_COST]  U25
	        Where U25.[ARWU08_CCTSS_DSGN_SUPL_K] = V08a.[ARWU08_CCTSS_DSGN_SUPL_K]
			  and U25.ARWU17_BOM_SUB_ASSY_K      = V08a.ARWU17_BOM_SUB_ASSY_K
		      and U25.[ARWU19_DSGN_PART_K]       = V08a.[ARWU19_DSGN_PART_K]
          )
/*		  	   
		  (SELECT U25.[ARWU08_CCTSS_DSGN_SUPL_K] 
	             ,u25.[ARWU19_DSGN_PART_K]
			     ,v08b.[ARWU18_BOM_PART_IX_N]
             FROM [dbo].[PARWU25_RAW_MTRL_COST]  U25
			 Join [PARWV08_CCS_SUPL_QUOTE_FLAT] V08b
	           ON U25.[ARWU08_CCTSS_DSGN_SUPL_K] = v08b.[ARWU08_CCTSS_DSGN_SUPL_K]
		      and U25.[ARWU19_DSGN_PART_K]       = V08b.[ARWU19_DSGN_PART_K]
			  and v08a.[ARWU18_BOM_PART_IX_N]    = v08b.[ARWU18_BOM_PART_IX_N]
          )
*/
	   )
 	) Err
;


GO
