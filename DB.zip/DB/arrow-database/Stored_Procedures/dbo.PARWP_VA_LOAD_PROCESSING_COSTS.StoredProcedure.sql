SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 08/01/2019
-- Description:	load ARROW U68 processing design costs table 
--              deletes are in PARWP_VA_LOAD_ADJUSTMENT_DETAILS procedure
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08/26/2019  ashaik12           Added join on User_selected_WALK_VRNT_X
-- 08/27/2019  ashaik12           Added ARWU04_CCTSS_VRNT_K in join to U65 table
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 05/13/2020  rwesley2	 US1600015 VA multitab changes
-- 06/30/2022  ASHAIK12  US3778477 Add cost_type filter to filter out the improvement idea records
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VA_LOAD_PROCESSING_COSTS]
-- Input Parameter
@GUID          Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

-------U68 INSERT

INSERT INTO PARWU68_PROCG_VRNT_ADJ
SELECT 
       --ARWU68_PROCG_VRNT_ADJ_K Identity key
	   u09_view.[ARWU09_CCTSS_VRNT_SUPL_K]  as ARWU09_CCTSS_VRNT_SUPL_K
      ,S52.row_idx   as ARWU68_PROCG_COST_DSPLY_SEQ_R
      ,[ARWU65_CCTSS_VRNT_ADJ_K]                      as ARWU65_CCTSS_VRNT_ADJ_K
      ,IsNULL(S52.operation_index,'')                 as ARWU68_PROCG_OPER_IX_C
      ,IsNULL(S52.operation_desc,'')                  as ARWU68_PROCG_OPER_X

	  ,Case When A28.ARWA28_CNTRY_K is Null then 
		         A28_EmptyStr.ARWA28_CNTRY_K 
			Else A28.ARWA28_CNTRY_K 
	   End as ARWA28_MFG_LOC_CNTRY_K

      ,A29.ARWA29_CRCY_K                              as ARWA29_LCL_CRCY_K
      ,IsNULL(S52.machine_make_model,'')              as ARWU68_MACH_MAKE_MDL_X
      ,CASE WHEN s52.capital_exp_for_machine = '' then '0.00'
	        else ltrim(rtrim(CAST(s52.capital_exp_for_machine as decimal (28,9))) )     
	   END AS ARWU68_CPTL_EXPNDTR_FOR_MACH_A
	  ,CASE WHEN s52.machine_size = '' then  '0.00'
	        ELSE ltrim(rtrim(CAST(s52.machine_size as decimal (19,9))   ))
       END AS ARWU68_MACH_SIZE_IN_MET_TN_Q
	  ,IsNull(S52.no_of_pieces_per_subassy,0)         as ARWU68_PCE_PER_SUB_ASSY_Q
      ,IsNULL(S52.no_of_pieces_per_cycle,0)           as ARWU68_PCS_PER_CYC_Q
      ,IsNULL(S52.cycle_time_sec,0)                   as ARWU68_CYC_TIME_IN_SEC_Q
      ,IsNULL(S52.machinehourly_operation_overhead,0) as ARWU68_MACH_OPER_OVRHD_HRLY_A
      ,IsNULL(S52.direct_headcount,0)                 as ARWU68_DIR_HDCNT_Q
      ,IsNULL(S52.direct_hourly_labor_headcount,0)    as ARWU68_DIR_HRLY_LBR_HDCNT_A
      ,IsNULL(S52.indirect_labor_costs,0)             as ARWU68_INDIR_LBR_PER_DIR_P
      ,IsNULL(S52.fringes,0)                          as ARWU68_FRNG_PER_DIR_LBR_P
      ,IsNULL(S52.packaging_costs,0)                  as ARWU68_PKNG_COST_PER_PCE_A
      ,IsNULL(S52.logistics_cost,0)                   as ARWU68_LGSTCS_COST_PER_PCE_A
      ,IsNULL(S52.tax_duty_per_piece,0)               as ARWU68_TAX_AND_DUTY_PER_PCE_A
      ,IsNULL(S52.licensing_costs,0)                  as ARWU68_LICSNG_COST_PER_PCE_A
      ,IsNULL(S52.comments,'')                        as ARWU68_PROCG_ASSMP_CMT_X
      ,@TIME_STAMP                                   as ARWU68_CREATE_S
      ,@CDSID                                         as ARWU68_CREATE_USER_C                              
      ,@TIME_STAMP                                   as ARWU68_LAST_UPDT_S
      ,@CDSID                                         as ARWU68_LAST_UPDT_USER_C                              
   From [dbo].[PARWS45_VA_COVER_PAGE_INFO]       S45 
  JOIN  [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] S52
    ON S52.Processing_ID       = S45.Processing_ID
   AND S52.filename            = S45.filename
   
 -- Join with Supplier Qoute View
   JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view
    ON S45.Eng_SubCommodity_name        = u09_view.[ARWA03_ENRG_SUB_CMMDTY_X]
   AND S45.User_Selected_CTSP_N         = u09_view.ARWU31_CTSP_N
   AND S45.User_Selected_CTSP_Region_C  = u09_view.[ARWA06_RGN_C]
   AND S45.User_Selected_BNCMK_VRNT_N   = u09_view.[ARWU01_BNCHMK_VRNT_N]     --BoB variant
   AND S45.User_Selected_SUPL_N         = u09_view.ARWA17_SUPL_N
   AND S45.User_Selected_SUPL_CNTRY_N   = u09_view.ARWA28_CNTRY_N
   AND S45.User_Selected_SUPL_C         = u09_view.ARWA17_SUPL_C
   AND S45.User_selected_WALK_VRNT_X    = u09_view.ARWU04_VRNT_N

--Design Adjustment Part
      Join [dbo].[PARWU65_CCTSS_VRNT_ADJ]   U65
        ON U65.ARWU04_CCTSS_VRNT_K = u09_view.ARWU04_CCTSS_VRNT_K
       AND U65.[ARWU65_CCTSS_VRNT_ADJ_ID_N] = S52.change_id
--Currency   
      JOIN dbo.PARWA29_CRCY  A29          ON A29.ARWA29_CRCY_C = s52.local_currency
--Manufacturing Location
 Left JOIN dbo.PARWA28_CNTRY A28          ON A28.ARWA28_CNTRY_N               = s52.manufacturing_location
      JOIN dbo.PARWA28_CNTRY A28_EmptyStr ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

Where S45.Processing_ID             = @GUID
  AND S45.Skip_loading_due_to_error_f = 0
  AND S52.cost_type='Adjustment Costs'
;

GO
