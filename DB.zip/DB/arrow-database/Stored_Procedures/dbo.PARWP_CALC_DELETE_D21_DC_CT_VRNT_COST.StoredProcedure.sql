SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASOLOSKY
-- Create date: 12/20/2021
-- Description:	Procedure to Delete the PARWD21_DC_CT_VRNT_COST table based on the STUDY passed in
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_DELETE_D21_DC_CT_VRNT_COST]
@ARWU01_CCTSS_K        int
--@T06_CCTSS_DSGN  [dbo].[PARWT06_CCTSS_DSGN] READONLY
AS

--Declare @Start_Time DATETIME = GETUTCDATE();
Begin
  Delete PARWD21_DC_CT_VRNT_COST
   Where ARWU01_CCTSS_K  = @ARWU01_CCTSS_K 
  ;
--  Select QUOTENAME(OBJECT_NAME(@@PROCID))           as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
