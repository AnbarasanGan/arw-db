DROP PROCEDURE IF EXISTS  [dbo].[PARWP_TYGRA_UI_LOAD_UB1_PROC_TBL] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load UB1 from PARWP05_TYGRA_LOAD 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2	  4-06-2021   added check for attempted insert of a file already loaded
-- rwesley2   4-20-2021   U2453456 use MAX length when declaring a variable   
-- rwesley2   4-20-2021   US2456552 remove hard-coded cdsid
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- ASHAIK12   06-16-2021  US2628806 Use fl.BCJU41_ProgramNm to load into [ARWUB1_TYGRA_FILE_PGM_N], no join to U31 table to get program name,
--                        Program name in ACT does not match program name in ARROW
-- rwesley2	  07-29-2021  US2747200 replace global temp table with processing table
--                        changed global temp to local temp. renamed SP because it can only be used with the new
--                        SP using the processing table. These SPs end wtih _PROC_TBL. Will not work the old process
--rwesley2    09-02-2021  US2844309, DE230299 - when processing from ARROW the UB1 table is not loaded.  However, the P05 still needs
--                        to be updated with the ARWUB1_TYGRA_FILE_K.  Added an update to the GOTO SKIPUB1LOAD section. 
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_UB1_PROC_TBL] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@processing_id varchar(max)
--@programnm varchar(max) = 'template'

AS

SET NOCOUNT ON;

--******************************************************
-- in UI user selects a single file to load to ARROW.  UI passes in file_name and version
-- 
 --******************************************************

--***************************************
-- check file source. if ACT then load UB1. if Arrow UB1 table, go to end of job label = SKIPUB1LOAD
--***************************************
DECLARE @skipub1load varchar(max) = (select File_source
from PARWP05_TYGRA_LOAD p05
where p05.processing_id = @processing_id) ;

select @skipub1load

Begin
If @skipub1load = 'ARROW'
GOTO SKIPUB1LOAD
END

 --***************************************
-- check if the Tygra file has already been loaded
--***************************************

declare @dup_insert int = (select  count(*)
from PARWUB1_TYGRA_FILE  ub1
join PARWP05_TYGRA_LOAD p05
on ub1.[ARWUB1_TYGRA_FILE_N] = p05.BCJU41_FileNameSPTygra
and ub1.[ARWUB1_REV_S] = p05.BCJU41_TygraSPFileLastModifiedDtTm
where ARWUB1_TYGRA_FILE_PGM_N = p05.BCJU41_ProgramNm
and p05.Processing_ID = @processing_id
and p05.File_source = 'ACT'
group by ub1.[ARWUB1_TYGRA_FILE_N])

select @dup_insert

begin
if @dup_insert is null 
  set @dup_insert = 0 
end

Begin
If @dup_insert > 0 
GOTO dupub1
END


-- load UB1
MERGE INTO PARWUB1_TYGRA_FILE UB1
USING (
select * from (
select 
p05.BCJU41_ProgramNm as ARWUB1_TYGRA_FILE_PGM_N
,p05.ARWA54_TYGRA_FILE_TYPE_K as ARWA54_TYGRA_FILE_TYPE_K
,1 as [ARWA55_TYGRA_FILE_VER_K]   -- default to 1 as we don't care about template version
,p05.BCJU41_FileNameSPTygra         as ARWUB1_TYGRA_FILE_N
,GETUTCDATE() as [ARWUB1_CREATE_S]
,p05.[CREATE_USER_C] as [ARWUB1_CREATE_USER_C]
,GETUTCDATE() as [ARWUB1_LAST_UPDT_S]
,p05.[CREATE_USER_C] as [ARWUB1_LAST_UPDT_USER_C]
,p05.BCJU51_VERSION_F as [ARWUB1_TYGRA_FILE_REV_R]  
,p05.BCJU41_WRKSHP_NUM_C   as ARWUB1_WRKSHP_N 
,p05.BCJU41_WRKSHP_STATUS_C  as ARWUB1_REV_STAT_N
,p05.[BCJU41_TygraSPFileLastModifiedDtTm]             as [ARWUB1_REV_S]   
from PARWP05_TYGRA_LOAD p05
where p05.Processing_ID = @processing_id
)x
)y
on ub1.[ARWUB1_TYGRA_FILE_N] = y.[ARWUB1_TYGRA_FILE_N]
and ub1.[ARWUB1_REV_S] = y.[ARWUB1_REV_S]
When NOT MATCHED THEN
     INSERT 
     VALUES (
	 y.ARWUB1_TYGRA_FILE_PGM_N
	 ,y.ARWA54_TYGRA_FILE_TYPE_K
     ,y.ARWA55_TYGRA_FILE_VER_K
     ,y.ARWUB1_TYGRA_FILE_N
     ,y.ARWUB1_TYGRA_FILE_REV_R  
     ,y.ARWUB1_WRKSHP_N 
     ,y.ARWUB1_REV_STAT_N
     ,y.ARWUB1_REV_S
     ,y.ARWUB1_CREATE_S
     ,y.ARWUB1_CREATE_USER_C
     ,y.ARWUB1_LAST_UPDT_S
     ,y.ARWUB1_LAST_UPDT_USER_C
	 )   
	 ; 

update PARWP05_TYGRA_LOAD
set ARWUB1_TYGRA_FILE_K = (select ub1.ARWUB1_TYGRA_FILE_K from PARWUB1_TYGRA_FILE ub1
                           join PARWP05_TYGRA_LOAD p05
                           on ub1.ARWUB1_TYGRA_FILE_N = p05.BCJU41_FileNameSPTygra
                           and ub1.ARWUB1_TYGRA_FILE_REV_R = p05.BCJU51_VERSION_F
                           and ub1.ARWA54_TYGRA_FILE_TYPE_K = p05.ARWA54_TYGRA_FILE_TYPE_K
						   and ub1.ARWUB1_TYGRA_FILE_PGM_N = p05.BCJU41_ProgramNm
                           where p05.Processing_ID = @processing_id);


select 'UB1 loaded'
GOTO EOJ

DUPUB1: select 'Attempleted to load a duplicate UB1 file.  File was not loaded.';
GOTO EOJ

SKIPUB1LOAD: select 'skipped ub1 load';
update PARWP05_TYGRA_LOAD
set ARWUB1_TYGRA_FILE_K = (select ub1.ARWUB1_TYGRA_FILE_K from PARWUB1_TYGRA_FILE ub1
                           join PARWP05_TYGRA_LOAD p05
                           on ub1.ARWUB1_TYGRA_FILE_N = p05.BCJU41_FileNameSPTygra
                           and ub1.ARWUB1_TYGRA_FILE_REV_R = p05.BCJU51_VERSION_F
                           and ub1.ARWA54_TYGRA_FILE_TYPE_K = p05.ARWA54_TYGRA_FILE_TYPE_K
						   and ub1.ARWUB1_TYGRA_FILE_PGM_N = p05.BCJU41_ProgramNm
                           where p05.Processing_ID = @processing_id);


EOJ: select 'EOJ'


GO



