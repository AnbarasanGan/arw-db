SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		asamriya
-- Create date: 07/31/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 08/26/2019  ashaik12            Added join on User_selected_WALK_VRNT_X
-- 08/28/2019  Asolosky  US1154597 Changed UoM from a _K column to a description column to handle text. 
--                                 Removed join on the PARWA27_UOM table.
-- 01/14/2020  Ashaik12            Added Time_Stamp parameter and removed filter on Processing Status
-- 05/13/2020  rwesley2	 US1600015 VA multitab changes
-- 06/30/2022  ASHAIK12  US3778477 Add cost_type filter to filter out the improvement idea records
-- ==============================================
CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VA_LOAD_RAW_MTRLS] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO PARWU67_RAW_MTRL_VRNT_ADJ
SELECT --ARWU67_RAW_MTRL_VRNT_ADJ_K is an identity 
       U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K                      AS ARWU09_CCTSS_VRNT_SUPL_K
	  ,S51.row_idx AS ARWU67_RAW_MTRL_DSPLY_SEQ_R
      ,U65.ARWU65_CCTSS_VRNT_ADJ_K           AS ARWU65_CCTSS_VRNT_ADJ_K
	  ,S51.material_specification            AS ARWU67_RAW_MTRL_SPEC_X
	  ,S51.source_supplier                   AS ARWU67_SRC_SUPL_N

	  ,Case When A28.ARWA28_CNTRY_K is Null then A28_EmptyStr.ARWA28_CNTRY_K Else A28.ARWA28_CNTRY_K  End AS ARWA28_SRC_CNTRY_K

	  ,A29.ARWA29_CRCY_K                     AS ARWA29_LCL_CRCY_K
	  ,S51.no_of_pieces                      AS ARWU67_PCE_PER_SUB_ASSY_Q
	  ,S51.uom                               AS ARWU67_RAW_MTRL_UOM_X
	  ,S51.gross_usage_per_piece             AS ARWU67_GRS_USG_PER_PCE_Q
	  ,IsNULL(S51.[material_price],0)        AS ARWU67_MTRL_PEL_RATE_PER_UOM_A  
      ,IsNULL(S51.inbound_packaging_costs,0) AS ARWU67_INBND_PKNG_COST_UOM_A
      ,IsNULL(S51.inbound_logistics_costs,0) AS ARWU67_INBND_LGSTCS_COST_UOM_A
      ,IsNULL(S51.tax_duty_per_uom,0)        AS ARWU67_TAX_AND_DUTY_PER_UOM_A
      ,IsNULL(S51.reclamation_pcntg,0)       AS ARWU67_RCLMTN_P
      ,IsNULL(S51.scrap_price,0)             AS ARWU67_SCRAP_PRCE_PER_UOM_A
      ,IsNULL(S51.comments,0)                AS ARWU67_RAW_MTRL_ASSMP_CMT_X
	  ,@TIME_STAMP                          AS ARWU67_CREATE_S
	  ,@CDSID                                AS ARWU67_CREATE_USER_C
	  ,@TIME_STAMP                          AS ARWU67_LAST_UPDT_S
	  ,@CDSID                                AS ARWU67_LAST_UPDT_USER_C

  From PARWS45_VA_COVER_PAGE_INFO     S45  
  JOIN PARWS51_VA_RAW_MATERIALS_INFO  S51
    ON S51.Processing_ID       = S45.Processing_ID
   AND S51.filename            = S45.filename

 -- Join with Supplier Quote View
    JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]   U09_VRNT
    ON S45.Eng_SubCommodity_name        = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
   AND S45.User_Selected_CTSP_N         = U09_VRNT.ARWU31_CTSP_N
   AND S45.User_Selected_CTSP_Region_C  = U09_VRNT.ARWA06_RGN_C
   AND S45.User_Selected_BNCMK_VRNT_N   = U09_VRNT.ARWU01_BNCHMK_VRNT_N      --BoB variant
   AND S45.User_Selected_SUPL_N         = U09_VRNT.ARWA17_SUPL_N
   AND S45.User_Selected_SUPL_CNTRY_N   = U09_VRNT.ARWA28_CNTRY_N
   AND S45.User_Selected_SUPL_C         = U09_VRNT.ARWA17_SUPL_C
   AND S45.User_selected_WALK_VRNT_X    = U09_VRNT.ARWU04_VRNT_N

--Design Adjustment Part
  Join PARWU65_CCTSS_VRNT_ADJ  U65  -- U37 
    ON U65.ARWU04_CCTSS_VRNT_K         = U09_VRNT.ARWU04_CCTSS_VRNT_K
   And U65.ARWU65_CCTSS_VRNT_ADJ_ID_N  = S51.change_id  
 --Currency
  JOIN PARWA29_CRCY      A29           ON S51.local_currency   = A29.ARWA29_CRCY_C
 --Source-Country
 Left JOIN PARWA28_CNTRY A28           ON S51.source_country   = A28.ARWA28_CNTRY_N
  JOIN PARWA28_CNTRY     A28_EmptyStr  ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

  Where S45.Processing_ID               = @GUIDIN
	AND S45.Skip_loading_due_to_error_f = 0
	AND S51.cost_type='Adjustment Costs'
;


GO
