SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		asamriya
-- Create date: 07/30/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08/26/2019 Ashaik12            Fixed filter condition for Final Assembly Load
-- 08/26/2019  ashaik12           Added join on User_selected_WALK_VRNT_X
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 05/13/2020  rwesley2	 US1600015 VA multitab changes
-- 06/30/2022  ASHAIK12  US3778477 Add cost_type filter to filter out the improvement idea records
-- =============================================
CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VA_LOAD_ASSEMBLY] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO PARWU69_ASSY_VRNT_ADJ       --  PARWU41_ASSY_DSGN_ADJ
SELECT
       U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K                     AS ARWU09_CCTSS_VRNT_SUPL_K
	  ,ASSEMBLY_STAGE.row_idx                                AS ARWU69_ASSY_COST_DSPLY_SEQ_R
	  ,U65.ARWU65_CCTSS_VRNT_ADJ_K                           AS ARWU65_CCTSS_VRNT_ADJ_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')             AS ARWU69_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')              AS ARWU69_ASSY_OPER_X
	  
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_OPER_LOC_CNTRY_K
	   
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_LCL_CRCY_K 

	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU69_MACH_MAKE_MDL_X
      ,CASE WHEN ASSEMBLY_STAGE.capital_exp_for_machine = '' then '0.00'
	        else ltrim(rtrim(CAST(ASSEMBLY_STAGE.capital_exp_for_machine as decimal (28,9))) )     
	   END AS ARWU69_CPTL_EXPNDTR_FOR_MACH_A
	  ,CASE WHEN ASSEMBLY_STAGE.machine_size = '' then  '0.00'
	        ELSE ltrim(rtrim(CAST(ASSEMBLY_STAGE.machine_size as decimal (19,9))   ))
       END AS ARWU69_MACH_SIZE_IN_MET_TN_Q 
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU69_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU69_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU69_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU69_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU69_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU69_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU69_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU69_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU69_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU69_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWU69_CREATE_S
	  ,@CDSID                                                    AS ARWU69_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWU69_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU69_LAST_UPDT_USER_C

       From PARWS53_VA_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
        JOIN dbo.PARWS45_VA_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename

  JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]    U09_VRNT
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U09_VRNT.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U09_VRNT.ARWA06_RGN_C
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U09_VRNT.ARWU01_BNCHMK_VRNT_N
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U09_VRNT.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U09_VRNT.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U09_VRNT.ARWA28_CNTRY_N
		 AND COVER_PAGE_STAGE.User_selected_WALK_VRNT_X          = U09_VRNT.ARWU04_VRNT_N

  JOIN [dbo].[PARWU65_CCTSS_VRNT_ADJ]   U65   -- U37
       ON U09_VRNT.ARWU04_CCTSS_VRNT_K = U65.ARWU04_CCTSS_VRNT_K
	   AND ASSEMBLY_STAGE.change_id = U65.ARWU65_CCTSS_VRNT_ADJ_ID_N
  

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency=CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
       JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''

  Where cover_page_stage.Processing_ID               = @GUIDIN
  AND ASSEMBLY_STAGE.sub_assembly_name <> 'Adjustment Final Assembly'
    And cover_page_stage.Skip_loading_due_to_error_f = 0
    AND ASSEMBLY_STAGE.cost_type='Adjustment Costs'
;
----------------------------------------------------------------------------------------------------- 
--Final Assembly
-----------------------------------------------------------------------------------------------------

INSERT INTO PARWU71_FNL_ASSY_VRNT_ADJ             -- PARWU43_FNL_ASSY_DSGN_ADJ
SELECT  
       U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K                         AS ARWU09_CCTSS_VRNT_SUPL_K
      ,ASSEMBLY_STAGE.row_idx                                    AS ARWU71_FNLASSYCOST_DSPLY_SEQ_R
	  ,U65.ARWU65_CCTSS_VRNT_ADJ_K                               AS ARWU65_CCTSS_VRNT_ADJ_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')                 AS ARWU71_FNL_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')                  AS ARWU71_FNL_ASSY_OPER_X
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_OPER_LOC_CNTRY_K
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_LCL_CRCY_K 
	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU71_MACH_MAKE_MDL_X
      ,CASE WHEN ASSEMBLY_STAGE.capital_exp_for_machine = '' then '0.00'
	        else ltrim(rtrim(CAST(ASSEMBLY_STAGE.capital_exp_for_machine as decimal (28,9))) )     
	   END AS ARWU71_CPTL_EXPNDTR_FOR_MACH_A
	  ,CASE WHEN ASSEMBLY_STAGE.machine_size = '' then  '0.00'
	        ELSE ltrim(rtrim(CAST(ASSEMBLY_STAGE.machine_size as decimal (19,9))   ))
       END AS ARWU71_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU71_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU71_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU71_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU71_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU71_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU71_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU71_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU71_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU71_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU71_FNL_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWU71_CREATE_S
	  ,@CDSID                                                    AS ARWU71_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWU71_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU71_LAST_UPDT_USER_C
  From PARWS53_VA_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN dbo.PARWS45_VA_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename


   JOIN  [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]   U09_VRNT
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = U09_VRNT.[ARWA03_ENRG_SUB_CMMDTY_X]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U09_VRNT.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U09_VRNT.[ARWA06_RGN_C]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U09_VRNT.ARWU01_BNCHMK_VRNT_N
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U09_VRNT.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U09_VRNT.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U09_VRNT.ARWA28_CNTRY_N
	  AND COVER_PAGE_STAGE.User_selected_WALK_VRNT_X          = U09_VRNT.ARWU04_VRNT_N

	   JOIN [dbo].[PARWU65_CCTSS_VRNT_ADJ] U65   -- U37 
	   ON U65.ARWU04_CCTSS_VRNT_K = U09_VRNT.ARWU04_CCTSS_VRNT_K
	   AND U65.ARWU65_CCTSS_VRNT_ADJ_ID_N = ASSEMBLY_STAGE.change_id

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency = CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''
  Where cover_page_stage.Processing_ID               = @GUIDIN
    And cover_page_stage.Skip_loading_due_to_error_f = 0
	And ASSEMBLY_STAGE.sub_assembly_name             = 'Adjustment Final Assembly'
;

GO
