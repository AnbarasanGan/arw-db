DROP PROCEDURE [dbo].[PARWP_DACT_LOAD_U73_SUPL_DSGN]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 07/16/2019
-- Description:	Load data from the DA Consolidation Tool Views to the final table
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08/20/2019  ASHAIK12           fixed isNull in select , union to union all and left outer join on V20
-- 09/05/2019  asolosky           Moved the delete to procedure PARWP_DAII_LOAD_ADJUSTMENT_DETAILS
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DACT_LOAD_U73_SUPL_DSGN] 
-- Input Parameter
@CCTSS_K Int,
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO PARWU73_SUPL_DSGN_ADJ
Select CCT_PART_SUPPLIER_Sum.ARWU08_CCTSS_DSGN_SUPL_K                          AS [ARWU08_CCTSS_DSGN_SUPL_K]
      ,CCT_PART_SUPPLIER_Sum.[ARWU37_CCTSS_DSGN_ADJ_K]                         AS [ARWU37_CCTSS_DSGN_ADJ_K]
	  ,Pur_Qty                                                                 AS [ARWU73_PURC_PART_Q]
	  ,Purch_Cost                                                              AS [ARWU73_PURC_PART_TOT_A]
	  ,Pur_Tier2_MarkUp                                                        AS [ARWU73_PURC_PART_MRKP_A]
	  ,Purch_Total_Cost                                                        AS [ARWU73_PURC_PART_TOT_W_MRKP_A]
	  ,Raw_Qty                                                                 AS [ARWU73_RAW_MTRL_Q]
      ,Raw_Cost                                                                AS [ARWU73_RAW_MTRL_TOT_A]
	  ,Pro_Qty                                                                 AS [ARWU73_PROC_Q]
	  ,Pro_Direct_Labor                                                        AS [ARWU73_PROC_DIR_LBR_A]
	  ,Pro_Direct_Fringe                                                       AS [ARWU73_PROC_DIR_FRNG_A]
	  ,Pro_InDirect_Labor                                                      AS [ARWU73_PROC_INDIR_LBR_A]
	  ,Pro_InDirect_Fringe                                                     AS [ARWU73_PROC_INDIR_FRNG_A]
	  ,Pro_Overhead                                                            AS [ARWU73_PROC_OVRHD_A]
	  ,Pro_Misc                                                                AS [ARWU73_PROC_MISC_A]
	  ,Pro_Total_Cost                                                          AS [ARWU73_PROC_TOT_A]
	  ,Purch_Total_Cost + ((Raw_Cost + Pro_Total_Cost) * (1+IsNull(V20.COMPOUNDED_TOTAL,0))) AS [ARWU73_DSGN_PART_TOT_W_MRKP_A]
	  ,Direct_Labor                                                            AS [ARWU73_ASSY_DIR_LBR_A]
	  ,Direct_Fringe                                                           AS [ARWU73_ASSY_DIR_FRNG_A]
	  ,Indirect_Labor                                                          AS [ARWU73_ASSY_INDIR_LBR_A]
	  ,Indirect_Fringe                                                         AS [ARWU73_ASSY_INDIR_FRNG_A]
	  ,Overhead                                                                AS [ARWU73_ASSY_OVRHD_A]
	  ,Misc                                                                    AS [ARWU73_ASSY_MISC_A]
	  ,Sub_Assy_total                                                          AS [ARWU73_ASSY_TOT_A]
	  ,Sub_Assy_total * (1+IsNull(V20.COMPOUNDED_TOTAL,0))                     AS [ARWU73_ASSY_TOT_W_MRKP_A]
	  ,Final_Direct_Labor                                                      AS [ARWU73_FNL_ASSY_DIR_LBR_A]
	  ,Final_Direct_Fringe                                                     AS [ARWU73_FNL_ASSY_DIR_FRNG_A]
	  ,Final_Indirect_Labor                                                    AS [ARWU73_FNL_ASSY_INDIR_LBR_A]
	  ,Final_Indirect_Fringe                                                   AS [ARWU73_FNL_ASSY_INDIR_FRNG_A]
	  ,Final_Overhead                                                          AS [ARWU73_FNL_ASSY_OVRHD_A]
	  ,Final_Misc                                                              AS [ARWU73_FNL_ASSY_MISC_A]
	  ,Final_Sub_Assy_Total                                                    AS [ARWU73_FNL_ASSY_TOT_A]
	  ,Final_Sub_Assy_Total* (1+IsNull(V21.COMPOUNDED_TOTAL,0))                AS [ARWU73_FNL_ASSY_TOT_W_MRKP_A]
      ,@TIME_STAMP                                                            AS [ARWU73_CREATE_S]
	  ,@CDSID                                                                  AS [ARWU73_CREATE_USER_C]
	  ,@TIME_STAMP                                                            AS [ARWU73_LAST_UPDT_S]
	  ,@CDSID                                                                  AS [ARWU73_LAST_UPDT_USER_C]
  From
(
Select CCT_PART_SUPPLIER.ARWU01_CCTSS_K            AS ARWU01_CCTSS_K
      ,CCT_PART_SUPPLIER.[ARWU37_CCTSS_DSGN_ADJ_K] AS ARWU37_CCTSS_DSGN_ADJ_K
      ,CCT_PART_SUPPLIER.ARWU08_CCTSS_DSGN_SUPL_K  AS ARWU08_CCTSS_DSGN_SUPL_K 
	  ,CCT_PART_SUPPLIER.[ARWU17_BOM_SUB_ASSY_K]   AS ARWU17_BOM_SUB_ASSY_K
	  ,Sum(Pur_Qty)                                as Pur_Qty
	  ,Sum(Purch_Cost)                             as Purch_Cost
	  ,Sum(Pur_Tier2_MarkUp)                       as Pur_Tier2_MarkUp
	  ,Sum([Purch_Total_Cost])                     as Purch_Total_Cost
	  ,Sum(Raw_Qty)                                as Raw_Qty
      ,Sum(Raw_Cost)                               as Raw_Cost
	  ,Sum(Pro_Qty)                                as Pro_Qty
	  ,Sum(Pro_Direct_Labor)                       as Pro_Direct_Labor
	  ,Sum(Pro_Direct_Fringe)                      as Pro_Direct_Fringe
	  ,Sum(Pro_InDirect_Labor)                     as Pro_InDirect_Labor
	  ,Sum(Pro_InDirect_Fringe)                    as Pro_InDirect_Fringe
	  ,Sum(Pro_Overhead)                           as Pro_Overhead   
	  ,Sum(Pro_Misc)                               as Pro_Misc
	  ,Sum(Pro_Total_Cost)                         as Pro_Total_Cost
	  ,SUM(Direct_Labor)                           AS Direct_Labor  
	  ,SUM(Direct_Fringe)                          AS Direct_Fringe
	  ,SUM(Indirect_Labor)                         AS Indirect_Labor
	  ,SUM(Indirect_Fringe)                        AS Indirect_Fringe
	  ,SUM(Overhead)	                           AS Overhead
	  ,SUM(Misc)		                           AS Misc
	  ,SUM(Sub_Assy_total)                         AS Sub_Assy_total
	  ,SUM(Final_Direct_Labor)                     AS Final_Direct_Labor
	  ,SUM(Final_Direct_Fringe)		               AS Final_Direct_Fringe
	  ,SUM(Final_Indirect_Labor)	               AS Final_Indirect_Labor
	  ,SUM(Final_Indirect_Fringe)	               AS Final_Indirect_Fringe
	  ,SUM(Final_Overhead)			               AS Final_Overhead
	  ,SUM(Final_Misc)				               AS Final_Misc
	  ,SUM(Final_Sub_Assy_Total)	               AS Final_Sub_Assy_Total
  From
(
Select ARWU01_CCTSS_K
      ,ARWU37_CCTSS_DSGN_ADJ_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
	  ,[ARWU17_BOM_SUB_ASSY_K]
	  ,Pur_Qty         
	  ,Purch_Cost       
	  ,Pur_Tier2_MarkUp
	  ,Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,0                               AS Pro_Qty 
	  ,0                               AS Pro_Direct_Labor   
	  ,0                               AS Pro_Direct_Fringe  
	  ,0                               AS Pro_InDirect_Labor
	  ,0                               AS Pro_InDirect_Fringe
	  ,0                               AS Pro_Overhead  
	  ,0                               AS Pro_Misc
	  ,0                               AS Pro_Total_Cost
	  ,0                               AS Direct_Labor
      ,0                               AS Direct_Fringe
      ,0                               AS Indirect_Labor
      ,0                               AS Indirect_Fringe
      ,0                               AS Overhead
      ,0                               AS Misc
	  ,0                               AS Sub_Assy_total
	  ,0                               AS Final_Direct_Labor
	  ,0                               AS Final_Direct_Fringe
	  ,0                               AS Final_Indirect_Labor
	  ,0                               AS Final_Indirect_Fringe
	  ,0                               AS Final_Overhead
	  ,0                               AS Final_Misc
	  ,0                               AS Final_Sub_Assy_Total
  From PARWV40_DACT_PART_SUPPLIER_PURCHPART
 Where ARWU01_CCTSS_K = @CCTSS_K
Union ALL
Select ARWU01_CCTSS_K
      ,ARWU37_CCTSS_DSGN_ADJ_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
	  ,[ARWU17_BOM_SUB_ASSY_K]
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
      ,Raw_Qty  
      ,Raw_Cost
	  ,0                               AS Pro_Qty 
	  ,0                               AS Pro_Direct_Labor   
	  ,0                               AS Pro_Direct_Fringe  
	  ,0                               AS Pro_InDirect_Labor
	  ,0                               AS Pro_InDirect_Fringe
	  ,0                               AS Pro_Overhead  
	  ,0                               AS Pro_Misc
	  ,0                               AS Pro_Total_Cost
	  ,0                               AS Direct_Labor
      ,0                               AS Direct_Fringe
      ,0                               AS Indirect_Labor
      ,0                               AS Indirect_Fringe
      ,0                               AS Overhead
      ,0                               AS Misc
	  ,0                               AS Sub_Assy_total
	  ,0                               AS Final_Direct_Labor
	  ,0                               AS Final_Direct_Fringe
	  ,0                               AS Final_Indirect_Labor
	  ,0                               AS Final_Indirect_Fringe
	  ,0                               AS Final_Overhead
	  ,0                               AS Final_Misc
	  ,0                               AS Final_Sub_Assy_Total
  From PARWV41_DACT_PART_SUPPLIER_RAW
 Where ARWU01_CCTSS_K = @CCTSS_K
Union ALL
Select ARWU01_CCTSS_K
      ,ARWU37_CCTSS_DSGN_ADJ_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
	  ,[ARWU17_BOM_SUB_ASSY_K]
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,Pro_Qty             
	  ,Pro_Direct_Labor    
	  ,Pro_Direct_Fringe   
	  ,Pro_InDirect_Labor  
	  ,Pro_InDirect_Fringe 
	  ,Pro_Overhead        	   
	  ,Pro_Misc            
	  ,Pro_Total_Cost      
	  ,0                                AS Direct_Labor
      ,0                                AS Direct_Fringe
      ,0                                AS Indirect_Labor
      ,0                                AS Indirect_Fringe
      ,0                                AS Overhead
      ,0                                AS Misc
	  ,0                                AS Sub_Assy_total
	  ,0                                AS Final_Direct_Labor
	  ,0                                AS Final_Direct_Fringe
	  ,0                                AS Final_Indirect_Labor
	  ,0                                AS Final_Indirect_Fringe
	  ,0                                AS Final_Overhead
	  ,0                                AS Final_Misc
	  ,0                                AS Final_Sub_Assy_Total
  From [dbo].[PARWV42_DACT_PART_SUPPLIER_PROCESS]
 Where ARWU01_CCTSS_K = @CCTSS_K

 Union ALL
 select
       ARWU01_CCTSS_K
      ,ARWU37_CCTSS_DSGN_ADJ_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
	  ,[ARWU17_BOM_SUB_ASSY_K]
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,0                               AS Pro_Qty             
	  ,0                               AS Pro_Direct_Labor    
	  ,0                               AS Pro_Direct_Fringe   
	  ,0                               AS Pro_InDirect_Labor  
	  ,0                               AS Pro_InDirect_Fringe 
	  ,0                               AS Pro_Overhead        	   
	  ,0                               AS Pro_Misc            
	  ,0                               AS Pro_Total_Cost      
      ,Direct_Labor
      ,Direct_Fringe
      ,Indirect_Labor
      ,Indirect_Fringe
      ,Overhead
      ,Misc
      ,(Direct_Labor+Direct_Fringe+Indirect_Labor+Indirect_Fringe+Overhead+Misc) as Sub_Assy_total
	  ,0                                                                         AS Final_Direct_Labor
	  ,0                                                                         AS Final_Direct_Fringe
	  ,0                                                                         AS Final_Indirect_Labor
	  ,0                                                                         AS Final_Indirect_Fringe
	  ,0                                                                         AS Final_Overhead
	  ,0                                                                         AS Final_Misc
	  ,0                                                                         AS Final_Sub_Assy_Total
  FROM PARWV43_DACT_ASSEMBLY 
   Where ARWU01_CCTSS_K = @CCTSS_K

   Union ALL
 select
       ARWU01_CCTSS_K
      ,ARWU37_CCTSS_DSGN_ADJ_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
	  ,[ARWU17_BOM_SUB_ASSY_K]
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,0                               AS Pro_Qty             
	  ,0                               AS Pro_Direct_Labor    
	  ,0                               AS Pro_Direct_Fringe   
	  ,0                               AS Pro_InDirect_Labor  
	  ,0                               AS Pro_InDirect_Fringe 
	  ,0                               AS Pro_Overhead        	   
	  ,0                               AS Pro_Misc            
	  ,0                               AS Pro_Total_Cost      
      ,0                               AS Direct_Labor
      ,0                               AS Direct_Fringe
      ,0                               AS Indirect_Labor
      ,0                               AS Indirect_Fringe
      ,0                               AS Overhead
      ,0                               AS Misc
      ,0                               as Sub_Assy_total
	  ,Final_Direct_Labor
	  ,Final_Direct_Fringe
	  ,Final_Indirect_Labor
	  ,Final_Indirect_Fringe
	  ,Final_Overhead
	  ,Final_Misc
	  ,(Final_Direct_Labor+Final_Direct_Fringe+Final_Indirect_Labor+Final_Indirect_Fringe+Final_Overhead+Final_Misc) as Final_Sub_Assy_Total
  FROM PARWV44_DACT_FINAL_ASSEMBLY 
   Where ARWU01_CCTSS_K = @CCTSS_K
) CCT_PART_SUPPLIER

Group by 
 CCT_PART_SUPPLIER.ARWU08_CCTSS_DSGN_SUPL_K
,CCT_PART_SUPPLIER.[ARWU37_CCTSS_DSGN_ADJ_K]
,CCT_PART_SUPPLIER.ARWU01_CCTSS_K
,CCT_PART_SUPPLIER.[ARWU17_BOM_SUB_ASSY_K]
) CCT_PART_SUPPLIER_Sum
Left JOIN [dbo].PARWV20_MFG_MRKP V20
     ON V20.ARWU08_CCTSS_DSGN_SUPL_K = CCT_PART_SUPPLIER_Sum.ARWU08_CCTSS_DSGN_SUPL_K
    AND V20.ARWU17_BOM_SUB_ASSY_K    = CCT_PART_SUPPLIER_Sum.ARWU17_BOM_SUB_ASSY_K
Left JOIN [dbo].[PARWV21_FINAL_ASSEMBLY_MFG_MRKP] V21
	ON V21.ARWU08_CCTSS_DSGN_SUPL_K = CCT_PART_SUPPLIER_Sum.ARWU08_CCTSS_DSGN_SUPL_K
    where CCT_PART_SUPPLIER_sum.ARWU01_CCTSS_K=@CCTSS_K
;





GO
