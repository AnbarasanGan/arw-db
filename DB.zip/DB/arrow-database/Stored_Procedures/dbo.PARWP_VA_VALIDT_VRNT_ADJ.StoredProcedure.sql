DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_VRNT_ADJ]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 02/11/2020
-- Description:	validate variant adjustment details for BoB files with 'PBOM and DA UI'  
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 05/08/2020  rwesley2  US1600015 removed hard-coded value for ARWE01_EXCEL_TAB_X and replaced with s46.sheet_name.
-- 07/14/2020  Asolosky  US1701019 Removed validation on part name since it was already in PARWP_VA_VALIDT_PART_INDEX which caused duplicate errors.
-- 07/27/2020  Asolosky  US1771016 Part name error message: added <LF> to display when line feed is present. 
-- 08/12/2020  Asolosky  US1839680 Multiple Query joins had to be changed from S45.Benchmark_Var_N to S45.User_Selected_BNCMK_VRNT_N
--                                 Changed the U18 join for error 'Part index does not match ARROW Variant Adjustment part index'  from: ON U18.ARWU01_CCTSS_K = U09_VRNT.ARWU01_CCTSS_K and U18.ARWU18_BOM_PART_IX_N   = S46.part_index  to: ON  U18.ARWU18_BOM_PART_K = U65.ARWU18_BOM_PART_K
--                                 Changed the A40 join for error 'Type of change' from: On A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X = S46.type_of_change to On A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = U65.ARWA40_DSGN_ADJ_PART_CHG_TYP_K 
-- 09/30/2020  Ashaik12  US1910884 Switched from E01 error table to E02 to include part_index and arrow_Value
-- 06/25/2021  Asolosky  US2561600 Message changed for: Variant Adjustment in Arrow does not appear in an Adjustment Details tab (ADJ-). 
--                                 Added more detail to say there may be blank rows in the Excel sheet.
-- 10/19/2021  Asolosky  US2979369  New ERROR for: The Variant Adjustment (ADJ-) Change ID sheet name does not match the sub assembly in Arrow
--                                 We had a user that selected the wrong sub-assembly in the DA manage adjustment screen and tried to fix by manually changing the ADJ sheet.
-- 04/04/2022  Asolosky  US3411440 Changed the error: 'The Variant Adjustment entered into Arrow is missing from the Sheet Name'...
--                                 so it was easier to understand.  Added sub-assembly to the query and error table for better meaning 
-- 05/09/2022  ASolosky  US3411440  Users didn't like the message for 2nd validation
--                                 'Variant Adjustment in Arrow does not appear in an Adjustment Details tab (ADJ-)'. So changed to this
--                                 'The Variant Adjustment in Arrow is missing from the sheet'.  Also gave the exact sheet name where it should be located.
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VA_VALIDT_VRNT_ADJ] 
-- Input Parameter
@GUID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;
BEGIN TRY

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate change ID on VA file but not in Arrow
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
      ,'The Change ID does not match a Variant Adjustment in Arrow.'    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'ERROR'
	  ,s46.sheet_name
	  ,s46.row_idx 
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,'' -- No Arrow value
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46 
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N            = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C     = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N            = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C            = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N      = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X       = U09_VRNT.ARWU04_VRNT_N         
   AND S45.User_Selected_BNCMK_VRNT_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N
LEFT join PARWU65_CCTSS_VRNT_ADJ u65
on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
where s45.Processing_ID = @GUID
  and u65.ARWU65_CCTSS_VRNT_ADJ_ID_N IS NULL
;

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate change ID in ARROW but not on VA file
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   s45.Source_c 
	  ,IsNull(s46.change_id,'"Missing"')
     ,'The Variant Adjustment entered in Arrow is missing from the sheet. Also check if the import file''s Sheet has 2 or more blank rows between parts. If it does, remove the extra blank rows.'  AS ARWE02_ERROR_X 
	  ,s45.[Processing_ID] 
	  ,s45.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,0
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'ERROR'
	  ,'ADJ-' + U17.ARWU17_BOM_SUB_ASSY_N
	  ,''                                -- row_idx will not exist for this scenario
	  ,U65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]  -- Part Index/Change Id
	  ,U65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]  -- ARROW Value
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N            = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C     = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N            = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C            = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N      = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X       = U09_VRNT.ARWU04_VRNT_N    
   AND S45.User_Selected_BNCMK_VRNT_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N              
join PARWU65_CCTSS_VRNT_ADJ U65 on u09_VRNT.ARWU04_CCTSS_VRNT_K = U65.ARWU04_CCTSS_VRNT_K
join PARWU18_BOM_PART       U18 on U18.ARWU18_BOM_PART_K        = U65.ARWU18_BOM_PART_K
join PARWU17_BOM_SUB_ASSY   U17 on U17.ARWU17_BOM_SUB_ASSY_K    = U18.ARWU17_BOM_SUB_ASSY_K
LEFT JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46 
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
 and u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N] = s46.change_id 
where s45.Processing_ID = @GUID
  and s46.change_id IS NULL
;

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate part index/change Id matchs part index/change ID in ARROW
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')
      ,'The Variant Adjustment Change ID has a Part Index that does not match the ARROW Part Index. Please update the file to match ARROW.'
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'ERROR'
	  ,s46.sheet_name
	  ,s46.row_idx 
	  ,u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
	  ,u18.ARWU18_BOM_PART_IX_N 
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
  ON S45.User_Selected_CTSP_N            = U09_VRNT.ARWU31_CTSP_N              
 AND S45.User_Selected_CTSP_Region_C     = U09_VRNT.ARWA06_RGN_C               
 AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
 AND S45.User_Selected_SUPL_N            = U09_VRNT.ARWA17_SUPL_N               
 AND S45.User_Selected_SUPL_C            = U09_VRNT.ARWA17_SUPL_C               
 AND S45.User_Selected_SUPL_CNTRY_N      = U09_VRNT.ARWA28_CNTRY_N              
 AND S45.User_selected_WALK_VRNT_X       = U09_VRNT.ARWU04_VRNT_N  
 AND S45.User_Selected_BNCMK_VRNT_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
JOIN PARWU65_CCTSS_VRNT_ADJ u65
  ON u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
 AND s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
-- part index and name
JOIN [dbo].[PARWU18_BOM_PART] U18
  ON  U18.ARWU18_BOM_PART_K = U65.ARWU18_BOM_PART_K
where s45.Processing_ID = @GUID
  and s46.part_index <> u18.ARWU18_BOM_PART_IX_N
;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Name in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 s46.Source_c                                                as [ARWE02_SOURCE_C]
		,replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>') as [ARWE02_ERROR_VALUE]
		,'Part Name does not match ARROW part name'  as [ARWE02_ERROR_X]
		,@GUID
		,S46.filename                                                as [ARWE02_FILENAME] 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s46.sheet_name
		,s46.row_idx
		,change_id
		,U18.ARWU18_BOM_PART_X
        FROM [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
		JOIN PARWS45_VA_COVER_PAGE_INFO          S45
          ON S45.Processing_ID       = S46.Processing_ID
         AND S45.filename            = S46.filename
		 JOIN PARWU01_CCTSS_FLAT   U01    
          ON U01.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
         AND U01.ARWA06_RGN_C               = S45.User_Selected_CTSP_Region_C
         AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S45.User_Selected_ENRG_SUB_CMMDTY_X 
         AND U01.ARWU01_BNCHMK_VRNT_N       = S45.User_Selected_BNCMK_VRNT_N
		JOIN PARWU18_BOM_PART U18
		  ON U18.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
		 AND U18.ARWU18_BOM_PART_IX_N = S46.part_index
       WHERE S46.Processing_ID         = @GUID
	     and S46.part_name !=U18.ARWU18_BOM_PART_X;

	--++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Sub Assembly in Arrow does not match file
	--++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		   s46.Source_c                                                      as [ARWE02_SOURCE_C]
		  ,IsNull(Substring(S46.sheet_name,5,datalength(S46.sheet_name)),'') as [ARWE02_ERROR_VALUE]
		  ,'The Variant (ADJ-) Change ID sub assembly does not match ARROW. Verify all new Adds have the correct sub-assembly in the Manage Adjustment screen or there wasn''t a manual change in the ADJ- sheet'  as [ARWE02_ERROR_X]
		  ,@GUID
		  ,S46.filename 
		  ,OBJECT_NAME(@@PROCID)	  
		  ,@TIME_STAMP  
		  ,@CDSID 
		  ,@TIME_STAMP  
		  ,@CDSID
		  ,ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K
		  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
		  ,'ERROR'
		  ,s46.sheet_name
		  ,s46.row_idx
		  ,S46.change_id
		  ,U17.ARWU17_BOM_SUB_ASSY_N
      FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
	  JOIN PARWS45_VA_COVER_PAGE_INFO         S45
        ON S45.Processing_ID       = S46.Processing_ID
       AND S45.filename            = S46.filename
	  JOIN PARWU01_CCTSS_FLAT   U01    
        ON U01.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
       AND U01.ARWA06_RGN_C               = S45.User_Selected_CTSP_Region_C
       AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S45.User_Selected_ENRG_SUB_CMMDTY_X 
       AND U01.ARWU01_BNCHMK_VRNT_N       = S45.User_Selected_BNCMK_VRNT_N
	  JOIN PARWU18_BOM_PART     U18
	    ON U18.ARWU01_CCTSS_K             = U01.ARWU01_CCTSS_K
	   AND U18.ARWU18_BOM_PART_IX_N       = S46.part_index
	  Join PARWU17_BOM_SUB_ASSY U17
	    ON U17.ARWU17_BOM_SUB_ASSY_K      = U18.ARWU17_BOM_SUB_ASSY_K
     WHERE S46.Processing_ID         = @GUID
	   AND Substring(S46.sheet_name,5,datalength(S46.sheet_name)) != U17.ARWU17_BOM_SUB_ASSY_N;

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate type of change
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,s46.type_of_change
     ,'Type of change does not match ARROW Variant Adjustment Type of change' AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'ERROR'
	  ,s46.sheet_name
	  ,s46.row_idx 
	  ,s46.change_id
	  ,a40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N            = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C     = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N            = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C            = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N      = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X       = U09_VRNT.ARWU04_VRNT_N   
   AND S45.User_Selected_BNCMK_VRNT_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N               
join PARWU65_CCTSS_VRNT_ADJ u65
on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
--Part Change Type
  Join PARWA40_DSGN_ADJ_PART_CHG_TYP  A40
    On A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = U65.ARWA40_DSGN_ADJ_PART_CHG_TYP_K 
where s45.Processing_ID = @GUID
  and s46.type_of_change <> a40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X
;

/*
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate Ford Spec SDS
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,cast(s46.ford_spec_sds as CHAR(128))
      ,'Ford Spec SD '+ cast(s46.ford_spec_sds as CHAR(128))  + ' does not match ARROW Variant Adjustment Ford Spec SD ' + u65.ARWU65_SPEC_SDS_NUM_X + ' for change ID ' + u65.ARWU65_CCTSS_VRNT_ADJ_ID_N    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'WARNING'
	  ,s46.sheet_name
	  ,s46.row_idx 
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X = U09_VRNT.ARWU04_VRNT_N  
   AND S45.Benchmark_Var_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
join PARWU65_CCTSS_VRNT_ADJ u65
on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
where s45.Processing_ID = @GUID
  and s46.ford_spec_sds <> u65.ARWU65_SPEC_SDS_NUM_X
;

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate level 1 waterfall category
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,s46.lvl1_waterfall_cat
      ,'Level 1 waterfall category '+ S46.lvl1_waterfall_cat  + ' does not match ARROW Variant Adjustment Level 1 waterfall category ' + COALESCE(A18.ARWA18_LVL1_ADJ_CATG_ABBR_N,'') + ' for change ID ' + u65.ARWU65_CCTSS_VRNT_ADJ_ID_N    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'WARNING'
	  ,s46.sheet_name
	  ,s46.row_idx 
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X = U09_VRNT.ARWU04_VRNT_N  
   AND S45.Benchmark_Var_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
join PARWU65_CCTSS_VRNT_ADJ u65
  ON u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
--Waterfall
JOIN [dbo].[PARWU91_VRNT_ADJ_TRDOFF]  U91
  ON U65.ARWU65_CCTSS_VRNT_ADJ_K = U91.ARWU65_CCTSS_VRNT_ADJ_K
left JOIN PARWU89_TRDOFF_LVL2_CATG    U89
  ON U91.ARWU85_CCTSS_TRDOFF_K = U89.ARWU85_CCTSS_TRDOFF_K
LEFT JOIN PARWA19_LVL2_ADJ_CATG       A19
  ON U89.ARWA19_LVL2_ADJ_CATG_K = A19.ARWA19_LVL2_ADJ_CATG_K
LEFT JOIN PARWA18_LVL1_ADJ_CATG       A18
  ON a19.ARWA18_LVL1_ADJ_CATG_K = A18.ARWA18_LVL1_ADJ_CATG_K
WHERE s45.Processing_ID = @GUID
  and S46.lvl1_waterfall_cat <> COALESCE(A18.ARWA18_LVL1_ADJ_CATG_ABBR_N,'')
;

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate level 2 waterfall category
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,s46.lvl2_waterfall_cat
      ,'Level 2 waterfall category '+ S46.lvl2_waterfall_cat   + ' does not match ARROW Variant Adjustment Level 2 waterfall category ' + COALESCE(A19.ARWA19_LVL2_ADJ_CATG_N,'') + ' for change ID ' + u65.ARWU65_CCTSS_VRNT_ADJ_ID_N    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'WARNING'
	  ,s46.sheet_name
	  ,s46.row_idx 
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X = U09_VRNT.ARWU04_VRNT_N 
   AND S45.Benchmark_Var_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                 
join PARWU65_CCTSS_VRNT_ADJ u65
  on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
 and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
--Waterfall
JOIN [dbo].[PARWU91_VRNT_ADJ_TRDOFF]   U91
ON U65.ARWU65_CCTSS_VRNT_ADJ_K = U91.ARWU65_CCTSS_VRNT_ADJ_K
LEFT JOIN PARWU89_TRDOFF_LVL2_CATG     U89
       ON U91.ARWU85_CCTSS_TRDOFF_K = U89.ARWU85_CCTSS_TRDOFF_K
LEFT JOIN PARWA19_LVL2_ADJ_CATG        A19
       ON U89.ARWA19_LVL2_ADJ_CATG_K = A19.ARWA19_LVL2_ADJ_CATG_K
WHERE s45.Processing_ID = @GUID
  and S46.lvl2_waterfall_cat <> COALESCE(A19.ARWA19_LVL2_ADJ_CATG_N,'')
;


--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate tough choice grouping
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   s46.Source_c 
	  ,s46.tough_choice_grouping 

      ,'Tough choice grouping '+ s46.tough_choice_grouping  + ' does not match ARROW Variant Adjustment Tough choice grouping ' + u85.ARWU85_CCTSS_TRDOFF_X  + ' for change ID ' + u65.ARWU65_CCTSS_VRNT_ADJ_ID_N    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'WARNING'
	  ,s46.sheet_name
	  ,s46.row_idx 
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X = U09_VRNT.ARWU04_VRNT_N  
   AND S45.Benchmark_Var_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
join PARWU65_CCTSS_VRNT_ADJ u65
  on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
 and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
-- tough choice grouping
JOIN [dbo].[PARWU91_VRNT_ADJ_TRDOFF]    U91
ON U65.ARWU65_CCTSS_VRNT_ADJ_K = U91.ARWU65_CCTSS_VRNT_ADJ_K
LEFT JOIN [dbo].[PARWU85_CCTSS_TRDOFF]  U85
ON U91.ARWU85_CCTSS_TRDOFF_K = u85.ARWU85_CCTSS_TRDOFF_K
where s45.Processing_ID = @GUID
  and s46.tough_choice_grouping <>  u85.ARWU85_CCTSS_TRDOFF_X
;
*/
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate Ford intended design attribute
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,replace(replace(s46.ford_intended_dsgn_attr,char(10),'<LF>'),char(13),'<CR>')
      ,'Ford intended design attribute does not match ARROW Variant Adjustment Ford intended design attribute'    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'ERROR'
	  ,s46.sheet_name
	  ,s46.row_idx 
	  ,s46.change_id
	  ,u65.ARWU65_FORD_INTD_DSGN_ATTR_X 
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N            = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C     = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N            = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C            = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N      = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X       = U09_VRNT.ARWU04_VRNT_N  
   AND S45.User_Selected_BNCMK_VRNT_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
join PARWU65_CCTSS_VRNT_ADJ u65
on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
where s45.Processing_ID = @GUID
  and s46.ford_intended_dsgn_attr <> u65.ARWU65_FORD_INTD_DSGN_ATTR_X
 
;

--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate Ford variant design attribute
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,replace(replace(s46.ford_variant_dsgn_attr,char(10),'<LF>'),char(13),'<CR>')
      ,'Ford variant design attribute does not match ARROW Variant Adjustment Ford variant design attribute' AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'ERROR'
	  ,s46.sheet_name
	  ,s46.row_idx 
	  ,s46.change_id
	  ,u65.ARWU65_FORD_VRNT_DSGN_ATTR_X
FROM PARWS45_VA_COVER_PAGE_INFO s45
JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N            = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C     = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N            = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C            = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N      = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X       = U09_VRNT.ARWU04_VRNT_N  
   AND S45.User_Selected_BNCMK_VRNT_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
join PARWU65_CCTSS_VRNT_ADJ u65
on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
where s45.Processing_ID = @GUID
  and s46.ford_variant_dsgn_attr <> u65.ARWU65_FORD_VRNT_DSGN_ATTR_X
;
/*
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- validate comments
--+++++++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   s46.Source_c 
	  ,s46.comments
      ,'Comment '+ s46.comments + ' does not match ARROW Variant Adjustment comments for change ID ' + u65.ARWU65_CCTSS_VRNT_ADJ_ID_N    AS ARWE02_ERROR_X 
	  ,s46.[Processing_ID] 
	  ,s46.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
	  ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46'     
	  ,'WARNING'
	  ,s46.sheet_name
	  ,s46.row_idx 
FROM PARWS45_VA_COVER_PAGE_INFO s45
 JOIN PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
  on S45.Processing_ID       = S46.Processing_ID
 and S45.filename            = S46.filename
JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.User_Selected_CTSP_N = U09_VRNT.ARWU31_CTSP_N              
   AND S45.User_Selected_CTSP_Region_C = U09_VRNT.ARWA06_RGN_C               
   AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   
   AND S45.User_Selected_SUPL_N = U09_VRNT.ARWA17_SUPL_N               
   AND S45.User_Selected_SUPL_C = U09_VRNT.ARWA17_SUPL_C               
   AND S45.User_Selected_SUPL_CNTRY_N = U09_VRNT.ARWA28_CNTRY_N              
   AND S45.User_selected_WALK_VRNT_X = U09_VRNT.ARWU04_VRNT_N  
   AND S45.Benchmark_Var_N      = u09_VRNT.ARWU01_BNCHMK_VRNT_N                
join PARWU65_CCTSS_VRNT_ADJ u65
on u09_VRNT.[ARWU04_CCTSS_VRNT_K] = u65.ARWU04_CCTSS_VRNT_K
and s46.change_id = u65.[ARWU65_CCTSS_VRNT_ADJ_ID_N]
where s45.Processing_ID = @GUID
  and s46.comments <> u65.ARWU65_CCTSS_VRNT_ADJ_CMT_X
;
*/

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID               --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
			 ,''
			 ,''

END CATCH;


GO
