DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDATIONS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 02/03/2020
-- Description:	Moved all the common Validations for PBOM import 
--              1st load, kill and fill and surgical into this procedure
-- Make sure any new validations added are common to the 3 types of imports
-- =============================================
-- Changes
-- =============================================
-- Author     Date     User Story Description
-- ------     -----    ---------- ----------
-- asolosky 07/21/2020 US1573358  Added procedure PARWP_PBOM_VALIDT_BNCHMK_VRNT
-- asolosky 08/24/2020 US1804570  Added procedure PARWP_PBOM_VALIDT_CHAR_LENGTH
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDATIONS] 
	-- Add the parameters for the stored procedure here
@GUIDIN varchar(500), 
@CDSID  varchar(8),
@TIME_STAMP DATETIME

AS
Begin

--PBOM Validation
 EXEC [dbo].[PARWP_PBOM_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_PBOM_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_PBOM_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP;  
 EXEC [dbo].[PARWP_PBOM_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;  

 EXEC [dbo].[PARWP_PBOM_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;   
 EXEC [dbo].[PARWP_PBOM_VALIDT_BOM_PART]              @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_PBOM_VALIDT_BOM_PART_NAME]         @GUIDIN, @CDSID, @TIME_STAMP;  
 EXEC [dbo].[PARWP_PBOM_VALIDT_NUMERIC]               @GUIDIN, @CDSID, @TIME_STAMP;    
 EXEC [dbo].[PARWP_PBOM_VALIDT_UOM]                   @GUIDIN, @CDSID, @TIME_STAMP;   
 EXEC [dbo].[PARWP_PBOM_VALIDT_END_ITEMS]             @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_PBOM_VALIDT_SUB_ASSEMBLY]          @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_PBOM_VALIDT_CHAR_LENGTH]           @GUIDIN, @CDSID, @TIME_STAMP;
END
GO
