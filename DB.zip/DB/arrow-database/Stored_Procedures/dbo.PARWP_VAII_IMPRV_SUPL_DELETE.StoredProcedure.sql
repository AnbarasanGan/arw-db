SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 06/30/2022
-- Description:	Deletes any Supplier-originated
--              Improvement Ideas already imported
--              for the Designs/Suppliers included
--              in the VAII import. They are kill-
--              and-fill just like the quote data.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/25/2022  ASHAIK12  DE260421  Add join to U04_K to get delete keys only for the valid variant
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VAII_IMPRV_SUPL_DELETE] 
-- Input Parameter
@GUIDIN Varchar(5000)
AS

SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++++++++++++
-- Delete Supplier-originated Improvement Ideas
--++++++++++++++++++++++++++++++++++++++++++++++

DECLARE @UD2_delete_keys TABLE (
 ARWUD2_CCTSS_VRNT_IMPRV_K INT
,ARWU18_BOM_PART_K INT
)

INSERT INTO @UD2_delete_keys
SELECT
	 ARWUD2_CCTSS_VRNT_IMPRV_K
	,ARWU18_BOM_PART_K
FROM PARWUD2_CCTSS_VRNT_IMPRV AS UD2
JOIN (
	SELECT
		 ARWU04_CCTSS_VRNT_K
		,ARWU07_CCTSS_SUPL_K
	From    [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45
      -- Join with Supplier Quote View
         JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09
          ON S45.User_Selected_CTSP_N         = U09.ARWU31_CTSP_N
         AND S45.User_Selected_CTSP_Region_C  = U09.[ARWA06_RGN_C]
		 AND S45.[User_Selected_ENRG_CMMDTY_X] = U09.[ARWA02_ENRG_CMMDTY_X]
		 AND S45.Eng_SubCommodity_name        = U09.[ARWA03_ENRG_SUB_CMMDTY_X]         
         AND S45.User_Selected_BNCMK_VRNT_N   = U09.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
		 AND S45.[User_selected_WALK_VRNT_X] = U09.[ARWU04_VRNT_N]
         AND S45.User_Selected_SUPL_N         = U09.ARWA17_SUPL_N
         AND S45.User_Selected_SUPL_CNTRY_N   = U09.ARWA28_CNTRY_N
         AND S45.User_Selected_SUPL_C         = U09.ARWA17_SUPL_C
		 AND S45.Processing_ID = @GUIDIN
		 AND S45.Skip_loading_due_to_error_f = 0
	GROUP BY 
		 ARWU04_CCTSS_VRNT_K
		,ARWU07_CCTSS_SUPL_K
	) VAII_DSGN_SUPL
	ON UD2.ARWU07_CCTSS_SUPL_K = VAII_DSGN_SUPL.ARWU07_CCTSS_SUPL_K
	AND UD2.ARWU04_CCTSS_VRNT_K = VAII_DSGN_SUPL.ARWU04_CCTSS_VRNT_K
	--AND UD2.ARWU07_CCTSS_SUPL_K is NOT NULL

DELETE FROM PARWUD3_VRNT_IMPRV_TRDOFF
WHERE ARWUD2_CCTSS_VRNT_IMPRV_K IN
	(SELECT ARWUD2_CCTSS_VRNT_IMPRV_K
	 FROM @UD2_delete_keys)

DELETE FROM PARWUD2_CCTSS_VRNT_IMPRV
WHERE ARWUD2_CCTSS_VRNT_IMPRV_K IN
	(SELECT ARWUD2_CCTSS_VRNT_IMPRV_K
	 FROM @UD2_delete_keys)

--++++++++++++++++++++++++++++++++++++++++++++++
-- Delete any BOM Parts that were used only for
-- Improvement Ideas that were just deleted
--++++++++++++++++++++++++++++++++++++++++++++++

DELETE FROM PARWU18_BOM_PART
WHERE ARWU18_BOM_PART_K IN (
	SELECT UD2_DEL.ARWU18_BOM_PART_K
	FROM @UD2_delete_keys AS UD2_DEL
	LEFT JOIN PARWU19_DSGN_PART AS U19
		ON UD2_DEL.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K
	LEFT JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON UD2_DEL.ARWU18_BOM_PART_K = U37.ARWU18_BOM_PART_K
	LEFT JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON UD2_DEL.ARWU18_BOM_PART_K = U46.ARWU18_BOM_PART_K
	LEFT JOIN PARWU65_CCTSS_VRNT_ADJ AS U65
		ON UD2_DEL.ARWU18_BOM_PART_K = U65.ARWU18_BOM_PART_K
	LEFT JOIN PARWU75_DA_MNLSLCT_BOM_PART AS U75
		ON UD2_DEL.ARWU18_BOM_PART_K = U75.ARWU18_BOM_PART_K
	LEFT JOIN PARWU78_II_MNLSLCT_BOM_PART AS U78
		ON UD2_DEL.ARWU18_BOM_PART_K = U78.ARWU18_BOM_PART_K
	LEFT JOIN PARWU82_VA_MNLSLCT_BOM_PART AS U82
		ON UD2_DEL.ARWU18_BOM_PART_K = U82.ARWU18_BOM_PART_K
	LEFT JOIN [dbo].[PARWU63_VRNT_BOM_PART_END_ITM] AS U63
		ON UD2_DEL.ARWU18_BOM_PART_K = U63.ARWU18_BOM_PART_K
	LEFT JOIN [dbo].[PARWUD2_CCTSS_VRNT_IMPRV] UD2
		ON UD2_DEL.ARWU18_BOM_PART_K = UD2.ARWU18_BOM_PART_K
	LEFT JOIN [dbo].[PARWUE0_VII_MNLSLCT_BOM_PART] UE0
		ON UD2_DEL.ARWU18_BOM_PART_K = UE0.ARWU18_BOM_PART_K
	WHERE U19.ARWU18_BOM_PART_K IS NULL
		AND U37.ARWU18_BOM_PART_K IS NULL
		AND U46.ARWU18_BOM_PART_K IS NULL
		AND U65.ARWU18_BOM_PART_K IS NULL
		AND U75.ARWU18_BOM_PART_K IS NULL
		AND U78.ARWU18_BOM_PART_K IS NULL
		AND U82.ARWU18_BOM_PART_K IS NULL
	    AND U63.ARWU18_BOM_PART_K IS NULL
		AND UD2.ARWU18_BOM_PART_K IS NULL
		AND UE0.ARWU18_BOM_PART_K IS NULL
	)


GO
