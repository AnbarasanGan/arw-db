DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUPL_CRNCY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 06/26/2019
-- Description:	Stored Procedure to validate Supplier Picked Currency Code and Exchange rates
--              First in Exchange rate is loaded.  All others loaded after must match or its an error
--==============================================================================================
-- Changes
-- Date       CDSID     User Story Description
-- -----      ------    ---------- -------------------------------------------------
-- 09/10/2019 Asolosky             Added row_id
-- 10/03/2019 Ashaik12             Added Values in Error Description
-- 10/03/2019 Asolosky             Removed row_idx and hard coded for 3. 'Currency Code for the selected country...'
-- 10/17/2019 rwesley2             to fix arithmetic overflow as cast to U22 currency
-- 12/01/2019 ashaik12             Added Supplier Country Name to the join
-- 12/25/2019 ashaik12             Refactor the joins to use U07_FLAT
-- 01/10/2020 Ashaik12             Added TimeStamp parameter and removed filter on Processing Status
-- 02/25/2020 Asolosky  DE154961   Removed rounding on Arrow tables and changed staging to round to 9 decimals (no truncation)
--                                 SQL auto rounds decimals on inserts/updates so when validating, the staging data must match arrow.
-- 03/04/2020 btemkow	US1461766  Added validation to check that Supplier Picked Currency Code has a Program Exchange Rate
-- 09/11/2020 Asolosky  US1910882  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
--drop procedure [dbo].[PARWP_CCS_VALIDT_SUPL_CRNCY] 


CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUPL_CRNCY] 
	-- Add the parameters for the stored procedure here
	 @GUID varchar(500),
	 @CDSID varchar(8),
	 @TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--********************************************************
--Validate Supplier Picked Currency Code has a Program Exchange Rate
--********************************************************
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT 
	 S27.Source_c
	,S27.supplier_picked_crcy_c
	,'Supplier Currency Code does not have an Exchange Rate defined in Arrow. Contact ARROW support.'
	,S27.Processing_ID
	,S27.filename
	,OBJECT_NAME(@@PROCID)
	,@TIME_STAMP
	,@CDSID
	,@TIME_STAMP
	,@CDSID
	,min(ARWS27_CCS_EXCHANGE_RATE_TAB_K)
	,'PARWS27_CCS_EXCHANGE_RATE_TAB'
	,'ERROR'
	,'Exchange rates'
	,11
	,''  --No Part Index
	,''  --No ARROW Value
FROM PARWS27_CCS_EXCHANGE_RATE_TAB as S27
join PARWS22_CCS_COVER_PAGE_INFO as S22
	on S27.processing_id = S22.Processing_ID
	and S27.filename = S22.filename
join PARWU01_CCTSS_FLAT as U01_FLAT
	on S22.User_Selected_CTSP_N = U01_FLAT.ARWU31_CTSP_N
    and S22.User_Selected_CTSP_Region_C = U01_FLAT.ARWA06_RGN_C
	and S22.User_Selected_ENRG_SUB_CMMDTY_X = U01_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
	and S22.User_Selected_BNCMK_VRNT_N = U01_FLAT.ARWU01_BNCHMK_VRNT_N
join PARWA29_CRCY as A29
	on S27.supplier_picked_crcy_c = A29.ARWA29_CRCY_C
left join PARWU33_CTSP_CRCY_EXCHG_RATE as U33
	on U01_FLAT.ARWU31_CTSP_K = U33.ARWU31_CTSP_K
	and A29.ARWA29_CRCY_K = U33.ARWA29_CRCY_K
where S27.processing_id = @GUID
and U33.ARWA29_CRCY_K is null
group by
	 S27.Source_c
	,S27.supplier_picked_crcy_c
	,U01_FLAT.ARWU31_CTSP_N
	,S27.Processing_ID
	,S27.filename
;

--********************************************************
--Validate Supplier Picked Currency Code matches the already existing Supplier Picked currency code for the same BoB
--********************************************************
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT 
             [ARWE02_SOURCE_C],
	         [ARWE02_ERROR_VALUE],
	         [ARWE02_ERROR_X],
	         [ARWE02_PROCESSING_ID],
	         [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS27_CCS_EXCHANGE_RATE_TAB' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
			 3                               as ARWE02_ROW_IDX,
	         '',  --No Part Index
	         ARWA29_CRCY_C   --No ARROW Value
		FROM
(
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         Validate.supplier_picked_crcy_c as [ARWE02_ERROR_VALUE],
	         'Currency Code for the selected country, does not match a previous imported CCS File for the same Program/Supplier'  [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         Validate.[ARWS27_CCS_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
			 ROW_NUMBER() OVER (PARTITION BY Validate.ARWU01_CCTSS_K, Validate.ARWU07_CCTSS_SUPL_K  ORDER BY Validate.ARWS27_CCS_EXCHANGE_RATE_TAB_K ) AS Distinct_Row,
			 ROW_IDX,
			 ARWA29_CRCY_C
       FROM 
(
select U07.ARWU01_CCTSS_K
      ,U07.ARWU07_CCTSS_SUPL_K
      ,U07.ARWA17_SUPL_K
	  ,U07.ARWA17_SUPL_N
	  ,U07.ARWA17_SUPL_C
      ,U21.ARWA29_CRCY_K
	  ,A29.ARWA29_CRCY_C
	  ,U07.ARWU31_CTSP_N
	  ,U07.ARWA06_RGN_C
	  ,U07.ARWA03_ENRG_SUB_CMMDTY_X
	  ,U07.ARWU01_BNCHMK_VRNT_N
	  ,STAGE.Processing_ID
	  ,STAGE.Source_c
	  ,STAGE.supplier_picked_crcy_c
	  ,STAGE.filename
	  ,STAGE.ARWS27_CCS_EXCHANGE_RATE_TAB_K
	  ,STAGE.ROW_IDX
FROM
PARWU07_CCTSS_SUPL_FLAT U07
JOIN PARWU21_CCTSS_SUPL_CRCY U21
ON U07.ARWU07_CCTSS_SUPL_K=U21.ARWU07_CCTSS_SUPL_K
JOIN PARWA29_CRCY A29
ON A29.ARWA29_CRCY_K=U21.ARWA29_CRCY_K
JOIN
(select S22.User_Selected_CTSP_N
       ,S22.User_Selected_CTSP_Region_C
	   ,S22.User_Selected_ENRG_SUB_CMMDTY_X
	   ,S22.User_Selected_SUPL_C
	   ,S22.User_Selected_SUPL_CNTRY_N
	   ,S22.User_Selected_SUPL_N
	   ,S22.User_Selected_BNCMK_VRNT_N
	   ,S27.supplier_picked_crcy_c
	   ,S27.currency_code
	   ,S27.usd_per_local_currency
	   ,S22.Processing_ID
	   ,S22.Processing_Status_x
	   ,S27.Source_c
	   ,S27.filename
	   ,S27.ARWS27_CCS_EXCHANGE_RATE_TAB_K
	   ,S27.ROW_IDX
FROM [dbo].[PARWS27_CCS_EXCHANGE_RATE_TAB] S27
		  JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] S22
		  ON S27.Processing_ID=S22.Processing_ID
		  AND S27.filename=S22.filename
Where S22.Processing_ID=@GUID		  
) STAGE
ON STAGE.User_Selected_CTSP_N               =U07.ARWU31_CTSP_N
AND STAGE.User_Selected_CTSP_Region_C       =U07.ARWA06_RGN_C
AND STAGE.User_Selected_ENRG_SUB_CMMDTY_X   =U07.ARWA03_ENRG_SUB_CMMDTY_X
AND STAGE.User_Selected_BNCMK_VRNT_N        =U07.ARWU01_BNCHMK_VRNT_N
AND STAGE.User_Selected_SUPL_N              =U07.ARWA17_SUPL_N
AND STAGE.User_Selected_SUPL_C              =U07.ARWA17_SUPL_C
AND STAGE.[User_Selected_SUPL_CNTRY_N]      =U07.ARWA28_CNTRY_N
where STAGE.Processing_ID=@GUID
AND STAGE.supplier_picked_crcy_c != A29.ARWA29_CRCY_C
) Validate
)X
where X.Distinct_Row=1
;

--*********************************************************************
--Currency Exchange Rates do not match the existing Exchange Rate for the Currency Codes
--*********************************************************************
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	         Validate.[Source_c]                      as [ARWE02_SOURCE_C],
	         CAST(Validate.usd_per_local_currency     as VARCHAR(500)) as [ARWE02_ERROR_VALUE],
	         'Currency Exchange Rates do not match a previous imported CCS File for the same Program/Supplier' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID]                  as [ARWE02_PROCESSING_ID],
	         Validate.[filename]                       as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                     as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                               as [ARWE02_CREATE_S],
	         @CDSID                                    as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                               as [ARWE02_LAST_UPDT_S],
	         @CDSID                                    as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS27_CCS_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS27_CCS_EXCHANGE_RATE_TAB'           as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
			 row_idx                                   as ARWE02_ROW_IDX,
	         '',  --No Part Index
	         CAST(Validate.ARWU22_CRCY_PER_SUPL_CRCY_R as VARCHAR(500))   --ARROW Value

       FROM 
(
select U07.ARWU01_CCTSS_K
      ,U07.ARWU07_CCTSS_SUPL_K
      ,U07.ARWA17_SUPL_K
	  ,U07.ARWA17_SUPL_N
	  ,U07.ARWA17_SUPL_C
      ,U22.ARWA29_CRCY_K
	  ,A29.ARWA29_CRCY_C
	  ,U22.ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,U07.ARWU31_CTSP_N
	  ,U07.ARWA06_RGN_C
	  ,U07.ARWA03_ENRG_SUB_CMMDTY_X
	  ,U07.ARWU01_BNCHMK_VRNT_N
	  ,STAGE.Processing_ID
	  ,STAGE.Source_c
	  ,STAGE.supplier_picked_crcy_c
	  ,STAGE.currency_code
	  ,STAGE.usd_per_local_currency
	  ,STAGE.filename
	  ,STAGE.ARWS27_CCS_EXCHANGE_RATE_TAB_K
	  ,STAGE.ROW_IDX
FROM
PARWU07_CCTSS_SUPL_FLAT U07
JOIN [dbo].[PARWU22_SUPL_CRCY_EXCHG_RATE] U22
ON U07.ARWU07_CCTSS_SUPL_K=U22.ARWU07_CCTSS_SUPL_K
JOIN PARWA29_CRCY A29
ON A29.ARWA29_CRCY_K=U22.ARWA29_CRCY_K
Left JOIN
(select S22.User_Selected_CTSP_N
       ,S22.User_Selected_CTSP_Region_C
	   ,S22.User_Selected_ENRG_SUB_CMMDTY_X
	   ,S22.User_Selected_SUPL_C
	   ,S22.User_Selected_SUPL_CNTRY_N
	   ,S22.User_Selected_SUPL_N
	   ,S22.User_Selected_BNCMK_VRNT_N
	   ,S27.supplier_picked_crcy_c
	   ,S27.currency_code
	   ,S27.usd_per_local_currency
	   ,S22.Processing_ID
	   ,S27.Source_c
	   ,S27.filename
	   ,S27.ARWS27_CCS_EXCHANGE_RATE_TAB_K
	   ,S27.ROW_IDX
FROM [dbo].[PARWS27_CCS_EXCHANGE_RATE_TAB] S27
		  JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] S22
		  ON S27.Processing_ID=S22.Processing_ID
		  AND S27.filename=S22.filename
		  WHERE S22.Processing_ID=@GUID
) STAGE
ON STAGE.User_Selected_CTSP_N                    =U07.ARWU31_CTSP_N
AND STAGE.User_Selected_CTSP_Region_C            =U07.ARWA06_RGN_C
AND STAGE.User_Selected_ENRG_SUB_CMMDTY_X        =U07.ARWA03_ENRG_SUB_CMMDTY_X
AND STAGE.User_Selected_BNCMK_VRNT_N             =U07.ARWU01_BNCHMK_VRNT_N
AND STAGE.User_Selected_SUPL_N                   =U07.ARWA17_SUPL_N
AND STAGE.User_Selected_SUPL_C                   =U07.ARWA17_SUPL_C
AND STAGE.[User_Selected_SUPL_CNTRY_N]           =U07.ARWA28_CNTRY_N
AND isnull(STAGE.currency_code,'#~@')            =A29.ARWA29_CRCY_C
where STAGE.Processing_ID=@GUID
AND U22.ARWU22_CRCY_PER_SUPL_CRCY_R != ROUND(isnull(STAGE.usd_per_local_currency,0),9)
) Validate
;
END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS27_CCS_EXCHANGE_RATE_TAB'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH
GO
