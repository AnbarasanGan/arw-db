DROP PROCEDURE [dbo].[PARWP_GCS_SCRUB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 02/20/2020
-- Description:	scub procedure to Update SG&A to SG&A - Total in S18 table 
-- =============================================
-- CHANGES
-- Date			CDSID	  Feature	Description
-- ----------   --------  -------   -----------
-- 09/11/2020  Asolosky   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================	
CREATE PROCEDURE [dbo].[PARWP_GCS_SCRUB]
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

---- Scrub procedure to Update SG&A to SG&A - Total in S18 table  
UPDATE [dbo].PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO
   SET manufacturing_markup_desc = 'SG&A - Total'
         WHERE Processing_ID       = @GUID 
		 and manufacturing_markup_desc='SG&A'
;

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWP_GCS_SCRUB' 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH

GO
