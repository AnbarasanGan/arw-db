DROP PROCEDURE [dbo].[PARWP_TYGRA_VALIDT_PRE_VALIDATIONS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 03/23/2021
-- Description:	Pre-validations are run after the stage tables are loaded and before UB tables are loaded
--              All validations are WARNINGS.
--              Validation errors will be reviewed prior to loading UB tables.  This is to allow any data cleanup before loading. 
--              
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   04/19/2021  Add validation for BOB PIA EI
-- rwesley2   04-20-2021  US2453456 use MAX length when declaring a variable 
-- rwesley2   04-21-2021  US2444239 Use S63 instead of hard-coded region
-- Ashaik12   04/2/2021   US2478016 Add validation for FEDEBOM PLANNED BOB PIA EI
-- rwesley2	  04-28-2021  US2492277 remove validation that requires both base and suffix be present for a part to be valid
--                                  for starting point parts
-- Ashaik12   06-15-2021  US2546661 Starting point prefix, base and suffix cannot be blank
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_PRE_VALIDATIONS] 
-- Input Parameter
 @GUID varchar(MAX)
,@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select z.source_c                as [ARWE02_SOURCE_C]
      ,ISNULL(z.program,'x')      as [ARWE02_ERROR_VALUE]
	  ,'Tygra program was not found in Arrow.'  as [ARWE02_ERROR_x]
      ,z.Processing_ID           as [ARWE02_PROCESSING_ID]
	  ,z.file_name               as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)     as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP               as [ARWE02_CREATE_S]
	  ,@CDSID                    as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP               as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                    as [ARWE02_LAST_UPDT_USER_C]
	  ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS61_TYGRA_TITLE_PAGE'   as [ARWE02_STAGING_TABLE_X]
	  ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --WARNING
	  ,'Tygra Title Page'        as [ARWE02_EXCEL_TAB_X]
	  ,''                        as [ARWE02_ROW_IDX]
	  ,''                        as [ARWE02_Part_Index]
	  ,ISNULL(z.ARWU31_CTSP_N,'')           as [ARWE02_ARROW_Value]
from (
select  Processing_ID 
       ,Source_c
       ,program
	   ,file_name
       ,ARWU31_CTSP_N
from (
select Processing_ID 
       ,Source_c
      ,s61.program
	  ,file_name 
      ,u31.ARWU31_CTSP_N
from PARWS61_TYGRA_TITLE_PAGE s61 
left join PARWU31_CTSP  u31
on s61.program = u31.ARWU31_CTSP_N
where s61.Processing_ID = @GUID
group by Processing_ID,Source_c,s61.program,file_name,u31.ARWU31_CTSP_N
)x
where (                                        
        x.ARWU31_CTSP_N is NULL
		)
)z
;

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select 'TYGRA'                   as [ARWE02_SOURCE_C]
      ,z.ccm                     as [ARWE02_ERROR_VALUE]
	  ,'Tygra CCM was not found in Arrow.'  as [ARWE02_ERROR_x]
      ,z.Processing_ID           as [ARWE02_PROCESSING_ID]
	  ,z.file_name               as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)     as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP               as [ARWE02_CREATE_S]
	  ,@CDSID                    as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP               as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                    as [ARWE02_LAST_UPDT_USER_C]
	  ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS61_TYGRA_TITLE_PAGE'   as [ARWE02_STAGING_TABLE_X]
	  ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --WARNING
	  ,'Tygra Title Page'                        as [ARWE02_EXCEL_TAB_X]
	  ,''                        as [ARWE02_ROW_IDX]
	  ,''                        as [ARWE02_Part_Index]
	  ,z.ccm + ':  ' + z.program + ' /  ' + z.variant    as [ARWE02_ARROW_Value]
from (
select  Processing_ID 
       ,ccm
	   ,file_name
       ,variant
	   ,program
from (
select s61.program
      ,s61.ccm
      ,ltrim(rtrim(ISNULL(s61.region,'') + ' - ' + ISNULL(s61.series,'') + ' - ' + ISNULL(s61.description,''))) as variant
      ,[ARWA09_PGM_CCM_X]
      ,[ARWA08_CCM_C]
  	  ,s61.processing_id
	  ,s61.file_name
	  ,row_number() OVER (order by s61.program, s61.ccm) as rownum
from PARWS61_TYGRA_TITLE_PAGE s61
left join PARWA09_PGM_CCM_FLAT a09
ON S61.[CM_NICKNAME] = A09.ARWA08_CCM_C		
AND S61.[CM_PROGRAM] = A09.ARWA05_ENRG_PGM_C
AND S61.Region = A09.ARWA06_RGN_C

where s61.processing_ID = @GUID	
AND CASE WHEN S61.[CM_MDLYR] = ''     THEN '0' ELSE cast(S61.[CM_MDLYR] as decimal (6,2)) END =
    CASE WHEN A09.ARWA07_MDL_YR_C= '' THEN '0' ELSE cast(A09.ARWA07_MDL_YR_C as decimal (6,2)) END
)x
where x.[ARWA08_CCM_C] is NULL
)z
;

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select z.source_c                as [ARWE02_SOURCE_C]
      ,z.engineering_commodity   as [ARWE02_ERROR_VALUE]
	  ,'Tygra engineering commodity was not mapped to Arrow engineering commodity.'  as [ARWE02_ERROR_x]
      ,z.Processing_ID           as [ARWE02_PROCESSING_ID]
	  ,z.file_name               as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)     as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP               as [ARWE02_CREATE_S]
	  ,@CDSID                    as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP               as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                    as [ARWE02_LAST_UPDT_USER_C]
	  ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS62_TYGRA_SUMMARY'   as [ARWE02_STAGING_TABLE_X]
	  ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --ERROR
	  ,'Tygra parts'             as [ARWE02_EXCEL_TAB_X]
	  ,''                        as [ARWE02_ROW_IDX]
	  ,''                        as [ARWE02_Part_Index]
	  ,''                        as [ARWE02_ARROW_Value]
from (
select  Processing_ID 
       ,Source_c
       ,engineering_commodity
	   ,file_name
       ,ARWS64_TYGRA_ENRG_CMMDTY_X 
from (
select Processing_ID 
       ,Source_c
      ,s62.engineering_commodity   
	  ,file_name 
      ,S64.ARWS64_TYGRA_ENRG_CMMDTY_X
from PARWS62_TYGRA_SUMMARY s62 
left join [dbo].[PARWS64_TYGRA_ENRG_CMMDTY] S64
on s62.Engineering_Commodity = S64.ARWS64_TYGRA_ENRG_CMMDTY_X
group by s62.Processing_ID, s62.Source_c,s62.Engineering_Commodity ,file_name, S64.ARWS64_TYGRA_ENRG_CMMDTY_X

)x
where x.ARWS64_TYGRA_ENRG_CMMDTY_X is NULL
  and x.Processing_ID = @GUID	 	
)z
;

 -- validate start point parts
 -- validation for slash
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	       Err.Source_c                                 as [ARWE02_SOURCE_C],
	       staging_data_error_value                     as [ARWE02_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE02_ERROR_X],
	       Err.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       Err.file_name                                as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       Err.ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS62_TYGRA_SUMMARY'                      as [ARWE02_STAGING_TABLE_X],
	       'PRE_VALIDATION'                             as [ARWE02_ERROR_TYPE_X], --WARNING
	       'Tygra parts'                                as [ARWE02_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE02_ROW_IDX],
		   ''                                           as ARWE02_Part_Index,
		   err.engineering_commodity                    as ARWE02_Arrow_value
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS62_TYGRA_SUMMARY  
              ,Source_c
			  ,Vehicle_name
			  ,engineering_commodity  
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then Start_Point_part_prefix
				    when error_col = 'match_position_base_slash'    then Start_Point_part_base 
				    when error_col = 'match_position_suffix_slash'  then Start_Point_part_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then 'Start Point part Prefix contains a slash'
				    when error_col = 'match_position_base_slash'    then 'Start Point part Base contains a slash'
				    when error_col = 'match_position_suffix_slash'  then 'Start Point part Suffix contains a slash'
			   END as error_msg
			 from 
             (SELECT 
 			         Processing_ID
				    ,file_name
				    ,ARWS62_TYGRA_SUMMARY
                    ,Source_c
					,vehicle_name
					,engineering_commodity  
					,row_idx
					,Start_Point_part_prefix
					,Case when CHARINDEX('/',Start_Point_part_prefix) > 0 then 1 else 0 end as match_position_prefix_slash 
					,Start_Point_part_base
					,case when CHARINDEX('/',Start_Point_part_base) > 0 then 1 else 0 end as match_position_base_slash   
					,Start_Point_part_suffix	
					,case when CHARINDEX('/',Start_Point_part_suffix ) > 0 then 1 else 0 end  as match_position_suffix_slash  
                    ,row_number() over (partition by s62.Processing_ID, s62.vehicle_name, Start_Point_part_prefix,Start_Point_part_base,Start_Point_part_suffix   Order by s62.vehicle_name) as rownum
                FROM PARWS62_TYGRA_SUMMARY s62
				join PARWS64_TYGRA_ENRG_CMMDTY s64
				on s62.Vehicle_name = s64.ARWS64_TYGRA_PROGRAM
				and s62.Engineering_Commodity = s64.ARWS64_ARROW_ENRG_CMMDTY_X
               WHERE Processing_ID = @GUID 
				
        ) s62
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_slash
                                              ,match_position_base_slash 
                                              ,match_position_suffix_slash  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;


-- validation for decimal 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	       Err.Source_c                                 as [ARWE02_SOURCE_C],
	       staging_data_error_value                     as [ARWE02_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE02_ERROR_X],
	       Err.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       Err.file_name                                as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       Err.ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS62_TYGRA_SUMMARY'                      as [ARWE02_STAGING_TABLE_X],
	       'PRE_VALIDATION'                             as [ARWE02_ERROR_TYPE_X], --WARNING
	       'Tygra parts'                                as [ARWE02_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE02_ROW_IDX],
		   ''                                           as ARWE02_Part_Index,
		   err.engineering_commodity                    as ARWE02_Arrow_value
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS62_TYGRA_SUMMARY  
              ,Source_c
			  ,Vehicle_name
			  ,engineering_commodity  
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then Start_Point_part_prefix
				    when error_col = 'match_position_base_decimal'    then Start_Point_part_base 
				    when error_col = 'match_position_suffix_decimal'  then Start_Point_part_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then 'Start Point part Prefix contains a decimal point'
				    when error_col = 'match_position_base_decimal'    then 'Start Point part Base contains a decimal point'
				    when error_col = 'match_position_suffix_decimal'  then 'Start Point part Suffix contains a decimal point'
			   END as error_msg
			 from 
             (SELECT 
 			         Processing_ID
				    ,file_name
				    ,ARWS62_TYGRA_SUMMARY
                    ,Source_c
					,vehicle_name
			        ,engineering_commodity  
					,row_idx
					,Start_Point_part_prefix
					,Case when CHARINDEX('.',Start_Point_part_prefix) > 0 then 1 else 0 end as match_position_prefix_decimal 
					,Start_Point_part_base
					,case when CHARINDEX('.',Start_Point_part_base) > 0 then 1 else 0 end as match_position_base_decimal    
					,Start_Point_part_suffix	
					,case when CHARINDEX('.',Start_Point_part_suffix ) > 0 then 1 else 0 end  as match_position_suffix_decimal  
                    ,row_number() over (partition by s62.Processing_ID, s62.vehicle_name, Start_Point_part_prefix,Start_Point_part_base,Start_Point_part_suffix   Order by s62.vehicle_name) as rownum
                FROM PARWS62_TYGRA_SUMMARY s62
				join PARWS64_TYGRA_ENRG_CMMDTY s64
				on s62.Vehicle_name = s64.ARWS64_TYGRA_PROGRAM
				and s62.Engineering_Commodity = s64.ARWS64_ARROW_ENRG_CMMDTY_X
               WHERE Processing_ID = @GUID 
				
        ) s62
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_decimal 
                                              ,match_position_base_decimal 
                                              ,match_position_suffix_decimal  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;
 
 
--Error for end_item_prefix over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Start_Point_part_prefix
		,'Start Point part Prefix can''t be more than 32 characters.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY               as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'            as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                   as [ARWE02_ERROR_TYPE_X] --WARNING
	    ,'Tygra parts'                      as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                            as [ARWE02_ROW_IDX]
	    ,''                                 as ARWE02_Part_Index
	    ,Engineering_Commodity              as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62
  join PARWS64_TYGRA_ENRG_CMMDTY s64
	on s62.Vehicle_name = s64.ARWS64_TYGRA_PROGRAM
   and s62.Engineering_Commodity = s64.ARWS64_ARROW_ENRG_CMMDTY_X
  Where Processing_ID    = @GUID
    and DATALENGTH(Start_Point_part_prefix)  > 32;

--Error for end_item_base over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Start_Point_part_base
		,'Start Point part Base can''t be more than 32 characters.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                         as [ARWE02_ERROR_TYPE_X] --WARNING
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,Engineering_Commodity                    as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62   
    join PARWS64_TYGRA_ENRG_CMMDTY s64
	on s62.Vehicle_name = s64.ARWS64_TYGRA_PROGRAM
   and s62.Engineering_Commodity = s64.ARWS64_ARROW_ENRG_CMMDTY_X
  Where Processing_ID    = @GUID
    and DATALENGTH(Start_Point_part_base)  > 32;
	
--Error for end_item_suffix over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Start_Point_part_suffix
		,'Start Point part Suffix can''t be more than 32 characters.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                         as [ARWE02_ERROR_TYPE_X] --WARNING
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,Engineering_Commodity                    as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62
    join PARWS64_TYGRA_ENRG_CMMDTY s64
	on s62.Vehicle_name = s64.ARWS64_TYGRA_PROGRAM
   and s62.Engineering_Commodity = s64.ARWS64_ARROW_ENRG_CMMDTY_X
  Where Processing_ID    = @GUID
    and DATALENGTH(Start_Point_part_suffix)  > 32
 ;
 
 	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[program]
		,'Control Model PROGRAM missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE' 
	    ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --ERROR                    
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.program is NULL
	   and S61.processing_ID = @GUID
	) Err
	;

 INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[region]
		,'Control Model REGION missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE' 
	    ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --ERROR                      
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.region is NULL 
	   	   and S61.processing_ID = @GUID
	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[region]
		,'Control Model REGION Invalid from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'   
	    ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --ERROR                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
	(
	     SELECT 
          Processing_ID,
		  s61.program,
		  ccm,
		  region,
		  Source_c,
          ARWS61_TYGRA_TITLE_PAGE,
		  file_name,
		  row_idx
        FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
		join PARWS63_TYGRA_CM_MAPPING  s63
		on s61.region = s63.STAGING_REGION
        WHERE S61.processing_ID =  @GUID
	    and NOT  Exists
		      (Select 'X'
			     from  [dbo].[PARWA06_RGN] a06
                where s63.ARROW_REGION = a06.ARWA06_RGN_C
              )
                   
       ) Err
  ;

  	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[CM_MDLYR]
		,'Control Model MODEL YEAR missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
        ,OBJECT_NAME(@@PROCID) as procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
	    ,'PRE_VALIDATION'          as [ARWE02_ERROR_TYPE_X] --ERROR                     
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE (s61.[CM_MDLYR] is NULL or s61.[CM_MDLYR] = '')
	   	   and S61.processing_ID = @GUID 
	) Err
	;


 -- VALIDATE BOB PIA EI, first split BOB PIA EI into Prefix, Base and Suffix and check against Start Point Prefix, Start Point Base and Start Point Suffix

	-- Check if BOB_PIA_EI has all three Prefix Base and Suffix 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'BOB PIA EI should have all Prefix-Base-Suffix values' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,0                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   From 
   (
   SELECT 
			  dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 1, '-') AS Prefix,
			  dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 2, '-') AS Base,
			  dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 3, '-') AS Suffix,
			  file_name, row_idx , Source_c
		FROM [dbo].[PARWS62_TYGRA_SUMMARY] where Processing_Id=@GUID
   ) X
   where Prefix='' or Base='' or Suffix=''
   ;
	-- Check if the BOB_PIA_EI prefix base and suffix are Start Point prefix base and suffix
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'BOB PIA EI should be an existing Start Point Prefix-Base-Suffix' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   
   From 
   (Select Source_c,[Start_Point_Part_Prefix],[Start_Point_Part_Base],[Start_Point_Part_Suffix]
   ,[Processing_ID],file_name,ARWS62_TYGRA_SUMMARY,row_idx,
   dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 1, '-') AS Prefix,
   dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 2, '-') AS Base,
   dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 3, '-') AS Suffix
   FROM PARWS62_TYGRA_SUMMARY
  Where Processing_ID    = @GUID ) S62
 WHERE (Start_Point_Part_Prefix != Prefix    
AND [Start_Point_Part_Base] != Base
AND [Start_Point_Part_Suffix] != Suffix)
AND (Prefix !='' AND Base !='' AND Suffix !='')
AND (Prefix is NOT NULL AND Base is NOT NULL AND Suffix is NOT NULL)
;



	-- Check if FEDEBOM BOB_PIA_EI has all three Prefix Base and Suffix 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'FEDEBOM PLANNED BOB PIA EI should have all Prefix-Base-Suffix values' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,0                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   From 
   (
   SELECT 
			  dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 1, '-') AS Prefix,
			  dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 2, '-') AS Base,
			  dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 3, '-') AS Suffix,
			  file_name, row_idx , Source_c
		FROM [dbo].[PARWS62_TYGRA_SUMMARY] where Processing_Id=@GUID
   ) X
   where Prefix='' or Base='' or Suffix=''
   ;
	-- Check if the FEDEBOM BOB_PIA_EI prefix base and suffix are FEDEBOM PLANNED Point prefix base and suffix
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'FEDEBOM PLANNED BOB PIA EI should be an existing FEDEBOM PLANNED Point Prefix-Base-Suffix' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   
   From 
   (Select Source_c,[FEDEBOM_Planned_Prefix],[FEDEBOM_Planned_Base],[FEDEBOM_Planned_Suffix]
   ,[Processing_ID],file_name,ARWS62_TYGRA_SUMMARY,row_idx,
   dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 1, '-') AS Prefix,
   dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 2, '-') AS Base,
   dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 3, '-') AS Suffix
   FROM PARWS62_TYGRA_SUMMARY
  Where Processing_ID    = @GUID ) S62
 WHERE (FEDEBOM_Planned_Prefix != Prefix    
AND [FEDEBOM_Planned_Base] != Base
AND [FEDEBOM_Planned_Suffix] != Suffix)
AND (Prefix !='' AND Base !='' AND Suffix !='')
AND (Prefix is NOT NULL AND Base is NOT NULL AND Suffix is NOT NULL)
;

-- Starting point Prefix, base and suffix cannot be empty

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,''
		,'Starting Point Prefix, Base and Suffix cannot be blank or NULL.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'PRE_VALIDATION'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   
  FROM PARWS62_TYGRA_SUMMARY S62
  Where
  S62.Processing_ID    = @GUID
  AND (
  (S62.Start_Point_Part_Prefix='' and S62.Start_Point_Part_Base ='' and S62.Start_Point_Part_Suffix='') 
  OR (S62.Start_Point_Part_Prefix is NULL AND S62.Start_Point_Part_Base is NULL and S62.Start_Point_Part_Suffix is NULL) 
  )


END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS62_TYGRA_SUMMARY'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	

GO
