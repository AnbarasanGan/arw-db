SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 06/30/2022
-- Description:	Load Processing data from stage table to base table for improvement ideas
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/27/22    ASHAIK12  DE260318  Appending supplier key to fix pink screen
-- 07/28/2022  ASHAIK12  DE260907  Remove join on u07 key 
-- 08/04/22    ASHAIK12  US3906818 Fix U07 supplier key join from using ud2 to u09 view
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VAII_LOAD_PROCESSING_COSTS]
-- Input Parameter
@GUID          Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

-------U68 INSERT

INSERT INTO PARWUD6_PROCG_VRNT_IMPRV
SELECT 
       --ARWUD6_PROCG_VRNT_ADJ_K Identity key
	   u09_view.[ARWU09_CCTSS_VRNT_SUPL_K]  as ARWU09_CCTSS_VRNT_SUPL_K
      ,S52.row_idx   as ARWUD6_PROCG_COST_DSPLY_SEQ_R
      ,ARWUD2_CCTSS_VRNT_IMPRV_K                      as ARWUD2_CCTSS_VRNT_IMPRV_K
      ,IsNULL(S52.operation_index,'')                 as ARWUD6_PROCG_OPER_IX_C
      ,IsNULL(S52.operation_desc,'')                  as ARWUD6_PROCG_OPER_X

	  ,Case When A28.ARWA28_CNTRY_K is Null then 
		         A28_EmptyStr.ARWA28_CNTRY_K 
			Else A28.ARWA28_CNTRY_K 
	   End as ARWA28_MFG_LOC_CNTRY_K

      ,A29.ARWA29_CRCY_K                              as ARWA29_LCL_CRCY_K
      ,IsNULL(S52.machine_make_model,'')              as ARWUD6_MACH_MAKE_MDL_X
      ,CASE WHEN s52.capital_exp_for_machine = '' then '0.00'
	        else ltrim(rtrim(CAST(s52.capital_exp_for_machine as decimal (28,9))) )     
	   END AS ARWUD6_CPTL_EXPNDTR_FOR_MACH_A
	  ,CASE WHEN s52.machine_size = '' then  '0.00'
	        ELSE ltrim(rtrim(CAST(s52.machine_size as decimal (19,9))   ))
       END AS ARWUD6_MACH_SIZE_IN_MET_TN_Q
	  ,IsNull(S52.no_of_pieces_per_subassy,0)         as ARWUD6_PCE_PER_SUB_ASSY_Q
      ,IsNULL(S52.no_of_pieces_per_cycle,0)           as ARWUD6_PCS_PER_CYC_Q
      ,IsNULL(S52.cycle_time_sec,0)                   as ARWUD6_CYC_TIME_IN_SEC_Q
      ,IsNULL(S52.machinehourly_operation_overhead,0) as ARWUD6_MACH_OPER_OVRHD_HRLY_A
      ,IsNULL(S52.direct_headcount,0)                 as ARWUD6_DIR_HDCNT_Q
      ,IsNULL(S52.direct_hourly_labor_headcount,0)    as ARWUD6_DIR_HRLY_LBR_HDCNT_A
      ,IsNULL(S52.indirect_labor_costs,0)             as ARWUD6_INDIR_LBR_PER_DIR_P
      ,IsNULL(S52.fringes,0)                          as ARWUD6_FRNG_PER_DIR_LBR_P
      ,IsNULL(S52.packaging_costs,0)                  as ARWUD6_PKNG_COST_PER_PCE_A
      ,IsNULL(S52.logistics_cost,0)                   as ARWUD6_LGSTCS_COST_PER_PCE_A
      ,IsNULL(S52.tax_duty_per_piece,0)               as ARWUD6_TAX_AND_DUTY_PER_PCE_A
      ,IsNULL(S52.licensing_costs,0)                  as ARWUD6_LICSNG_COST_PER_PCE_A
      ,IsNULL(S52.comments,'')                        as ARWUD6_PROCG_ASSMP_CMT_X
      ,@TIME_STAMP                                   as ARWUD6_CREATE_S
      ,@CDSID                                         as ARWUD6_CREATE_USER_C                              
      ,@TIME_STAMP                                   as ARWUD6_LAST_UPDT_S
      ,@CDSID                                         as ARWUD6_LAST_UPDT_USER_C                              
   From [dbo].[PARWS45_VA_COVER_PAGE_INFO]       S45 
  JOIN  [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] S52
    ON S52.Processing_ID       = S45.Processing_ID
   AND S52.filename            = S45.filename
   JOIN [dbo].[PARWS67_VA_IMPROVEMENT_IDEAS_INFO]  S67
    ON S45.Processing_ID       = S67.Processing_ID
   AND S45.filename            = S67.filename
   AND S52.change_id = S67.improvement_id
   
 -- Join with Supplier Qoute View
   JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view
    ON S45.Eng_SubCommodity_name        = u09_view.[ARWA03_ENRG_SUB_CMMDTY_X]
	AND S45.User_Selected_ENRG_CMMDTY_X = u09_view.ARWA02_ENRG_CMMDTY_X
    AND S45.User_Selected_CTSP_N         = u09_view.ARWU31_CTSP_N
    AND S45.User_Selected_CTSP_Region_C  = u09_view.[ARWA06_RGN_C]
    AND S45.User_Selected_BNCMK_VRNT_N   = u09_view.[ARWU01_BNCHMK_VRNT_N]     --BoB variant
    AND S45.User_Selected_SUPL_N         = u09_view.ARWA17_SUPL_N
    AND S45.User_Selected_SUPL_CNTRY_N   = u09_view.ARWA28_CNTRY_N
    AND S45.User_Selected_SUPL_C         = u09_view.ARWA17_SUPL_C
    AND S45.User_selected_WALK_VRNT_X    = u09_view.ARWU04_VRNT_N

--Design Adjustment Part
      Join [dbo].PARWUD2_CCTSS_VRNT_IMPRV   UD2
        ON UD2.ARWU04_CCTSS_VRNT_K = u09_view.ARWU04_CCTSS_VRNT_K
       AND UD2.[ARWUD2_CCTSS_VRNT_IMPRV_ID_N] = (CASE 
	      WHEN S67.originator = 'Supplier'
		      THEN  S52.change_id + '#' + CONVERT(VARCHAR,u09_view.[ARWU07_CCTSS_SUPL_K])  	            
		       ELSE S52.change_id 
        END)

--Currency   
      JOIN dbo.PARWA29_CRCY  A29          ON A29.ARWA29_CRCY_C = s52.local_currency
--Manufacturing Location
 Left JOIN dbo.PARWA28_CNTRY A28          ON A28.ARWA28_CNTRY_N               = s52.manufacturing_location
      JOIN dbo.PARWA28_CNTRY A28_EmptyStr ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

Where S45.Processing_ID             = @GUID
  AND S45.Skip_loading_due_to_error_f = 0
  AND S52.cost_type='Improvement Costs'
;


GO
