DROP PROCEDURE [dbo].[PARWP_CCT_LOAD_U08_FINAL_ASSY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ashaik12
-- Create date: 05/24/2019
-- Description:	After the CCS is processed, this procedure loads data into the CCt table U08 for Final Assembly data(displayed in the Cluster Grouping Assembly tab in CCT).
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   01/10/2020  Added TimeStamp parameter
-- Ashaik12   08/31/2020  Simplified logic for total to handle CCS v10.0 and GCS
--==============================================
CREATE PROCEDURE  [dbo].[PARWP_CCT_LOAD_U08_FINAL_ASSY] 
-- Input Parameter
@CCTSS_K INT,
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME


AS

SET NOCOUNT ON;

MERGE INTO [dbo].[PARWU08_CCTSS_DSGN_SUPL] U08
USING
(
Select 
 ARWU08_CCTSS_DSGN_SUPL_K
--,ARWU17_BOM_SUB_ASSY_K
,SUM(Direct_Labor) AS Tot_Direct_Labor
,SUM(Direct_Fringe) AS Tot_Direct_Fringe
,SUM(Indirect_Labor) As Tot_Indirect_Labor
,SUM(Indirect_Fringe) AS Tot_Indirect_Fringe
,SUM(Overhead) As Tot_Overhead
,SUM(Misc) As Tot_Misc
,SUM(FINAL_ASSEMBLY_COST_LoCurr) as Total
,SUM(Final_Assembly_Labor_w_markups) As Tot_Sub_Assy_Labor_w_Markups
From
(
select 
 (V16.DIRECT_LABOR_COST_PER_OPRTN)*(V16.ARWU22_CRCY_PER_SUPL_CRCY_R)*(V16.ARWU33_CRCY_PER_USD_R)   AS Direct_Labor
,(V16.DIRECT_LABOR_COST_PER_OPRTN)*(V16.ARWU22_CRCY_PER_SUPL_CRCY_R)*(V16.ARWU33_CRCY_PER_USD_R)*(V16.ARWU29_FRNG_PER_DIR_LBR_P) AS Direct_Fringe
,(V16.DIRECT_LABOR_COST_PER_OPRTN)*(V16.ARWU22_CRCY_PER_SUPL_CRCY_R)*(V16.ARWU33_CRCY_PER_USD_R)*(V16.ARWU29_INDIR_LBR_PER_DIR_P) AS Indirect_Labor
,(V16.DIRECT_LABOR_COST_PER_OPRTN)*(V16.ARWU22_CRCY_PER_SUPL_CRCY_R)*(V16.ARWU33_CRCY_PER_USD_R)*(V16.ARWU29_INDIR_LBR_PER_DIR_P)*(ARWU29_FRNG_PER_DIR_LBR_P) AS Indirect_Fringe
,(V16.MCHN_OP_OVHD_CSTS_PER_OPRTN)*(V16.ARWU22_CRCY_PER_SUPL_CRCY_R)*(V16.ARWU33_CRCY_PER_USD_R) AS Overhead
,(V16.ARWU29_PKNG_COST_PER_PCE_A+V16.ARWU29_LGSTCS_COST_PER_PCE_A+V16.ARWU29_TAX_AND_DUTY_PER_PCE_A)*(V16.ARWU22_CRCY_PER_SUPL_CRCY_R)*(V16.ARWU33_CRCY_PER_USD_R) AS Misc
,V16.ARWU08_CCTSS_DSGN_SUPL_K
,V16.FINAL_ASSEMBLY_COST_LoCurr*(V16.ARWU33_CRCY_PER_USD_R) as FINAL_ASSEMBLY_COST_LoCurr
--,V16.[ARWU17_BOM_SUB_ASSY_N]
,((V16.FINAL_ASSEMBLY_COST_LoCurr)*(V16.ARWU33_CRCY_PER_USD_R))*(1+V21.COMPOUNDED_TOTAL) as Final_Assembly_Labor_w_markups
FROM [dbo].[PARWV16_CCS_FINAL_ASSEMBLY_FLAT] V16
JOIN [dbo].[PARWV21_FINAL_ASSEMBLY_MFG_MRKP] V21
ON  V16.ARWU08_CCTSS_DSGN_SUPL_K=V21.[ARWU08_CCTSS_DSGN_SUPL_K]
--AND V16.ARWU17_BOM_SUB_ASSY_K=V20.ARWU17_BOM_SUB_ASSY_K
WHERE V16.ARWU01_CCTSS_K=@CCTSS_K
) a
group by a.ARWU08_CCTSS_DSGN_SUPL_K
--,a.ARWU17_BOM_SUB_ASSY_K
) U08_Load
ON (
 U08.[ARWU08_CCTSS_DSGN_SUPL_K]=U08_Load.[ARWU08_CCTSS_DSGN_SUPL_K]
)
WHEN MATCHED THEN 
          UPDATE SET
             [ARWU08_FNL_ASSY_DIR_LBR_A]    = Tot_Direct_Labor
			,[ARWU08_FNL_ASSY_DIR_FRNG_A]   = Tot_Direct_Fringe
			,[ARWU08_FNL_ASSY_INDIR_LBR_A]  = Tot_Indirect_Labor
			,[ARWU08_FNL_ASSY_INDIR_FRNG_A] = Tot_Indirect_Fringe
			,[ARWU08_FNL_ASSY_OVRHD_A]      = Tot_Overhead
			,[ARWU08_FNL_ASSY_MISC_A]       = Tot_Misc
			,[ARWU08_FNL_ASSY_TOT_A]        = Total
			,[ARWU08_FNL_ASSY_TOT_W_MRKP_A] = Tot_Sub_Assy_Labor_w_Markups
			,[ARWU08_LAST_UPDT_S]           = @TIME_STAMP
			,[ARWU08_LAST_UPDT_USER_C]      = @CDSID;


GO
