DROP PROCEDURE [dbo].[PARWP_PBOM_MASTER]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 01/08/2020
-- Description:	Master Procedure to call PBOM Stored Procedures
-- this version of the MASTER has code to stop the execution of the procedure if any validation produces an ERROR
-- IN parameter:  @GUIDIN  - Staging processing ID
--                @CDSID   - User that ran the file import 
-- Out paramenter:@@result - 1 indicates the program ran without any abnormal error. 0 indicates an abnormal error (system processin error)
-- How to run:
--   Declare @GUIDIN varchar(500);
--   Declare @CDSID  varchar(8)
--   Declare @result INT
--   execute PARWP_PBOM_MASTER 'F4A1CC72-30B9-49DA-8824-E2E2C1993BC9', 'ASOLOSKY', @result OUTPUT;
--   select @result as PBOM;
-- =============================================
-- Changes
-- =============================================
-- Author     Date       User Story  Description
-- ------     -----      ----------  -----------
-- rwesley2   2/21/2020              added validation for Region
-- ashaik12   4/15/2020              Added validation for End item
-- asolosky   4/30/2020              Moved the validation code to PARWP_PBOM_VALIDATIONS
-- rwesley2   09-11-2020 US1910880   Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10/20/2020 US1996362   Switch from E02 to E03 and include Excel column
-- Asolosky   03/22/2022 US3447020   Added PARWP_CALC_MASTER_LOAD_PRIMARY to load the D tables
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_PBOM_MASTER] 
@GUIDIN varchar(500), 
@CDSID  varchar(8),
@result varchar(5000) Output

AS
Begin
 DECLARE @Processing_Status_x VARCHAR(500);
 DECLARE @CCTSS_K             INT;
 DECLARE @FILE_TYPE           VARCHAR(50);
 DECLARE @IMPORT_STATUS       VARCHAR(50) = 'Regular';
 DECLARE @threshold           DECIMAL(5,3);
 DECLARE @TIME_STAMP          DATETIME    = GETUTCDATE();
 DECLARE @LAST_IMPT_result    VARCHAR(20) = '';
 DECLARE @ret_code            INT;
 DECLARE @ERROR_TYPE          VARCHAR(50);
 DECLARE @u01_Study Varchar(100);
 DECLARE @Primary_output_error VARCHAR(5000) = '';

 SET @result = 'Failure';

 SET NOCOUNT ON;
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));

 EXEC [dbo].[PARWP_GET_CCTSS_KEY]    @GUIDIN, @CCTSS_K OUTPUT, @FILE_TYPE = 'PBOM';
 Set @u01_Study = (Select U01.ARWU31_CTSP_N           + ' ' +
                         U01.ARWA06_RGN_C             + ' ' +
                   	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                    from PARWU01_CCTSS_FLAT U01
                   where U01.ARWU01_CCTSS_K = @CCTSS_K
 				       );
						   
-- scrub special characters for PBOM stage tables
 EXEC [dbo].[PARWP_PBOM_SCRUB_SPCL_CHARS]        @GUIDIN, @CDSID, @TIME_STAMP;

--PBOM Validation
 EXEC [dbo].[PARWP_PBOM_VALIDATIONS]             @GUIDIN, @CDSID, @TIME_STAMP; 

 -- only continue to table load SPs if there are WARNING or no errors
 EXEC [dbo].[PARWP_PBOM_GO_NO_GO]                     @GUIDIN, @CDSID, @TIME_STAMP, @ERROR_TYPE OUTPUT  

 IF @ERROR_TYPE = 'SYSTEM Error'  -- Capture System error. If system errors don't load tables
 Begin
    Set @result        = 'SYSTEM Error';  --The UI needs this set for an unexpected (system) error.
	 Set @IMPORT_STATUS = 'Processing_Error';
    GOTO EOJ          
 End

 IF @ERROR_TYPE = 'Validation Error'  -- Capture Validation error. If validation errors don't load tables
 Begin
    Set @result        = 'SUCCESS';   --The UI needs this set to 1 to display validation ERRORs .
	 Set @IMPORT_STATUS = 'Validation Error';
    GOTO EOJ          
 End

 BEGIN TRY
   
   BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master
--  Load Parts Tables
	 EXEC [dbo].[PARWP_PBOM_LOAD]        @GUIDIN, @CDSID, @TIME_STAMP, @CCTSS_K;

    exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
         @U01_k                = @CCTSS_K
       , @U06_k                = -1
       , @U04_k                = -1
       , @CDSID                = @CDSID
       , @TRIGGER              = 'PBOM IMPORT'
       , @Primary_output_error = @Primary_output_error OUTPUT
    ;
    
    If @Primary_output_error = ''
    Begin
       COMMIT TRANSACTION
       Set @result = 'SUCCESS';
    End
    Else
    Begin
       Rollback
       Set @result = @Primary_output_error;
    End
    ;
   
 END TRY

 --CATCH
 BEGIN CATCH
   Rollback;
   Set @result = 'PBOM Surgical SYSTEM ERROR:' +              
	             ' Study Key: '      + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
				    ' |Processing Id: ' + @GUIDIN +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				    ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				    ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

   INSERT INTO PARWE03_BATCH_PBOM_ERRORS
	SELECT  
	    'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
      ,@GUIDIN                           --Processing_id
		,'UNKNOWN'                         --Filename
      ,ERROR_PROCEDURE()                 --Procedure_x
      ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
      ,NULL 
		,NULL
		--ARWE03_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'PBOM MASTER PROCEDURE'
      ,0                              as ARWE03_ROW_IDX	
	   ,''                               -- part_index 
	   ,''                               -- ARROW_VALUE
		,''                               -- Column
	;

  END CATCH;	
EOJ:  

   EXEC @ret_code = [dbo].[PARWP_PBOM_UPDT_LAST_IMPT]  @GUIDIN, @CDSID, @TIME_STAMP, @IMPORT_STATUS, @CCTSS_K, @LAST_IMPT_result Output;
	-- When there's a System error in PARWP_PBOM_UPDT_LAST_IMPT, the @result must return to the UI with an error (result=0)
	If @LAST_IMPT_result = 'SYSTEM ERROR'
	   set @result = 'SYSTEM ERROR';
END;




GO
