DROP PROCEDURE [dbo].[PARWP_CCS_SCRUB_SPCL_CHARS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 10/31/2019
-- Description:	scub procedure to remove special characters from 
-- =============================================
-- CHANGES
-- Date			CDSID		Feature	 Description
-- ----------   --------    -------  -----------
-- 01/10/2020   rwesley2             add scrubbing for part index and remove cdsid and date from update and processing status from Where  
-- 07/20/2020   asolosky    1771016  Removed scrubbing for LF/CR. The validation procedure will reject if LF/CR are found. 
--                                   Can't scrub '-' to zero until the staging columns are varchar.  For now the code is commented out 
-- 09/11/2020   Asolosky   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value. The Catch was changed to add the new columns
-- =============================================	
CREATE PROCEDURE [dbo].[PARWP_CCS_SCRUB_SPCL_CHARS]
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET [part_index] = LTRIM(RTRIM(part_index)),
       [part_name]  = LTRIM(RTRIM(part_name))
  FROM [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO] 
 WHERE Processing_ID = @GUID
;

UPDATE PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO
   SET [part_index]        = LTRIM(RTRIM(part_index)),
       [part_description]  = LTRIM(RTRIM([part_description]))
  FROM PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO
 WHERE Processing_ID = @GUID
;
UPDATE PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO
   SET [part_index]        = LTRIM(RTRIM(part_index)),
       [part_description]  = LTRIM(RTRIM([part_description]))
  FROM PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO
 WHERE Processing_ID = @GUID
;
UPDATE PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO
   SET [part_index]        = LTRIM(RTRIM(part_index)),
       [part_description]  = LTRIM(RTRIM([part_description]))
  FROM PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO
 WHERE Processing_ID = @GUID
;
UPDATE PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO
   SET part_index       = LTRIM(RTRIM(part_index)),
       operation_index  = LTRIM(RTRIM(operation_index)),
	   operation_desc   = LTRIM(RTRIM(operation_desc))
  FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO
 WHERE Processing_ID = @GUID
;

/* US1824362 EDU - Entering a '-' in the CCS/GCS BOM sheets will write 2714.0 to the staging table. This would be a problem for Pre-PBOMs
--This is the reason this is code is commented.  Current state would never have a '-' in the staging table. Can't address until staging table switches from decimal to char.
--This can all be added to the S13 update statement above using a case statement.  No need to filter for '-', just check all data for the processing_id.
UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET length = 0
 from PARWS13_CCS_FORD_BOM_PARTS_INFO 
WHERE Processing_ID         = @GUID
  and LTRIM(RTRIM(length))  = '-'
;
UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET width = 0
 from PARWS13_CCS_FORD_BOM_PARTS_INFO 
WHERE Processing_ID         = @GUID
  and LTRIM(RTRIM(width))  = '-'
;
UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET depth = 0
 from PARWS13_CCS_FORD_BOM_PARTS_INFO 
WHERE Processing_ID         = @GUID
  and LTRIM(RTRIM(depth))  = '-'
;
UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET material_usage = 0
 from PARWS13_CCS_FORD_BOM_PARTS_INFO 
WHERE Processing_ID         = @GUID
  and LTRIM(RTRIM(material_usage))  = '-'
;
UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET material_thickness = 0
 from PARWS13_CCS_FORD_BOM_PARTS_INFO 
WHERE Processing_ID         = @GUID
  and LTRIM(RTRIM(material_thickness))  = '-'
;
UPDATE [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO]
   SET diameter = 0
 from PARWS13_CCS_FORD_BOM_PARTS_INFO 
WHERE Processing_ID         = @GUID
  and LTRIM(RTRIM(diameter))  = '-'
;
*/

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,GETUTCDATE() 
             ,@CDSID
             ,GETUTCDATE()
             ,@CDSID
			 ,''
			 ,'PARWP_CCS_SCRUB_SPCL_CHAR' 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
			 ,''
			 ,''
END CATCH
;

GO
