SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- ============================================================================================
-- Author:		btemkow
-- Create date: 2020-10-05
-- Description:	This SP deletes a CCTSS_DSGN and all data dependent on it. To be invoked via
--				BoB Authoring - Designs screen when user chooses to delete a Design.
-- Input Parameter:
--		@ARWU06_CCTSS_DSGN_K
-- Output Parameter: 
--		@RESULT - Returns 'SUCCESS' if successful, SQL error message if error occurred
-- How to Run:  
--		EXECUTE @RC = [dbo].[PARWP_DELETE_CCTSS_DSGN] @ARWU06_CCTSS_DSGN_K, @RESULT OUTPUT
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow	  2020-10-05  initial version
-- btemkow    2020-11-18  changed return code to an output parameter per Malek's request
-- asolosky   2021-03-18  US2385952 Table PARWU63_BOM_PART_END_ITM was changed to PARWU63_VRNT_BOM_PART_END_ITM
-- asolosky   2022-01-10  US3190286 Removed the commit and rollback.  The UI will handle it.
-- btemkow    2022-03-14  US3416696 Added delete for UC8
-- btemkow    2022-03-16  US3425919 Added delete for UC5
-- btemkow    2022-08-22  US3962137 add a check for UD2 to the U18 delete section
-- ============================================================================================
--DROP PROCEDURE [dbo].[PARWP_DELETE_CCTSS_DSGN] 

CREATE OR ALTER PROCEDURE [dbo].[PARWP_DELETE_CCTSS_DSGN] 
 @ARWU06_CCTSS_DSGN_K INT
,@RESULT VARCHAR(MAX) OUTPUT

AS

SET NOCOUNT ON;

	BEGIN TRY
--		BEGIN TRANSACTION

		--U08 key deletes

			declare @U08_delete_keys table (
			ARWU08_CCTSS_DSGN_SUPL_K int
			)

			insert into @U08_delete_keys
			select ARWU08_CCTSS_DSGN_SUPL_K
			from PARWU08_CCTSS_DSGN_SUPL
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU80_II_MNLSLCT_FNL_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU79_II_MNLSLCT_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU78_II_MNLSLCT_BOM_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU77_DA_MNLSLCT_FNL_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU76_DA_MNLSLCT_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU75_DA_MNLSLCT_BOM_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU74_SUPL_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU73_SUPL_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU62_MNLSLCT_FNL_ASSY_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU61_MNLSLCT_FNL_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU60_MNLSLCT_SUB_ASSY_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU59_MNLSLCT_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU58_MNLSLCT_DSGN_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU56_SUPL_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU55_SUPL_DSGN_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU54_FNLASSYMRKP_DSGN_IMPV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU53_FNL_ASSY_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU52_MFG_MRKP_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU51_ASSY_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU50_PROCG_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU49_RAW_MTRL_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU48_PURC_PART_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU44_FNLASSY_MRKP_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU43_FNL_ASSY_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU42_MFG_MRKP_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU41_ASSY_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU40_PROCG_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU39_RAW_MTRL_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU38_PURC_PART_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU30_FNL_ASSY_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU29_FNL_ASSY_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU28_MFG_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU27_ASSY_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU26_PROCG_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU25_RAW_MTRL_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU24_PURC_PART_COST_PARNT
			where ARWU23_PURC_PART_COST_K in (
				select ARWU23_PURC_PART_COST_K
				from PARWU23_PURC_PART_COST as U23
				join @U08_delete_keys as U08_del
					on U23.ARWU08_CCTSS_DSGN_SUPL_K = U08_del.ARWU08_CCTSS_DSGN_SUPL_K
			)

			delete from PARWU23_PURC_PART_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU08_CCTSS_DSGN_SUPL
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

		--U06 key deletes

			delete from PARWUC8_TRDOFF_ACTN_DTL_DSGN
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWUC5_CNSTR_SYS_VRNT_BM_DSGN
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWUA5_II_MNLSLCT_FNL_ASSY_STAT
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWUA4_II_MNLSLCT_SUB_ASSY_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWUA3_II_MNLSLCT_BOM_PART_STAT
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWUA2_DA_MNLSLCT_FNL_ASSY_STAT
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWUA1_DA_MNLSLCT_SUB_ASSY_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWUA0_DA_MNLSLCT_BOM_PART_STAT
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU99_MNLSLCT_FNLASSYMKRP_STAT
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU98_MNLSLCT_FNL_ASSY_STAT
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU97_MNLSLCT_SUBASSYMKRP_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWU96_MNLSLCT_SUB_ASSY_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU80_II_MNLSLCT_FNL_ASSY
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU79_II_MNLSLCT_SUB_ASSY
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU78_II_MNLSLCT_BOM_PART
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU77_DA_MNLSLCT_FNL_ASSY
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU76_DA_MNLSLCT_SUB_ASSY
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU75_DA_MNLSLCT_BOM_PART
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU62_MNLSLCT_FNL_ASSY_MRKP
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU61_MNLSLCT_FNL_ASSY
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU60_MNLSLCT_SUB_ASSY_MRKP
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU59_MNLSLCT_SUB_ASSY
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)
	
			delete from PARWU57_CCTSS_DSGN_SUB_ASSY
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU87_DSGN_IMPRV_TRDOFF
			where ARWU46_CCTSS_DSGN_IMPRV_K in (
				select ARWU46_CCTSS_DSGN_IMPRV_K
				from PARWU46_CCTSS_DSGN_IMPRV as U46
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWU47_DSGN_IMPRV_LVL2_CATG
			where ARWU46_CCTSS_DSGN_IMPRV_K in (
				select ARWU46_CCTSS_DSGN_IMPRV_K
				from PARWU46_CCTSS_DSGN_IMPRV as U46
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWU46_CCTSS_DSGN_IMPRV
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU45_CCTSS_DSGN_IMPRV_GRP
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU86_DSGN_ADJ_TRDOFF
			where ARWU37_CCTSS_DSGN_ADJ_K in (
				select ARWU37_CCTSS_DSGN_ADJ_K
				from PARWU37_CCTSS_DSGN_ADJ as U37
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWU37_CCTSS_DSGN_ADJ
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU36_CCTSS_DSGN_ADJ_GRP
			where ARWU06_CCTSS_DSGN_K  = @ARWU06_CCTSS_DSGN_K

			delete from PARWU95_MNLSLCT_DSGN_PART_STAT
			where ARWU19_DSGN_PART_K in (
				select ARWU19_DSGN_PART_K
				from PARWU19_DSGN_PART as U19
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			--2nd delete attempt on this table (because U08 key can be NULL)
			delete from PARWU58_MNLSLCT_DSGN_PART
			where ARWU19_DSGN_PART_K in (
				select ARWU19_DSGN_PART_K
				from PARWU19_DSGN_PART as U19
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWU20_DSGN_PART_GRP_IX
			where ARWU19_DSGN_PART_K in (
				select ARWU19_DSGN_PART_K
				from PARWU19_DSGN_PART as U19
				where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
			)

			delete from PARWU19_DSGN_PART
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

		--delete BOM Parts which are not referenced by any other Design Part, DA, II or VA 
			declare @U18_delete_keys table (
			ARWU18_BOM_PART_K int
			)

			insert into @U18_delete_keys
			select U18.ARWU18_BOM_PART_K
			from PARWU18_BOM_PART as U18
			join PARWU06_CCTSS_DSGN as U06
				on U18.ARWU01_CCTSS_K = U06.ARWU01_CCTSS_K
			LEFT JOIN PARWU19_DSGN_PART AS U19
				ON U18.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K
			LEFT JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
				ON U18.ARWU18_BOM_PART_K = U37.ARWU18_BOM_PART_K
			LEFT JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
				ON U18.ARWU18_BOM_PART_K = U46.ARWU18_BOM_PART_K
			LEFT JOIN PARWU65_CCTSS_VRNT_ADJ AS U65
				ON U18.ARWU18_BOM_PART_K = U65.ARWU18_BOM_PART_K
			LEFT JOIN PARWUD2_CCTSS_VRNT_IMPRV AS UD2
				ON U18.ARWU18_BOM_PART_K = UD2.ARWU18_BOM_PART_K
			where U06.ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
				AND U19.ARWU18_BOM_PART_K IS NULL
				AND U37.ARWU18_BOM_PART_K IS NULL
				AND U46.ARWU18_BOM_PART_K IS NULL
				AND U65.ARWU18_BOM_PART_K IS NULL
				AND UD2.ARWU18_BOM_PART_K IS NULL


			DELETE FROM PARWU63_VRNT_BOM_PART_END_ITM
			WHERE ARWU18_BOM_PART_K IN (
				SELECT ARWU18_BOM_PART_K
				FROM @U18_delete_keys
			)

			DELETE FROM PARWU18_BOM_PART
			WHERE ARWU18_BOM_PART_K IN (
				SELECT ARWU18_BOM_PART_K
				FROM @U18_delete_keys
			)

		----------------------------------------------------------------------------------

			delete from PARWU14_CCTSS_DSGN_DSPLY
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

			delete from PARWU06_CCTSS_DSGN
			where ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K

--			COMMIT TRANSACTION  --calling action will handle commit
			SET @RESULT = 'SUCCESS'
		END TRY
		BEGIN CATCH
--			ROLLBACK TRANSACTION --calling action will handle rollback

            Declare @u01_Study Varchar(100);
            Set @u01_Study = (Select U06.ARWU31_CTSP_N            + ' ' +
                                     U06.ARWA06_RGN_C             + ' ' +
                              	     substring(u06.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                              	     substring(u06.ARWU01_BNCHMK_VRNT_N,1,25)
                                from PARWU06_CCTSS_DSGN_FLAT U06
                               where U06.ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
            				 );
         
            Set @RESULT = 'Design Key: '      + cast(@ARWU06_CCTSS_DSGN_K as varchar(20)) + 
                          ' |Study: '         + ISNULL(@u01_Study, '') +
                          ' |GMT Date/Time: ' + CONVERT(varchar, getutcdate(), 120) +
--                        ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
--                        ' |CDS: '           + SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER)) +
                          ' |Procedure: '     + ERROR_PROCEDURE() + 
					      ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
					      ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
		END CATCH


GO
