DROP PROCEDURE [dbo].[PARWP_PBOM_AVAILABLE_FOR_SUPL_QUOTES]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2019
-- Description:	Determines if a BoB has PBOM or (Cost Sheets/DAII/Variant) files already loaded
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- IN parameter:  @CCTSS_K  = U01_K (BoB key)
-- Out paramenter:@CCS      = 'Y' If Cost Sheets/DAII/Variant files are loaded.
-- How to Execute:
--     Declare @CCS  Varchar(1);
--     execute PARWP_PBOM_AVAILABLE 130,@CCS OUTPUT;
--     select @CCS as CCS;
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_PBOM_AVAILABLE_FOR_SUPL_QUOTES] 
-- Input Parameter
 @CCTSS_K                    Int
,@CCS_DAII_VA_AVAILABLE_OUT  Varchar(1) = 'N' OUTPUT
AS

Declare @CCS_DAII_AVAILABLE Varchar(1) = 'N';
Declare @VA_AVAILABLE       Varchar(1) = 'N';

SET NOCOUNT ON;

--Check if Cost Sheet or Design Adjust/Improvement Idea files are available
Select TOP (1) @CCS_DAII_AVAILABLE = 'Y'
  From PARWU08_CCTSS_DSGN_SUPL_FLAT
 Where ARWU01_CCTSS_K = @CCTSS_K
   and (   IsNull(ARWU08_CCS_LAST_IMPT_FILE_N,'')  != '' 
        or IsNull(ARWU08_DAII_LAST_IMPT_FILE_N,'') != ''
	   )
;

--Check if Variant files are available
Select TOP (1) @VA_AVAILABLE = 'Y'
  From PARWU09_CCTSS_VRNT_SUPL_FLAT
 Where ARWU01_CCTSS_K = @CCTSS_K
   and IsNull(ARWU09_VA_LAST_IMPT_FILE_N,'') != ''
;  
  
--Return 1 variable when CCS/DAII/VA files are already loaded for the BoB
If @CCS_DAII_AVAILABLE = 'Y' or @VA_AVAILABLE = 'Y' 
   Set @CCS_DAII_VA_AVAILABLE_OUT = 'Y'
Else
   Set @CCS_DAII_VA_AVAILABLE_OUT = 'N'
;
GO
