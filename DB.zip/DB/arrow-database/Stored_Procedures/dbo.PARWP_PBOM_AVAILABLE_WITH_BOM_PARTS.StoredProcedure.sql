DROP PROCEDURE [dbo].[PARWP_PBOM_AVAILABLE_WITH_BOM_PARTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2019
-- Description:	Determines if a BoB has PBOM or (Cost Sheets/DAII/Variant) files already loaded
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- IN parameter : @CCTSS_K  = U01_K (BoB key)
-- Out parameter: @DA_II_VA_PARTS_AVAILABLE_OUT  
--                'Y' If DA, II, Variant parts exist, 'N' if no parts exist
-- How to Execute:
--     Declare @CCS  Varchar(1);
--     execute PARWP_PBOM_AVAILABLE 130,@CCS OUTPUT;
--     select @CCS as CCS;
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_PBOM_AVAILABLE_WITH_BOM_PARTS] 
-- Input Parameter
 @CCTSS_K                       Int
,@DA_II_VA_PARTS_AVAILABLE_OUT  Varchar(1) = 'N' OUTPUT
AS

Declare @DA_PARTS_AVAILABLE Varchar(1) = 'N';
Declare @II_PARTS_AVAILABLE Varchar(1) = 'N';
Declare @VA_PARTS_AVAILABLE Varchar(1) = 'N';

SET NOCOUNT ON;

--Check if Design Adjustment Parts are available 
Select TOP (1) @DA_PARTS_AVAILABLE = 'Y'
  FROM PARWU18_BOM_PART          U18 
  JOIN PARWU17_BOM_SUB_ASSY      U17 ON U17.ARWU01_CCTSS_K        = U18.ARWU01_CCTSS_K 
                                    AND U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
  JOIN PARWU06_CCTSS_DSGN_FLAT   U06 ON U06.ARWU01_CCTSS_K        = U18.ARWU01_CCTSS_K
  JOIN PARWU37_CCTSS_DSGN_ADJ    U37 ON U37.ARWU06_CCTSS_DSGN_K   = u06.ARWU06_CCTSS_DSGN_K
                                    And U37.ARWU18_BOM_PART_K     = U18.ARWU18_BOM_PART_K
 Where U06.ARWU01_CCTSS_K = @CCTSS_K
;

--Check if Improvement Parts are available
Select TOP (1) @II_PARTS_AVAILABLE = 'Y'
  FROM PARWU18_BOM_PART            U18 
  JOIN PARWU17_BOM_SUB_ASSY        U17 ON U17.ARWU01_CCTSS_K        = U18.ARWU01_CCTSS_K 
                                      AND U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
  JOIN PARWU06_CCTSS_DSGN_FLAT     U06 ON U06.ARWU01_CCTSS_K        = U18.ARWU01_CCTSS_K
  JOIN PARWU46_CCTSS_DSGN_IMPRV    U46 ON U46.ARWU06_CCTSS_DSGN_K   = u06.ARWU06_CCTSS_DSGN_K
                                      And U46.ARWU18_BOM_PART_K     = U18.ARWU18_BOM_PART_K
 Where U06.ARWU01_CCTSS_K = @CCTSS_K
;

--Check if Variant Parts are available
Select TOP (1) @VA_PARTS_AVAILABLE = 'Y'
 FROM PARWU18_BOM_PART            U18 
 JOIN PARWU17_BOM_SUB_ASSY        U17 ON U17.ARWU01_CCTSS_K        = U18.ARWU01_CCTSS_K 
                                     AND U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
 JOIN PARWU04_CCTSS_VRNT          U04 ON U04.ARWU01_CCTSS_K        = U04.ARWU01_CCTSS_K
 JOIN PARWU65_CCTSS_VRNT_ADJ      U65 ON U65.ARWU04_CCTSS_VRNT_K   = U04.ARWU04_CCTSS_VRNT_K
                                     And U65.ARWU18_BOM_PART_K     = U18.ARWU18_BOM_PART_K
 Where U04.ARWU01_CCTSS_K = @CCTSS_K
;
  
--Return Y when DA,II,VA parts exist
If IsNull(@DA_PARTS_AVAILABLE,'N') = 'Y' or IsNull(@II_PARTS_AVAILABLE,'N') = 'Y' or IsNull(@VA_PARTS_AVAILABLE,'N') = 'Y' 
   Set @DA_II_VA_PARTS_AVAILABLE_OUT = 'Y'
Else
   Set @DA_II_VA_PARTS_AVAILABLE_OUT = 'N'
;
GO
