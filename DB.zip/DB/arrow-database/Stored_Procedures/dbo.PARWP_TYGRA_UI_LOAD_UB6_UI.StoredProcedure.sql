DROP PROCEDURE IF EXISTS  [dbo].[PARWP_TYGRA_UI_LOAD_UB6_UI]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load UB6 to associate Tygra file to BoBs.  SP used in UI
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- rwesley2   06-10-2021  US2569418 add UB6 insert for BoB refresh
-- rwesley2   06-30-2021  US2623732 check U01 Tygra reqd flag and write a record where set to 1
-- rwesley2	  09-03-2021  US2835340 SP used NULL for u01 key to indicate an initial load.  UI can't pass a NULL.  Changig U01 key to 
--                                  -1 (negative 1) for initial load logic 
-- rwesley2   09-30-2021  US2879211 load Current files
--                                  pass processing ID in  
-- rwesley2   10-22-2021  UB2995475 removed P05 join.  
--                                  Added S66 join. 
--                                  Removed branching logic and Created 1 MERGE to handle INSERT for initial load and BoB refresh 

-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_UB6_UI] 
	-- Add the parameters for the stored procedure here

-- Input Parameter

@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME
,@tygra_file_name varchar(MAX)
,@tygra_file_type int
,@version  int
,@ARWUB1_TYGRA_FILE_K  int
,@load_to_pgm_name varchar(MAX) 
,@processing_id  varchar(max)



AS

SET NOCOUNT ON;

--******************************************************
-- this step updates or inserts to the UB6 table
-- the update assumes that BoBs already exist and will associate the imported Tygra file with those BoBs 
-- 
 --******************************************************
MERGE INTO [dbo].[PARWUB6_CCTSS_TYGRA_FILE] ub6
USING (
select * from (
     select s66.ARWU01_CCTSS_K 
      ,ARWA54_TYGRA_FILE_TYPE_K
	  ,@TIME_STAMP    as [ARWUB6_CREATE_S]
	  ,@CDSID         as [ARWUB6_CREATE_USER_C]
	  ,@TIME_STAMP    as [ARWUB6_LAST_UPDT_S]
	  ,@CDSID         as [ARWUB6_LAST_UPDT_USER_C]
	  ,[ARWUB1_TYGRA_FILE_K]
     from PARWUB1_TYGRA_FILE ub1
     join PARWU01_CCTSS_FLAT u01
	 on u01.[ARWU31_CTSP_N] =  @load_to_pgm_name  --template'
	 join PARWS66_TYGRA_BOB s66
	 on s66.processing_id = @processing_id
	 and u01.ARWU01_CCTSS_K = s66.ARWU01_CCTSS_K
where ub1.ARWUB1_TYGRA_FILE_K = @ARWUB1_TYGRA_FILE_K  
and ub1.ARWUB1_TYGRA_FILE_N = @tygra_file_name  
and ub1.ARWA54_TYGRA_FILE_TYPE_K = @tygra_file_type 
and ub1.ARWUB1_TYGRA_FILE_REV_R = @version  
and u01.ARWU01_TYGRA_REQD_F = 1

)x
)y
on  ub6.[ARWU01_CCTSS_K]           = y.[ARWU01_CCTSS_K]
and ub6.[ARWA54_TYGRA_FILE_TYPE_K] = y.[ARWA54_TYGRA_FILE_TYPE_K]
When MATCHED THEN UPDATE 
			SET 
	          ARWUB1_TYGRA_FILE_K = y.[ARWUB1_TYGRA_FILE_K]
	        , ARWUB6_LAST_UPDT_S = @TIME_STAMP
	        , ARWUB6_LAST_UPDT_USER_C = @CDSID

When NOT MATCHED THEN
     INSERT 
     VALUES (
	          y.ARWU01_CCTSS_K 
			 ,y.ARWA54_TYGRA_FILE_TYPE_K
	         ,y.ARWUB6_CREATE_S
	         ,y.ARWUB6_CREATE_USER_C
	         ,y.ARWUB6_LAST_UPDT_S
	         ,y.ARWUB6_LAST_UPDT_USER_C
	         ,y.ARWUB1_TYGRA_FILE_K
			 )
			 ;



GO


