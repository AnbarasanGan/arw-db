DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_REGION]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 06/25/2019
-- Description:	validate Design Adjustment Region Code
-- =============================================

-- Changes
-- =============================================
-- asamriya  09/10/2019   Added row_idx
-- Ashaik12  01/14/2020  Added Time_Stamp parameter and removed filter on Processing Status
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_REGION] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
-- Declare	@v_procedure varchar(5000) = 'PARWP_CCS_VALIDT_REGION' ;
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  Err.[Region] as [ARWE02_ERROR_VALUE],
	  'Region Code on the cover page does not match the selected Region' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS34_DAII_COVER_PAGE_INFO_K]  as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS34_DAII_COVER_PAGE_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  'Cover' as [ARWE02_EXCEL_TAB_X],
	  0,                            -- err_idx
	  '',                           --No part index
	  User_Selected_CTSP_Region_C   --ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
		  Region,
		  User_Selected_CTSP_Region_C,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS34_DAII_COVER_PAGE_INFO_K]
        FROM  [dbo].[PARWS34_DAII_COVER_PAGE_INFO]     s34    
        WHERE Processing_ID=@GUID
        and S34.User_Selected_CTSP_Region_C <> S34.Region
)
                    
       Err

    ;
END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS34_DAII_COVER_PAGE_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;


GO
