DROP PROCEDURE [dbo].[PARWP_VA_UPDT_LAST_IMPT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asamriya
-- Create date: 08/19/2019
-- Description:	load ARROW U09 Design Supplier table
-- =============================================
-- Changes
-- Author    Date       User Story  Description
-- ------    --------   ----------  -----------
-- ASOLOSKY  07/18/2020 US1694181   Added Template version to the update
-- ASOLOSKY  10/26/2020 US1950592   Changed update of Template version to only happen when there's no error.
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_VA_UPDT_LAST_IMPT] 
-- Input Parameter
@GUIDIN                 Varchar(5000),
@CDSID	                Varchar(30),
@IMPORT_STATUS      Varchar(50)

AS

SET NOCOUNT ON;

MERGE INTO [dbo].[PARWU09_CCTSS_VRNT_SUPL]  U09_Target
   USING
   (
   select   
            U09_Flat.[ARWU09_CCTSS_VRNT_SUPL_K]  
		   ,A22.ARWA22_VRNT_SUPL_QTE_STAT_K 
		   ,A22.[ARWA22_VRNT_SUPL_QTE_STAT_N]
		   ,S45.filename						
           ,S45.LAST_UPDT_S                      
           ,@CDSID                            AS [ARWU09_VA_LAST_IMPT_USER_C]
		   ,case when @IMPORT_STATUS = 'Processing_Error' then 'Error'			
			when @IMPORT_STATUS = 'Regular' and S45.Skip_loading_due_to_error_f = 0 then 'No Error'
			else 'Error' end               AS PROCESSING_STATUS
			,U09.ARWA22_VRNT_SUPL_QTE_STAT_K  as Current_Status
			,U09.[ARWU09_VA_LAST_IMPT_USER_C] as Current_Imp_User
			,U09.[ARWU09_VA_LAST_IMPT_S]      as Current_Imp_Timestamp
			,U09.[ARWU09_VA_LAST_IMPT_FILE_N] as Current_Imp_filename
			,U09.[ARWA52_VA_FILE_VER_K]       as U09_ARWA52_VA_FILE_VER_K
			,A52.[ARWA52_VA_FILE_VER_K]       as A52_ARWA52_VA_FILE_VER_K
			,ROW_NUMBER()                   OVER (PARTITION BY U09_Flat.[ARWU09_CCTSS_VRNT_SUPL_K] ORDER BY S45.filename) AS rownum    


          from [dbo].[PARWS45_VA_COVER_PAGE_INFO] S45

		              
           JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09_Flat
              on 
			         s45.[User_Selected_CTSP_N]            = U09_Flat.ARWU31_CTSP_N
            and s45.[User_Selected_CTSP_Region_C]     = U09_Flat.[ARWA06_RGN_C]
			and s45.[User_Selected_ENRG_SUB_CMMDTY_X] = U09_Flat.[ARWA03_ENRG_SUB_CMMDTY_X]
            and s45.[User_Selected_BNCMK_VRNT_N]      = U09_Flat.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
			and s45.[User_selected_WALK_VRNT_X]       = U09_Flat.[ARWU04_VRNT_N]
            AND s45.[User_Selected_SUPL_N]            = U09_Flat.ARWA17_SUPL_N
            AND s45.[User_Selected_SUPL_C]            = U09_Flat.ARWA17_SUPL_C
            AND s45.[User_Selected_SUPL_CNTRY_N]      = U09_Flat.ARWA28_CNTRY_N

				 left JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL] U09

			on U09_Flat.[ARWU09_CCTSS_VRNT_SUPL_K] = U09.[ARWU09_CCTSS_VRNT_SUPL_K]

			JOIN [PARWA22_VRNT_SUPL_QTE_STAT] A22
			
			ON A22.ARWA22_VRNT_SUPL_QTE_STAT_N = case when @IMPORT_STATUS = 'Processing_Error'  
			                                               and U09.ARWA22_VRNT_SUPL_QTE_STAT_K = (select ARWA22_VRNT_SUPL_QTE_STAT_K 
														                                            from [dbo].[PARWA22_VRNT_SUPL_QTE_STAT] 
																								   where [ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Not Imported')  
			                                          then 'Not Imported'
			                                          when @IMPORT_STATUS = 'Regular' and S45.Skip_loading_due_to_error_f = 0 then 'Imported'
			                                          else 'Import Error'
												  end			
            Join PARWA52_VA_FILE_VER A52 on a52.ARWA52_VA_FILE_VER_N = S45.TEMPLATE_VERSION
		 where S45.[Processing_ID]             =   @GUIDIN 

		) U09_Source
			
			      ON  U09_Target.[ARWU09_CCTSS_VRNT_SUPL_K]  =  U09_Source.[ARWU09_CCTSS_VRNT_SUPL_K]
				  and U09_Source.rownum = 1
				  
		 WHEN MATCHED THEN
       UPDATE SET         	
	   
	     U09_Target.ARWU09_VA_LAST_IMPT_FILE_N       = case when PROCESSING_STATUS = 'No Error' then U09_Source.filename else U09_Source.Current_Imp_filename end
		,U09_Target.ARWU09_VA_LAST_IMPT_S            = case when PROCESSING_STATUS = 'No Error' then U09_Source.LAST_UPDT_S else U09_Source.Current_Imp_Timestamp end
	    ,U09_Target.ARWU09_VA_LAST_IMPT_USER_C       = case when PROCESSING_STATUS = 'No Error' then U09_Source.ARWU09_VA_LAST_IMPT_USER_C else U09_Source.Current_Imp_User end
		,U09_Target.ARWA22_VRNT_SUPL_QTE_STAT_K		 = case when U09_Source.[ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Not Imported' and PROCESSING_STATUS = 'Error' then (select ARWA22_VRNT_SUPL_QTE_STAT_K from [dbo].[PARWA22_VRNT_SUPL_QTE_STAT] where [ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Not Imported')
														    when U09_Source.[ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Imported' and PROCESSING_STATUS = 'Error' then (select ARWA22_VRNT_SUPL_QTE_STAT_K from [dbo].[PARWA22_VRNT_SUPL_QTE_STAT] where [ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Import Error')
														    when U09_Source.[ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Import Error' and PROCESSING_STATUS = 'Error' then (select ARWA22_VRNT_SUPL_QTE_STAT_K from [dbo].[PARWA22_VRNT_SUPL_QTE_STAT] where [ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Import Error')
														    else (select ARWA22_VRNT_SUPL_QTE_STAT_K from [dbo].[PARWA22_VRNT_SUPL_QTE_STAT] where [ARWA22_VRNT_SUPL_QTE_STAT_N] = 'Imported') end														
		,U09_Target.ARWU09_LAST_UPDT_S				 = U09_Source.LAST_UPDT_S
		,U09_Target.ARWU09_LAST_UPDT_USER_C          = U09_Source.ARWU09_VA_LAST_IMPT_USER_C
		,U09_Target.ARWA52_VA_FILE_VER_K             = case when PROCESSING_STATUS = 'No Error' then U09_Source.A52_ARWA52_VA_FILE_VER_K else U09_Source.U09_ARWA52_VA_FILE_VER_K end
;


GO
