DROP PROCEDURE IF EXISTS  [dbo].[PARWP_TYGRA_UI_LOAD_PROC_TBL] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 07/301/2021
-- Description:	Load Tygra processing table
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley    09-15-2021  US2879211 - load Curent files.  New input parmameter @TYGRA_FILE_TYPE_N
--                        changed DECLARE to get A54 key to use new input parm
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_PROC_TBL] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@CDSID varchar(MAX)
,@Program_name varchar(max)
,@TYGRA_FILE_TYPE_N varchar(max)
,@wrkshp_name varchar(max)
,@wrkshp_status varchar (max)
,@Tygra_file_version INT
,@Tygra_ID INt
,@Tygra_file_name varchar(maX)
,@Tygra_file_last_updt_s varchar(max)
,@file_source varchar(max) 
,@processing_id varchar(max)

AS

--DECLARE @guid uniqueidentifier = NEWID();
DECLARE @ARWA54_TYGRA_FILE_TYPE_K INT = 
   (select ARWA54_TYGRA_FILE_TYPE_K from PARWA54_TYGRA_FILE_TYPE where [ARWA54_TYGRA_FILE_TYPE_N] = @TYGRA_FILE_TYPE_N);



SET NOCOUNT ON;


--******************************************************
-- Insert into table using input variables
 --******************************************************


INSERT INTO [dbo].[PARWP05_TYGRA_LOAD]
           ([Processing_ID]
           ,[BCJU41_ProgramNm]
           ,BCJU41_WRKSHP_NUM_C
           ,[ARWA54_TYGRA_FILE_TYPE_K]
           ,[BCJU41_WRKSHP_STATUS_C]
           ,[BCJU51_VERSION_F]
           ,[BCJU41_TYGRA_ID_K]
           ,[BCJU41_FileNameSPTygra]
		   ,[BCJU41_TygraSPFileLastModifiedDtTm]
           ,[ARWUB1_TYGRA_FILE_K]
           ,[CREATE_USER_C]
           ,[FILE_SOURCE])
     VALUES
           (@processing_id
           ,@Program_name
           ,@wrkshp_name
           ,@ARWA54_TYGRA_FILE_TYPE_K
           ,@wrkshp_status
           ,@Tygra_file_version
           ,@Tygra_ID
           ,@Tygra_file_name
           ,@Tygra_file_last_updt_s
		   ,NULL
           ,@CDSID
           ,@file_source
		   )
		   ;


GO




