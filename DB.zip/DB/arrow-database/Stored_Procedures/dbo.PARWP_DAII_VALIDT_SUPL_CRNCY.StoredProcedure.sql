DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_SUPL_CRNCY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		asamriya
-- Create date: 07/22/2019

--==============================================================================================
-- Changes              User
-- Date       CDSID     Story     Description
-- -----      ------    -----     -------------------------------------------------
-- asamriya  09/10/2019           Added row_idx
-- Asolosky  10/03/2019           Removed row_idx and hard coded for 3. 'Currency Code for the selected country...'
-- rwesley2  10/17/2019           to fix arithmetic overflow added cast to U22 currency
-- ashaik12  12/01/2019           Added Supplier Country Name to the join
-- asolosky  12/06/2019           Changed all messages from WARNING for ERROR
--                                Removed the validation 'Exchange Rate does not match CCS Exchange Rate' since it's a duplicate of the last error validation.
--                                Changed last validation's round function to 9 decimals and added the function=1 to truncate the data instead of round
-- ashaik12  12/25/2019           Refactor the joins to use U07_FLAT
-- Ashaik12  01/14/2020           Added Time_Stamp parameter and removed filter on Processing Status
-- Asolosky  01/14/2020           Changed the round function from 9,1 to 9,0 so it rounds instead of truncate
-- Asolosky  02/25/2020 DE154961  Removed rounding on Arrow tables and changed staging to round to 9 decimals (no truncation)
--                                SQL auto rounds decimals on inserts/updates so when validating, the staging data must match arrow.
-- Asolosky  09/11/2020 US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================


--********************************************************
--Validate Supplier Picked Currency Code matches the already existing Supplier Picked currency code for the same BoB
--********************************************************
CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_SUPL_CRNCY] 
	-- Add the parameters for the stored procedure here
	 @GUID varchar(500),
	 @CDSID varchar(8)
	 ,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


-----------------------------------------------------------------------------------
--Validate selected source country from the top of the Excel exchange rate tab.  It must match the CCS country loaded which is in the U21 table. 
--The country is not loaded to the U21.  It's really the currency code of the country is the A29 table.
-----------------------------------------------------------------------------------

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT 
             [ARWE02_SOURCE_C],
	         [ARWE02_ERROR_VALUE],
	         [ARWE02_ERROR_X],
	         [ARWE02_PROCESSING_ID],
	         [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS55_DAII_EXCHANGE_RATE_TAB' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates'
			 ,3             --row_idx has to be hard code.  The UI doesn't insert this record to the staging table.
		     ,''            --No part index
		     ,ARWA29_CRCY_C --ARROW Value
			 FROM
(
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         Validate.supplier_picked_crcy_c as [ARWE02_ERROR_VALUE],
	         'Currency Code for the selected country does not match GCS/CCS File' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
			 ARWA29_CRCY_C,
			 ROW_NUMBER() OVER (PARTITION BY Validate.ARWU01_CCTSS_K, Validate.ARWU07_CCTSS_SUPL_K  ORDER BY Validate.ARWS55_DAII_EXCHANGE_RATE_TAB_K ) AS Distinct_Row,
			 Validate.ROW_IDX
       FROM 
(
select U07.ARWU01_CCTSS_K
      ,U07.ARWU07_CCTSS_SUPL_K
      ,U07.ARWA17_SUPL_K
	  ,U07.ARWA17_SUPL_N
	  ,U07.ARWA17_SUPL_C
      ,U21.ARWA29_CRCY_K
	  ,A29.ARWA29_CRCY_C
	  ,U07.ARWU31_CTSP_N
	  ,U07.ARWA06_RGN_C
	  ,U07.ARWA03_ENRG_SUB_CMMDTY_X
	  ,U07.ARWU01_BNCHMK_VRNT_N
	  ,STAGE.Processing_ID
	  ,STAGE.Source_c
	  ,STAGE.supplier_picked_crcy_c
	  ,STAGE.filename
	  ,STAGE.ARWS55_DAII_EXCHANGE_RATE_TAB_K
	  ,STAGE.ROW_IDX
FROM
PARWU07_CCTSS_SUPL_FLAT U07
JOIN PARWU21_CCTSS_SUPL_CRCY U21
ON U07.ARWU07_CCTSS_SUPL_K=U21.ARWU07_CCTSS_SUPL_K
JOIN PARWA29_CRCY A29
ON A29.ARWA29_CRCY_K=U21.ARWA29_CRCY_K
JOIN
(select S34.User_Selected_CTSP_N
       ,S34.User_Selected_CTSP_Region_C
	   ,S34.User_Selected_ENRG_SUB_CMMDTY_X
	   ,S34.User_Selected_SUPL_C
	   ,S34.User_Selected_SUPL_CNTRY_N
	   ,S34.User_Selected_SUPL_N 
	   ,S34.User_Selected_BNCMK_VRNT_N
	   ,S55.supplier_picked_crcy_c
	   ,S55.currency_code
	   ,S55.usd_per_local_currency
	   ,S34.Processing_ID
	   ,S34.Processing_Status_x
	   ,S55.Source_c
	   ,S55.filename
	   ,S55.ARWS55_DAII_EXCHANGE_RATE_TAB_K
	   ,S55.ROW_IDX
FROM [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
		  JOIN [dbo].[PARWS34_DAII_COVER_PAGE_INFO] S34
		  ON S55.Processing_ID=S34.Processing_ID
	--	  AND S27.Processing_status_x=S22.Processing_Status_x
		  AND S55.filename=S34.filename
where S34.Processing_ID=@GUID		  
) STAGE
ON STAGE.User_Selected_CTSP_N             =U07.ARWU31_CTSP_N
AND STAGE.User_Selected_CTSP_Region_C     =U07.ARWA06_RGN_C
AND STAGE.User_Selected_ENRG_SUB_CMMDTY_X =U07.ARWA03_ENRG_SUB_CMMDTY_X
AND STAGE.User_Selected_BNCMK_VRNT_N      =U07.ARWU01_BNCHMK_VRNT_N
AND STAGE.User_Selected_SUPL_N            =U07.ARWA17_SUPL_N
AND STAGE.User_Selected_SUPL_C            =U07.ARWA17_SUPL_C
AND STAGE.[User_Selected_SUPL_CNTRY_N]    =U07.ARWA28_CNTRY_N
where STAGE.Processing_ID=@GUID
AND STAGE.supplier_picked_crcy_c != A29.ARWA29_CRCY_C
) Validate
)X
where X.Distinct_Row=1
;

--*********************************************************************
--Currency Exchange Rates do not match the existing Exchange Rate for the Currency Codes
--*********************************************************************
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         CAST(Validate.usd_per_local_currency as VARCHAR(500)) as [ARWE02_ERROR_VALUE],
	         'Currency Exchange Rate does not match the existing GCS/CCS Exchange Rate'  as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS55_DAII_EXCHANGE_RATE_TAB' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
			 isNull(Validate.ROW_IDX,0),
		     ''  ,                        --No part index
		     ARWU22_CRCY_PER_SUPL_CRCY_R  --ARROW Value

       FROM 
(
select U07.ARWU01_CCTSS_K
      ,U07.ARWU07_CCTSS_SUPL_K
      ,U07.ARWA17_SUPL_K
	  ,U07.ARWA17_SUPL_N
	  ,U07.ARWA17_SUPL_C
      ,U22.ARWA29_CRCY_K
	  ,A29.ARWA29_CRCY_C
	  ,U22.ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,U07.ARWU31_CTSP_N
	  ,U07.ARWA06_RGN_C
	  ,U07.ARWA03_ENRG_SUB_CMMDTY_X
	  ,U07.ARWU01_BNCHMK_VRNT_N
	  ,STAGE.Processing_ID
	  ,STAGE.Source_c
	  ,STAGE.supplier_picked_crcy_c
	  ,STAGE.currency_code
	  ,STAGE.usd_per_local_currency
	  ,STAGE.filename
	  ,STAGE.ARWS55_DAII_EXCHANGE_RATE_TAB_K
	  ,STAGE.ROW_IDX
FROM
PARWU07_CCTSS_SUPL_FLAT U07
JOIN [dbo].[PARWU22_SUPL_CRCY_EXCHG_RATE] U22
ON U07.ARWU07_CCTSS_SUPL_K=U22.ARWU07_CCTSS_SUPL_K
JOIN PARWA29_CRCY A29
ON A29.ARWA29_CRCY_K=U22.ARWA29_CRCY_K
Left JOIN
(select S34.User_Selected_CTSP_N
       ,S34.User_Selected_CTSP_Region_C
	   ,S34.User_Selected_ENRG_SUB_CMMDTY_X
	   ,S34.User_Selected_SUPL_C
	   ,S34.User_Selected_SUPL_CNTRY_N
	   ,S34.User_Selected_SUPL_N
	   ,S34.User_Selected_BNCMK_VRNT_N
	   ,S55.supplier_picked_crcy_c
	   ,S55.currency_code
	   ,S55.usd_per_local_currency
	   ,S34.Processing_ID
	   ,S34.Processing_Status_x
	   ,S55.Source_c
	   ,S55.filename
	   ,S55.ARWS55_DAII_EXCHANGE_RATE_TAB_K
	   ,s55.ROW_IDX
FROM [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55    
		  JOIN [dbo].[PARWS34_DAII_COVER_PAGE_INFO] S34    
		  ON S55.Processing_ID=S34.Processing_ID
		  AND S55.filename=S34.filename
where S34.Processing_ID=@GUID		  
) STAGE
ON STAGE.User_Selected_CTSP_N               =U07.ARWU31_CTSP_N
AND STAGE.User_Selected_CTSP_Region_C       =U07.ARWA06_RGN_C
AND STAGE.User_Selected_ENRG_SUB_CMMDTY_X   =U07.ARWA03_ENRG_SUB_CMMDTY_X
AND STAGE.User_Selected_BNCMK_VRNT_N        =U07.ARWU01_BNCHMK_VRNT_N
AND STAGE.User_Selected_SUPL_N              =U07.ARWA17_SUPL_N
AND STAGE.User_Selected_SUPL_C              =U07.ARWA17_SUPL_C
AND STAGE.[User_Selected_SUPL_CNTRY_N]      =U07.ARWA28_CNTRY_N
AND isnull(STAGE.currency_code,'#~@')       =A29.ARWA29_CRCY_C
where STAGE.Processing_ID=@GUID
AND U22.ARWU22_CRCY_PER_SUPL_CRCY_R != ROUND(isnull(STAGE.usd_per_local_currency,0),9)
) Validate
;



END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS55_DAII_EXCHANGE_RATE_TAB'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;


GO
