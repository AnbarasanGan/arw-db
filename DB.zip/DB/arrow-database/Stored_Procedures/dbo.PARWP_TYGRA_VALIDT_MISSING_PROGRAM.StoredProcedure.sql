DROP PROCEDURE [dbo].[PARWP_TYGRA_VALIDT_MISSING_PROGRAM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 01/08/2021
-- Description:	If Arrpw program not in Arrow then createa an ERROR
--              
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_MISSING_PROGRAM] 
-- Input Parameter
 @GUID varchar(MAX)
,@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select z.source_c                as [ARWE02_SOURCE_C]
      ,ISNULL(z.program,'x')      as [ARWE02_ERROR_VALUE]
	  ,'Tygra program was not found in Arrow.'  as [ARWE02_ERROR_x]
      ,z.Processing_ID           as [ARWE02_PROCESSING_ID]
	  ,z.file_name               as [ARWE02_FILENAME]
	  ,'PARWP_TYGRA_VALIDT_MISSING_PROGRAM'     as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP               as [ARWE02_CREATE_S]
	  ,@CDSID                    as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP               as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                    as [ARWE02_LAST_UPDT_USER_C]
	  ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS61_TYGRA_TITLE_PAGE'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                   as [ARWE02_ERROR_TYPE_X]
	  ,''                        as [ARWE02_EXCEL_TAB_X]
	  ,''                        as [ARWE02_ROW_IDX]
	  ,''                        as [ARWE02_Part_Index]
	  ,ISNULL(z.ARWU31_CTSP_N,'')           as [ARWE02_ARROW_Value]
from (
select  Processing_ID 
       ,Source_c
       ,program
	   ,file_name
       ,ARWU31_CTSP_N
from (
select Processing_ID 
       ,Source_c
      ,s61.program
	  ,file_name 
      ,u31.ARWU31_CTSP_N
from PARWS61_TYGRA_TITLE_PAGE s61 
left join PARWU31_CTSP  u31
on s61.program = u31.ARWU31_CTSP_N
where s61.Processing_ID = @GUID
group by Processing_ID,Source_c,s61.program,file_name,u31.ARWU31_CTSP_N
)x
where (                                        
        x.ARWU31_CTSP_N is NULL
		)
)z
;
END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS62_TYGRA_SUMMARY'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	




GO
