DROP PROCEDURE [dbo].[PARWP_VA_LOAD_MFG_MARKUPS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 07/30/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
--              DELETE for these tables is in  PARWP_VA_LOAD_ADJUSTMENT_DETAILS
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08/26/2019 Ashaik12            Fixed filter condition for Final Assembly Load
-- 08/26/2019  ashaik12           Added join on User_selected_WALK_VRNT_X
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_VA_LOAD_MFG_MARKUPS] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;


------------------- Insert into U70
INSERT INTO [dbo].[PARWU70_MFG_MRKP_VRNT_ADJ]
SELECT
   U09_view.[ARWU09_CCTSS_VRNT_SUPL_K]             as [ARWU09_CCTSS_VRNT_SUPL_K]  
  ,A38.ARWA38_MFG_MRKP_TYP_K                       as [ARWA38_MFG_MRKP_TYP_K]
  ,isNULL(mfg_markup.manufacturing_markup_value,0) as [ARWU52_MFG_MRKP_P]
  ,isNULL(mfg_markup.comments,'')                  as [ARWU52_MFG_MRKP_ASSMP_CMT_X]
  ,@TIME_STAMP                                    as [ARWU52_CREATE_S]
  ,@CDSID                                          as ARWU52_CREATE_USER_C
  ,@TIME_STAMP                                    as ARWU52_LAST_UPDT_S
  ,@CDSID                                          as ARWU52_LAST_UPDT_USER_C
 from [dbo].[PARWS54_VA_MANUFACTURING_MARKUPS_INFO]     mfg_markup
 JOIN [dbo].[PARWS45_VA_COVER_PAGE_INFO]                cover_page_stage
 ON cover_page_stage.Processing_ID        = mfg_markup.Processing_ID
 AND cover_page_stage.filename            = mfg_markup.filename

-- SUPPLIER QUOTE MFG MARKUPS VIEW
JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]  U09_view
          ON U09_view.ARWU31_CTSP_N              = cover_page_stage.User_Selected_CTSP_N
         AND U09_view.[ARWA06_RGN_C]             = cover_page_stage.User_Selected_CTSP_Region_c 
         AND U09_view.[ARWA03_ENRG_SUB_CMMDTY_X] = cover_page_stage.User_Selected_ENRG_SUB_CMMDTY_X 
         AND U09_view.[ARWU01_BNCHMK_VRNT_N]     = cover_page_stage.User_Selected_BNCMK_VRNT_N
         AND U09_view.ARWA17_SUPL_N              = cover_page_stage.User_Selected_SUPL_N
         AND U09_view.ARWA17_SUPL_C              = cover_page_stage.User_Selected_SUPL_C
         AND U09_view.ARWA28_CNTRY_N             = cover_page_stage.User_Selected_SUPL_CNTRY_N
		 AND U09_view.ARWU04_VRNT_N              = cover_page_stage.User_selected_WALK_VRNT_X
 
--AND mfg_markup.supplier_name=SUPL_QUTE.[ARWA17_SUPL_N]
-- Get A38 Key
JOIN [dbo].[PARWA38_MFG_MRKP_TYP]          A38
ON mfg_markup.manufacturing_markup_desc            = A38.[ARWA38_MFG_MRKP_TYP_X]
where cover_page_stage.Processing_ID               = @Processing_ID
  AND mfg_markup.sub_assembly_name                 = 'Adjustment Costs'
  AND mfg_markup.manufacturing_markup_value       <> 0
  AND cover_page_stage.Skip_loading_due_to_error_f = 0
 
 ;


 ------------------- Insert into U72
INSERT INTO [dbo].[PARWU72_FNLASSY_MRKP_VRNT_ADJ]
Select U09_view.[ARWU09_CCTSS_VRNT_SUPL_K]             as [ARWU09_CCTSS_VRNT_SUPL_K] 
      ,Staging.ARWA38_MFG_MRKP_TYP_K                as ARWA38_MFG_MRKP_TYP_K
      ,isNULL(Staging.manufacturing_markup_value,0) as ARWU54_FNL_ASSY_MRKP_P
      ,isNULL(Staging.comments,'')                  as ARWU54_FNLASSYMRKP_ASSMP_CMT_X
      ,@TIME_STAMP                                 as ARWU54_CREATE_S
      ,@CDSID                                       as ARWU54_CREATE_USER_C
      ,@TIME_STAMP                                 as ARWU54_LAST_UPDT_S
	  ,@CDSID                                       as ARWU54_LAST_UPDT_USER_C
  From [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]  U09_view
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
			 ,cover_page_stage.User_selected_WALK_VRNT_X
			 ,S54.manufacturing_markup_value
			 ,S54.comments
             ,A38.ARWA38_MFG_MRKP_TYP_K 
			 ,A38.ARWA38_MFG_MRKP_TYP_C
			 ,A38.ARWA38_MFG_MRKP_TYP_X
       from [dbo].[PARWS54_VA_MANUFACTURING_MARKUPS_INFO]   S54
 JOIN  [dbo].[PARWS45_VA_COVER_PAGE_INFO]                 cover_page_stage
         ON cover_page_stage.Processing_ID       = S54.Processing_ID
        AND cover_page_stage.filename            = S54.filename
	   JOIN [dbo].[PARWA38_MFG_MRKP_TYP] A38
         ON S54.manufacturing_markup_desc        = A38.[ARWA38_MFG_MRKP_TYP_X]
      where cover_page_stage.Processing_ID       = @Processing_ID
		AND cover_page_stage.Skip_loading_due_to_error_f = 0
        AND S54.sub_assembly_name                = 'Final assembly'    
      ) Staging
    ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X] = U09_view.[ARWA03_ENRG_SUB_CMMDTY_X]
   AND Staging.[User_Selected_CTSP_N]            = U09_view.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]     = U09_view.[ARWA06_RGN_C] 
    AND Staging.[User_Selected_BNCMK_VRNT_N]     = U09_view.[ARWU01_BNCHMK_VRNT_N]
   AND Staging.[User_Selected_SUPL_N]            = U09_view.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]      = U09_view.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]            = U09_view.ARWA17_SUPL_C
   AND Staging.User_selected_WALK_VRNT_X         = U09_view.ARWU04_VRNT_N
   AND Staging.manufacturing_markup_value <> 0
 ;


GO
