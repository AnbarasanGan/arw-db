SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASOLOSKY
-- Create date: 12/21/2021
-- Description:	Procedure to Delete the PARWD23_DC_VRNT_SUP_COST table based on the STUDY passed in
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_DELETE_D23_DC_VRNT_SUP_COST]
@ARWU01_CCTSS_K        int
AS

--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

  Delete PARWD23_DC_VRNT_SUP_COST
   Where ARWU04_CCTSS_VRNT_K  in (select ARWU04_CCTSS_VRNT_K from PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K = @ARWU01_CCTSS_K)
  ;

--  Select QUOTENAME(OBJECT_NAME(@@PROCID))           as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
