DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_U51U53_ASSY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ashaik12
-- Create date: 06/28/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08-20-2019  ashaik12  na	      add logic to add supplier key to improvement id name when originator is SUPPLIER 
--                                and FORD when originator is FORD on the Join Condition to match on what is inserted in U46
-- 08-28-2019  asolosky           Moved Delete to the PARWP_DAII_IMPRV_DELETE procedure
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 07/28/2020  Ashaik12           US1798783 -- update CAST on U07_K to CONVERT
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_U51U53_ASSY] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--Moved Delete to the PARWP_DAII_IMPRV_DELETE procedure

----------------------------------------------------------------------------------------------------- 
--Assembly
-----------------------------------------------------------------------------------------------------
INSERT INTO [PARWU51_ASSY_DSGN_IMPRV]
SELECT  -- [ARWU51_ASSY_DSGN_IMPRV_K] is an identity key 
       V04.ARWU08_CCTSS_DSGN_SUPL_K                             AS ARWU08_CCTSS_DSGN_SUPL_K
	   ,ROW_NUMBER() OVER (PARTITION BY COVER_PAGE_STAGE.filename, V04.ARWU08_CCTSS_DSGN_SUPL_K 
	                           ORDER BY ASSEMBLY_STAGE.row_idx
						  )                                     AS [ARWU51_ASSY_COST_DSPLY_SEQ_R]
	  ,U46.ARWU46_CCTSS_DSGN_IMPRV_K                            AS [ARWU46_CCTSS_DSGN_IMPRV_K]
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')                AS ARWU51_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')                 AS ARWU51_ASSY_OPER_X
	  
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End                                                       AS ARWA28_SRC_CNTRY_K 
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_CRCY_K 
	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU51_MACH_MAKE_MDL_X
	  ,ISNULL(ASSEMBLY_STAGE.capital_exp_for_machine,0)          AS ARWU51_CPTL_EXPNDTR_FOR_MACH_A
	  ,ISNULL(ASSEMBLY_STAGE.machine_size,0)                     AS ARWU51_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU51_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU51_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU51_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU51_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU51_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU51_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU51_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU51_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU51_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU51_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWU51_CREATE_S
	  ,@CDSID                                                    AS ARWU51_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWU51_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU51_LAST_UPDT_USER_C

  From PARWS42_DAII_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN PARWS34_DAII_COVER_PAGE_INFO       COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename

   JOIN PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
    ON COVER_PAGE_STAGE.Processing_ID       = S44.Processing_ID
   AND COVER_PAGE_STAGE.filename            = S44.filename
   AND ASSEMBLY_STAGE.change_improvement_id = S44.improvement_id

  JOIN PARWV04_DSGN_SUPL   V04
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.VARIANT
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	     AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
  
  JOIN PARWU46_CCTSS_DSGN_IMPRV U46
        ON U46.ARWU06_CCTSS_DSGN_K = V04.ARWU06_CCTSS_DSGN_K
		AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  ASSEMBLY_STAGE.change_improvement_id + '#' + CONVERT(VARCHAR,[ARWU07_CCTSS_SUPL_K]) 
	       WHEN S44.originator = 'FORD' THEN  ASSEMBLY_STAGE.change_improvement_id  + '#' + 'Ford'	            
		  ELSE ASSEMBLY_STAGE.change_improvement_id + '#' + 'UNK'   
        END)
 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency=CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''

  Where cover_page_stage.Processing_ID               = @GUIDIN
	AND ASSEMBLY_STAGE.sub_assembly_name = 'Improvement Costs'
    And cover_page_stage.Skip_loading_due_to_error_f = 0
;
----------------------------------------------------------------------------------------------------- 
--Final Assembly
-----------------------------------------------------------------------------------------------------
INSERT INTO PARWU53_FNL_ASSY_DSGN_IMPRV
SELECT -- [ARWU53_FNL_ASSY_DSGN_IMPRV_K] is an identity key
       V04.ARWU08_CCTSS_DSGN_SUPL_K                              AS ARWU08_CCTSS_DSGN_SUPL_K
      ,ROW_NUMBER() OVER (PARTITION BY COVER_PAGE_STAGE.filename, V04.ARWU08_CCTSS_DSGN_SUPL_K 
	                           ORDER BY ASSEMBLY_STAGE.row_idx
						  )                                      AS ARWU53_FNLASSYCOST_DSPLY_SEQ_R
	  ,U46.ARWU46_CCTSS_DSGN_IMPRV_K                             AS ARWU46_CCTSS_DSGN_IMPRV_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')                 AS ARWU53_FNL_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')                  AS ARWU53_FNL_ASSY_OPER_X
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_SRC_CNTRY_K
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_CRCY_K 
	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU53_MACH_MAKE_MDL_X
	  ,ISNULL(ASSEMBLY_STAGE.capital_exp_for_machine,0)          AS ARWU53_CPTL_EXPNDTR_FOR_MACH_A
	  ,ISNULL(ASSEMBLY_STAGE.machine_size,0)                     AS ARWU53_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU53_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU53_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU53_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU53_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU53_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU53_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU53_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU53_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU53_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU53_FNL_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWU53_CREATE_S
	  ,@CDSID                                                    AS ARWU53_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWU53_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU53_LAST_UPDT_USER_C

  From PARWS42_DAII_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename

   JOIN PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
    ON COVER_PAGE_STAGE.Processing_ID       = S44.Processing_ID
   AND COVER_PAGE_STAGE.filename            = S44.filename
   AND ASSEMBLY_STAGE.change_improvement_id = S44.improvement_id

   JOIN  [dbo].[PARWV04_DSGN_SUPL]  V04
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V04.[ENG_SUB_CMMDTY_DESC]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.[CTSP_REGION_CODE]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N

	   JOIN PARWU46_CCTSS_DSGN_IMPRV U46
        ON U46.ARWU06_CCTSS_DSGN_K = V04.ARWU06_CCTSS_DSGN_K
    	AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  ASSEMBLY_STAGE.change_improvement_id + '#' + CONVERT(VARCHAR,[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  ASSEMBLY_STAGE.change_improvement_id  + '#' + 'Ford'	            
		  ELSE ASSEMBLY_STAGE.change_improvement_id + '#' + 'UNK'   
        END)

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency = CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C           = ''
  Where cover_page_stage.Processing_ID               = @GUIDIN
    And cover_page_stage.Skip_loading_due_to_error_f = 0
	And ASSEMBLY_STAGE.sub_assembly_name             = 'Improvement Final Assembly'
	AND ASSEMBLY_STAGE.cost_type = 'Improvement Costs'
;


GO
