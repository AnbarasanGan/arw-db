DROP PROCEDURE IF EXISTS [dbo].[PARWP_TYGRA_UI_GET_UB1_LIST_UI] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 05/11/2021
-- Description:	Get tygra file(s) to process from UB1 table
-- business rules: returns list of Tygra file already loaded to UB1. SP is used in UI 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2	  07-29-2021  US2747200 replace global temp table with processing table
--                        changed global temp to local temp. renamed SP because it can only be used with the new
--                        SP using the processing table. These SPs end wtih _PROC_TBL. Will not work the old process.
-- rwesley2  09-03-2021   US2835340 list was not returning all UB1 records. Fixed join and added an update to get the 
--                        ACT tygra id key  
-- rwesley2  09-15-2021   US2879211 - load Curent files.  Added TYGRA_FILE_TYPE_N to temp table and insert.  
-- rwesley2  09-21-2021   US2835340 limit file list to recoreds where Tygra ID from ACT is not NULL
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_UB1_LIST_UI] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@U41_ProgramNm varchar(50) 

AS


SET NOCOUNT ON;

CREATE TABLE #file_list (
         BCJU41_ProgramNm   varchar(50)   
        ,TYGRA_FILE_TYPE_N varchar(50)
        ,BCJU41_WRKSHP_NUM_C  varchar(50)      
        ,BCJU41_WRKSHP_STATUS_C varchar(10)
		,BCJU41_FileNameSPTygra Varchar(1000)
	    ,BCJU51_VERSION_F  INT
		,BCJU41_TygraSPFileLastModifiedDtTm datetime
        ,BCJU41_TYGRA_ID_K INT
		                        )
 	;

---******************************************************
-- in UI user selects program.  Program is passed to ACT V53 and a list of file names is 
-- returned to UI. 
 --******************************************************

-- returns list of files already loaded to UB1
INSERT INTO #file_list 
select 
[ARWUB1_TYGRA_FILE_PGM_N]  
 ,case when ARWA54_TYGRA_FILE_TYPE_K = 1  then 'Scope'
       when ARWA54_TYGRA_FILE_TYPE_K = 2  then 'Current'
  else NULL
  end as TYGRA_FILE_TYPE_N
,[ARWUB1_WRKSHP_N]      
,[ARWUB1_REV_STAT_N]  
,[ARWUB1_TYGRA_FILE_N]   
,[ARWUB1_TYGRA_FILE_REV_R]
,[ARWUB1_REV_S]
,NULL   --[BCJU41_TYGRA_ID_K]
 from  [dbo].[PARWUB1_TYGRA_FILE] ub1
where ARWUB1_TYGRA_FILE_PGM_N  = @U41_ProgramNm 

--update to get ACT tygra ID
update #file_list  
set BCJU41_TYGRA_ID_K = v53.BCJU41_TYGRA_ID_K 
from [dbo].[PBCJV53_TYGRA_ARROW_LNK_SYN] v53
join #file_list  fl
 on  v53.[BCJU41_ProgramNm] = fl.[BCJU41_ProgramNm]               
 and v53.[BCJU41_FileNameSPTygra] = fl.[BCJU41_FileNameSPTygra]   
 and v53.[BCJU51_VERSION_F] = fl.[BCJU51_VERSION_F]               
 and v53.bcju41_wrkshp_status_c = fl.bcju41_wrkshp_status_c   
 where fl.BCJU41_ProgramNm = @U41_ProgramNm  
						   ;

select * from  #file_list
where BCJU41_TYGRA_ID_K is not NULL








GO


