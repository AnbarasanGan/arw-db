DROP PROCEDURE IF EXISTS [dbo].[PARWP_TYGRA_LOAD_ENRG_CMMDTY_MAPPING_UI] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 01/06/2021
-- Description:	Map TYGRA engineering commodities to ARROW engineering commodities.  SP used in the UI.
-- =============================================
-- Changes
-- CDSID        DATE     Feature  Description
-- ----------  --------  -------  -----------
--Ashaik12   03/09/2021           Use S64 table instead of M01
--rwesley2   03/15/2021           added program to s64 
--rwesley2   4-20-2021   U2453456 use MAX length when declaring a variable 
--rwesley2   10-22-2021  U2995491 remove join to P05 processing table
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_TYGRA_LOAD_ENRG_CMMDTY_MAPPING_UI] 
-- Input Parameter
@CDSID	Varchar(MAX),
@TIME_STAMP DATETIME,
@processing_id varchar(MAX)

AS
Begin 

SET NOCOUNT ON;

Begin TRY


----------------------------------------------------------------------------------------------------- 
--Load S64 Tygra mapping table with exact matches
-----------------------------------------------------------------------------------------------------

MERGE INTO PARWS64_TYGRA_ENRG_CMMDTY S64
USING
(
select * from (
select s62.vehicle_name
,s62.engineering_commodity     -- this join matches exact desriptions
,a02.ARWA02_ENRG_CMMDTY_X
from PARWA02_ENRG_CMMDTY  a02
left join PARWS62_TYGRA_SUMMARY s62 
on  engineering_commodity = ARWA02_ENRG_CMMDTY_X
where s62.processing_id = @processing_id
group by s62.vehicle_name, s62.Engineering_Commodity ,a02.ARWA02_ENRG_CMMDTY_X
) STAGING
where (                                        
        staging.Engineering_Commodity is not NULL
		)
 )x
ON (
    x.vehicle_name = s64.ARWS64_TYGRA_PROGRAM
    and x.engineering_commodity = s64.ARWS64_TYGRA_ENRG_CMMDTY_X
	and x.ARWA02_ENRG_CMMDTY_X = s64.ARWS64_ARROW_ENRG_CMMDTY_X
)
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 (  
	   x.vehicle_name
	  ,x.engineering_commodity
	  ,ARWA02_ENRG_CMMDTY_X
	  ,@TIME_STAMP               
	  ,@CDSID					 
	  ,@TIME_STAMP               
	  ,@CDSID					 
	 )
;


----------------------------------------------------------------------------------------------------- 
--Load S64 Tygra mapping table with close matches.
-- this is where one desciption or the other has the same text(words) but may have a separator like - or /
-----------------------------------------------------------------------------------------------------
--MERGE INTO PARWS64_TYGRA_ENRG_CMMDTY S64
--USING
--(
--select * from (
--select s62.vehicle_name
--,s62.engineering_commodity     -- this join matches similar desriptions
--,a02.ARWA02_ENRG_CMMDTY_X
--from PARWA02_ENRG_CMMDTY  a02
--left join PARWS62_TYGRA_SUMMARY s62 
--on replace(replace(replace(replace(replace(ARWA02_ENRG_CMMDTY_X,' ','') ,'-',''),'(','' ),')',''),'/','')   = 
--   replace(replace(replace(replace(replace(engineering_commodity,' ',''),'-',''),'(','' ),')',''),'/','')
--join [dbo].[PARWP05_TYGRA_LOAD] p05
--on s62.processing_id = p05.processing_id
--where s62.processing_id = @GUID
--group by s62.vehicle_name, s62.Engineering_Commodity ,a02.ARWA02_ENRG_CMMDTY_X
--) STAGING
--where (                                        
--        staging.Engineering_Commodity is not NULL
----		and staging.Engineering_Commodity = 'BODY ISOLATORS'
--		)
-- )x
--ON (
--    x.vehicle_name = s64.ARWS64_TYGRA_PROGRAM
--    and x.engineering_commodity = s64.ARWS64_ARROW_ENRG_CMMDTY_X
--	and x.ARWA02_ENRG_CMMDTY_X = s64.ARWS64_ARROW_ENRG_CMMDTY_X
--   )
--When NOT MATCHED THEN
--     INSERT 
--     VALUES 
--	 (  
--	   x.vehicle_name
--	  ,x.engineering_commodity
--	  ,ARWA02_ENRG_CMMDTY_X
--	  ,@TIME_STAMP               
--	  ,@CDSID					 
--	  ,@TIME_STAMP               
--	  ,@CDSID					 
--	 )
--	 ;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@processing_id                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS62_TYGRA_SUMMARY'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	

END;



GO


