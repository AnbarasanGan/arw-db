DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_PROGRAM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 03/14/2019
-- Description:	Stored Procedure to validate Program Code
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   06/04/2019  Changed the validation to compare the user selected program to the cover page program
-- Asolosky   09/10/2019  Added row_idx
-- Ashaik12   01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_PROGRAM] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(500)
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Validate Program Code coming from Cover Page
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	      Validate.[Source_c]                        as [ARWE02_SOURCE_C],
	      Validate.[Program]                         as [ARWE02_ERROR_VALUE],
	      'Program Name on the cover page, does not match the program selected'  as [ARWE02_ERROR_x],
	      Validate.[Processing_ID]                   as [ARWE02_PROCESSING_ID],
	      Validate.[filename]                        as [ARWE02_FILENAME],
	      OBJECT_NAME(@@PROCID)                      as [ARWE02_PROCEDURE_X],
	      @TIME_STAMP                                as [ARWE02_CREATE_S],
	      @CDSID                                     as [ARWE02_CREATE_USER_C],
	      @TIME_STAMP                                as [ARWE02_LAST_UPDT_S], 
		  @CDSID                                     as [ARWE02_LAST_UPDT_USER_C],
	      Validate.[ARWS22_CCS_COVER_PAGE_INFO_K]    as [ARWE02_BATCH_ERRORS_REF_K],
	      'PARWS22_CCS_COVER_PAGE_INFO'              as [ARWE02_STAGING_TABLE_X],
		  'ERROR'                                    as [ARWE02_ERROR_TYPE_X],
		  'Cover'                                    as [ARWE02_EXCEL_TAB_X],
		  0                                          as ARWE02_ROW_IDX,
		  ''                                         as ARWE02_Part_Index,
		   User_Selected_CTSP_N                      as ARWE02_ARROW_Value
       FROM 
 --Find staging records where the Program IS NOT equal to the user selected program
	   (SELECT 
               Processing_ID,
		       Program,
			   User_Selected_CTSP_N,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO S22
         WHERE Processing_ID       = @GUID
           and Program            != User_Selected_CTSP_N
        ) Validate;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP 
             ,@CDSID
			 ,''
			 ,'PARWS22_CCS_COVER_PAGE_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''                                --Part_index
		     ,''                                --Arrow value
END CATCH



GO
