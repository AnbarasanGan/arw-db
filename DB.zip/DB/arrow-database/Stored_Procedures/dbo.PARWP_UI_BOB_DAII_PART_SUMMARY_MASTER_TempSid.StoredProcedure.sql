DROP PROCEDURE [dbo].[PARWP_UI_BOB_DAII_PART_SUMMARY_MASTER_TempSid]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Asolosky
-- Create date: 11/08/2019
-- Description:	Used to run the PARWP_UI_BOB_DAII_PART_SUMMARY_GBL_TABLE procedure and return the results
--  Stored Procedure to give the bob, da, ii details for a design/supplier/part. the details include
--	1. Bob - Supplier quote, Supplier quote with Adj markup, Adjusted Bob value, Manual adjustment, Comments
--	2. DA  - Supplier quote, Supplier quote with Adj markup, Adjusted DA value, Manual adjustment, Comments
--	3. II  - Supplier quote, Supplier quote with Adj markup, Adjusted DA value, Manual adjustment, Comments
-- Input Parameter: @ARWU01_CCTSS_K, @ARWU06_CCTSS_DSGN_K
-- Output: All values from ##BOB_DAII_PART_SUMMARY
-- How to Run:  Execute PARWP_UI_BOB_DAII_PART_SUMMARY_MASTER @ARWU01_CCTSS_K = '2', @ARWU06_CCTSS_DSGN_K = '1'
-- How to Run:  Execute PARWP_UI_BOB_DAII_PART_SUMMARY_MASTER @ARWU01_CCTSS_K = '2', @ARWU06_CCTSS_DSGN_K = '%'
-- How to Run:  Execute PARWP_UI_BOB_DAII_PART_SUMMARY_MASTER @ARWU01_CCTSS_K = '%', @ARWU06_CCTSS_DSGN_K = '%'
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
--
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_UI_BOB_DAII_PART_SUMMARY_MASTER_TempSid] 
-- Parameters for the stored procedure
@ARWU01_CCTSS_K        varchar(30),
@ARWU06_CCTSS_DSGN_K   varchar(30)
AS
SET NOCOUNT ON;

BEGIN TRY
  Execute PARWP_UI_BOB_DAII_PART_SUMMARY_GBL_TABLE_TempSid @ARWU01_CCTSS_K , @ARWU06_CCTSS_DSGN_K;
  Select * From ##BOB_DAII_PART_SUMMARY_TempSid;
  DROP TABLE IF EXISTS ##BOB_DAII_PART_SUMMARY_TempSid;
END TRY

BEGIN CATCH
  Print ERROR_PROCEDURE() + ' Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) ;
  DROP TABLE IF EXISTS ##BOB_DAII_PART_SUMMARY;		
END CATCH;	
GO
