DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_RAW_MATERIALS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 3/29/2019
-- Description:	Validate Raw Materials
-- =============================================
-- Changes
-- =============================================
--                      User
-- Author    Date       Story     Description
-- ------    -----      --------  -----------
-- ASHAIK12  06/25                Added validation for calculated field
-- ASHAIK12  07/31                Changed Calculated field validations to WARNINGS
-- Asolosky  09/10/2019           Added row_idx
-- rwesley2  09/13/2019           added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019           changed warning to error for calculated field validations
-- asolosky  09/30/2019           Changed error messages to more descriptive
-- rwesley2  10/01/2019           temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	          removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	          F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/10/2020           Added TimeStamp parameter and removed filter on Processing Status
-- Ashaik12  08/31/2020           Added formulas to handle different versions in validation of reclaim revenue.
-- Asolosky  09/11/2020 US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  01/21/2021 US2209131 Use ARWA10_COST_EST_PERFD_F instead of ARWA10_CCTSS_METHD_N like '%DEA%'
-- Asolosky  04/07/2021 US2430167 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021 US2815039 Added a case statement in the first part index validation for Part Index does not belong the BOM Sub Assembly.
--                                This happens if the user does a copy paste from another sheet.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_RAW_MATERIALS] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
    -- Part Index validation - Check if the Part Index belongs to the PBOM sheet
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.Source_c                                    as [ARWE02_SOURCE_C]
	  ,Err.part_index                                  as [ARWE02_ERROR_VALUE]
	  ,Error_x                                         as [ARWE02_ERROR_X]
	  ,Err.Processing_ID                               as [ARWE02_PROCESSING_ID]
	  ,Err.filename                                    as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)                           as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP                                     as [ARWE02_CREATE_S]
	  ,@CDSID                                          as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP                                     as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                                          as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.ARWS15_CCS_RAW_MATERIALS_K                  as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                                         as ARWE02_ROW_IDX
	  ,Err.part_index
	  ,''  --No ARROW Value
  FROM 
       (
        SELECT 
		       s15.Processing_ID,
               s15.part_index,
		       s15.Processing_Status_x,
		       s15.Source_c,
		       s15.filename,
               s15.ARWS15_CCS_RAW_MATERIALS_K,
		       s15.sub_assembly_name,
		       s15.row_idx,
		       Case When S13.part_sub_assembly_name != s15.sub_assembly_name 
		            Then 'Raw Materials: Part Index was found on a different BOM Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the part index.'
			        When S13.part_sub_assembly_name is Null
		            Then 'Raw Materials: Part Index was not found on any BOM Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the part index.'
		            Else ''
		       End Error_x
          FROM PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO s15
     Left Join PARWS13_CCS_FORD_BOM_PARTS_INFO               s13
            ON s15.part_index    = s13.part_index
		   and s15.filename      = s13.file_name
		   and s15.Processing_ID = s13.Processing_ID
         WHERE s15.Processing_ID = @GUID                  
       ) Err
 Where Error_x != ''
;

--++++++++++++++++++++++++++++++++++++
    -- Part Description validation - Check if the Part Description matches to the PBOM sheet
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,Err.[part_description]  as [ARWE02_ERROR_VALUE]
	  ,'Raw Materials: Part Description does not match PBOM Part Name'   as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS15_CCS_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
      ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  part_index,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS15_CCS_RAW_MATERIALS_K],
		  sub_assembly_name,
		  row_idx
        FROM 
          [dbo].[PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO] s15
        WHERE Processing_ID= @GUID
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO] s13
               where s15.[part_index] = s13.[part_index]
			     and s15.part_description=s13.part_name
				 and s15.[filename] = s13.[file_name]
				 and s15.Processing_ID=s13.Processing_ID

)
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,Err.[local_currency]  as [ARWE02_ERROR_VALUE]
	  ,'Raw Materials: Invalid Currency Code'   as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS15_CCS_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [local_currency],
		  part_index,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS15_CCS_RAW_MATERIALS_K],
		  sub_assembly_name,
		  row_idx
        FROM 
          [dbo].[PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO] s15 
        WHERE Processing_ID=@GUID
			and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s15.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Reclaim revenue [LoCur/pc]
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c] as ARWE02_SOURCE_C
	  ,Err.reclaim_revenue 
	  ,'Raw materials - For Reclaim revenue, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename] as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS15_CCS_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index
	  ,'Calculated Value: ' +  CAST(Err.Calculated_value as Varchar(50))  --No ARROW Value
       FROM 
       (
	   select
          s22.Processing_ID,
          part_index,
		  s22.Processing_Status_x,
		  s22.Source_c,
		  s22.filename,
          [ARWS15_CCS_RAW_MATERIALS_K],
		  sub_assembly_name,
		  reclaim_revenue,
		  CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and [ARWA53_LGCY_CCS_PGM_N] is NULL    
			   THEN ((gross_usage_per_piece)*reclamation_pcntg*scrap_price)
		       ELSE  ((gross_usage_per_piece-net_usage_per_piece)*reclamation_pcntg*scrap_price) 
		  END as Calculated_value,
		  s15.row_idx
        FROM 
             [dbo].[PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO] s15
        JOIN [dbo].PARWS22_CCS_COVER_PAGE_INFO S22 On s15.Processing_ID=s22.Processing_ID and s15.filename=s22.filename
        JOIN [dbo].PARWU01_CCTSS_FLAT u01 
      	  on s22.User_Selected_CTSP_N            = u01.ARWU31_CTSP_N 
         and s22.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
         and s22.User_Selected_CTSP_Region_C     = u01.ARWA06_RGN_C
         and s22.User_Selected_BNCMK_VRNT_N      = u01.ARWU01_BNCHMK_VRNT_N
        LEFT JOIN PARWA53_LGCY_CCS_PGM A53 ON u01.ARWU31_CTSP_N = A53.[ARWA53_LGCY_CCS_PGM_N]
       WHERE s22.Processing_ID = @GUID
       ) Err
	   Where ABS(Calculated_value) - ABS(reclaim_revenue) > @threshold 

    ;

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Raw Materials: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS15_CCS_RAW_MATERIALS_K
	  ,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,'' --supplier_picked_crcy_c + ' Per Local Currency from Exchange rates sheet: ' +  CAST(usd_per_local_currency as Varchar(50))  --ARROW Value
  FROM 
      (
        SELECT 
               S15.Processing_ID
              ,s15.exchange_rate
  		      ,s15.Source_c
  		      ,s15.filename
              ,s15.ARWS15_CCS_RAW_MATERIALS_K
  		      ,s15.sub_assembly_name
  		      ,s15.part_index
			  ,s15.row_idx
			  ,S27.usd_per_local_currency
			  ,S27.supplier_picked_crcy_c
          FROM PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO S15 
		  Join PARWS27_CCS_EXCHANGE_RATE_TAB                 S27
		    On S27.Processing_ID  = S15.Processing_ID
		   And S27.filename       = S15.filename
		   And S27.currency_code  = S15.local_currency
         WHERE S15.Processing_ID  = @GUID
		   and S15.exchange_rate != S27.usd_per_local_currency
      ) Err
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
	    ,0                                 --row_idx
	    ,''  --Part_index
		,''  --Arrow value	
;
END CATCH;




GO
