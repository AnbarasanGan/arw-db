SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ===========================================================================================
-- Author:		btemkow
-- Create date: 2022-07-06
-- Description:	This SP returns the Part Cost of every End Item in a non-DC Study
-- Input Parameter: @ARWU01_CCTSS_K
-- Output: Returns the values from a select statement
-- How to Run:  Execute [PARWP_UI_PART_COST] @ARWU01_CCTSS_K = 1
-- Changes
-- =========================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow	  2022-07-06  initial version
-- =========================================================================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_UI_PART_COST] 
	@ARWU01_CCTSS_K        INTEGER

AS

SET NOCOUNT ON;

--Get the "Lowest IDC / Lowest Normalized BOV" Design Key
--to pass into PARWP_UI_COST_ALLOCATION_EI (D13)
--and PARWP_UI_COST_ALLOCATION_EI_ASM (D18)

DECLARE @D06 TABLE (
	[ARWU01_CCTSS_K] [int] NOT NULL,
	[ARWU06_CCTSS_DSGN_K] [int] NOT NULL,
	[IDC] [decimal](38, 9) NULL,
	[DESIGN_NAME] [varchar](5000) NULL,
	[TYPE] [varchar](5000) NULL,
	[ARWD06_CREATE_S] [datetime] NOT NULL,
	[ARWD06_CREATE_USER_C] [varchar](8) NOT NULL
)

INSERT INTO @D06 Execute PARWP_UI_LOWEST_IDC_DESIGN @ARWU01_CCTSS_K;

DECLARE @U06_K int = (
	select ARWU06_CCTSS_DSGN_K 
	from @D06
);

DECLARE @D13 TABLE (
	[TYPE] [varchar](5000) NULL,
	[ARWU04_CCTSS_VRNT_K] [int] NOT NULL,
	[ARWA47_FORD_END_ITM_K] [int] NOT NULL,
	[ARWA47_FORD_END_ITM_PREF_N] [varchar](5000) NULL,
	[ARWA47_FORD_END_ITM_BSE_N] [varchar](5000) NULL,
	[ARWA47_FORD_END_ITM_SFX_N] [varchar](5000) NULL,
	[ARWUB3_STRTG_PT_PART_X] [varchar](5000) NULL,
	[ARWUA9_VRNT_END_ITM_K] [int] NULL,
	[PI_LIST] [varchar](5000) NULL,
	[QUOTE_PARTS_AMT] [decimal](19, 9) NULL,
	[DA_AMT] [decimal](19, 9) NULL,
	[II_AMT] [decimal](19, 9) NULL,
	[VA_AMT] [decimal](19, 9) NULL,
	[ARWUB3_STRTG_PT_Q] [decimal](19, 9) NULL,
	[ARWUA9_FNL_ASSY_ALLOC_A] [decimal](19, 9) NULL,
	[ARWUA9_2PAGER_ALLOC_A] [decimal](19, 9) NULL,
	[ARWUA9_DIRTR_ADJ_ALLOC_A] [decimal](19, 9) NULL,
	[ARWUA9_BM_DIRTR_ADJ_ALLOC_A] [decimal](19, 9) NULL,
	[LWST_IDC] [decimal](19, 9) NULL,
	[LWST_IDC_DSGN_KEY] [int] NULL,
	[TOT_VRNT_ADJ] [decimal](19, 9) NULL,
	[PROCESSING_ID] [varchar](5000) NULL
);

--Get the PROC_ID from D13
--to pass into PARWP_UI_COST_ALLOCATION_EI_ASM (D18)

DECLARE @PROC_ID varchar(5000);

DECLARE @D18 TABLE (
	[DATATYPE] [varchar](32) NOT NULL,
	[ARWA47_FORD_END_ITM_K] [int] NULL,
	[ARWU17_BOM_SUB_ASSY_K] [int] NOT NULL,
	[ASM_QUOTE] [decimal](19, 9) NULL
);

--D18 does not include U04_K in its results so @D18_VRNT is used
--to hold multiple variants' sub assy costs

DECLARE @D18_VRNT TABLE (
	[ARWU04_CCTSS_VRNT_K] [int] NOT NULL,
	[DATATYPE] [varchar](32) NOT NULL,
	[ARWA47_FORD_END_ITM_K] [int] NULL,
	[ARWU17_BOM_SUB_ASSY_K] [int] NOT NULL,
	[ASM_QUOTE] [decimal](19, 9) NULL
);

--Invoke D13 and D18 for each Variant in the Study

DECLARE @U04_K int;

DECLARE U04_K_CUR CURSOR FOR SELECT ARWU04_CCTSS_VRNT_K FROM PARWU04_CCTSS_VRNT WHERE ARWU01_CCTSS_K = @ARWU01_CCTSS_K;
OPEN U04_K_CUR;
FETCH NEXT FROM U04_K_CUR INTO @U04_K;
WHILE @@FETCH_STATUS = 0
	BEGIN

		INSERT INTO @D13 Execute PARWP_UI_COST_ALLOCATION_EI @U04_K, @U06_K; 

		SET @PROC_ID = (
			select PROCESSING_ID 
			from @D13
			where ARWU04_CCTSS_VRNT_K = @U04_K
			group by PROCESSING_ID 
		);

		INSERT INTO @D18 Execute PARWP_UI_COST_ALLOCATION_EI_ASM @U04_K, @U06_K, @PROC_ID;

		INSERT INTO @D18_VRNT
			select
			 @U04_K
			,DATATYPE
			,ARWA47_FORD_END_ITM_K
			,ARWU17_BOM_SUB_ASSY_K
			,ASM_QUOTE
			from @D18;
		
		DELETE FROM @D18;

		FETCH NEXT FROM U04_K_CUR INTO @U04_K;
	END;

CLOSE U04_K_CUR;
DEALLOCATE U04_K_CUR;

--Get all Current Starting Point Tygra Record -> Variant mappings

DECLARE @REC_VRNT TABLE (
	 ARWUB3_TYGRA_FILE_REC_K int
	,ARWU04_CCTSS_VRNT_K int
	,ARWUB5_IN_SCOPE_F bit
);

INSERT INTO @REC_VRNT
	select
	 UB3.ARWUB3_TYGRA_FILE_REC_K
	,U04.ARWU04_CCTSS_VRNT_K
	,UB5.ARWUB5_IN_SCOPE_F
	from PARWUB5_CCTSS_TYGRA_FILE_REC as UB5
	join PARWUB3_TYGRA_FILE_REC as UB3
		on UB5.ARWUB3_TYGRA_FILE_REC_K = UB3.ARWUB3_TYGRA_FILE_REC_K
	join PARWUB1_TYGRA_FILE as UB1
		on UB3.ARWUB1_TYGRA_FILE_K = UB1.ARWUB1_TYGRA_FILE_K
	join PARWA54_TYGRA_FILE_TYPE as A54
		on UB1.ARWA54_TYGRA_FILE_TYPE_K = A54.ARWA54_TYGRA_FILE_TYPE_K
	join PARWUB4_TYGRA_FILE_REC_CCM as UB4
		on UB3.ARWUB3_TYGRA_FILE_REC_K = UB4.ARWUB3_TYGRA_FILE_REC_K
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join PARWA09_PGM_CCM as A09
		on UB2.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
	join PARWA08_CCM as A08
		on A09.ARWA08_CCM_K = A08.ARWA08_CCM_K
	join PARWU05_CCTSS_VRNT_CCM as U05
		on A09.ARWA09_PGM_CCM_K = U05.ARWA09_PGM_CCM_K
	join PARWU04_CCTSS_VRNT as U04
		on U05.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
		and UB5.ARWU01_CCTSS_K = U04.ARWU01_CCTSS_K
	where ARWUB3_JOB1_TRGT_A <> 0  --starting point
		and ARWA54_TYGRA_FILE_TYPE_N = 'Current'
		and UB5.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
	group by
	 UB3.ARWUB3_TYGRA_FILE_REC_K
	,U04.ARWU04_CCTSS_VRNT_K
	,UB5.ARWUB5_IN_SCOPE_F;

--Get all Current, Starting Point Tygra Record -> CCM mappings
--(used to build the "CCM Matrix" in the final results)

DECLARE @REC_CCM TABLE (
	 ARWUB3_TYGRA_FILE_REC_K int
	,ARWU04_CCTSS_VRNT_K int
	,ARWA08_CCM_C varchar(8)
);

INSERT INTO @REC_CCM
	select
	 UB3.ARWUB3_TYGRA_FILE_REC_K
	,U04.ARWU04_CCTSS_VRNT_K
	,ARWA08_CCM_C
	from PARWUB5_CCTSS_TYGRA_FILE_REC as UB5
	join PARWUB3_TYGRA_FILE_REC as UB3
		on UB5.ARWUB3_TYGRA_FILE_REC_K = UB3.ARWUB3_TYGRA_FILE_REC_K
	join PARWUB1_TYGRA_FILE as UB1
		on UB3.ARWUB1_TYGRA_FILE_K = UB1.ARWUB1_TYGRA_FILE_K
	join PARWA54_TYGRA_FILE_TYPE as A54
		on UB1.ARWA54_TYGRA_FILE_TYPE_K = A54.ARWA54_TYGRA_FILE_TYPE_K
	join PARWUB4_TYGRA_FILE_REC_CCM as UB4
		on UB3.ARWUB3_TYGRA_FILE_REC_K = UB4.ARWUB3_TYGRA_FILE_REC_K
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join PARWA09_PGM_CCM as A09
		on UB2.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
	join PARWA08_CCM as A08
		on A09.ARWA08_CCM_K = A08.ARWA08_CCM_K
	join PARWU05_CCTSS_VRNT_CCM as U05
		on A09.ARWA09_PGM_CCM_K = U05.ARWA09_PGM_CCM_K
	join PARWU04_CCTSS_VRNT as U04
		on U05.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
		and UB5.ARWU01_CCTSS_K = U04.ARWU01_CCTSS_K
	where ARWUB3_JOB1_TRGT_A <> 0  --starting point
		and ARWA54_TYGRA_FILE_TYPE_N = 'Current'
		and UB5.ARWU01_CCTSS_K = @ARWU01_CCTSS_K;

--Return all the Current, Starting Point Tygra Record -> Variant mappings (End Items)
--along with their Job 1 Target Costs (Act - Vehicle Target)
--and if they are In Scope and they have been mapped to Part Indexes with
--costs from the study, display those costs (BCET - Vehicle Target)

select
 A47.ARWA47_FORD_END_ITM_PREF_N as 'Prefix'
,A47.ARWA47_FORD_END_ITM_BSE_N as 'Base'
,A47.ARWA47_FORD_END_ITM_SFX_N as 'Suffix'
,UB3.ARWUB3_STRTG_PT_PART_X as 'Description'
,case when ARWUB5_IN_SCOPE_F = 0 then 'Out' else 'In' end as 'In/Out of Scope'
,UB3.ARWUB3_STRTG_PT_Q as 'Qty'
,case when ARWUB5_IN_SCOPE_F = 0 then ARWUB3_JOB1_TRGT_A / UB3.ARWUB3_STRTG_PT_Q else
	( QUOTE_PARTS_AMT
	+ coalesce(SUB_ASM_SUM,0)
	+ coalesce(ARWUA9_FNL_ASSY_ALLOC_A,0)
	+ DA_AMT
	+ II_AMT
	+ (QUOTE_PARTS_AMT 
		+ coalesce(SUB_ASM_SUM,0) 
		+ coalesce(ARWUA9_FNL_ASSY_ALLOC_A,0) 
		+ DA_AMT 
		+ II_AMT) * U04_BM.ARWU04_CMMRCL_ADJ_P
	 + coalesce(ARWUA9_2PAGER_ALLOC_A,0)
	 + coalesce(ARWUA9_BM_DIRTR_ADJ_ALLOC_A,0)
	 + VA_AMT
	 + VA_AMT * U04.ARWU04_CMMRCL_ADJ_P
	 + coalesce(ARWUA9_DIRTR_ADJ_ALLOC_A,0)) / UB3.ARWUB3_STRTG_PT_Q end as 'BCET - Part Target'
,case when ARWUB5_IN_SCOPE_F = 0 then ARWUB3_JOB1_TRGT_A else
	  QUOTE_PARTS_AMT
	+ coalesce(SUB_ASM_SUM,0)
	+ coalesce(ARWUA9_FNL_ASSY_ALLOC_A,0)
	+ DA_AMT
	+ II_AMT
	+ (QUOTE_PARTS_AMT 
		+ coalesce(SUB_ASM_SUM,0) 
		+ coalesce(ARWUA9_FNL_ASSY_ALLOC_A,0) 
		+ DA_AMT 
		+ II_AMT) * U04_BM.ARWU04_CMMRCL_ADJ_P
	 + coalesce(ARWUA9_2PAGER_ALLOC_A,0)
	 + coalesce(ARWUA9_BM_DIRTR_ADJ_ALLOC_A,0)
	 + VA_AMT
	 + VA_AMT * U04.ARWU04_CMMRCL_ADJ_P
	 + coalesce(ARWUA9_DIRTR_ADJ_ALLOC_A,0) end as 'BCET - Vehicle Target'
,ARWUB3_JOB1_TRGT_A as 'Act - Vehicle Target'
,U04.ARWU04_VRNT_N as 'Variant'
,case when REC_CCM_1.ARWA08_CCM_C = 'CM1' then 'X' else '' end as CM1
,case when REC_CCM_2.ARWA08_CCM_C = 'CM2' then 'X' else '' end as CM2
,case when REC_CCM_3.ARWA08_CCM_C = 'CM3' then 'X' else '' end as CM3
,case when REC_CCM_4.ARWA08_CCM_C = 'CM4' then 'X' else '' end as CM4
,case when REC_CCM_5.ARWA08_CCM_C = 'CM5' then 'X' else '' end as CM5
,case when REC_CCM_6.ARWA08_CCM_C = 'CM6' then 'X' else '' end as CM6
,case when REC_CCM_7.ARWA08_CCM_C = 'CM7' then 'X' else '' end as CM7
,case when REC_CCM_8.ARWA08_CCM_C = 'CM8' then 'X' else '' end as CM8
,case when REC_CCM_9.ARWA08_CCM_C = 'CM9' then 'X' else '' end as CM9
,case when REC_CCM_10.ARWA08_CCM_C = 'CM10' then 'X' else '' end as CM10
,case when REC_CCM_11.ARWA08_CCM_C = 'CM11' then 'X' else '' end as CM11
,case when REC_CCM_12.ARWA08_CCM_C = 'CM12' then 'X' else '' end as CM12
,case when REC_CCM_13.ARWA08_CCM_C = 'CM13' then 'X' else '' end as CM13
,case when REC_CCM_14.ARWA08_CCM_C = 'CM14' then 'X' else '' end as CM14
,case when REC_CCM_15.ARWA08_CCM_C = 'CM15' then 'X' else '' end as CM15
,case when REC_CCM_16.ARWA08_CCM_C = 'CM16' then 'X' else '' end as CM16
from @REC_VRNT as REC_VRNT
join PARWUB3_TYGRA_FILE_REC as UB3
	on REC_VRNT.ARWUB3_TYGRA_FILE_REC_K = UB3.ARWUB3_TYGRA_FILE_REC_K
join PARWA47_FORD_END_ITM as A47
	on UB3.ARWA47_FEDEBOM_PLN_END_ITM_K = A47.ARWA47_FORD_END_ITM_K
join PARWU04_CCTSS_VRNT as U04
	on REC_VRNT.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
join PARWU04_CCTSS_VRNT as U04_BM
	on U04_BM.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
	and U04_BM.ARWU04_BNCHMK_F = 1
left join @D13 as D13
	on U04.ARWU04_CCTSS_VRNT_K = D13.ARWU04_CCTSS_VRNT_K
	and A47.ARWA47_FORD_END_ITM_K = D13.ARWA47_FORD_END_ITM_K
left join (
	select
	 ARWU04_CCTSS_VRNT_K
	,ARWA47_FORD_END_ITM_K
	,sum(ASM_QUOTE) as SUB_ASM_SUM
	from @D18_VRNT
	group by
	 ARWU04_CCTSS_VRNT_K
	,ARWA47_FORD_END_ITM_K
) D18_GRP
	on U04.ARWU04_CCTSS_VRNT_K = D18_GRP.ARWU04_CCTSS_VRNT_K
	and A47.ARWA47_FORD_END_ITM_K = D18_GRP.ARWA47_FORD_END_ITM_K
left join @REC_CCM as REC_CCM_1
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_1.ARWUB3_TYGRA_FILE_REC_K
	and U04.ARWU04_CCTSS_VRNT_K = REC_CCM_1.ARWU04_CCTSS_VRNT_K
	and REC_CCM_1.ARWA08_CCM_C = 'CM1'
left join @REC_CCM as REC_CCM_2
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_2.ARWUB3_TYGRA_FILE_REC_K
	and U04.ARWU04_CCTSS_VRNT_K = REC_CCM_2.ARWU04_CCTSS_VRNT_K
	and REC_CCM_2.ARWA08_CCM_C = 'CM2'
left join @REC_CCM as REC_CCM_3
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_3.ARWUB3_TYGRA_FILE_REC_K
	and U04.ARWU04_CCTSS_VRNT_K = REC_CCM_3.ARWU04_CCTSS_VRNT_K
	and REC_CCM_3.ARWA08_CCM_C = 'CM3'
left join @REC_CCM as REC_CCM_4
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_4.ARWUB3_TYGRA_FILE_REC_K
	and U04.ARWU04_CCTSS_VRNT_K = REC_CCM_4.ARWU04_CCTSS_VRNT_K
	and REC_CCM_4.ARWA08_CCM_C = 'CM4'
left join @REC_CCM as REC_CCM_5
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_5.ARWUB3_TYGRA_FILE_REC_K
	and U04.ARWU04_CCTSS_VRNT_K = REC_CCM_5.ARWU04_CCTSS_VRNT_K
	and REC_CCM_5.ARWA08_CCM_C = 'CM5'
left join @REC_CCM as REC_CCM_6
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_6.ARWUB3_TYGRA_FILE_REC_K
	and U04.ARWU04_CCTSS_VRNT_K = REC_CCM_6.ARWU04_CCTSS_VRNT_K
	and REC_CCM_6.ARWA08_CCM_C = 'CM6'
left join @REC_CCM as REC_CCM_7
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_7.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_7.ARWA08_CCM_C = 'CM7'
left join @REC_CCM as REC_CCM_8
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_8.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_8.ARWA08_CCM_C = 'CM8'
left join @REC_CCM as REC_CCM_9
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_9.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_9.ARWA08_CCM_C = 'CM9'
left join @REC_CCM as REC_CCM_10
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_10.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_10.ARWA08_CCM_C = 'CM10'
left join @REC_CCM as REC_CCM_11
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_11.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_11.ARWA08_CCM_C = 'CM11'
left join @REC_CCM as REC_CCM_12
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_12.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_12.ARWA08_CCM_C = 'CM12'
left join @REC_CCM as REC_CCM_13
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_13.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_13.ARWA08_CCM_C = 'CM13'
left join @REC_CCM as REC_CCM_14
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_14.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_14.ARWA08_CCM_C = 'CM14'
left join @REC_CCM as REC_CCM_15
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_15.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_15.ARWA08_CCM_C = 'CM15'
left join @REC_CCM as REC_CCM_16
	on UB3.ARWUB3_TYGRA_FILE_REC_K = REC_CCM_16.ARWUB3_TYGRA_FILE_REC_K
	and REC_CCM_16.ARWA08_CCM_C = 'CM16'

--Also, for each Variant, return any Part Index costs that haven't been assigned
--to any End Items (N/A  EI NOT ASSIGNED)

union
select
 ARWA47_FORD_END_ITM_PREF_N
,ARWA47_FORD_END_ITM_BSE_N
,ARWA47_FORD_END_ITM_SFX_N
,ARWUB3_STRTG_PT_PART_X
,NULL
,NULL
,NULL
,  QUOTE_PARTS_AMT
	-- + coalesce(SUB_ASM_SUM,0)
	 + coalesce(ARWUA9_FNL_ASSY_ALLOC_A,0)
	 + DA_AMT
	 + II_AMT
	 + (QUOTE_PARTS_AMT 
		--+ coalesce(SUB_ASM_SUM,0) 
		+ coalesce(ARWUA9_FNL_ASSY_ALLOC_A,0) 
		+ DA_AMT 
		+ II_AMT) * U04_BM.ARWU04_CMMRCL_ADJ_P
	 + coalesce(ARWUA9_2PAGER_ALLOC_A,0)
	 + coalesce(ARWUA9_BM_DIRTR_ADJ_ALLOC_A,0)
	 + VA_AMT
	 + VA_AMT * U04.ARWU04_CMMRCL_ADJ_P
	 + coalesce(ARWUA9_DIRTR_ADJ_ALLOC_A,0)
,NULL
,U04.ARWU04_VRNT_N
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
,''
from @D13 as D13
join PARWU04_CCTSS_VRNT as U04_BM
	on U04_BM.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
	and U04_BM.ARWU04_BNCHMK_F = 1
join PARWU04_CCTSS_VRNT as U04
	on D13.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
where TYPE = 'UN-AS'

order by 
 A47.ARWA47_FORD_END_ITM_PREF_N
,A47.ARWA47_FORD_END_ITM_BSE_N
,A47.ARWA47_FORD_END_ITM_SFX_N
,U04.ARWU04_VRNT_N;

GO