DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_DESIGN]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 06/24/2019
-- Description:	validate Design Adjustment make, model, model year
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   07/22/2019  Added validation on design variant
-- asamriya   09/10/2019   Added row_idx
-- Ashaik12   01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- Ashaik12   09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

-- =============================================
CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_DESIGN] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
    -- Walked Variant Name validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS] 
   SELECT Err.[Source_c]
	     ,Err.Walked_Var_N
	     ,'The Design Variant on the cover page does not match the selected Design Variant'  
	     ,Err.[Processing_ID]
	     ,Err.[filename] 
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,Err.ARWS45_VA_COVER_PAGE_INFO_K
	     ,'PARWS45_VA_COVER_PAGE_INFO'
		 ,'WARNING' as [ARWE02_ERROR_TYPE_X]
		 ,'Cover' as [ARWE02_EXCEL_TAB_X]
		 ,0                               -- err_idx
		 ,''
		 ,Err.[User_selected_WALK_VRNT_X] 
   FROM 
       (
        SELECT 
               Processing_ID,
			   Walked_Var_N,
			   [User_selected_WALK_VRNT_X],
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS45_VA_COVER_PAGE_INFO_K]
          FROM [dbo].[PARWS45_VA_COVER_PAGE_INFO] S45
         WHERE Processing_ID       = @GUID
		   and [Walked_Var_N]      <> [User_selected_WALK_VRNT_X]    
       ) Err
;

END TRY

BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,'' 
			 ,'PARWS45_VA_COVER_PAGE_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                           -- row_idx
			 ,''
			 ,''

END CATCH;




GO
