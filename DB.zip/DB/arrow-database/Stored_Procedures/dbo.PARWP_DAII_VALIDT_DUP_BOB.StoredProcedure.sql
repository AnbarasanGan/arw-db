DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_DUP_BOB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 06/25/2019
-- Description:	Validate Design Adjustment for duplicate BoB for a Design and Supplier in the same Batch.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asamriya  09/10/2019   Added row_idx
-- ashaik12  12/25/2019   Added supplier code to partition by
-- Ashaik12  01/14/2020   Added Time_Stamp parameter
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_DUP_BOB] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(5000)
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
-- =============================================
-- Dup check against Cover Page select data
-- =============================================
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   Err.Source_c                          as ARWE02_SOURCE_C
	  ,Err.filename                          as ARWE02_ERROR_VALUE 
	  ,'A duplicate "Cover Page" - BoB (Program, Region, Sub-Commodity, Benchmark Variant Name), Design and Supplier was imported in the same batch. Only one can be imported per batch.' as ARWE02_ERROR_X
	  ,Err.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,Err.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,Err.[ARWS34_DAII_COVER_PAGE_INFO_K]   as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS34_DAII_COVER_PAGE_INFO' as ARWE02_STAGING_TABLE_X
	  -- Identity Key Column
	  ,'ERROR' as ARWE02_ERROR_TYPE
	  ,'Cover' as ARWE02_EXCEL_TAB
	  ,0                               -- err_idx
	  ,''  --No part index
	  ,''  --No ARROW Value
	  FROM
	  (
select 
 COUNT(*) OVER (PARTITION BY s34.Program,s34.Region,s34.Eng_SubCommodity_name,s34.Benchmark_Var_N,
                             s34.design_Brand,s34.design_Model,design_model_year,design_Var,
							 s34.supplier_name,s34.supplier_code,s34.Processing_ID) AS COUNT_BOB1

,filename
	  ,s34.Program
	  ,s34.Region
	  ,s34.Eng_SubCommodity_name
	  ,s34.Benchmark_Var_N
	  ,s34.design_Brand
	  ,s34.design_Model
	  ,s34.supplier_name
	  ,s34.Source_c
	  ,s34.Processing_ID
	  ,s34.[ARWS34_DAII_COVER_PAGE_INFO_K]
	 
from [dbo].[PARWS34_DAII_COVER_PAGE_INFO]    s34
where Processing_ID=@GUID
) Err
where COUNT_BOB1>1 ;

-- =============================================
-- Dup check against User select data
-- =============================================
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   Err.Source_c                          as ARWE02_SOURCE_C
	  ,Err.filename                          as ARWE02_ERROR_VALUE 
	  ,'A duplicate "User Selected" - BoB (Program, Region, Sub-Commodity, Benchmark Variant Name), Design and Supplier was imported in the same batch. Only one can be imported per batch.' as ARWE02_ERROR_X
	  ,Err.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,Err.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,Err.[ARWS34_DAII_COVER_PAGE_INFO_K]   as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS34_DAII_COVER_PAGE_INFO' as ARWE02_STAGING_TABLE_X
	  -- Identity Key Column
	  ,'ERROR' as ARWE02_ERROR_TYPE
	  ,'Cover' as ARWE02_EXCEL_TAB
	  ,0                               -- err_idx
	  ,''  --No part index
	  ,''  --No ARROW Value
	  FROM
	  (
select 
       COUNT(*) OVER (PARTITION BY s34.User_Selected_CTSP_N, s34.User_Selected_CTSP_Region_C, s34.User_Selected_ENRG_SUB_CMMDTY_X, s34.User_Selected_BNCMK_VRNT_N,
                                   s34.User_Selected_VEH_MAKE_N,   s34.User_Selected_VEH_MDL_N, s34.User_Selected_VEH_MDL_YR_C, s34.User_Selected_VEH_MDL_VRNT_X,
							       s34.User_Selected_SUPL_CNTRY_N, s34.User_Selected_SUPL_N, s34.User_Selected_SUPL_C 
			         ) AS COUNT_BOB1
      ,s34.filename
	  ,s34.Source_c
	  ,s34.User_Selected_CTSP_N
	  ,s34.User_Selected_CTSP_Region_C
	  ,s34.User_Selected_ENRG_SUB_CMMDTY_X
	  ,s34.User_Selected_BNCMK_VRNT_N
	  ,s34.User_Selected_VEH_MAKE_N
	  ,s34.User_Selected_VEH_MDL_N
	  ,s34.User_Selected_SUPL_CNTRY_N
	  ,s34.User_Selected_SUPL_C
	  ,s34.User_Selected_SUPL_N
	  ,s34.Processing_ID
	  ,s34.[ARWS34_DAII_COVER_PAGE_INFO_K] 
	 
from [dbo].[PARWS34_DAII_COVER_PAGE_INFO] s34 
where Processing_ID=@GUID
) Err
where COUNT_BOB1>1 ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS34_DAII_COVER_PAGE_INFO'
			 --Identity Key Column
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;



GO
