DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_ADDED_PARTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		Ashaik12
-- Create date: 11/22/2019
-- Description:	Check if the Added part is being matched under multiple sub assemblies when adding to U18 
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 12/10/2019  ASHIAK12            Add filename,row_idx to MERGE ON Clause
-- 01/14/2020  Ashaik12            Added Time_Stamp parameter and removed filter on Processing Status
-- 05/04/2020  rwesley2  US1575405 removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s35.sheet_name. 
--                                 Only applies to DA not II
-- 07/30/2020  Ashaik12  US1809333 Increase column sizes in temp table to match database column sizes.
-- 09/11/2020  Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- 10/15/2020  Ashaik12  US2000814 Fixed [ARWE02_STAGING_TABLE_X] and [ARWE02_EXCEL_TAB_X] for II validations
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_DAII_VALIDT_ADDED_PARTS] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS
BEGIN TRY

SET NOCOUNT ON;
-- TABLE variables to hold new Part Index
 DECLARE @new_part_index TABLE (
         NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
    --  ,NEW_CHANGE_ID VARCHAR (16) NOT NULL
    --  ,NEW_PART_NAME VARCHAR (128) NOT NULL
	--	,NEW_DESIGN_MAKE VARCHAR (32) NOT NULL
	--	,NEW_DESIGN_MODEL VARCHAR (32) NOT NULL
	--	,NEW_MY VARCHAR (7) NOT NULL
		,NEW_CCTSS int NOT NULL
	    ,row_idx INT
		,Processing_ID varchar(500)
		,filename varchar(500)
		,Ref_k int
		,Error_Flag VARCHAR(50)
		,sheet_name VARCHAR(500)
		,change_id  VARCHAR(5000) 
		                        )
 	;
-- get new part index from s35 that is not on u18 when type of change is ADD    
INSERT INTO @new_part_index
       SELECT s35.part_index as not_matched_PI
  	      --  ,s35.change_id
	       -- ,s35.part_name
		   -- ,s34.[User_Selected_VEH_MAKE_N]
		   -- ,s34.[User_Selected_VEH_MDL_N]
		   -- ,s34.[User_Selected_VEH_MDL_YR_C]
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,s35.[row_idx]
			 ,S35.Processing_ID
			 ,s35.filename
			 ,s35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
			 ,''
			 ,s35.sheet_name
			 ,S35.change_id
       FROM [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO] S35
	   JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S35.Processing_ID
        and S34.filename            = S35.filename
	           
	   join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X
		
	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u06_view.[ARWU01_CCTSS_K] = U18.[ARWU01_CCTSS_K]
		 AND S35.[part_index] = U18.ARWU18_BOM_PART_IX_N

       WHERE   s35.Processing_ID       =  @Processing_ID
	     and s35.type_of_change  = 'ADD'
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
;


-- Validate for 2 character match
MERGE INTO @new_part_index temp_table
USING
(
select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
from @new_part_index npi
JOIN PARWU18_BOM_PART U18
ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
AND   substring(npi.NEW_BOM_PART_IX_N,1,2) = substring(U18.[ARWU18_BOM_PART_IX_N],1,2)
JOIN PARWU17_BOM_SUB_ASSY U17
ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
) X
ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = '2 Char Pass'
;


-- Validate for 1 character
MERGE INTO @new_part_index temp_table
USING
(
select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
from @new_part_index npi
JOIN PARWU18_BOM_PART U18
ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
AND   substring(npi.NEW_BOM_PART_IX_N,1,1) = substring(U18.[ARWU18_BOM_PART_IX_N],1,1)
JOIN PARWU17_BOM_SUB_ASSY U17
ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
and npi.Error_Flag !='2 Char Pass'
and substring(npi.NEW_BOM_PART_IX_N,1,2) <> 'DP'
and substring(U18.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
) X
ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = '1 Char Pass'
;



MERGE INTO @new_part_index temp_table
USING
(
      SELECT npi.NEW_CCTSS        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
			,npi.filename
			,npi.row_idx
      FROM  @new_part_index npi
	  LEFT JOIN [PARWU18_BOM_PART] U18
        on u18.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	    and substring(u18.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_BOM_PART_IX_N,1,1)
		WHERE npi.Error_Flag =''
		and u18.[ARWU18_BOM_PART_IX_N] is NULL
    ) X

ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.ARWU18_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = 'No Sub-Assy'
;


INSERT INTO [dbo].PARWE02_BATCH_ERRORS
 select 
        'UI' AS [ARWE02_SOURCE_C] 
       ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
	   ,'ARROW is Unable to determine which Sub-Assembly the Added Part should belong to. First and Second Characters match Part Indexes from multiple Sub Assemblies' as [ARWE02_ERROR_X]
	   ,Processing_ID as [ARWE02_PROCESSING_ID]
	   ,FileName as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP  as [ARWE02_CREATE_S]
       ,@CDSID  as [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
       ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
	   ,sheet_name as [ARWE02_EXCEL_TAB_X]
	   ,row_idx as [ARWE02_ROW_IDX]
	   ,change_id
	   ,''  --No ARROW Value
 from @new_part_index 
 where Error_Flag=''

 INSERT INTO [dbo].PARWE02_BATCH_ERRORS
 select 
        'UI' AS [ARWE02_SOURCE_C] 
       ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
	   ,'Invalid Part Index: No Sub-Assembly found for ADD Part index' as [ARWE02_ERROR_X]
	   ,Processing_ID as [ARWE02_PROCESSING_ID]
	   ,FileName as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP  as [ARWE02_CREATE_S]
       ,@CDSID  as [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
       ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
	   ,sheet_name as [ARWE02_EXCEL_TAB_X]
	   ,row_idx as [ARWE02_ROW_IDX]
	   ,change_id
	   ,''  --No ARROW Value
 from @new_part_index 
 where Error_Flag='No Sub-Assy'

 
------------------------------------------------------------------------------------------
-- This section is to validate the new parts in Improvement Ideas.
-- Just making sure that the temp table is empty before validating improvement idea's.
------------------------------------------------------------------------------------------
delete from @new_part_index;


-- get new part index from S44 that is not on u18.  
INSERT INTO @new_part_index
       SELECT S44.part_index as not_matched_PI
  	    --     ,S44.improvement_id
	    --     ,S44.part_name
		--	 ,s34.[User_Selected_VEH_MAKE_N]
		--	 ,s34.[User_Selected_VEH_MDL_N]
		--	 ,s34.[User_Selected_VEH_MDL_YR_C]
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,s44.[row_idx]
			 ,S44.Processing_ID
			 ,s44.filename
			 ,s44.ARWS44_DAII_IMPROVEMENT_IDEA_K
			 ,'' as Error_Flag
			 ,'' -- improvement ideas do not have multiple tabs so not uisng sheet name
			 ,S44.improvement_id
       FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
	   JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S44.Processing_ID
        and S34.filename            = S44.filename
	           
	   join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X
		
	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u06_view.[ARWU01_CCTSS_K] = U18.[ARWU01_CCTSS_K]
		 AND S44.[part_index] = U18.ARWU18_BOM_PART_IX_N

       WHERE s44.Processing_ID       =  @Processing_ID 
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
;

-- Validate for 2 character match
MERGE INTO @new_part_index temp_table
USING
(
select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
from @new_part_index npi
JOIN PARWU18_BOM_PART U18
ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
AND   substring(npi.NEW_BOM_PART_IX_N,1,2) = substring(U18.[ARWU18_BOM_PART_IX_N],1,2)
JOIN PARWU17_BOM_SUB_ASSY U17
ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
) X
ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = '2 Char Pass'
;


-- Validate for 1 character
MERGE INTO @new_part_index temp_table
USING
(
select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
from @new_part_index npi
JOIN PARWU18_BOM_PART U18
ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
AND   substring(npi.NEW_BOM_PART_IX_N,1,1) = substring(U18.[ARWU18_BOM_PART_IX_N],1,1)
JOIN PARWU17_BOM_SUB_ASSY U17
ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
and npi.Error_Flag !='2 Char Pass'
and substring(npi.NEW_BOM_PART_IX_N,1,2) <> 'DP'
and substring(U18.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
) X
ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = '1 Char Pass'
;



MERGE INTO @new_part_index temp_table
USING
(
      SELECT npi.NEW_CCTSS        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
			,npi.filename
			,npi.row_idx
      FROM  @new_part_index npi
	  LEFT JOIN [PARWU18_BOM_PART] U18
        on u18.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	    and substring(u18.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_BOM_PART_IX_N,1,1)
		WHERE npi.Error_Flag =''
		and u18.[ARWU18_BOM_PART_IX_N] is NULL
    ) X

ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.ARWU18_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = 'No Sub-Assy'
;



INSERT INTO [dbo].PARWE02_BATCH_ERRORS
 select 
        'UI' AS [ARWE02_SOURCE_C] 
       ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
	   ,'ARROW is Unable to determine which Sub-Assembly the Added Part should belong to. First and Second Characters match Part Indexes from multiple Sub Assemblies' as [ARWE02_ERROR_X]
	   ,Processing_ID as [ARWE02_PROCESSING_ID]
	   ,FileName as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP  as [ARWE02_CREATE_S]
       ,@CDSID  as [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
       ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
	   ,'Improvement Ideas' as [ARWE02_EXCEL_TAB_X]
	   ,row_idx as [ARWE02_ROW_IDX]
	   ,change_id
	   ,''  --No ARROW Value
 from @new_part_index 
 where Error_Flag=''

 INSERT INTO [dbo].PARWE02_BATCH_ERRORS
 select 
        'UI' AS [ARWE02_SOURCE_C] 
       ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
	   ,'Invalid Part Index: No Sub-Assembly found for ADD Part index' as [ARWE02_ERROR_X]
	   ,Processing_ID as [ARWE02_PROCESSING_ID]
	   ,FileName as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP  as [ARWE02_CREATE_S]
       ,@CDSID  as [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
       ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
	   ,'Improvement Ideas' as [ARWE02_EXCEL_TAB_X]
	   ,row_idx as [ARWE02_ROW_IDX]
	   ,change_id
	   ,''  --No ARROW Value
 from @new_part_index 
 where Error_Flag='No Sub-Assy'

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@Processing_ID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO/PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH

;




GO
