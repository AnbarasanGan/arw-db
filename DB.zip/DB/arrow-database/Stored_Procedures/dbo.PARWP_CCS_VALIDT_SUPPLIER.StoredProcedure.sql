DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUPPLIER]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 3/18/2019
-- Description:	validate supplier name
-- =============================================
-- Changes
-- =============================================
-- Author    Date        Description
-- ------    -----       -----------
-- Asolosky  05/08/2019  Added the validation for 'The combination of Design, Supplier, Supplier Manufacturing Country is not assigned to the BoB program'
-- Asolosky  09/10/2019  Added row_idx
-- Ashaik12  12/25/2019  Added validation for Supplier Country
-- Ashaik12  01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky  09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUPPLIER] 

      @GUID varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.[supplier_name]  
	  ,'Supplier name on the cover page does not match the selected Supplier Name' 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)
	  ,@TIME_STAMP  
	  ,@CDSID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	  ,'PARWS22_CCS_COVER_PAGE_INFO',
	  'WARNING' as [ARWE02_ERROR_TYPE_X],
	  'Cover'   as [ARWE02_EXCEL_TAB_X],
	  0                              as ARWE02_ROW_IDX,
	  '',                       --No part index
	  Err.User_Selected_SUPL_N  --ARROW value
       FROM 
       (
        SELECT Processing_ID,
		       Supplier_name,
			   User_Selected_SUPL_N,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO S22
         WHERE Processing_ID       = @GUID
		   and supplier_name      != User_Selected_SUPL_N              
       ) Err
    ;
--++++++++++++++++++++++++++++++++++++
    -- U07 Supplier CODE
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.supplier_code  
	  ,'Supplier Code on the cover page does not match the selected Supplier Code'
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)
	  ,@TIME_STAMP  
	  ,@CDSID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	  ,'PARWS22_CCS_COVER_PAGE_INFO',
	  'WARNING' as [ARWE02_ERROR_TYPE_X],
	  'Cover'   as [ARWE02_EXCEL_TAB_X],
	  0         as ARWE02_ROW_IDX,
	  '',                      --No part index
	  Err.User_Selected_SUPL_C --ARROW value
       FROM 
       (
        SELECT Processing_ID,
		       Supplier_name,
			   User_Selected_SUPL_C,
			   supplier_code,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO S22
         WHERE Processing_ID       = @GUID
		   and supplier_code      != User_Selected_SUPL_C              
       ) Err
    ;

--++++++++++++++++++++++++++++++++++++
    -- U07 Supplier COUNTRY
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.[supplier_country]  
	  ,'Supplier Country from the cover page does not match the selected Supplier Country'
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)
	  ,@TIME_STAMP  
	  ,@CDSID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	  ,'PARWS22_CCS_COVER_PAGE_INFO',
	  'WARNING' as [ARWE02_ERROR_TYPE_X],
	  'Cover'   as [ARWE02_EXCEL_TAB_X],
	  0         as ARWE02_ROW_IDX,
	  '',                             --No part index
	  Err.User_Selected_SUPL_CNTRY_N  --ARROW value
       FROM 
       (
        SELECT Processing_ID,
		       Supplier_name,
			   [User_Selected_SUPL_CNTRY_N],
			   [supplier_country],
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO S22
         WHERE Processing_ID       = @GUID
		   and [supplier_country]      != [User_Selected_SUPL_CNTRY_N]              
       ) Err
    ;
END TRY

BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS22_CCS_COVER_PAGE_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;



GO
