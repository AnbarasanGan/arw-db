DROP PROCEDURE [dbo].[PARWP_CST_CONSL_DELETE_SUM_TBLS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 03/20/2020
-- Description:	Delete Script for CCT summary tables.  
--              UI Exchange rate update only needs to delete the summary tables before recalculating.
--              Copied the deletes from PARWP_CST_CONSL_DELETE_SCRIPT
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CST_CONSL_DELETE_SUM_TBLS] 
@CCTSS_K       Int

AS

SET NOCOUNT ON;

--DELETE: using Merge statement to Delete data in the [PARWU55_SUPL_DSGN_PART] table when it's reloaded.

MERGE INTO PARWU55_SUPL_DSGN_PART  U55_Target
Using
(
 Select U55.ARWU08_CCTSS_DSGN_SUPL_K
       ,U55.ARWU19_DSGN_PART_K
   From PARWU55_SUPL_DSGN_PART  U55
   Join PARWU08_CCTSS_DSGN_SUPL U08
     On U08.ARWU08_CCTSS_DSGN_SUPL_K = U55.ARWU08_CCTSS_DSGN_SUPL_K
   Join PARWU06_CCTSS_DSGN      U06
     On U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
  Where U06.ARWU01_CCTSS_K      = @CCTSS_K
) as U55_Source
ON (U55_Target.ARWU08_CCTSS_DSGN_SUPL_K = U55_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;


--Delete PARWU56_SUPL_SUB_ASSY
MERGE INTO PARWU56_SUPL_SUB_ASSY   U56_Target
Using
(
 Select ARWU08_CCTSS_DSGN_SUPL_K AS ARWU08_CCTSS_DSGN_SUPL_K
 From
 (
  select V13.ARWU08_CCTSS_DSGN_SUPL_K as ARWU08_CCTSS_DSGN_SUPL_K
        ,V13.ARWU17_BOM_SUB_ASSY_K
        ,V13.[ARWU17_BOM_SUB_ASSY_N]
    FROM PARWV13_CCS_ASSEMBLY_FLAT V13
    JOIN PARWV20_MFG_MRKP          V20
      ON V13.ARWU08_CCTSS_DSGN_SUPL_K = V20.[ARWU08_CCTSS_DSGN_SUPL_K]
     AND V13.ARWU17_BOM_SUB_ASSY_K    = V20.ARWU17_BOM_SUB_ASSY_K
   WHERE V13.ARWU01_CCTSS_K = @CCTSS_K
 ) a
 group by a.ARWU08_CCTSS_DSGN_SUPL_K 
         ,a.[ARWU17_BOM_SUB_ASSY_N]
         ,a.ARWU17_BOM_SUB_ASSY_K
) as U56_Source
ON (U56_Target.ARWU08_CCTSS_DSGN_SUPL_K=U56_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

GO
