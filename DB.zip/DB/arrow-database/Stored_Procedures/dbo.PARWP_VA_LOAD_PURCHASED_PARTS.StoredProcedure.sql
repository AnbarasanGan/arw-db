SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		asamriya
-- Create date: 07/31/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08/26/2019  ashaik12           Added join on User_selected_WALK_VRNT_X
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 05/13/2020  rwesley2	 US1600015 VA multitab changes
-- 06/30/2022  ASHAIK12  US3778477 Add cost_type filter to filter out the improvement idea records
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VA_LOAD_PURCHASED_PARTS] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO PARWU66_PURC_PART_VRNT_ADJ
SELECT --ARWU66_PURC_PART_VRNT_ADJ_K is an identity 
        U09_VRNT.[ARWU09_CCTSS_VRNT_SUPL_K] AS ARWU09_CCTSS_VRNT_SUPL_K
	  , S50.row_idx                  AS ARWU66_PURC_PART_DSPLY_SEQ_R
      , U65.ARWU65_CCTSS_VRNT_ADJ_K  AS ARWU65_CCTSS_VRNT_ADJ_K
	  , S50.part_specification       AS ARWU66_PURC_PART_SPEC_X
	  , source_supplier              AS ARWU66_SRC_SUPL_N

	  ,Case When LOC.ARWA28_CNTRY_K is Null then A28_EmptyStr.ARWA28_CNTRY_K Else LOC.ARWA28_CNTRY_K  End AS ARWA28_SRC_CNTRY_K

	  , A29.ARWA29_CRCY_K                     AS ARWA29_LCL_CRCY_K
	  , isNULL(no_of_pieces,0)                AS ARWU66_PCE_PER_SUB_ASSY_Q
	  , isNULL(purchased_price_per_piece,0)   AS ARWU66_PURC_PART_PER_PCE_A
	  , isNULL(inbound_packaging_costs,0)     AS ARWU66_INBND_PKNG_COST_PCE_A
	  , isNULL(inbound_logistics_costs,0)     AS ARWU66_INBND_LGSTCS_COST_PCE_A
	  , isNULL(tax_duty,0)                    AS ARWU66_TAX_AND_DUTY_PER_PCE_A
	  , isNULL(purchased_parts_markup_cost,0) AS ARWU66_PURC_PART_MRKP_P  --purchased_parts_markup_cost should be renamed in the database as purchased_parts_markup_p
	  , comments                              AS ARWU66_PURC_PART_ASSMP_CMT_X
	  , @TIME_STAMP                          AS ARWU66_CREATE_S
	  , @CDSID                                AS ARWU66_CREATE_USER_C
	  , @TIME_STAMP                          AS ARWU66_LAST_UPDT_S
	  , @CDSID                                AS ARWU66_LAST_UPDT_USER_C

  From PARWS45_VA_COVER_PAGE_INFO       S45
  JOIN PARWS50_VA_PURCHASED_PARTS_INFO  S50 --S39
    ON S45.Processing_ID       = S50.Processing_ID
   AND S45.filename            = S50.filename

 -- Join with Supplier Quote View
      JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]   U09_VRNT
         ON S45.Eng_SubCommodity_name        = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
        AND S45.User_Selected_CTSP_N         = U09_VRNT.ARWU31_CTSP_N
        AND S45.User_Selected_CTSP_Region_C  = U09_VRNT.ARWA06_RGN_C
        AND S45.User_Selected_BNCMK_VRNT_N   = U09_VRNT.ARWU01_BNCHMK_VRNT_N     --BoB variant
        AND S45.User_Selected_SUPL_N         = U09_VRNT.ARWA17_SUPL_N
        AND S45.User_Selected_SUPL_CNTRY_N   = U09_VRNT.ARWA28_CNTRY_N
        AND S45.User_Selected_SUPL_C         = U09_VRNT.ARWA17_SUPL_C
		AND S45.User_selected_WALK_VRNT_X    = U09_VRNT.ARWU04_VRNT_N

--Design Adjustment Part
  Join PARWU65_CCTSS_VRNT_ADJ  U65
    ON U65.ARWU04_CCTSS_VRNT_K         = U09_VRNT.ARWU04_CCTSS_VRNT_K
   And U65.ARWU65_CCTSS_VRNT_ADJ_ID_N  = S50.change_id
 --Currency
     JOIN PARWA29_CRCY        A29          ON A29.ARWA29_CRCY_C = S50.local_currency
 --Source-Country
Left JOIN PARWA28_CNTRY       LOC          ON LOC.ARWA28_CNTRY_N = S50.source_country
     JOIN [dbo].PARWA28_CNTRY A28_EmptyStr ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C  = ''
   
  Where S45.Processing_ID               = @GUIDIN
	AND S45.Skip_loading_due_to_error_f = 0
	AND S50.cost_type                   = 'Adjustment Costs'

;



GO
