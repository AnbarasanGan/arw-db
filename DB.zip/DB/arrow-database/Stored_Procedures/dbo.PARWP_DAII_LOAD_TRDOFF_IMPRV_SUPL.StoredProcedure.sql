DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_TRDOFF_IMPRV_SUPL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		btemkow
-- Create date: 02/18/2020
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 02/18/2020  btemkow            Based on PARWP_DAII_LOAD_CCTSS_TRDOFF
--                                only loads tradeoffs for Supplier-originated Improvement Ideas
--                                for 'PBOM and DA UI' version BoBs
-- 11/19/2020  asolosky US2064099 DAW Import fails with a Duplicate trade off when there are groupings with [UNASSIGNED] and blank.  
--                                INSERT INTO [PARWU85_CCTSS_TRDOFF]: Moved the case statement from the outer query to the inner query.
-- =============================================
--DROP PROCEDURE  [dbo].[PARWP_DAII_LOAD_TRDOFF_IMPRV_SUPL]

CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_TRDOFF_IMPRV_SUPL] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--**********************************
-- Insert into U85
--********************************** 

INSERT INTO [PARWU85_CCTSS_TRDOFF]
select ARWU01_CCTSS_K
      ,1                               AS ARWU85_BNCHMK_F
      ,improvement_idea_grouping       AS ARWU85_CCTSS_TRDOFF_X
	  ,''                              AS ARWU85_CCTSS_TRDOFF_RTNLE_X
	  ,''                              AS ARWU85_CCTSS_TRDOFF_DATA_SRC_X
	  ,1                               AS ARWU85_CCTSS_TRDOFF_INCLD_F
	  ,[ARWA31_CONFID_LVL_K]           AS ARWA31_CONFID_LVL_K
	  ,0                               AS ARWU85_TRDOFF_AGRMT_BFR_MP_F
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]   AS ARWA43_TRDOFF_AGRMT_FORUM_K
	  ,@TIME_STAMP                     AS ARWU85_CREATE_S
      ,@CDSID                          AS ARWU85_CREATE_USER_C
      ,@TIME_STAMP                     AS ARWU85_LAST_UPDT_S
      ,@CDSID                          AS ARWU85_LAST_UPDT_USER_C
from (
   SELECT  
          U01.ARWU01_CCTSS_K 
   	     ,CASE WHEN S44.improvement_idea_grouping = '' 
   	           THEN 'UNASSIGNED' 
   			   ELSE S44.improvement_idea_grouping  
   	      END AS improvement_idea_grouping
   	     ,A31.ARWA31_CONFID_LVL_K
   	     ,A43.ARWA43_TRDOFF_AGRMT_FORUM_K
     FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
     JOIN PARWS34_DAII_COVER_PAGE_INFO        S34
       ON S34.Processing_ID       = S44.Processing_ID
      AND S34.filename            = S44.filename

     JOIN PARWU01_CCTSS_FLAT   U01
       ON U01.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
      AND U01.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
      AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
      AND U01.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N
     JOIN PARWA31_CONFID_LVL A31
       ON A31.ARWA31_CONFID_LVL_X ='High'
     JOIN PARWA43_TRDOFF_AGRMT_FORUM A43
       ON A43.ARWA43_TRDOFF_AGRMT_FORUM_N='To be determined'
    Where S34.Processing_ID               = @GUIDIN
      And S34.Skip_loading_due_to_error_f = 0
	  And S44.originator = 'Supplier'
      And not exists --Can't add a trade off if it already exists
         (Select 'X'
            From PARWU85_CCTSS_TRDOFF U85_Check
	       Where U85_Check.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
		   AND ARWU85_BNCHMK_F = 1
		   And U85_Check.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S44.improvement_idea_grouping='' THEN 'UNASSIGNED' ELSE S44.improvement_idea_grouping END
         )
	)x
Group by --Get distinct data to write into the table
       ARWU01_CCTSS_K          
	  ,improvement_idea_grouping
	  ,ARWA31_CONFID_LVL_K
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]
	 ;



--**********************************
-- Insert into U87
--********************************** 

INSERT INTO [dbo].PARWU87_DSGN_IMPRV_TRDOFF
SELECT U46.ARWU46_CCTSS_DSGN_IMPRV_K   AS ARWU46_CCTSS_DSGN_IMPRV_K
      ,U85.ARWU85_CCTSS_TRDOFF_K       AS ARWU85_CCTSS_TRDOFF_K
	  ,@TIME_STAMP                    AS ARWU86_CREATE_S
      ,@CDSID                          AS ARWU86_CREATE_USER_C
      ,@TIME_STAMP                    AS ARWU86_LAST_UPDT_S
      ,@CDSID                          AS ARWU86_LAST_UPDT_USER_C
FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
  JOIN PARWS34_DAII_COVER_PAGE_INFO           S34
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename

 -- Join with Design/Supplier Flat View
  JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT   U08
    ON U08.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND U08.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
   AND U08.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND U08.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N
   AND U08.ARWA14_VEH_MAKE_N          = S34.[User_Selected_VEH_MAKE_N]
   AND U08.ARWA34_VEH_MDL_N           = S34.[User_Selected_VEH_MDL_N]   
   AND U08.ARWA35_DSGN_VEH_MDL_YR_C	  = S34.[User_Selected_VEH_MDL_YR_C]
   AND U08.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.[User_Selected_VEH_MDL_VRNT_X]
   AND U08.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
   AND U08.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
   AND U08.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N

   JOIN PARWU46_CCTSS_DSGN_IMPRV U46
   ON U46.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
   AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  s44.improvement_id + '#' + CONVERT(VARCHAR,U08.[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  s44.improvement_id  + '#' + 'Ford'	              
        END)

   JOIN PARWU85_CCTSS_TRDOFF U85
   ON  U85.ARWU01_CCTSS_K = U08.ARWU01_CCTSS_K
   AND U85.ARWU85_BNCHMK_F=1
   AND U85.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S44.improvement_idea_grouping='' THEN 'UNASSIGNED' ELSE S44.improvement_idea_grouping END


    Where S34.Processing_ID               = @GUIDIN 
    And S34.Skip_loading_due_to_error_f = 0
    AND not exists --Can't add if it already exists
       (
	     Select 'X'
          From PARWU87_DSGN_IMPRV_TRDOFF U87_check
	     Where U87_check.ARWU46_CCTSS_DSGN_IMPRV_K = U46.ARWU46_CCTSS_DSGN_IMPRV_K 
       )
	GROUP BY U46.ARWU46_CCTSS_DSGN_IMPRV_K,U85.ARWU85_CCTSS_TRDOFF_K

	;
GO
