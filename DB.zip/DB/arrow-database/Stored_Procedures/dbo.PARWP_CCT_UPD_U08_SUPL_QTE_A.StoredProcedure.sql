DROP PROCEDURE [dbo].[PARWP_CCT_UPD_U08_SUPL_QTE_A]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 053/31/2019
-- Description:	Update the PARWU08_CCTSS_DSGN_SUPL.ARWU08_DSGN_SUPL_QTE_A column based on the 
--              CCTSS_K input parameter
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 06/17/2019  Asolosky  N/A      Delete by ARWU08_CCTSS_DSGN_SUPL_K, remove the ARWU17_BOM_SUB_ASSY_K from the on clause
-- 08/13/2019  ASHAIK12           Removed Delete Statements
-- 09/05/2019  Ashaik12           Make join to left join on U56 table to fix LSQ update issue.
-- 01/10/2020  Ashaik12           Added TimeStamp parameter
-- 09/27/2021  ashaik12           US2914035 - Change from JOIN to LEFT JOIN for cases when all parts are removed in the surgical process for U55.
--==============================================
CREATE PROCEDURE  [dbo].[PARWP_CCT_UPD_U08_SUPL_QTE_A] 
-- Input Parameter
@CCTSS_K       INT,
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;
-----------------------------------------------------------------------------------------------------
--PARWU08_CCTSS_DSGN_SUPL
MERGE INTO PARWU08_CCTSS_DSGN_SUPL   U08_Target
USING
(SELECT V04.ARWU08_CCTSS_DSGN_SUPL_K
,isNull(ARWU55_DSGN_PART_TOT_W_MRKP_A,0) AS ARWU55_DSGN_PART_TOT_W_MRKP_A
,isNull(ARWU56_ASSY_TOT_W_MRKP_A,0) AS ARWU56_ASSY_TOT_W_MRKP_A
,V04.ARWU08_FNL_ASSY_TOT_W_MRKP_A
,(isNull(ARWU55_DSGN_PART_TOT_W_MRKP_A,0) + isNull(ARWU56_ASSY_TOT_W_MRKP_A,0) + isNull(ARWU08_FNL_ASSY_TOT_W_MRKP_A,0)) as ARWU08_DSGN_SUPL_QTE_A
FROM [dbo].PARWV04_DSGN_SUPL V04
LEFT JOIN (
select 
       U55.ARWU08_CCTSS_DSGN_SUPL_K
      ,Sum(ARWU55_DSGN_PART_TOT_W_MRKP_A) as ARWU55_DSGN_PART_TOT_W_MRKP_A
	-- , Sum(U56.ARWU56_ASSY_TOT_W_MRKP_A)  as ARWU56_ASSY_TOT_W_MRKP_A
      FROM PARWU55_SUPL_DSGN_PART U55
	  GROUP BY U55.ARWU08_CCTSS_DSGN_SUPL_K
	  ) U55
	  ON U55.ARWU08_CCTSS_DSGN_SUPL_K=V04.ARWU08_CCTSS_DSGN_SUPL_K
LEFT JOIN (select 
      Sum(U56.ARWU56_ASSY_TOT_W_MRKP_A)  as ARWU56_ASSY_TOT_W_MRKP_A
      ,U56.ARWU08_CCTSS_DSGN_SUPL_K
        FROM PARWU56_SUPL_SUB_ASSY U56
   GROUP BY U56.ARWU08_CCTSS_DSGN_SUPL_K
) U56
ON U56.ARWU08_CCTSS_DSGN_SUPL_K= V04.ARWU08_CCTSS_DSGN_SUPL_K
where V04.ARWU01_CCTSS_K=@CCTSS_K
) U08_Source

ON (U08_Target.ARWU08_CCTSS_DSGN_SUPL_K  = U08_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN
     UPDATE SET          
	    U08_Target.ARWU08_DSGN_SUPL_QTE_A  = U08_Source.ARWU08_DSGN_SUPL_QTE_A
	   ,U08_Target.ARWU08_LAST_UPDT_S      = @TIME_STAMP 
	   ,U08_Target.ARWU08_LAST_UPDT_USER_C = @CDSID
;


GO
