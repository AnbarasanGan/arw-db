SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2019
-- Description:	Master Procedure to call Variant Adjustment Stored Procedures
-- =============================================
-- Changes
-- =============================================
-- Author     Date      User Story Description
-- ------     -----     ---------- -----------
-- asamriya   8/22/2019            Added Parameter for Import Status and Procedure to populate Import status 
-- asolosky  09/05/2019            Added PARWP_VA_DELETE_TABLES procedure to do all deletes before loading
--                                 Added PARWP_VACT_LOAD_U81_SUPL_VRNT_ADJ, the consolidation procedure
-- rwesley2	 09/17/2019            Added variables for upper/lower limits on SPs Assembly, Processing, Purchased Parts, and Raw Materials
-- rwesley2	 10/08/2019	           removing upper/lower bound and changing to a comparison to a dollar value	
-- rwesley2  10/11/2019            added ARWP_VA_LOAD_EXCHG_RATE 
-- rwesley2  10/18/2019            added PARWP_VA_VALIDT_CHANGE_ID
-- ashaik12  10/25/2019            Add validation for -- If quoted flag is YES check if the part made it to final table
-- rwesley2  11/08/2019            added scrub for special characters on staged tables 
-- ashaik12  11/23/2019            Added new validation for checking if added part returns two sub-assemblies.
-- ashaik12  12/02/2019            commenting out part_name validation , it is now part of part_index validation
-- ashaik12  12/16/2019            Added new Procedure to load Trade Off tables.
-- Ashaik12  01/14/2020            Added Time_Stamp parameter
-- rwesley2	 02/12/2022            added BoB versioning
-- asolosky  05/05/2020 US1599381  commented out the PARWP_VA_LOAD_MFG_MARKUPS procedure.  With the multiple sub-assembly sheets, this
--                                 will cause an issue loading these tables. The UI doesn't use these markups.  The UI uses the CCS markups.
-- ASHAIK12  06/03/2020            Add new Sub Assembly Validation for Post PBoM Load
-- asolosky  06/25/2020            Added the PARWP_VA_SCRUB_SPCL_CHARS to code for PBOM Version. The scrub was changed to remove a line feed or carriage return at the end of character columns.
-- Asolosky  07/16/2020 US1774947  Remove procedure PARWP_VA_VALIDT_QUOTED_PART_MISSING.  It was in the PRE-PBOM and PBOM section
-- Asolosky  07/27/2020 US1771016  Added PARWP_VA_VALIDT_PART_NAME to the Pre PBOM section. Remove [PARWP_VA_VALIDT_PART_INDEX] from PBOM section because PARWP_VA_VALIDT_VRNT_ADJ handles the index and name validation
-- Ashaik12  09/30/2020 US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12  12/12/2020 US2137799  Added new procedure to validate total after loading the base tables.
-- Asolosky  01/19/2021 US2164194  Changed the threshold from a dynamic number, which was in the UpperBound and LowerBound function, to a static number.
-- Asolosky  02/19/2021 US2267679  Replaced the 5 Pre Load VA Summary Validation procedures with PARWP_VA_VALIDT_SUMMARY_PRE, which included validation for markups
-- Asolosky  03/26/2021 US2394217  Added @Filename to the @results
-- Asolosky  01/07/2022 US3190192  Added new logic (PARWP_CALC_MASTER_LOAD_PRIMARY) for populating the Calc tables at the of EACH MAIN BLOCK. 
-- Asolosky  06/15/2022 US3612620  Added procedure, PARWP_VA_DEL_TYP_COPY_FROM_GCS, to copy GCS purchpart, raw and processing data  
--                                 to equivalent VA tables when VA part is type Delete.  This will create a zero balance for the part.
-- ASHAIK12  06/30/2022 US3778477  Add new SP's to Validate and load the Variant Improvement Ideas
-- ASHAIK12  07/22/2022 DE260310 Add SP to load VII tradeoff for supplier ideas
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_VA_MASTER] 
	-- Add the parameters for the stored procedure here
@GUIDIN varchar(500), 
@CDSID  varchar(8),
@result varchar(MAX) Output


AS
Begin  -- procedure
 DECLARE @Processing_Status_x Varchar(500)
 DECLARE @CCTSS_K INT
 DECLARE @FILE_TYPE VARCHAR(50)
 DECLARE @IMPORT_STATUS  varchar(50)
 DECLARE @threshold DECIMAL(5,3)
 DECLARE @TIME_STAMP DATETIME 
 DECLARE @BoB_version VARCHAR(500)
 DECLARE @Error VARCHAR(500)
 DECLARE @Calculated_Value DECIMAL(38,18)
 DECLARE @Staging_Value DECIMAL(38,18)
 DECLARE @File_Name VARCHAR(500)
 DECLARE @Ref_K INT
 DECLARE @V_Threshold_A DECIMAL(38,18)
 DECLARE @AtLeast1_file_loaded int = 0;
 DECLARE @Primary_output_error  VARCHAR(5000);
 DECLARE @u01_Study             Varchar(100);
 DECLARE @T09_CCTSS_VRNT_SUPL  dbo.PARWT09_CCTSS_VRNT_SUPL;

 SET NOCOUNT ON;
 SET @IMPORT_STATUS = 'Regular'
 SET @result       = '';
 SET @TIME_STAMP = GETUTCDATE()
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));

--Determine BoB version
SELECT @BoB_version = 
    (select u01.ARWA46_CCTSS_IMPT_VER_N 
       from PARWS45_VA_COVER_PAGE_INFO s45
       JOIN PARWU01_CCTSS_FLAT u01
         on s45.User_Selected_CTSP_N            = u01.ARWU31_CTSP_N
        and s45.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
        and s45.User_Selected_CTSP_Region_C     = u01.ARWA06_RGN_C
        and s45.User_Selected_BNCMK_VRNT_N      = u01.ARWU01_BNCHMK_VRNT_N
     where s45.Processing_ID                    = @GUIDIN
     group by u01.ARWA46_CCTSS_IMPT_VER_N
    )
;

Select @V_Threshold_A = (Select ARWT01_THRESHOLD_A from PARWT01_THRESHOLD);

EXEC [dbo].[PARWP_GET_CCTSS_KEY]    @GUIDIN, @CCTSS_K OUTPUT,@FILE_TYPE='VA';
Set @u01_Study = (Select U01.ARWU31_CTSP_N    + ' ' +
                         U01.ARWA06_RGN_C     + ' ' +
                   	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                    from PARWU01_CCTSS_FLAT U01
                   where U01.ARWU01_CCTSS_K = @CCTSS_K
 				 );

-- execute Pre PBOM stored procedures
IF @BoB_version = 'Pre PBOM'  -- Begin PRE PBoM SPs
 BEGIN 
-- scrub special characters for stage tables
 EXEC [dbo].[PARWP_VA_SCRUB_SPCL_CHARS]         @GUIDIN, @CDSID; 
 --Cover Page, PBOM Validation
 EXEC [dbo].[PARWP_VA_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_VA_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_VA_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_SUPPLIER]              @GUIDIN, @CDSID, @TIME_STAMP;  
 EXEC [dbo].[PARWP_VA_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;   
 EXEC [dbo].[PARWP_VA_VALIDT_DUP_BOB]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_PURCH_CMMDTY]          @GUIDIN, @CDSID, @TIME_STAMP;   
 --Adjustment Details Validation
 EXEC [dbo].[PARWP_VA_VALIDT_TYPE_OF_CHANGE]        @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_CHANGE_ID]             @GUIDIN, @CDSID, @TIME_STAMP;
  --Exchange Rate tab Validations
 EXEC [dbo].[PARWP_VA_VALIDT_CRNCY_CODE]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_SUPL_CRNCY]            @GUIDIN, @CDSID, @TIME_STAMP;
--Supplier Quote Validation 
 EXEC [dbo].[PARWP_VA_VALIDT_PURCHASED_PARTS]       @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_RAW_MATERIALS]         @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_PROCESSING_COSTS]      @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_ASSEMBLY]              @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_MFG_MARKUP]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_BOM_QUOTED]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_PART_INDEX]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_PART_NAME]             @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_ADDED_PARTS]           @GUIDIN, @CDSID, @TIME_STAMP;

 EXEC [dbo].PARWP_VA_VALIDT_SUMMARY_PRE             @GUIDIN, @CDSID, @TIME_STAMP, @V_Threshold_A;

  BEGIN TRY
 
   BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

--      --Update the S45 cover page table's error flag
     EXEC [dbo].[PARWP_VA_UPDATE_S45_COVER_ERROR_FLAG]         @GUIDIN;

 --	 Load VA
     EXEC [dbo].[PARWP_VA_DELETE_TABLES]                       @GUIDIN, @CDSID, @CCTSS_K;
     EXEC [dbo].[PARWP_VA_LOAD_ADJUSTMENT_DETAILS]             @GUIDIN, @CDSID, @TIME_STAMP;														       
	 EXEC [dbo].[PARWP_VA_LOAD_PURCHASED_PARTS]                @GUIDIN, @CDSID, @TIME_STAMP;
     EXEC [dbo].[PARWP_VA_LOAD_RAW_MTRLS]                      @GUIDIN, @CDSID, @TIME_STAMP;   
	 EXEC [dbo].[PARWP_VA_LOAD_PROCESSING_COSTS]	           @GUIDIN, @CDSID, @TIME_STAMP;
     EXEC [dbo].[PARWP_VA_LOAD_ASSEMBLY]                       @GUIDIN, @CDSID, @TIME_STAMP;
--	 EXEC [dbo].[PARWP_VA_LOAD_MFG_MARKUPS]                    @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_VA_LOAD_EXCHG_RATE]                     @GUIDIN, @CDSID, @TIME_STAMP;

	  -- Begin for VA no Error block
-- Variant Consolidation

	 EXEC [dbo].[PARWP_VACT_LOAD_U81_SUPL_VRNT_ADJ]            @CCTSS_K, @CDSID, @TIME_STAMP;
	 -- Load Tradeoff tables 
     EXEC [dbo].[PARWP_VA_LOAD_CCTSS_TRDOFF]                    @GUIDIN, @CDSID, @TIME_STAMP;
-- Load Summary for file imports
	 EXEC [dbo].[PARWP_VA_UPDT_LAST_IMPT]                      @GUIDIN, @CDSID, @IMPORT_STATUS;
  
 -- POST LOAD VALIDATION CHECK
		EXEC [dbo].[PARWP_VA_VALIDT_SUMMARY_CST_POST] @GUIDIN,@CCTSS_K,@V_Threshold_A,@Error OUTPUT,@Calculated_Value OUTPUT,@Staging_Value OUTPUT,@File_Name OUTPUT,@Ref_K OUTPUT 
		IF @Error != ''  --Check if the post load summary validation generated an error 
			   Set @result = '***Post Load Error: Arrow calculated Total $' +CAST(@Calculated_Value as varchar(50)) +' using data loaded into base tables did not equal to Total on Summary sheet $'+CAST(@Staging_Value as varchar(50)) +' for Processing ID '+@GUIDIN; 

--++++++++++++++++++++++++++++++++++++++++++++++++
-- VA Type=Delete; copy GCS/CCS to VA for purch part, raw, processing when there's a VA type of DELETE. This will zero out the Variant BOV/Intended Design cost
-- Must be done after post validation or an email will happen every time because of the copy.
--++++++++++++++++++++++++++++++++++++++++++++++++
      Insert into @T09_CCTSS_VRNT_SUPL 
      Select U09.ARWU09_CCTSS_VRNT_SUPL_K
        From PARWS45_VA_COVER_PAGE_INFO    S45
        JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT  U09
          ON S45.User_Selected_CTSP_N            = U09.ARWU31_CTSP_N              
         AND S45.User_Selected_CTSP_Region_C     = U09.ARWA06_RGN_C               
         AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09.ARWA03_ENRG_SUB_CMMDTY_X   
         AND S45.User_Selected_SUPL_N            = U09.ARWA17_SUPL_N               
         AND S45.User_Selected_SUPL_C            = U09.ARWA17_SUPL_C               
         AND S45.User_Selected_SUPL_CNTRY_N      = U09.ARWA28_CNTRY_N              
         AND S45.User_selected_WALK_VRNT_X       = U09.ARWU04_VRNT_N         
         AND S45.User_Selected_BNCMK_VRNT_N      = U09.ARWU01_BNCHMK_VRNT_N
       Where S45.Processing_ID               = @GUIDIN
         AND S45.Skip_loading_due_to_error_f = 0;	
   EXEC [dbo].[PARWP_VA_DEL_TYP_COPY_FROM_GCS]     @CCTSS_K, @T09_CCTSS_VRNT_SUPL, @CDSID, @TIME_STAMP;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table load for Calculations
--++++++++++++++++++++++++++++++++++++++++++++++++
	Set @AtLeast1_file_loaded = (Select Count(*) 
	                               From PARWS45_VA_COVER_PAGE_INFO S45 
							      Where S45.Processing_ID               = @GUIDIN
								    and S45.Skip_loading_due_to_error_f = 0
							    );
	If IsNULL(@AtLeast1_file_loaded,0) > 0
       BEGIN
          exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
               @U01_k                = @CCTSS_K
             , @U06_k                = -1
             , @U04_k                = -1
             , @CDSID                = @CDSID
             , @TRIGGER              = 'VAW IMPORT'
             , @Primary_output_error = @Primary_output_error OUTPUT
          ;          
          If @Primary_output_error = ''
             Begin
                COMMIT TRANSACTION
                If @result = ''
				     Set @result = 'SUCCESS';
				Else Set @result = @result;  --Didn't need the ELSE but wanted to show there would be a POST load calculation error at this point
             End
          Else
             Begin
                Rollback
				If @result = ''
                     Set @result = 'Master Load Primary Error: ' + @Primary_output_error;
				Else Set @result = SUBSTRING(CONCAT('Master Load Primary Error: ', @Primary_output_error, ' ', @result),1,5000);  
             End
       End
	ELSE
	   BEGIN
          Set @result = 'SUCCESS'; --All files in the batch had a validation error. There should be no data to commit at this point but we should have something to match the begin transaction.
          COMMIT TRANSACTION;
	   End
    --End of: If IsNULL(@AtLeast1_file_loaded,0) > 0 
 END TRY

 --CATCH
 BEGIN CATCH
   Rollback;
   Set @result = 'VA_MASTER SYSTEM ERROR(Pre PBOM): ' +              
	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
				 ' |Processing Id: ' + @GUIDIN +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
--	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

   SET @IMPORT_STATUS = 'Processing_Error'

    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUIDIN                           --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'VA MASTER PROCEDURE - Pre PBOM'
        ,0                              as ARWE02_ROW_IDX	
		,''
		,''	
	;

	EXEC [dbo].[PARWP_VA_UPDT_LAST_IMPT]                      @GUIDIN, @CDSID, @IMPORT_STATUS;

  END CATCH;	
--  RETURN @result
  END -- END PRE PBoM SPs


--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

-- execute Pre PBOM stored procedures
ELSE  -- Begin PBOM and DA UI SPs

BEGIN 

-- scrub special characters for stage tables
 EXEC [dbo].[PARWP_VA_SCRUB_SPCL_CHARS]         @GUIDIN, @CDSID; 
 
 --Cover Page, PBOM Validation
 EXEC [dbo].[PARWP_VA_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_VA_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP; 
 EXEC [dbo].[PARWP_VA_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_SUPPLIER]              @GUIDIN, @CDSID, @TIME_STAMP;  
 EXEC [dbo].[PARWP_VA_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;   
 EXEC [dbo].[PARWP_VA_VALIDT_DUP_BOB]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_PURCH_CMMDTY]          @GUIDIN, @CDSID, @TIME_STAMP;  
  --Adjustment Details Validation
 EXEC [dbo].[PARWP_VA_VALIDT_TYPE_OF_CHANGE]        @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_CHANGE_ID]             @GUIDIN, @CDSID, @TIME_STAMP;
 
 --Adjustment Details Validation
 EXEC [dbo].[PARWP_VA_VALIDT_VRNT_ADJ]              @GUIDIN, @CDSID, @TIME_STAMP;
  --Exchange Rate tab Validations
 EXEC [dbo].[PARWP_VA_VALIDT_CRNCY_CODE]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_SUPL_CRNCY]            @GUIDIN, @CDSID, @TIME_STAMP;

 -- Sub - Assembly Validation
 EXEC [dbo].[PARWP_VA_VALIDT_SUB_ASSEMBLY]          @GUIDIN, @CDSID, @TIME_STAMP;

--Supplier Quote Validation 
 EXEC [dbo].[PARWP_VA_VALIDT_PURCHASED_PARTS]       @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_RAW_MATERIALS]         @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_PROCESSING_COSTS]      @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_ASSEMBLY]              @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_VA_VALIDT_MFG_MARKUP]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VA_VALIDT_BOM_QUOTED]            @GUIDIN, @CDSID, @TIME_STAMP;
 
 -- Validate Improvement Ideas
 EXEC [dbo].[PARWP_VAII_VALIDT_IMPROVEMENT_IDEAS]   @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VAII_VALIDT_VRNT_IMPRV_FORD]     @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_VAII_VALIDT_VRNT_IMPRV_SUPL]     @GUIDIN, @CDSID, @TIME_STAMP;



 EXEC [dbo].PARWP_VA_VALIDT_SUMMARY_PRE             @GUIDIN, @CDSID, @TIME_STAMP,@V_Threshold_A;
 EXEC [dbo].[PARWP_VAII_VALIDT_SUMMARY_PRE]         @GUIDIN, @CDSID, @TIME_STAMP,@V_Threshold_A;

  BEGIN TRY
 
   BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

--      --Update the S45 cover page table's error flag
     EXEC [dbo].[PARWP_VA_UPDATE_S45_COVER_ERROR_FLAG]         @GUIDIN;

 --	 Load VA
     EXEC [dbo].[PARWP_VA_DELETE_TABLES]                       @GUIDIN, @CDSID, @CCTSS_K;
	 EXEC [dbo].[PARWP_VA_LOAD_PURCHASED_PARTS]                @GUIDIN, @CDSID, @TIME_STAMP;
     EXEC [dbo].[PARWP_VA_LOAD_RAW_MTRLS]                      @GUIDIN, @CDSID, @TIME_STAMP;   
	 EXEC [dbo].[PARWP_VA_LOAD_PROCESSING_COSTS]	           @GUIDIN, @CDSID, @TIME_STAMP;
     EXEC [dbo].[PARWP_VA_LOAD_ASSEMBLY]                       @GUIDIN, @CDSID, @TIME_STAMP;
--	 EXEC [dbo].[PARWP_VA_LOAD_MFG_MARKUPS]                    @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_VA_LOAD_EXCHG_RATE]                     @GUIDIN, @CDSID, @TIME_STAMP;

 -- Load VA II
	EXEC [dbo].[PARWP_VAII_IMPRV_DELETE]                        @GUIDIN, @CDSID, @CCTSS_K;
    EXEC [dbo].[PARWP_VAII_IMPRV_SUPL_DELETE]					@GUIDIN
	EXEC [dbo].[PARWP_VAII_LOAD_VRNT_IMPRVMENT]                 @GUIDIN, @CDSID, @TIME_STAMP;
    EXEC [dbo].[PARWP_VAII_LOAD_PURCHASED_PARTS]                @GUIDIN, @CDSID, @TIME_STAMP;
    EXEC [dbo].[PARWP_VAII_LOAD_RAW_MTRLS]						@GUIDIN, @CDSID, @TIME_STAMP;
    EXEC [dbo].[PARWP_VAII_LOAD_PROCESSING_COSTS]				@GUIDIN, @CDSID, @TIME_STAMP;
    EXEC [dbo].[PARWP_VAII_LOAD_ASSEMBLY]						@GUIDIN, @CDSID, @TIME_STAMP;

-- Variant Consolidation
-- Delete of U81 is done in PARWP_VA_DELETE_TABLES
	 EXEC [dbo].[PARWP_VACT_LOAD_U81_SUPL_VRNT_ADJ]            @CCTSS_K, @CDSID, @TIME_STAMP;

-- Load UD9 table
	EXEC [dbo].[PARWP_VAIICT_LOAD_UD9_SUPL_DSGN_IMPRV]         @CCTSS_K, @CDSID, @TIME_STAMP;
	
-- Load VII supplier ideas tradeoff 
	EXEC [dbo].[PARWP_VAII_LOAD_TRDOFF_IMPRV_SUPL]              @GUIDIN, @CDSID, @TIME_STAMP;

-- Load Summary for file imports
	 EXEC [dbo].[PARWP_VA_UPDT_LAST_IMPT]                      @GUIDIN, @CDSID, @IMPORT_STATUS;

   -- POST LOAD VALIDATION CHECK
		EXEC [dbo].[PARWP_VA_VALIDT_SUMMARY_CST_POST] @GUIDIN,@CCTSS_K,@V_Threshold_A,@Error OUTPUT,@Calculated_Value OUTPUT,@Staging_Value OUTPUT,@File_Name OUTPUT,@Ref_K OUTPUT
    --[dbo].[PARWP_VII_VALIDT_SUMMARY_CST_POST] add this later..
		IF @Error != ''  --Check if the post load summary validation generated an error 
		   Set @result  = '***Post Load Error: Arrow calculated Total $' +CAST(@Calculated_Value as varchar(50)) +' using data loaded into base tables did not equal to Total on Summary sheet $'+CAST(@Staging_Value as varchar(50)) +' for Processing ID '+@GUIDIN
--		   Set @result  = '***Post Load Error: Arrow calculated Total $' +'0' +' using data loaded into base tables did not equal to Total on Summary sheet $'+ '0'+' for Processing ID '+@GUIDIN;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- VA Type=Delete; copy GCS/CCS to VA for purch part, raw, processing when there's a VA type of DELETE. This will zero out the Variant BOV/Intended Design cost
-- Must be done after post validation or an email will happen every time because of the copy.
--++++++++++++++++++++++++++++++++++++++++++++++++
      Insert into @T09_CCTSS_VRNT_SUPL 
      Select U09.ARWU09_CCTSS_VRNT_SUPL_K
        From PARWS45_VA_COVER_PAGE_INFO    S45
        JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT  U09
          ON S45.User_Selected_CTSP_N            = U09.ARWU31_CTSP_N              
         AND S45.User_Selected_CTSP_Region_C     = U09.ARWA06_RGN_C               
         AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U09.ARWA03_ENRG_SUB_CMMDTY_X   
         AND S45.User_Selected_SUPL_N            = U09.ARWA17_SUPL_N               
         AND S45.User_Selected_SUPL_C            = U09.ARWA17_SUPL_C               
         AND S45.User_Selected_SUPL_CNTRY_N      = U09.ARWA28_CNTRY_N              
         AND S45.User_selected_WALK_VRNT_X       = U09.ARWU04_VRNT_N         
         AND S45.User_Selected_BNCMK_VRNT_N      = U09.ARWU01_BNCHMK_VRNT_N
       Where S45.Processing_ID               = @GUIDIN
         AND S45.Skip_loading_due_to_error_f = 0;	
   EXEC [dbo].[PARWP_VA_DEL_TYP_COPY_FROM_GCS]     @CCTSS_K, @T09_CCTSS_VRNT_SUPL, @CDSID, @TIME_STAMP;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table load for Calculations
--++++++++++++++++++++++++++++++++++++++++++++++++
	Set @AtLeast1_file_loaded = (Select Count(*) 
	                               From PARWS45_VA_COVER_PAGE_INFO S45 
							      Where S45.Processing_ID               = @GUIDIN
								    and S45.Skip_loading_due_to_error_f = 0
							    );
	If IsNULL(@AtLeast1_file_loaded,0) > 0
       BEGIN
          exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
               @U01_k                = @CCTSS_K
             , @U06_k                = -1
             , @U04_k                = -1
             , @CDSID                = @CDSID
             , @TRIGGER              = 'VAW IMPORT'
             , @Primary_output_error = @Primary_output_error OUTPUT
          ;          
          If @Primary_output_error = ''
             Begin
                COMMIT TRANSACTION
                If @result = ''
				     Set @result = 'SUCCESS';
				Else Set @result = @result;  --Didn't need the ELSE but wanted to show there would be a POST load calculation error at this point
             End
          Else
             Begin
                Rollback
				If @result = ''
                     Set @result = 'Master Load Primary Error: ' + @Primary_output_error;
				Else Set @result = SUBSTRING(CONCAT('Master Load Primary Error: ', @Primary_output_error, ' ', @result),1,5000);  
             End
       End
	ELSE
	   BEGIN
          Set @result = 'SUCCESS'; --All files in the batch had a validation error. There should be no data to commit at this point but we should have something to match the begin transaction.
          COMMIT TRANSACTION;
	   End
    --End of: If IsNULL(@AtLeast1_file_loaded,0) > 0 
 END TRY

 --CATCH
 BEGIN CATCH
   Rollback;
   Set @result = 'VA_MASTER SYSTEM ERROR: ' +              
	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
				 ' |Processing Id: ' + @GUIDIN +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
--	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

   SET @IMPORT_STATUS = 'Processing_Error'

    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUIDIN                           --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'VA MASTER PROCEDURE - PBOM and DA UI'
        ,0                              as ARWE02_ROW_IDX		
		,''
		,''
	;

	EXEC [dbo].[PARWP_VA_UPDT_LAST_IMPT]                      @GUIDIN, @CDSID, @IMPORT_STATUS;

  END CATCH;	
 -- RETURN @result
  END; -- END PBOM IF/ELSE

END ;   -- end Procedure



GO
