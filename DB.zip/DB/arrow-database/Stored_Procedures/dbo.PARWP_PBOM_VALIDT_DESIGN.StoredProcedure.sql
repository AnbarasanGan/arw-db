DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_DESIGN]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		rwesley2
-- Create date: 01/07/2020
-- Description:	Stored Procedure to validate Program Code on PBOM
-- Assumption:  on the PBOM spread sheet, Design name will be in one cell. It will consist of make, model, and model year in that order
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   09-11-2020  US1910880 Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10-20-2020  US1996362 Switch from E02 to E03 and include Excel column
-- Asolosky   07-12-2021  US2657643 PBOM import - Validation to stop processing when there's duplicated design names
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDT_DESIGN] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(500)
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- Validate Design against Display name  
   INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
      SELECT
	      Validate.[Source_c]                          as [ARWE03_SOURCE_C],
	      Validate.design_name                         as [ARWE03_ERROR_VALUE],
	      'Design on the BoB Teardown Template does not match Design display name' as [ARWE03_ERROR_x],
	      Validate.[Processing_ID]                     as [ARWE03_PROCESSING_ID],
	      Validate.[file_name]                         as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      Validate.[ARWS59_PBOM_PARTS]                 as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  ''                                           as [ARWE03_EXCEL_TAB_X],
		  9                                            as ARWE03_ROW_IDX,
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  design_name_column                           as ARWE03_COLUMN
       FROM 
	   (SELECT Source_c,
			   design_name,
			   design_name_column,
               Processing_ID,
		       file_name,
			   Sub_commodity_name,
			   row_idx,
               ARWS59_PBOM_PARTS,
   		       Program,
   		       row_number() over (partition by S59.Processing_ID, S59.file_name,s59.program,s59.design_name    Order by s59.program,s59.design_name) as rownum
          FROM PARWS59_PBOM_PARTS s59 
		  LEFT join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view   -- get the BoB for the U01 and u06 keys
            on s59.User_Selected_CTSP_N            = u06_view.ARWU31_CTSP_N
	       and s59.User_Selected_CTSP_Region_C     = u06_view.ARWA06_RGN_C
		   and s59.User_Selected_ENRG_SUB_CMMDTY_X = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		   and s59.User_Selected_BNCMK_VRNT_N      = u06_view.ARWU01_BNCHMK_VRNT_N
 		   and s59.design_name                     = u06_view.ARWU14_CCTSS_DSGN_DSPLY_N   -- this will cause the name that doesn't match to drop out. won't have it for the u14 join.
         WHERE s59.Processing_ID       = @GUID
    	   and u06_view.ARWU14_CCTSS_DSGN_DSPLY_N  is NULL
         ) Validate
		 WHERE rownum=1
	 ;

-- Validate the user didn't enter the same design name more than once  
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
 SELECT
	    Source_c                            as [ARWE03_SOURCE_C]
	   ,design_name                         as [ARWE03_ERROR_VALUE]
	   ,'Duplicate Design Names were found in the PBOM import. Please correct by changing one of the design names.' as [ARWE03_ERROR_x]
	   ,Processing_ID                       as [ARWE03_PROCESSING_ID]
	   ,file_name                           as [ARWE03_FILENAME]
	   ,OBJECT_NAME(@@PROCID)               as [ARWE03_PROCEDURE_X]
	   ,@TIME_STAMP                         as [ARWE03_CREATE_S]
	   ,@CDSID                              as [ARWE03_CREATE_USER_C]
	   ,@TIME_STAMP 
	   ,@CDSID                              as [ARWE03_LAST_UPDT_USER_C]
	   ,ARWS59_PBOM_PARTS                   as [ARWE03_BATCH_ERRORS_REF_K]
	   ,'PARWS59_PBOM_PARTS'                as [ARWE03_STAGING_TABLE_X]
	   ,'ERROR'                             as [ARWE03_ERROR_TYPE_X]
	   ,''                                  as [ARWE03_EXCEL_TAB_X]
	   ,9                                   as ARWE03_ROW_IDX
	   ,''                                  as ARWE03_Part_Index
	   ,''                                  as ARWE03_Arrow_value
	   ,design_name_column                  as ARWE03_COLUMN
   FROM 
       (Select *   		       
              ,row_number() over (partition by Processing_ID, file_name, design_name
        		                      order by row_idx) rowdup 
          from 
       	      (SELECT Source_c
       			     ,design_name
       			     ,design_name_column
                     ,Processing_ID
       		         ,file_name
       			     ,Sub_commodity_name
       			     ,row_idx
                     ,ARWS59_PBOM_PARTS
          		     ,User_Selected_CTSP_N
       			     ,row_number() over (partition by Processing_ID, file_name, design_name, design_name_column
       			                             order by row_idx) rownum
                 FROM PARWS59_PBOM_PARTS  
                WHERE Processing_ID       = @GUID
              ) DSGN
         WHERE rownum = 1
       ) DUP_DSGN
  Where rowdup    > 1
;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE
		     ,''                               -- Column
END CATCH




GO
