DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUB_ASSEMBLY_PREPBOM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/07/2020
-- Description:	validate Sub Assembly Names must not be NULL, empty string, spaces or starts with a space
-- ================================================
-- CHANGES
-- Date			CDSID	  Feature	Description
-- ----------   --------  -------   -----------
-- 02/24/2021   Asolosky  US2261872 Added 'A sub assembly name can''t contain these special characters: [ ] * / \ : ?'
--                                        'Sub assembly name can''t be more than 25 characters'
--                                        'A sub assembly name can''t have an imbedded line feed <LF>'
--                                        'A sub assembly name can''t have an imbedded carriage return <CR>'
--=================================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUB_ASSEMBLY_PREPBOM] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO PARWE02_BATCH_ERRORS
      SELECT
	         Source_c                          as [ARWE02_SOURCE_C],
	         part_sub_assembly_name            as [ARWE02_ERROR_VALUE],
	         'Sub Assembly Name is missing. Please correct and re-import.' as [ARWE02_ERROR_X],
	         Processing_ID                     as [ARWE02_PROCESSING_ID],
	         file_name                         as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)             as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                       as [ARWE02_CREATE_S],
             @CDSID                            as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                       as [ARWE02_LAST_UPDT_S],
	         @CDSID                            as [ARWE02_LAST_UPDT_USER_C],
	         ARWS13_CCS_FORD_BOM_PARTS_INFO_K  as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS13_CCS_FORD_BOM_PARTS_INFO' as [ARWE02_STAGING_TABLE_X], 
	         'ERROR'                           as [ARWE02_ERROR_TYPE_X],
	         'BOM - ' + part_sub_assembly_name as [ARWE02_EXCEL_TAB_X], 
	         row_idx                           as [ARWE02_ROW_IDX],
	         part_index                        as [part_index], 
	         ''  --No ARROW Value
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO 
       Where Processing_ID = @GUID
         and isNULL(part_sub_assembly_name,'') = ''  --For Null, empty string, or space.  SQL considers empty string and a space as equal
    ;

	INSERT INTO PARWE02_BATCH_ERRORS
      SELECT
	         Source_c                          as [ARWE02_SOURCE_C],
	         part_sub_assembly_name            as [ARWE02_ERROR_VALUE],
	         'Sub Assembly Name starts with a space. Please correct and re-import.' as [ARWE02_ERROR_X],
	         Processing_ID                     as [ARWE02_PROCESSING_ID],
	         file_name                         as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)             as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                       as [ARWE02_CREATE_S],
             @CDSID                            as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                       as [ARWE02_LAST_UPDT_S],
	         @CDSID                            as [ARWE02_LAST_UPDT_USER_C],
	         ARWS13_CCS_FORD_BOM_PARTS_INFO_K  as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS13_CCS_FORD_BOM_PARTS_INFO' as [ARWE02_STAGING_TABLE_X], 
	         'ERROR'                           as [ARWE02_ERROR_TYPE_X],
	         'BOM - ' + part_sub_assembly_name as [ARWE02_EXCEL_TAB_X], 
	         row_idx                           as [ARWE02_ROW_IDX],
	         part_index                        as [part_index], 
	         ''  --No ARROW Value
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO 
       Where Processing_ID = @GUID
         and SUBSTRING(part_sub_assembly_name,1,1)  = ' '   
		 and len(part_sub_assembly_name)            > 1
    ;

INSERT INTO PARWE02_BATCH_ERRORS
    SELECT
	       'UI'                                         as [ARWE03_SOURCE_C],
	       part_sub_assembly_name                       as [ARWE03_ERROR_VALUE], 
	       'A sub assembly name can''t contain these special characters: [ ] * / \ : ?' as [ARWE03_ERROR_x],
	       Processing_ID                     as [ARWE02_PROCESSING_ID],
	       file_name                         as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)             as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                       as [ARWE02_CREATE_S],
           @CDSID                            as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                       as [ARWE02_LAST_UPDT_S],
	       @CDSID                            as [ARWE02_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K  as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO' as [ARWE02_STAGING_TABLE_X], 
	       'ERROR'                           as [ARWE02_ERROR_TYPE_X],
	       'BOM - ' + part_sub_assembly_name as [ARWE02_EXCEL_TAB_X], 
	       row_idx                           as [ARWE02_ROW_IDX],
	       part_index                        as [part_index], 
	       ''  --No ARROW Value
	  FROM PARWS13_CCS_FORD_BOM_PARTS_INFO 
     Where Processing_ID = @GUID
       and (part_sub_assembly_name like '%~[%' ESCAPE '~' or
			part_sub_assembly_name like '%~]%' ESCAPE '~' or
			part_sub_assembly_name like '%*%' or
			part_sub_assembly_name like '%/%' or
			part_sub_assembly_name like '%\%' or
			part_sub_assembly_name like '%:%' or
			part_sub_assembly_name like '%?%'  
		   )
;

--******************************************************
--Sub assembly name can''t be more than 25 characters
--******************************************************
	INSERT INTO PARWE02_BATCH_ERRORS
    SELECT
	       'UI'                                                  as [ARWE03_SOURCE_C],
	       part_sub_assembly_name                                as [ARWE03_ERROR_VALUE], 
	       'Sub assembly name can''t be more than 25 characters' as [ARWE03_ERROR_x],
	       Processing_ID                                         as [ARWE02_PROCESSING_ID],
	       file_name                                             as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                                 as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                           as [ARWE02_CREATE_S],
           @CDSID                                                as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                           as [ARWE02_LAST_UPDT_S],
	       @CDSID                                                as [ARWE02_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K                      as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'                     as [ARWE02_STAGING_TABLE_X], 
	       'ERROR'                                               as [ARWE02_ERROR_TYPE_X],
	       'BOM - ' + part_sub_assembly_name                     as [ARWE02_EXCEL_TAB_X], 
	       row_idx                                               as [ARWE02_ROW_IDX],
	       part_index                                            as [part_index], 
	       ''  --No ARROW Value
	  FROM PARWS13_CCS_FORD_BOM_PARTS_INFO 
     Where Processing_ID = @GUID
	   And len(part_sub_assembly_name) > 25                    
    ;

--******************************************************
-- Line Feed/Carriage return validation on sub assembly name
--******************************************************
DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
	INSERT INTO PARWE02_BATCH_ERRORS
    SELECT
	       Source_c                                                      as [ARWE03_SOURCE_C],
	       replace(part_sub_assembly_name,char(10),'<LF>')               as [ARWE03_ERROR_VALUE],  --replace line feed with <LF>
	       'A sub assembly name can''t have an imbedded line feed <LF>'  as [ARWE03_ERROR_X],
	       Processing_ID                                as [ARWE03_PROCESSING_ID],
	       file_name                                    as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K             as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'            as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       'BOM - ' + part_sub_assembly_name            as [ARWE03_EXCEL_TAB_X],
	       row_idx                                      as [ARWE03_ROW_IDX],
		   part_index                                   as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value -- no arrow value
	  FROM PARWS13_CCS_FORD_BOM_PARTS_INFO 
     Where Processing_ID = @GUID
       and NullIf(PATINDEX(@pat10,part_sub_assembly_name),0) > 0  --Looking for line feed
    ;

-- Carriage Return validation
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
	INSERT INTO PARWE02_BATCH_ERRORS
    SELECT
	       Source_c                                        as [ARWE03_SOURCE_C],
	       replace(part_sub_assembly_name,char(13),'<CR>') as [ARWE03_ERROR_VALUE],  --replace carriage return with <CR>
	       'A sub assembly name can''t have an imbedded carriage return <CR>' as [ARWE03_ERROR_X],
	       Processing_ID                                   as [ARWE03_PROCESSING_ID],
	       file_name                                       as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                           as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                     as [ARWE03_CREATE_S],
           @CDSID                                          as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                     as [ARWE03_LAST_UPDT_S],
	       @CDSID                                          as [ARWE03_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K                as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'               as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                         as [ARWE03_ERROR_TYPE_X],
	       'BOM - ' + part_sub_assembly_name               as [ARWE03_EXCEL_TAB_X],
	       row_idx                                         as [ARWE03_ROW_IDX],
		   part_index                                      as ARWE03_Part_Index,
		   ''                                              as ARWE03_Arrow_value -- no arrow value
	  FROM PARWS13_CCS_FORD_BOM_PARTS_INFO 
     Where Processing_ID = @GUID
       and NullIf(PATINDEX(@pat13,part_sub_assembly_name),0) > 0  --Looking for carriage 
    ;

END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'S13-S18'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''                                --Part_index
		     ,''                                --Arrow value	
END CATCH
;
GO
