SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		ashaik12
-- Create date: 06/24/2019
-- Description:	Load data for  improvement ideas grouping, Imporvement Id's and their relation into U45, U46 and U47 tables.
--              Only INSERTS and NO Deletes. Inserts if a record already doesn't exist in the tables
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08-14-2019  rwesley2  na	      added logic to add supplier key to improvement id name when originator is SUPPLIER 
--                                and FORD when originator is FORD on U46 INSERT
-- 08-27/2019  rwesley2           changed CAST to CONVERT for the above logic 
-- 08/29/2019  rwesley2           added CCTSS to U18 temp table build and U18 INSERT 
-- 09/05/2019  rwesley2		      changed NOT EXISTS on U46 load to parse for '#'
-- 10/16/2019  ashaik12           Added group by to U46 insert to handle identical data coming from two files on initial load for the same design.  
-- 11/21/2019  rwesley2           new business rule:  the first character of a part index defines the sub-assy  and removed rownum =1
-- 11/22/2019  rwesley2           business rule change: first look for part index match using first 2 characters of part index to find the sub-assy
--                                if no matches, use first character of part index to find the sub-assy
-- 12/03/2019  ashaik12           Added new join condition in 1 char load
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 07/30/2020  Ashaik12           US1809333 - Increase column sizes in temp table to match database column sizes.
-- 08/20/2020  rwesley2 US1868444 Eliminate duplicate insert error on improvement ideas 
-- 09/08/2020  Ashaik12           US1904085 -- Fix the not exists check in the U46 insert.
-- 01/25/2021  Ashaik12           US2202984 -- Add Ford SPEC SDS Number to U46 insert
-- 05/06/2022  btemkow            DE253060 -- Added ARWU46_CIA_ID_NUM_X column to U46 insert
-- 2020-07-08  btemkow            US3781226 Changed U46 Insert to have an explicit column list to accomodate ARWU46_FRTHR_OPPRT_INCLD_F and to "future proof" against more new columns
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_DAII_LOAD_DSGN_IMPRV_GRP] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;


INSERT INTO [PARWU45_CCTSS_DSGN_IMPRV_GRP]
SELECT  
       V04.[ARWU06_CCTSS_DSGN_K]       AS [ARWU06_CCTSS_DSGN_K]
      ,S44.improvement_idea_grouping   AS [ARWU45_CCTSS_DSGN_IMPRV_GRP_X]
	  ,A31.ARWA31_CONFID_LVL_K         AS [ARWA31_CONFID_LVL_K]
      ,@TIME_STAMP                    AS ARWU45_CREATE_S
      ,@CDSID                          AS ARWU45_CREATE_USER_C
      ,@TIME_STAMP                    AS ARWU45_LAST_UPDT_S
      ,@CDSID                          AS ARWU45_LAST_UPDT_USER_C
  FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO] S44
  JOIN PARWS34_DAII_COVER_PAGE_INFO           S34
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename

 -- Join with Design Supplier View
  JOIN PARWV04_DSGN_SUPL   V04
    ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
   AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
   AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
   AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
   AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
   AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
   AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
   AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
   AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N

   JOIN PARWA31_CONFID_LVL A31
   ON A31.ARWA31_CONFID_LVL_X ='High'

   LEFT JOIN PARWU46_CCTSS_DSGN_IMPRV U46
    ON U46.ARWU06_CCTSS_DSGN_K = V04.ARWU06_CCTSS_DSGN_K
	AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = S44.improvement_id   -- This Left join checks if there is a improvement idea grouping already exists for a improvement_id for that design 
  
  Where S34.Processing_ID               = @GUIDIN
    And S34.Skip_loading_due_to_error_f = 0
	AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N is NULL
    And not exists --Can't add a tough group if it already exists
       (Select 'X'
          From PARWU45_CCTSS_DSGN_IMPRV_GRP U45_Check
	     Where U45_Check.ARWU06_CCTSS_DSGN_K           = V04.ARWU06_CCTSS_DSGN_K
		   And U45_Check.ARWU45_CCTSS_DSGN_IMPRV_GRP_X = S44.improvement_idea_grouping    
       )
Group by --Get distinct data to write into the U36 table.
       V04.ARWU06_CCTSS_DSGN_K          
	  ,S44.improvement_idea_grouping
	  ,A31.ARWA31_CONFID_LVL_K
;   

--=============================================
--=============================================
--  U18 INSERT 
-- TABLE variables to hold new Part Index
 DECLARE @new_part_index TABLE (
         NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
        ,NEW_CHANGE_ID VARCHAR (64) NOT NULL
        ,NEW_PART_NAME VARCHAR (256) NOT NULL
		,NEW_DESIGN_MAKE VARCHAR (32) NOT NULL
		,NEW_DESIGN_MODEL VARCHAR (32) NOT NULL
		,NEW_MY VARCHAR (7) NOT NULL
		,NEW_CCTSS INT NOT NULL
	    ,row_idx INT
		                        )
 	;
-- get new part index from s35 that is not on u18. since improvement ideas don't have a type of change any part on the improvement ideas
-- tab that's not on the u18 is assummed to be a part ADD    
-- when skip loading flag is not 0, nothing is loaded to the temp table, so nothing is inserted to u18.
INSERT INTO @new_part_index
   select * from (
       SELECT distinct(s44.part_index )as not_matched_PI
  	         ,s44.improvement_id
	         ,s44.part_name
			 ,s34.[User_Selected_VEH_MAKE_N]
			 ,s34.[User_Selected_VEH_MDL_N]
			 ,s34.[User_Selected_VEH_MDL_YR_C]
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,row_number() OVER (PARTITION BY s44.part_index, s44.part_name,u06_view.[ARWU01_CCTSS_K]
			   order by s44.part_index, s44.part_name,u06_view.[ARWU01_CCTSS_K]) as rownum
       FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
	   LEFT JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S44.Processing_ID
        and S34.filename            = S44.filename
  	   LEFT join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	      on u06_view.ARWU01_CCTSS_K = u18.ARWU01_CCTSS_K
	     and S44.[part_index] = U18.ARWU18_BOM_PART_IX_N
       WHERE s44.Processing_ID       =  @GUIDIN 
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S34.Skip_loading_due_to_error_f = 0
		 ) x
		 Where x.rownum = 1
		 ;
 
-- check for part index match using first 2 characters 
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID       as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) = substring(npi.NEW_CHANGE_ID,1,2)
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;
-- deleting and reloading the temp table to make sure any parts inserted from the 2 character match above don't get inserted again fromn the 1 character match
-- anything inserted to the u18 from the 2 character match will not be on the temp table
DELETE from @new_part_index
INSERT INTO @new_part_index
   select * from (
       SELECT distinct(s44.part_index )as not_matched_PI
  	         ,s44.improvement_id
	         ,s44.part_name
			 ,s34.[User_Selected_VEH_MAKE_N]
			 ,s34.[User_Selected_VEH_MDL_N]
			 ,s34.[User_Selected_VEH_MDL_YR_C]
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,row_number() OVER (PARTITION BY s44.part_index, s44.part_name,u06_view.[ARWU01_CCTSS_K]
			   order by s44.part_index, s44.part_name,u06_view.[ARWU01_CCTSS_K]) as rownum
       FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
	   LEFT JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S44.Processing_ID
        and S34.filename            = S44.filename
  	   LEFT join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	      on u06_view.ARWU01_CCTSS_K = u18.ARWU01_CCTSS_K
	     and S44.[part_index] = U18.ARWU18_BOM_PART_IX_N
       WHERE s44.Processing_ID       =  @GUIDIN 
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S34.Skip_loading_due_to_error_f = 0
		 ) x
		 Where x.rownum = 1
		 ;
-- doing not DP because if only using first character from a directed part may get wrong sub-assy
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID      as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_CHANGE_ID,1,1)
	   and substring(npi.NEW_CHANGE_ID,1,2) <> 'DP'
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;
--=============================================
--=============================================

INSERT INTO  PARWU46_CCTSS_DSGN_IMPRV
(
	    ARWU06_CCTSS_DSGN_K
	   ,ARWU46_CCTSS_DSGN_IMPRV_ID_N
	   ,ARWU45_CCTSS_DSGN_IMPRV_GRP_K
	   ,ARWU18_BOM_PART_K
	   ,ARWU46_CCTSS_DSGN_IMPRV_IDEA_X
	   ,ARWU46_CCTSS_DSGN_IMPRV_ORIG_X
       ,ARWU46_CREATE_S
       ,ARWU46_CREATE_USER_C
       ,ARWU46_LAST_UPDT_S
       ,ARWU46_LAST_UPDT_USER_C
	   ,ARWU46_SPEC_SDS_NUM_X
	   ,ARWU46_CIA_ID_NUM_X
)
select
        ARWU06_CCTSS_DSGN_K
	   ,ARWU46_CCTSS_DSGN_IMPRV_ID_N
	   ,ARWU45_CCTSS_DSGN_IMPRV_GRP_K
	   ,ARWU18_BOM_PART_K
	   ,[ARWU46_CCTSS_DSGN_IMPRV_IDEA_X]
	   ,[ARWU46_CCTSS_DSGN_IMPRV_ORIG_X]
       ,@TIME_STAMP                      AS ARWU46_CREATE_S
       ,@CDSID                            AS ARWU46_CREATE_USER_C
       ,@TIME_STAMP                      AS ARWU46_LAST_UPDT_S
       ,@CDSID                            AS ARWU46_LAST_UPDT_USER_C
	   ,[ARWU46_SPEC_SDS_NUM_X]
	   ,''								AS ARWU46_CIA_ID_NUM_X
	  from
	  (
SELECT  V04.ARWU06_CCTSS_DSGN_K 
       ,(CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  s44.improvement_id + '#' + CONVERT(VARCHAR,[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  s44.improvement_id  + '#' + 'Ford'	            
--		  ELSE s44.improvement_id + '#' + 'UNK'   
        END) as ARWU46_CCTSS_DSGN_IMPRV_ID_N
	   ,U45.ARWU45_CCTSS_DSGN_IMPRV_GRP_K AS [ARWU45_CCTSS_DSGN_IMPRV_GRP_K] 
	   ,U18.ARWU18_BOM_PART_K             AS [ARWU18_BOM_PART_K]
	   ,S44.idea_description              AS [ARWU46_CCTSS_DSGN_IMPRV_IDEA_X]
	   ,S44.originator                    AS [ARWU46_CCTSS_DSGN_IMPRV_ORIG_X]
	   ,S44.Ford_Spec_SDS_Num             AS [ARWU46_SPEC_SDS_NUM_X]
        From PARWS34_DAII_COVER_PAGE_INFO     S34 
        JOIN PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename
    
  JOIN [dbo].[PARWV04_DSGN_SUPL]   V04
    ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
   AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
   AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
   AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
   AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
   AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
   AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
   AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
   AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N
    
   JOIN [dbo].[PARWU18_BOM_PART] U18
   ON  V04.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K
   AND U18.ARWU18_BOM_PART_IX_N       = S44.part_index  
   
--Improvement Idea Grouping
  Join PARWU45_CCTSS_DSGN_IMPRV_GRP  U45
    ON U45.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
   And U45.ARWU45_CCTSS_DSGN_IMPRV_GRP_X = S44.[improvement_idea_grouping]

 Where S34.Processing_ID               = @GUIDIN
   AND S34.Skip_loading_due_to_error_f = 0
   And NOT exists --Insert if it doesn't already exist
      (Select 'X'
        From PARWU46_CCTSS_DSGN_IMPRV U46_check
	   Where U46_check.ARWU06_CCTSS_DSGN_K        = V04.ARWU06_CCTSS_DSGN_K 
	       and (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  s44.improvement_id + '#' + CONVERT(VARCHAR,[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  s44.improvement_id  + '#' + 'Ford'	             
        END) = ARWU46_CCTSS_DSGN_IMPRV_ID_N 
      )
	  ) X
group by ARWU06_CCTSS_DSGN_K
	    ,ARWU46_CCTSS_DSGN_IMPRV_ID_N
	    ,ARWU45_CCTSS_DSGN_IMPRV_GRP_K
	    ,ARWU18_BOM_PART_K
	    ,[ARWU46_CCTSS_DSGN_IMPRV_IDEA_X]
	    ,[ARWU46_CCTSS_DSGN_IMPRV_ORIG_X]
		,[ARWU46_SPEC_SDS_NUM_X]
;









GO


