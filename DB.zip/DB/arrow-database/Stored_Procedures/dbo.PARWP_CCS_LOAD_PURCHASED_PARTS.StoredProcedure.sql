DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_PURCHASED_PARTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 04/09/2019
-- Description:	load ARROW U23 purchased parts table and u24 purchased parts parent
-- u23 must load before u24.  both are in this job
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 05/20/2019  Asolosky  N/A      If source country is not found in the A28 table, use the empty string country record.
--                                Also changed the insert's join to use the staging source country instead of the V08 view country and made it a left join
--                                Added the 2nd join to get the empty string country.
-- 06/13/2019  ASHAIK12  N/A      Make all join conditions from cover page columns to user selected columns. And Remove the join for Engineering Commodity.
-- 06/13/2019  ASHAIK12  N/A      Changed the order to Delete U24 , Delete U23 , Insert U23 , Insert U24
-- 06/17/2019  asolosky  N/A      Changed the delete to remove all purch part records related to the Design and Supplier instead of design_Supplier/sub-assembly
--                                Changed the delete on Parent purch parts to use all ARWU23_PURC_PART_COST_K records associated to the design-suppplier
-- 06/25/2019  rwesley2  N/A      changed ROW_NUMBER function to order by stage table row_idx col
-- 06/26/2019  rwesley2  N/A      Removed ROW_NUMBER function and replaced with row_idx col on U23 INSERT.  changed U24 INSERT to use U23.ARWU23_PURC_PART_DSPLY_SEQ_R
--                                Added Model Year to cover page select for U23 and U24 INSERT
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 07/16/2019  asolosky			  Removed the ISNULL function from the insert because they served no purpose.  The UI writes empty string to the staging tables.
-- 08/13/2019  ashaik12           Removed the Delete Statements
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- 01/17/2020  Ashaik12           New column added for U23 Insert for Purchase Part type (PIA/Directed/bailed)
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_PURCHASED_PARTS] 
-- Input Parameter
@GUIDIN        Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;






-------U23 INSERT

INSERT INTO [dbo].[PARWU23_PURC_PART_COST] 
   select   
            v08.[ARWU08_CCTSS_DSGN_SUPL_K]    AS [ARWU08_CCTSS_DSGN_SUPL_K]
	       ,v08.ARWU17_BOM_SUB_ASSY_K         AS [ARWU17_BOM_SUB_ASSY_K]
           ,s14.[row_idx]                     AS Distinct_row
           ,V08.[ARWU19_DSGN_PART_K]          AS [ARWU19_DSGN_PART_K]
		   ,s14.[part_specification]          AS [ARWU23_PURC_PART_SPEC_X]
           ,s14.source_supplier               AS ARWU23_SRC_SUPL_N

		   ,Case When a28.ARWA28_CNTRY_K is Null then  a28_EmptyStr.ARWA28_CNTRY_K  Else a28.ARWA28_CNTRY_K End AS ARWA28_SRC_CNTRY_K

		   ,A29.[ARWA29_CRCY_K]               AS [ARWA29_LCL_CRCY_K]
           ,s14.[purchased_price_per_piece]   AS [ARWU23_PURC_PART_PER_PCE_A]
           ,s14.[inbound_packaging_costs]     AS [ARWU23_INBND_PKNG_COST_PCE_A]
           ,s14.[inbound_logistics_costs]     AS [ARWU23_INBND_LGSTCS_COST_PCE_A]
           ,s14.[tax_duty]                    AS [ARWU23_TAX_AND_DUTY_PER_PCE_A]
           ,s14.[purchased_parts_markup_cost] AS ARWU23_PURC_PART_MRKP_P  --The staging column should've had a different name
           ,s14.[comments]                    AS [ARWU23_PURC_PART_ASSMP_CMT_X]
		   ,@TIME_STAMP                      AS [ARWU23_CREATE_S]
           ,@CDSID                            AS [ARWU23_CREATE_USER_C]
           ,@TIME_STAMP                      AS [ARWU23_LAST_UPDT_S]
           ,@CDSID                            AS [ARWU23_LAST_UPDT_USER_C]
		   ,A44.[ARWA44_PURC_PART_TYPE_K]     AS [ARWA44_PURC_PART_TYPE_K]

          from [dbo].[PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO] s14
           JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
             on s22.[Processing_ID] = s14.[Processing_ID]
            and s22.[filename] = s14.[filename]
           -- join to pbom view to get part_index 
           JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] v08
              on s22.[User_Selected_ENRG_SUB_CMMDTY_X] = v08.[ARWA03_ENRG_SUB_CMMDTY_X]
            and s22.[User_Selected_CTSP_N]            = v08.ARWU31_CTSP_N
            and s22.[User_Selected_CTSP_Region_C]     = v08.[ARWA06_RGN_C]
            and s22.[User_Selected_BNCMK_VRNT_N]      = V08.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
            and s22.[User_Selected_VEH_MAKE_N]        = v08.ARWA14_VEH_MAKE_N
            and s22.[User_Selected_VEH_MDL_N]         = v08.ARWA34_VEH_MDL_N
            and s22.[User_Selected_VEH_MDL_VRNT_X]    = V08.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
			AND S22.[User_Selected_VEH_MDL_YR_C]      = V08.[ARWA35_DSGN_VEH_MDL_YR_C]
            AND s22.[User_Selected_SUPL_N]            = V08.ARWA17_SUPL_N
            AND S22.[User_Selected_SUPL_C]            = V08.ARWA17_SUPL_C
            AND S22.[User_Selected_SUPL_CNTRY_N]      = V08.ARWA28_CNTRY_N
            and s14.part_index                        = V08.[ARWU18_BOM_PART_IX_N]
          --  and s14.supplier_name           = V08.[ARWA17_SUPL_N]

           JOIN [dbo].[PARWA29_CRCY] a29
             on a29.[ARWA29_CRCY_C]              = s14.[local_currency]
     Left  JOIN [dbo].PARWA28_CNTRY a28
             on a28.ARWA28_CNTRY_N               = s14.source_country
           JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
             on a28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''
		JOIN [dbo].[PARWA44_PURC_PART_TYPE] A44
			on s14.pia_directed_bailed = A44.[ARWA44_PURC_PART_TYPE_C]
          where s22.[Processing_ID]             = @GUIDIN
            and s22.Skip_loading_due_to_error_f = 0


;


---  U24 INSERT

INSERT INTO [dbo].[PARWU24_PURC_PART_COST_PARNT]
           select u23.[ARWU23_PURC_PART_COST_K] as part_index_ARWU23_PURC_PART_COST_K
		         ,v08b.[ARWU19_DSGN_PART_K] as parent_ARWU19_PARNT_DSGN_PART_K
				 ,@TIME_STAMP
				 ,@CDSID
 				 ,@TIME_STAMP
				 ,@CDSID
           from [dbo].[PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO] s14
           JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
             on s22.[Processing_ID] = s14.[Processing_ID] 
            and s22.[filename]      = s14.[filename]
  -- Join with Supplier Qoute View to get child key
             JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08
                on s22.[User_Selected_ENRG_SUB_CMMDTY_X] = v08.[ARWA03_ENRG_SUB_CMMDTY_X]
            and s22.[User_Selected_CTSP_N]               = v08.ARWU31_CTSP_N
            and s22.[User_Selected_CTSP_Region_C]                = v08.[ARWA06_RGN_C]
            and s22.[User_Selected_BNCMK_VRNT_N]       = V08.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
            and s22.[User_Selected_VEH_MAKE_N]            = v08.ARWA14_VEH_MAKE_N
            and s22.[User_Selected_VEH_MDL_N]            = v08.ARWA34_VEH_MDL_N
            and s22.[User_Selected_VEH_MDL_VRNT_X]              = V08.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
			AND S22.[User_Selected_VEH_MDL_YR_C]      = V08.[ARWA35_DSGN_VEH_MDL_YR_C]
            AND s22.[User_Selected_SUPL_N]           = V08.ARWA17_SUPL_N
            AND S22.[User_Selected_SUPL_C]          = V08.ARWA17_SUPL_C
            AND S22.[User_Selected_SUPL_CNTRY_N]        = V08.ARWA28_CNTRY_N
            and s14.part_index              = V08.[ARWU18_BOM_PART_IX_N]

           JOIN [dbo].[PARWU23_PURC_PART_COST] u23
		     on U23.ARWU08_CCTSS_DSGN_SUPL_K = V08.ARWU08_CCTSS_DSGN_SUPL_K
			And U23.ARWU17_BOM_SUB_ASSY_K    = V08.ARWU17_BOM_SUB_ASSY_K
--			And U23.ARWU19_DSGN_PART_K       = V08.ARWU19_DSGN_PART_K
            And U23.[ARWU23_PURC_PART_DSPLY_SEQ_R] =  s14.[row_idx]

  -- Join with Supplier Qoute View to get parent key
			  JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08b
               ON s22.[User_Selected_ENRG_SUB_CMMDTY_X]  = V08b.[ARWA03_ENRG_SUB_CMMDTY_X]
              and s22.[User_Selected_CTSP_N]                = V08b.ARWU31_CTSP_N
              and s22.[User_Selected_CTSP_Region_C]                 = V08b.[ARWA06_RGN_C]
              and s22.[User_Selected_BNCMK_VRNT_N]      = V08b.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
              and s22.[User_Selected_VEH_MAKE_N]           = V08b.[ARWA14_VEH_MAKE_N]
              and s22.[User_Selected_VEH_MDL_N]           = V08b.[ARWA34_VEH_MDL_N]
              and s22.[User_Selected_VEH_MDL_VRNT_X]             = V08b.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
			  AND S22.[User_Selected_VEH_MDL_YR_C]      = V08.[ARWA35_DSGN_VEH_MDL_YR_C]
			  AND s22.[User_Selected_SUPL_N]          = V08b.ARWA17_SUPL_N
              AND S22.[User_Selected_SUPL_C]          = V08b.ARWA17_SUPL_C
              AND S22.[User_Selected_SUPL_CNTRY_N]       = V08b.ARWA28_CNTRY_N
              and s14.[part_subassy_parent]  = V08b.[ARWU18_BOM_PART_IX_N]

           where s22.[Processing_ID]             = @GUIDIN
             and s22.Skip_loading_due_to_error_f = 0
;

GO
