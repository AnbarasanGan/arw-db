DROP PROCEDURE If Exists [dbo].[PARWP_CALC_MASTER_DELETE_PRIMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASOLOSKY
-- Create date: 11/04/2021
-- Description:	Master procedure to call all procedures that will run the data dump procedures
--   It uses a User-Defined Table Type that is defined in the database. It's found in SMS under TYPES
--   The Table type will be loaded with the designs needed for processing the calc tables.
-- Input Parameters
-- @U01_k - ARWU01_CCTSS_K and it must always be passed in 
--          A zero indicates that a developer is testing for a SYSTEM ERROR.  It was done this way so the code didn't have to be changed and recompiled every time messing up others testing.
-- @U06_k - ARWU06_CCTSS_DSGN_K only passed in when processing by design, otherwise it must be set to -1.
--          negative 1 means to process by the @U01_k parameter
-- @U04_k - ARWU04_CCTSS_VRNT_K only passed in when processing by design, otherwise it must be set to -1.
--          negative 1 means to process by the @U01_k parameter
-- @CDSID - The person who is triggering the procedure
-- @TRIGGER: Name that identifies the event that triggers this procedure
-- Output Parameter(s)
-- @Primary_output_error - Will return the error message on an exception. No error returns an empty string ('')
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CALC_MASTER_DELETE_PRIMARY]
 @U01_k                INT         --Study Key must always be passed in.  A zero indicates that a developer is testing for a SYSTEM ERROR
,@U06_k                INT       
,@U04_k                INT       
,@CDSID                varchar(8)
,@TRIGGER              varchar(100) 
,@Primary_delete_error varchar(5000) OUTPUT

AS

SET NOCOUNT ON;
--UDFs User Defined Table Types
Declare @T06_CCTSS_DSGN   [dbo].[PARWT06_CCTSS_DSGN];
Declare @T04_CCTSS_VRNT   [dbo].[PARWT04_CCTSS_VRNT];

BEGIN
 BEGIN TRY

 Declare @TMP INT = @U01_k/@U01_k;  -- A zero indicates that a developer is testing for a SYSTEM ERROR

 Set @Primary_delete_error = ''

 IF @U06_k = -1   --Process by the bob key
    Insert into @T06_CCTSS_DSGN 
    Select ARWU06_CCTSS_DSGN_K 
      From PARWU06_CCTSS_DSGN_FLAT
  	  Where ARWU01_CCTSS_K = @U01_k 
 else             --Process by the design key
    Insert into @T06_CCTSS_DSGN 
    Select ARWU06_CCTSS_DSGN_K 
      From PARWU06_CCTSS_DSGN 
     Where ARWU06_CCTSS_DSGN_K = @U06_k
 ;

 IF @U04_k = -1   --Process VARIANTS by the bob key
    Insert into @T04_CCTSS_VRNT 
    Select ARWU04_CCTSS_VRNT_K 
      From PARWU04_CCTSS_VRNT
  	  Where ARWU01_CCTSS_K = @U01_k 
 else             --Process by the Variant key
    Insert into @T04_CCTSS_VRNT 
    Select ARWU04_CCTSS_VRNT_K 
      From PARWU04_CCTSS_VRNT 
     Where ARWU04_CCTSS_VRNT_K = @U04_k
 ;
  
--  Select * FROM @T06_CCTSS_DSGN;
--  Select * FROM @T04_CCTSS_VRNT;
--  Select @TRIGGER;

  If @TRIGGER IN ('MANUAL', 'PBOM IMPORT', 'GCS IMPORT', 'DAW IMPORT'
                 ,'CLUSTER GROUP CHANGE' , 'MANUAL OVERRIDE QT/DA/II', 'ADJUSTMENT CHANGE DA/II'
				 ,'TRADEOFF CHANGE DA/II', 'COMMODITY SCOPE CHANGE'
				 ,'PROGRAM MARKUP CHANGE', 'PROGRAM EXCHANGE CHANGE', 'SUPPLIER EXCHANGE RATE CHANGE'
				 ,'STUDY DELETE', 'SUPPLIER DELETE', 'SUPPLIER ADD', 'PROGRAM DELETE', 'DESIGN DELETE'
                 )
    BEGIN
      Execute [dbo].[PARWP_CALC_DELETE_D01_BOB_DAII_PART_SUMMARY]    @T06_CCTSS_DSGN;
      Execute [dbo].[PARWP_CALC_DELETE_D02_BOB_DAII_ASM_SUMMARY]     @T06_CCTSS_DSGN;
      Execute [dbo].[PARWP_CALC_DELETE_D06_LWST_IDC_DSGN]            @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D03_VA_PART_SUMMARY]          @T04_CCTSS_VRNT;
      Execute [dbo].[PARWP_CALC_DELETE_D04_VA_ASM_SUMMARY]           @T04_CCTSS_VRNT;
--	  select 1/0;
    END;
 Else If @TRIGGER IN ('VAW IMPORT','MANUAL OVERRIDE VA','ADJUSTMENT CHANGE VA','TRADEOFF CHANGE VA'
                     ,'ADD VARIANT','VARIANT DELETE'
					 )
    BEGIN
      Execute [dbo].[PARWP_CALC_DELETE_D03_VA_PART_SUMMARY]          @T04_CCTSS_VRNT;
      Execute [dbo].[PARWP_CALC_DELETE_D04_VA_ASM_SUMMARY]           @T04_CCTSS_VRNT;
--	  select 1/0;
    END;
 ELSE
    Set @Primary_delete_error = 'The Trigger name does not exist: ' + @TRIGGER
; 

-- Select OBJECT_NAME(@@PROCID)                       as Procedure_Name 
--       ,convert(time, GETUTCDATE() - @TIME_STAMP)   as run_time
-- ;
-- COMMIT will be done by the calling process
 END TRY

 BEGIN CATCH
--   Rollback will be done by the calling process
    Declare @u01_Study Varchar(100);
    Set @u01_Study = (Select U01.ARWU31_CTSP_N            + ' ' +
                             U01.ARWA06_RGN_C             + ' ' +
                      	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                      	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                        from PARWU01_CCTSS_FLAT U01
                       where U01.ARWU01_CCTSS_K = @U01_k
    				 );

    Set @Primary_delete_error = 'Study Key: '      + cast(@U01_k as varchar(20)) + 
	                            ' |Study: '         + ISNULL(@u01_Study, '') +
	                            ' |Trigger: '       + @TRIGGER +
	                            ' |GMT Date/Time: ' + CONVERT(varchar, GETUTCDATE(), 120) +
--	                            ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
	                            ' |CDS: '           + @CDSID +
	                            ' |Procedure: '     + ERROR_PROCEDURE() + 
								' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
								' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

--select @Primary_output_error;
--    INSERT INTO PARWE02_BATCH_ERRORS
--	SELECT  
--	     'SYSTEM'                          --source_c
--		,'CALC ERROR'                      --error_value
--		,@Primary_output_error             --error_x
--        ,@GUID                             --Processing_id
--		,''                                --Filename
--        ,ERROR_PROCEDURE()                 --Procedure_x
--        ,@TIME_STAMP
--		,@CDSID
--		,@TIME_STAMP
--		,@CDSID
--        ,NULL 
--		,NULL
--		--ARWE02_BATCH_ERRORS_K (Identity key)
--		,'ERROR'
--		,OBJECT_NAME(@@PROCID)
--		,0                                 --row_idx
--		,''                                --Part_index
--		,''                                --Arrow value		
--;
  END CATCH;	

END;
GO
