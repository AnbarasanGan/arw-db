DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_U40_PROCESSING_COSTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 06/24/2019
-- Description:	load ARROW U40 processing design costs table 
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/12/2019	asolosky		  Moved the deletes to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure
-- 01/14/2020   Ashaik12          Added Time_Stamp parameter and removed filter on Processing Status
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_U40_PROCESSING_COSTS]
-- Input Parameter
@GUID          Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

-------U40 INSERT

INSERT INTO PARWU40_PROCG_DSGN_ADJ
SELECT 
       --ARWU40_PROCG_DSGN_ADJ_K Identity key
	   V04.ARWU08_CCTSS_DSGN_SUPL_K  as ARWU08_CCTSS_DSGN_SUPL_K
      ,S41.row_idx   as ARWU40_PROCG_COST_DSPLY_SEQ_R
      ,ARWU37_CCTSS_DSGN_ADJ_K                        as ARWU37_CCTSS_DSGN_ADJ_K
      ,IsNULL(S41.operation_index,'')                 as ARWU40_PROCG_OPER_IX_C
      ,IsNULL(S41.operation_desc,'')                  as ARWU40_PROCG_OPER_X

	  ,Case When A28.ARWA28_CNTRY_K is Null then 
		         A28_EmptyStr.ARWA28_CNTRY_K 
			Else A28.ARWA28_CNTRY_K 
	   End as ARWA28_MFG_LOC_CNTRY_K

      ,A29.ARWA29_CRCY_K                              as ARWA29_LCL_CRCY_K
      ,IsNULL(S41.machine_make_model,'')              as ARWU40_MACH_MAKE_MDL_X
      ,IsNULL(S41.capital_exp_for_machine,0)          as ARWU40_CPTL_EXPNDTR_FOR_MACH_A
      ,IsNULL(S41.machine_size,0)                     as ARWU40_MACH_SIZE_IN_MET_TN_Q
	  ,IsNull(S41.no_of_pieces_per_subassy,0)         as ARWU40_PCE_PER_SUB_ASSY_Q
      ,IsNULL(S41.no_of_pieces_per_cycle,0)           as ARWU40_PCS_PER_CYC_Q
      ,IsNULL(S41.cycle_time_sec,0)                   as ARWU40_CYC_TIME_IN_SEC_Q
      ,IsNULL(S41.machinehourly_operation_overhead,0) as ARWU40_MACH_OPER_OVRHD_HRLY_A
      ,IsNULL(S41.direct_headcount,0)                 as ARWU40_DIR_HDCNT_Q
      ,IsNULL(S41.direct_hourly_labor_headcount,0)    as ARWU40_DIR_HRLY_LBR_HDCNT_A
      ,IsNULL(S41.indirect_labor_costs,0)             as ARWU40_INDIR_LBR_PER_DIR_P
      ,IsNULL(S41.fringes,0)                          as ARWU40_FRNG_PER_DIR_LBR_P
      ,IsNULL(S41.packaging_costs,0)                  as ARWU40_PKNG_COST_PER_PCE_A
      ,IsNULL(S41.logistics_cost,0)                   as ARWU40_LGSTCS_COST_PER_PCE_A
      ,IsNULL(S41.tax_duty_per_piece,0)               as ARWU40_TAX_AND_DUTY_PER_PCE_A
      ,IsNULL(S41.licensing_costs,0)                  as ARWU40_LICSNG_COST_PER_PCE_A
      ,IsNULL(S41.comments,'')                        as ARWU40_PROCG_ASSMP_CMT_X
      ,@TIME_STAMP                                   as ARWU40_CREATE_S
      ,@CDSID                                         as ARWU40_CREATE_USER_C                              
      ,@TIME_STAMP                                   as ARWU40_LAST_UPDT_S
      ,@CDSID                                         as ARWU40_LAST_UPDT_USER_C                              
   From PARWS34_DAII_COVER_PAGE_INFO       S34 
  JOIN PARWS41_DAII_PROCESSING_PARTS_INFO  S41
    ON S41.Processing_ID       = S34.Processing_ID
   AND S41.filename            = S34.filename
   
 -- Join with Supplier Qoute View
   JOIN dbo.PARWV04_DSGN_SUPL V04
    ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

--Design Adjustment Part
      Join PARWU37_CCTSS_DSGN_ADJ   U37
        ON U37.ARWU06_CCTSS_DSGN_K  = V04.ARWU06_CCTSS_DSGN_K
       And U37.ARWU37_CCTSS_DSGN_ADJ_ID_N = S41.change_improvement_id
--Currency   
      JOIN dbo.PARWA29_CRCY  A29          ON A29.ARWA29_CRCY_C = s41.local_currency
--Manufacturing Location
 Left JOIN dbo.PARWA28_CNTRY A28          ON A28.ARWA28_CNTRY_N               = s41.manufacturing_location
      JOIN dbo.PARWA28_CNTRY A28_EmptyStr ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

Where S34.Processing_ID             = @GUID
  AND S41.cost_type = 'Adjustment Costs'
  AND S34.Skip_loading_due_to_error_f = 0
;

GO
