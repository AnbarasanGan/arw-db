SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 06/28/2022
-- Description:	This SP calls the Tygra UB1 table load script, the stage table load script and the validtion scripts.  These 3 scripts only need to be executed once by the UI as they are
--              at the file level not the study level.  
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   07-12-2022  US3820641 remove XACT_ABORT.  It is rolliong back catch errors.
-- rwesley2   07-26-2022  US3870129 - checks that engineering commodity picked in the UI is found on the Tygra file that the user wants to load
-- rwesley2   08-12-2022  US3283898 DE262236 - Sync QA and EDU code base
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_UI_TYGRA_VALIDATIONS] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@CDSID varchar(MAX)       
,@processing_id varchar(MAX)
,@Program_name varchar(max)
,@TYGRA_FILE_TYPE_N varchar(max)
,@wrkshp_name varchar(max)
,@wrkshp_status varchar(max)
,@Tygra_file_version INT
,@Tygra_ID_k INt
,@Tygra_file_name varchar(max)
,@Tygra_file_last_updt_s varchar(max)    
,@file_source varchar(max) 
,@load_to_pgm_name varchar(max)
,@TIME_STAMP    DATETIME       
,@result varchar(max) Output



AS
BEGIN
-- SET @result = 0;
 set @result  = 'No Errors';

SET NOCOUNT ON;

 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));


--DECLARE @TIME_STAMP    DATETIME    = GETUTCDATE();
DECLARE @tygra_file_type int = (select ARWA54_TYGRA_FILE_TYPE_K from PARWA54_TYGRA_FILE_TYPE   where ARWA54_TYGRA_FILE_TYPE_N =@TYGRA_FILE_TYPE_N );

DECLARE @TYGRA_ERROR_TYPE varchar(MAX);


--BEGIN TRY

 
-- only load stage tables when @file_source = ACT, otherwise skip.
If @file_source = 'ACT'
Begin
EXEC [dbo].[PARWP_TYGRA_UI_LOAD_STAGE_TBLS_UI] @processing_id,@Tygra_id_k,@File_source,@program_name,@cdsid,@TIME_STAMP  
End;


 -- load mapping tables
 EXEC [dbo].[PARWP_TYGRA_LOAD_ENRG_CMMDTY_MAPPING_UI]           @CDSID, @TIME_STAMP,@processing_id; 

-- Engineering commodity validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_ENG_COMM_UI]               @processing_id ,@CDSID ,@file_source ,@load_to_pgm_name ,@Tygra_file_name ,@TIME_STAMP 


--Title Page validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_TITLE_PAGE_UI]              @processing_id,  @CDSID, @TIME_STAMP; 

--Parts(detail) validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_PARTS_UI]                   @processing_id,@CDSID, @TIME_STAMP; 

-- Missing program validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_MISSING_PROGRAM_UI]         @processing_id,@CDSID, @TIME_STAMP; 

-- Missing CCM
 EXEC [dbo].[PARWP_TYGRA_VALIDT_MISSING_CCM_UI]            @processing_id, @CDSID, @TIME_STAMP,@Program_name,@Tygra_file_name,@file_source,@load_to_pgm_name; 

-- check for special character in parts columns
 EXEC [dbo].[PARWP_TYGRA_VALIDT_PARTS_SPCL_CHARS_UI]        @processing_id, @CDSID, @TIME_STAMP; 


 -- only continue to PARWP_TYGRA_UI_TYGRA_LOAD if there are errors.  UI will prevent the load SP from executing.
 EXEC [dbo].[PARWP_TYGRA_GO_NO_GO]                        @processing_id,  @CDSID, @TIME_STAMP, @TYGRA_ERROR_TYPE OUTPUT   


-- If system error or validation error, don't load UB tables
 IF @TYGRA_ERROR_TYPE = 'SYSTEM Error'  -- If system errors don't load tables
 Begin
    Set @result        =  'SYSTEM Error'   --The UI needs this set to 0 for an unexpected (system) error.
    GOTO EOJ    
 End

 IF @TYGRA_ERROR_TYPE = 'Validation Error'  -- If validation ERRORS don't load tables
 Begin
    Set @result        =    'Validation Error'   ---The UI needs this set to 1 to display validation ERRORs .
    GOTO EOJ    
  End


  EXEC [dbo].[PARWP_TYGRA_UI_LOAD_UB1_UI] @processing_id,@file_source,@program_name,@tygra_file_name,@tygra_file_version
                                       ,@TYGRA_FILE_TYPE_N,@cdsid,@wrkshp_name,@wrkshp_status,@Tygra_file_last_updt_s
									   ,@TIME_STAMP   ; 


EOJ:  

END;


GO


