DROP PROCEDURE IF EXISTS [dbo].[PARWP_UI_BOB_FORD_PART_MAPPING_SAVE]
GO

/****** Object:  StoredProcedure [dbo].[PARWP_UI_BOB_FORD_PART_MAPPING_SAVE]    Script Date: 8/16/2021 11:05:47 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ============================================================================================
-- Author:		ASHAIK12
-- Create date: 06/30/2021
-- Description:	This SP either deletes the Tygra associated tables or updates based on the action performed in Ford Part mapping screen.
-- Output: None
--
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   08/18/2021  DE229406: Add Variant key to join b/w U04 and UA9
-- ============================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_BOB_FORD_PART_MAPPING_SAVE] 

 @ARWU01_CCTSS_K        INT  -- BoB key
,@ARWU04_CCTSS_VRNT_K   INT  -- Variant key
,@U18_K                 INT  -- U18 Key
,@SCOPE_OR_CURRENT	    VARCHAR(30) -- Scope or Current 
,@U63_K                 INT -- U63 key of record being modified (if new record then pass -1)
,@A47                   INT -- A47 Key for Scope selection (-1 if being removed)
,@CDSID                 VARCHAR(MAX) 
,@RESULT                INT OUTPUT

AS

SET NOCOUNT ON;
BEGIN TRY

DECLARE @TIME_STAMP DATETIME = GETUTCDATE();

-- Insert into U63 if the mapping is being done for the first time.

if (@U63_K= -1)
Begin 
						INSERT INTO PARWU63_VRNT_BOM_PART_END_ITM
						SELECT
						 @ARWU04_CCTSS_VRNT_K AS [ARWU04_CCTSS_VRNT_K]
						,@U18_K              AS [ARWU18_BOM_PART_K]
						,(Select [ARWA57_END_ITM_MAP_TYPE_K] FROM PARWA57_END_ITM_MAP_TYPE where ARWA57_END_ITM_MAP_TYPE_X=@SCOPE_OR_CURRENT) AS [ARWA57_END_ITM_MAP_TYPE_K]
						,@A47              AS [ARWA47_FORD_END_ITM_K]
						,@TIME_STAMP         AS [ARWU63_CREATE_S]
						,@CDSID              AS [ARWU63_CREATE_USER_C]          
						,@TIME_STAMP         AS [ARWU63_LAST_UPDT_S]
						,@CDSID              AS [ARWU63_LAST_UPDT_USER_C]
end

-- Updating an already existing ford part mapping 
If (@U63_K != -1 AND @A47 != -1 AND @SCOPE_OR_CURRENT='Scope') -- If Scope then just update U63
BEGIN				
				UPDATE PARWU63_VRNT_BOM_PART_END_ITM SET [ARWA47_FORD_END_ITM_K]=@A47,[ARWU63_LAST_UPDT_S]=@TIME_STAMP,[ARWU63_LAST_UPDT_USER_C]=@CDSID
				WHERE [ARWU63_VRNT_BOM_PART_END_ITM_K] = @U63_K			
END

ELSE IF (@U63_K != -1 AND @A47 != -1 AND @SCOPE_OR_CURRENT='Current') -- if Current then delete from UB0 and UA9 and update U63
BEGIN


-- UB0
						MERGE [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0_T
						using
						(
						Select [ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						From [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0
						JOIN [dbo].[PARWUA9_VRNT_END_ITM] UA9
						ON UA9.[ARWUA9_VRNT_END_ITM_K] = UB0.[ARWUA9_VRNT_END_ITM_K]
						JOIN [dbo].[PARWU63_VRNT_BOM_PART_END_ITM] U63
						ON U63.[ARWA47_FORD_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND U63.[ARWU63_VRNT_BOM_PART_END_ITM_K]=@U63_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K] = U04.[ARWU04_CCTSS_VRNT_K]
						AND U04.[ARWU04_CCTSS_VRNT_K]= @ARWU04_CCTSS_VRNT_K
						) SRC
						ON SRC.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K] = UB0_T.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						WHEN MATCHED THEN DELETE
						;
-- UA9
						MERGE [dbo].[PARWUA9_VRNT_END_ITM] UA9_T
						using
						(
						Select [ARWUA9_VRNT_END_ITM_K]
						From [dbo].[PARWUA9_VRNT_END_ITM] UA9
						JOIN [dbo].[PARWU63_VRNT_BOM_PART_END_ITM] U63
						ON U63.[ARWA47_FORD_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND U63.[ARWU63_VRNT_BOM_PART_END_ITM_K]=@U63_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K] = U04.[ARWU04_CCTSS_VRNT_K]
						AND U04.[ARWU04_CCTSS_VRNT_K]= @ARWU04_CCTSS_VRNT_K
						) SRC
						ON SRC.[ARWUA9_VRNT_END_ITM_K] = UA9_T.[ARWUA9_VRNT_END_ITM_K]
						WHEN MATCHED THEN DELETE
						;

			UPDATE PARWU63_VRNT_BOM_PART_END_ITM SET [ARWA47_FORD_END_ITM_K]=@A47,[ARWU63_LAST_UPDT_S]=@TIME_STAMP,[ARWU63_LAST_UPDT_USER_C]=@CDSID
			WHERE [ARWU63_VRNT_BOM_PART_END_ITM_K] = @U63_K

END

-- If the existing Scope or Current EI is removed for a part index. Then remove from U63 for Scope and remove from U63,UB0,UA9 for Current
if (@U63_K != -1 AND @A47 = -1 AND @SCOPE_OR_CURRENT='Scope')
	BEGIN
		DELETE FROM PARWU63_VRNT_BOM_PART_END_ITM WHERE [ARWU63_VRNT_BOM_PART_END_ITM_K] = @U63_K
	END

ELSE IF (@U63_K != -1 AND @A47 = -1 AND @SCOPE_OR_CURRENT='Current')
	BEGIN

-- UB0
						MERGE [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0_T
						using
						(
						Select [ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						From [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0
						JOIN [dbo].[PARWUA9_VRNT_END_ITM] UA9
						ON UA9.[ARWUA9_VRNT_END_ITM_K] = UB0.[ARWUA9_VRNT_END_ITM_K]
						JOIN [dbo].[PARWU63_VRNT_BOM_PART_END_ITM] U63
						ON U63.[ARWA47_FORD_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND U63.[ARWU63_VRNT_BOM_PART_END_ITM_K]=@U63_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K] = U04.[ARWU04_CCTSS_VRNT_K]
						AND U04.[ARWU04_CCTSS_VRNT_K]= @ARWU04_CCTSS_VRNT_K
						) SRC
						ON SRC.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K] = UB0_T.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						WHEN MATCHED THEN DELETE
						;
-- UA9
						MERGE [dbo].[PARWUA9_VRNT_END_ITM] UA9_T
						using
						(
						Select [ARWUA9_VRNT_END_ITM_K]
						From [dbo].[PARWUA9_VRNT_END_ITM] UA9
						JOIN [dbo].[PARWU63_VRNT_BOM_PART_END_ITM] U63
						ON U63.[ARWA47_FORD_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND U63.[ARWU63_VRNT_BOM_PART_END_ITM_K]=@U63_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K] = U04.[ARWU04_CCTSS_VRNT_K]
						AND U04.[ARWU04_CCTSS_VRNT_K]= @ARWU04_CCTSS_VRNT_K
						) SRC
						ON SRC.[ARWUA9_VRNT_END_ITM_K] = UA9_T.[ARWUA9_VRNT_END_ITM_K]
						WHEN MATCHED THEN DELETE
						;
-- Delete from U63
			DELETE PARWU63_VRNT_BOM_PART_END_ITM WHERE [ARWU63_VRNT_BOM_PART_END_ITM_K] = @U63_K

	END


SET @RESULT = 1

END TRY

BEGIN CATCH
SET @RESULT = 0
END CATCH

RETURN @RESULT
GO


