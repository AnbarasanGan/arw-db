DROP PROCEDURE [dbo].[PARWP_CCT_LOAD_PURCHPART]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 05/24/2019
-- Description:	After the CCS data is loaded to arrow, this procedure will write to the PARWU55_SUPL_DSGN_PART table.
--              It uses 3 views that are based on the CCS data: PARWV17_CCT_PART_SUPPLIER_PURCHPART,
--              PARWV18_CCT_PART_SUPPLIER_RAW, PARWV19_CCT_PART_SUPPLIER_PROCESS
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 05/28       ashaik12  F151269   Added Delete part, Purch_Total_Cost, ARWU01_CCTSS_K in all sub selects and group by
-- 08/13/2019  ASHAIK12            Removed Delete Statements
-- 08/23/2109  Asolosky  US1154544 Changed the Union to Union All.  Made the join to the markup table a left join and put IsNull on compounded_total
-- 01/10/2020  Ashaik12            Added TimeStamp parameter
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCT_LOAD_PURCHPART] 
-- Input Parameter
@CCTSS_K Int,
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;




----------------------------------------------------------------------------------------------------- 
INSERT INTO PARWU55_SUPL_DSGN_PART
Select CCT_PART_SUPPLIER_Sum.ARWU08_CCTSS_DSGN_SUPL_K
      ,CCT_PART_SUPPLIER_Sum.ARWU19_DSGN_PART_K
	  ,Pur_Qty
	  ,Purch_Cost
	  ,Pur_Tier2_MarkUp
	  ,Purch_Total_Cost        --Need to create PURCH_Tot_Cost in the view -- done by ashaik12
	  ,Raw_Qty
      ,Raw_Cost
	  ,Pro_Qty
	  ,Pro_Direct_Labor
	  ,Pro_Direct_Fringe
	  ,Pro_InDirect_Labor
	  ,Pro_InDirect_Fringe
	  ,Pro_Overhead   
	  ,Pro_Misc
	  ,Pro_Total_Cost
	  ,Purch_Total_Cost + ((Raw_Cost + Pro_Total_Cost) * (1+IsNull(COMPOUNDED_TOTAL,0))) AS Total_Wih_Markups
	  ,@TIME_STAMP                                                            AS ARWU27_CREATE_S
	  ,@CDSID                                                                  AS ARWU27_CREATE_USER_C
	  ,@TIME_STAMP                                                            AS ARWU27_LAST_UPDT_S
	  ,@CDSID                                                                  AS ARWU27_LAST_UPDT_USER_C
  From
(
Select CCT_PART_SUPPLIER.ARWU01_CCTSS_K
      ,CCT_PART_SUPPLIER.ARWU17_BOM_SUB_ASSY_N
      ,CCT_PART_SUPPLIER.ARWU17_BOM_SUB_ASSY_K
      ,CCT_PART_SUPPLIER.ARWU08_CCTSS_DSGN_SUPL_K
      ,CCT_PART_SUPPLIER.ARWU19_DSGN_PART_K
	  ,Sum(Pur_Qty)  as Pur_Qty
	  ,Sum(Purch_Cost) as Purch_Cost
	  ,Sum(Pur_Tier2_MarkUp) as Pur_Tier2_MarkUp
	  ,Sum([Purch_Total_Cost]) as Purch_Total_Cost
	  ,Sum(Raw_Qty) as Raw_Qty
      ,Sum(Raw_Cost) as Raw_Cost
	  ,Sum(Pro_Qty) as Pro_Qty
	  ,Sum(Pro_Direct_Labor) as Pro_Direct_Labor
	  ,Sum(Pro_Direct_Fringe) as Pro_Direct_Fringe
	  ,Sum(Pro_InDirect_Labor) as Pro_InDirect_Labor
	  ,Sum(Pro_InDirect_Fringe) as Pro_InDirect_Fringe
	  ,Sum(Pro_Overhead) as	Pro_Overhead   
	  ,Sum(Pro_Misc) as Pro_Misc
	  ,Sum(Pro_Total_Cost) as Pro_Total_Cost
  From
(
Select ARWU01_CCTSS_K
      ,ARWU17_BOM_SUB_ASSY_N
      ,ARWU17_BOM_SUB_ASSY_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
      ,ARWU19_DSGN_PART_K
	  ,Pur_Qty  --D9
	  ,Purch_Cost         --D20 
	  ,Pur_Tier2_MarkUp   --D22
	  ,Purch_Total_Cost   --D23
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost

	  ,0                               AS Pro_Qty 
	  ,0                               AS Pro_Direct_Labor   
	  ,0                               AS Pro_Direct_Fringe  
	  ,0                               AS Pro_InDirect_Labor
	  ,0                               AS Pro_InDirect_Fringe
	  ,0                               AS Pro_Overhead  
	  ,0                               AS Pro_Misc
	  ,0                               AS Pro_Total_Cost
	  ,0                               AS Total_with_Markup 
  From PARWV17_CCT_PART_SUPPLIER_PURCHPART
 Where ARWU01_CCTSS_K = @CCTSS_K
Union ALL
Select ARWU01_CCTSS_K
      ,ARWU17_BOM_SUB_ASSY_N
      ,ARWU17_BOM_SUB_ASSY_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
      ,ARWU19_DSGN_PART_K
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0
      ,Raw_Qty  --D9
      ,Raw_Cost --D13

	  ,0                               AS Pro_Qty 
	  ,0                               AS Pro_Direct_Labor   
	  ,0                               AS Pro_Direct_Fringe  
	  ,0                               AS Pro_InDirect_Labor
	  ,0                               AS Pro_InDirect_Fringe
	  ,0                               AS Pro_Overhead  
	  ,0                               AS Pro_Misc
	  ,0                               AS Pro_Total_Cost
	  ,0                               AS Total_with_Markup 

  From PARWV18_CCT_PART_SUPPLIER_RAW
 Where ARWU01_CCTSS_K = @CCTSS_K
Union ALL
Select ARWU01_CCTSS_K
      ,ARWU17_BOM_SUB_ASSY_N
      ,ARWU17_BOM_SUB_ASSY_K
      ,ARWU08_CCTSS_DSGN_SUPL_K
      ,ARWU19_DSGN_PART_K
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost

	  ,Pro_Qty             --D8
	  ,Pro_Direct_Labor    --D24
	  ,Pro_Direct_Fringe   --D25
	  ,Pro_InDirect_Labor  --D26
	  ,Pro_InDirect_Fringe --D27
	  ,Pro_Overhead        --D28	   
	  ,Pro_Misc            --D29
	  ,Pro_Total_Cost      --D30
	  ,0 AS Total_with_Markup --,sum(Total_with_Markup)       AS Total_with_Markup --D31From PARWV19_CCT_PART_SUPPLIER_PROCESS
  From PARWV19_CCT_PART_SUPPLIER_PROCESS
 Where ARWU01_CCTSS_K = @CCTSS_K
) CCT_PART_SUPPLIER

Group by 
 CCT_PART_SUPPLIER.ARWU08_CCTSS_DSGN_SUPL_K
,CCT_PART_SUPPLIER.ARWU17_BOM_SUB_ASSY_K
,CCT_PART_SUPPLIER.ARWU17_BOM_SUB_ASSY_N
,CCT_PART_SUPPLIER.ARWU19_DSGN_PART_K
,CCT_PART_SUPPLIER.ARWU01_CCTSS_K
) CCT_PART_SUPPLIER_Sum
Left JOIN [dbo].[PARWV20_MFG_MRKP] V20
       ON V20.ARWU08_CCTSS_DSGN_SUPL_K = CCT_PART_SUPPLIER_Sum.ARWU08_CCTSS_DSGN_SUPL_K
      AND V20.ARWU17_BOM_SUB_ASSY_K    = CCT_PART_SUPPLIER_Sum.ARWU17_BOM_SUB_ASSY_K
where CCT_PART_SUPPLIER_sum.ARWU01_CCTSS_K=@CCTSS_K
;

GO
