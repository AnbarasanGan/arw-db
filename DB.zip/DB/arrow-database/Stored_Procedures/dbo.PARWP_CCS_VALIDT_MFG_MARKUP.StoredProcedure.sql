DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_MFG_MARKUP]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 4/02/2019
-- Description:	Manufacturing Markup data Validation
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   07/22/2019  Changed 2nd validation message to use a case statement
-- rwesley2   08/07/2019  changed all ERROR to WARNING per Glenn
-- Asolosky   08/08/2019  Changed back to ERROR from WARNING.  Removed this filter: manufacturing_markup_desc <> 'SG&A - Total' on Markup Type validation (1st validation)
--                        Replaced the manufacturing markup validation with a new query (2nd validation).  Had to bring all the data into 1 row
--                        in order to do the validation logic. Markup is only needed when raw, processing, assembly data is available (one of the 3)
--                        Only 1 validation message will be shown at a time because the data had to be brought into 1 record.
-- Asolosky   09/10/2019  Added row_idx
-- Ashaik12   12/25/2019  Remove Case when statements in Error Descriptions.
-- Ashaik12   01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_MFG_MARKUP] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Type Description validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.manufacturing_markup_desc         as ARWE02_ERROR_VALUE
	  ,'Manufacturing Markups: Manufacturing Markup Type is Invalid.' AS ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS18_CCS_MFG_MARKUP_K]         as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
   	  ,''  --No Part Index
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
               [manufacturing_markup_desc],
		       Processing_Status_x,
			   sub_assembly_name,
		       Source_c,
		       filename,
               [ARWS18_CCS_MFG_MARKUP_K],
			   row_idx
         FROM [dbo].[PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO] S18
        WHERE Processing_ID= @GUID
		  --and manufacturing_markup_desc <> 'SG&A - Total' --Remove this line. Not sure why it was there
	      and Not Exists
		      (Select 'X'
               from  [dbo].[PARWA38_MFG_MRKP_TYP] A38
               where A38.[ARWA38_MFG_MRKP_TYP_X] = S18.manufacturing_markup_desc 
			  )              
        ) ERR
;
--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Value data check for Scrap, SG&A and Profit
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select 
       Source_c                as ARWE02_SOURCE_C
      ,Error_Value_R           as ARWE02_ERROR_VALUE
      ,Error_Message_x         as ARWE02_ERROR_X
  	  ,Processing_ID           as ARWE02_PROCESSING_ID
	  ,filename                as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)   as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP             as ARWE02_CREATE_S
	  ,@CDSID                  as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP             as ARWE02_LAST_UPDT_S
	  ,@CDSID                  as ARWE02_LAST_UPDT_USER_C
	  ,ARWS18_CCS_MFG_MARKUP_K as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  --ARWE02_BATCH_ERRORS_K Identity number
	  ,Error_Type_x            as ARWE02_ERROR_TYPE_X
	  ,sub_assembly_name       as ARWE02_EXCEL_TAB_X
      ,0                       as ARWE02_ROW_IDX
   	  ,''  --No Part Index
	  ,''  --No ARROW Value
From
(
Select * 
      ,Case When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Profit_manufacturing_markup_value = 0
	        Then 'Manufacturing Markup: Supplier Quote for Profit cannot be zero' 
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Scrap_manufacturing_markup_value = 0
			Then 'Manufacturing Markup: Supplier Quote for Scrap is zero' 
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and SGA_total_manufacturing_markup_value = 0
			Then 'Manufacturing Markup: Supplier Quote for SG&A-Total is zero' 
	   End as Error_Message_x
      ,Case When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Profit_manufacturing_markup_value = 0
	        Then 'WARNING' 
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Scrap_manufacturing_markup_value = 0 
			Then 'WARNING' 
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and SGA_total_manufacturing_markup_value = 0
			Then 'WARNING' 
	   End as Error_Type_x
      ,Case When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Profit_manufacturing_markup_value = 0
	        Then Profit_manufacturing_markup_value
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Scrap_manufacturing_markup_value = 0
			Then Scrap_manufacturing_markup_value 
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and SGA_total_manufacturing_markup_value = 0
			Then SGA_total_manufacturing_markup_value
	   End as Error_Value_R
      ,Case When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Profit_manufacturing_markup_value = 0
	        Then Profit_ARWS18_CCS_MFG_MARKUP_K 
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and Scrap_manufacturing_markup_value = 0
			Then Scrap_ARWS18_CCS_MFG_MARKUP_K
			When (Raw_F = 1 or Process_F = 1 or Assembly_F = 1) and SGA_total_manufacturing_markup_value = 0
			Then Total_ARWS18_CCS_MFG_MARKUP_K
	   End as ARWS18_CCS_MFG_MARKUP_K
  From
(
Select 
	  Processing_ID  
	  ,filename
	  ,sub_assembly_name
	  ,Source_c
	  ,Sum(Purch_F)    OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Purch_F
	  ,Sum(Raw_F)      OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Raw_F
	  ,Sum(Process_F)  OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Process_F
	  ,Sum(Assembly_F) OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Assembly_F
	  ,Sum(Scrap_manufacturing_markup_value)     OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Scrap_manufacturing_markup_value
      ,Sum(SGA_total_manufacturing_markup_value) OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as SGA_total_manufacturing_markup_value
      ,Sum(profit_manufacturing_markup_value)    OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Profit_manufacturing_markup_value	
      ,SUM(Scrap_ARWS18_CCS_MFG_MARKUP_K)        OVER (PARTITION BY Processing_ID, sub_assembly_name,filename) as Scrap_ARWS18_CCS_MFG_MARKUP_K
	  ,SUM(Total_ARWS18_CCS_MFG_MARKUP_K)        OVER (PARTITION BY Processing_ID, sub_assembly_name,filename) as Total_ARWS18_CCS_MFG_MARKUP_K
	  ,SUM(Profit_ARWS18_CCS_MFG_MARKUP_K)       OVER (PARTITION BY Processing_ID, sub_assembly_name,filename) as Profit_ARWS18_CCS_MFG_MARKUP_K
      ,ROW_NUMBER()    OVER (PARTITION BY Processing_ID, filename,sub_assembly_name
	                          ORDER BY filename) as row_num
  From
(--Purchased Parts
      SELECT distinct 
	         Case When S14.Processing_ID is NULL then 0 else 1 end as Purch_F
			,0 as Raw_F
			,0 as Process_F
			,0 as Assembly_F
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as profit_manufacturing_markup_value	
	        ,0 as Scrap_ARWS18_CCS_MFG_MARKUP_K	
	        ,0 as Total_ARWS18_CCS_MFG_MARKUP_K
	        ,0 as Profit_ARWS18_CCS_MFG_MARKUP_K	
			,S14.sub_assembly_name  
			,S14.Processing_ID  
			,S14.filename
			,S14.Source_c
        FROM PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14 
        WHERE S14.Processing_ID       = @GUID
--Raw
Union
      SELECT distinct 
	         0 as Purch_F
			,Case When S15.Processing_ID is NULL then 0 else 1 end as Raw_F
			,0 as Process_F
			,0 as Assembly_F 
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as profit_manufacturing_markup_value
	        ,0 as Scrap_ARWS18_CCS_MFG_MARKUP_K	
	        ,0 as Total_ARWS18_CCS_MFG_MARKUP_K
	        ,0 as Profit_ARWS18_CCS_MFG_MARKUP_K					
			,S15.sub_assembly_name
			,S15.Processing_ID  
			,S15.filename
			,S15.Source_c
        FROM PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO S15 
        WHERE S15.Processing_ID       = @GUID
--Processing
Union
      SELECT distinct 
	         0 as Purch_F
			,0 as Raw_F
	        ,Case When S16.Processing_ID is Null then 0 else 1 end as Process_F
			,0 as Assembly_F
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as profit_manufacturing_markup_value	
	        ,0 as Scrap_ARWS18_CCS_MFG_MARKUP_K	
	        ,0 as Total_ARWS18_CCS_MFG_MARKUP_K
	        ,0 as Profit_ARWS18_CCS_MFG_MARKUP_K	
			,S16.sub_assembly_name
			,S16.Processing_ID  
			,S16.filename
			,S16.Source_c
        FROM PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO S16 
        WHERE S16.Processing_ID       = @GUID
--Assembly
Union
      SELECT distinct
	         0 as Purch_F
			,0 as Raw_F	   
			,0 as Process_F
	        ,Case When S17.Processing_ID is Null then 0 else 1 end as Assembly_F  
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as Profit_manufacturing_markup_value		
	        ,0 as Scrap_ARWS18_CCS_MFG_MARKUP_K	
	        ,0 as Total_ARWS18_CCS_MFG_MARKUP_K
	        ,0 as Profit_ARWS18_CCS_MFG_MARKUP_K				 
			,S17.sub_assembly_name 
			,S17.Processing_ID  
			,S17.filename
			,S17.Source_c
        FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17 
        WHERE S17.Processing_ID       = @GUID
Union 

-- Markups
Select Purch_F
      ,Raw_F	   
      ,Process_F
      ,Assembly_F  
      ,Scrap_manufacturing_markup_value
      ,SGA_total_manufacturing_markup_value
      ,Profit_manufacturing_markup_value	
	  ,Scrap_ARWS18_CCS_MFG_MARKUP_K	
	  ,Total_ARWS18_CCS_MFG_MARKUP_K
	  ,Profit_ARWS18_CCS_MFG_MARKUP_K
      ,sub_assembly_name 
      ,Processing_ID  
      ,filename
	  ,Source_c
  From
(
 Select 0 as Purch_F
       ,0 as Raw_F	   
	   ,0 as Process_F
	   ,0 as Assembly_F  
	   ,Sum(Scrap)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Scrap_manufacturing_markup_value
       ,Sum(Total)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as SGA_total_manufacturing_markup_value
       ,Sum(Profit)  OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as profit_manufacturing_markup_value

       ,SUM(Scrap_ARWS18_CCS_MFG_MARKUP_K)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Scrap_ARWS18_CCS_MFG_MARKUP_K
	   ,SUM(Total_ARWS18_CCS_MFG_MARKUP_K)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Total_ARWS18_CCS_MFG_MARKUP_K
	   ,SUM(Profit_ARWS18_CCS_MFG_MARKUP_K)  OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Profit_ARWS18_CCS_MFG_MARKUP_K

       ,ROW_NUMBER() OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name
	                           ORDER BY supplier_name) as row_num
	   ,sub_assembly_name
	   ,Processing_ID 
	   ,filename
	   ,Source_c
   from
 (
       SELECT 
             Processing_ID,
		     sub_assembly_name,
		     supplier_name,
		     manufacturing_markup_desc,
             manufacturing_markup_value,
		     case When [manufacturing_markup_desc] = 'SG&A - Total' then isNull([manufacturing_markup_value],0) else 0 end as Total,
		     case When [manufacturing_markup_desc] = 'Scrap' then isNull([manufacturing_markup_value],0) else 0 end as Scrap,
		     case When [manufacturing_markup_desc] = 'Profit' then isNull([manufacturing_markup_value],0) else 0 end as Profit,
		     Processing_Status_x,
		     Source_c,
		     filename,
		     case When [manufacturing_markup_desc] = 'SG&A - Total' then ARWS18_CCS_MFG_MARKUP_K end as Total_ARWS18_CCS_MFG_MARKUP_K,
		     case When [manufacturing_markup_desc] = 'Scrap'        then ARWS18_CCS_MFG_MARKUP_K end as Scrap_ARWS18_CCS_MFG_MARKUP_K,
		     case When [manufacturing_markup_desc] = 'Profit'       then ARWS18_CCS_MFG_MARKUP_K end as Profit_ARWS18_CCS_MFG_MARKUP_K,
             ARWS18_CCS_MFG_MARKUP_K
        FROM PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO S18
       WHERE S18.Processing_ID= @GUID and
		     S18.manufacturing_markup_desc in ('SG&A - Total','Scrap','Profit')
 ) mrkup
) Final_mrkup
where row_num = 1

) All_Unions
 Where sub_assembly_name is not NULL
) Sum_to_Combine_data
Where row_num = 1
) Case_Determine_ERROR
Where Error_Type_x in ('ERROR','WARNING')
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO'
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''  --Part_index
		,''  --Arrow value	
;
END CATCH;



GO
