DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUMMARY_CST_PURCHASED_PART_PRE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/17/2019
-- Description:	Validate if sum of Purchased Parts unit cost in usd is equal to the cost in Summary table. 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   01/10/2020  Added TimeStamp parameter
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky   12/14/2020  US2137799 Changed SUM(S14.unit_cost_usd) as summed_cost to a formula that matched Excel. This was done in case the users over-wrote the Excel Formula.
-- Asolosky   01/19/2021  US2164194 Changed the threshold from a dynamic number which used the UpperBound and LowerBound function, to a static number.
--                        The static threshold number is passed in from the master procedure and is based on the PARWT01_THRESHOLD table.
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUMMARY_CST_PURCHASED_PART_PRE] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
    -- Sub-Assembly Name validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
 X.Source_c
,CAST(S21_cost as Varchar(50))
,Case When sub_assembly_name = 'Directed Parts'
      Then 'Purchased Parts total in Supplier Quote Summary does not match calculated Purchased Parts total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Directed Parts sheet'
	  Else 'Purchased Parts total in Supplier Quote Summary does not match calculated Purchased Parts total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Costs sheet'
 end
,X.Processing_ID
,X.filename
,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
,@TIME_STAMP  as [ARWE02_CREATE_S]
,@CDSID       as [ARWE02_CREATE_USER_C]
,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
,@CDSID       as [ARWE02_LAST_UPDT_USER_C]
,X.ARWS21_CCS_SUMMARY_K
,'PARWS21_CCS_SUMMARY_TAB_INFO'
,'ERROR'
,sub_assembly_name
,0                               as ARWE02_ROW_IDX
,''       --Part_index
,CAST(summed_cost as varchar(50))       --Arrow value
FROM 
(
select 
       S21.[Source_c] 
      ,S14.sub_assembly_name
	  ,SUM(S14.unit_cost_usd) as S14_unit_cost_usd_sum
	  ,CASE WHEN SUM(S14.unit_cost_usd)=round(S21.cost,4) 
	        then '' 
			else 'Purchased Parts Subtotal '+ CAST(SUM(S14.unit_cost_usd) as varchar(50))+' Not equal to Purchased Parts Cost '+ CAST(S21.cost as Varchar(50)) + ' in Summary Tab for '+S14.sub_assembly_name 
	   end as old_error_msg
	  ,S22.[Processing_ID] 
	  ,S22.[filename] 
	  ,S21.[ARWS21_CCS_SUMMARY_K] 
--	  ,SUM(S14.unit_cost_usd)  as summed_cost
      ,Sum(
	       CASE WHEN S14.sub_assembly_name !='Directed Parts' and S14.pia_directed_bailed  ='B'  
                THEN IsNull ((S14.no_of_pieces)*(S14.purchased_price_per_piece + S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty) *(S14.purchased_parts_markup_cost) ,0) * IsNull(S14.exchange_rate,0)
	            WHEN S14.sub_assembly_name !='Directed Parts' and S14.pia_directed_bailed !='B' 
	            THEN IsNull ((S14.no_of_pieces)*(S14.purchased_price_per_piece + S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty) *(1 + S14.purchased_parts_markup_cost),0) * IsNull(S14.exchange_rate,0)
                WHEN S14.sub_assembly_name  ='Directed Parts' and S14.pia_directed_bailed  ='B'
		    	THEN 0 
                ELSE isNULL((S14.no_of_pieces *(S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty)
		    	             +(S14.purchased_parts_markup_cost*(S14.purchased_price_per_piece + S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty) * S14.no_of_pieces)
		    			    ) ,0)  * IsNull(S14.exchange_rate,0)

	       END 
	      )     as summed_cost
	  ,S21.cost as s21_cost
from [dbo].[PARWS21_CCS_SUMMARY_TAB_INFO] S21
JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] S22
ON S21.Processing_ID=S22.Processing_ID
AND S21.filename=S22.filename
JOIN [dbo].PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14
ON S22.Processing_ID = S14.Processing_ID
and S22.filename = S14.filename
and S14.sub_assembly_name = S21.part_cluster_type
where S21.cost_item like '%Purchased parts'
and S22.Processing_ID=@GUID
group by S21.cost,S21.[Source_c],S14.sub_assembly_name,S22.[Processing_ID],S22.[filename],S21.[ARWS21_CCS_SUMMARY_K]--,S14.pia_directed_bailed
) X

where --[ARWE02_ERROR_X]!=''
--and
   (
      ABS(summed_cost) <  ABS(s21_cost) - @V_Threshold_A
	  or 
	  ABS(summed_cost) >  ABS(s21_cost) + @V_Threshold_A
   )
;

END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS21_CCS_SUMMARY_TAB_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;
GO
