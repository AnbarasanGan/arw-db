SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		btemkow
-- Create date: 2021-12-09
-- Description:	
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- 03-18-2022 rwesley2 US3426269 load by U01 key
--
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_DELETE_D18_COST_ALLOCATION_EI_ASM]
@ARWU01_CCTSS_K INT

AS
--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

DELETE FROM PARWD18_COST_ALLOCATION_EI_ASM
WHERE ARWU04_CCTSS_VRNT_K in (select ARWU04_CCTSS_VRNT_K from PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K = @ARWU01_CCTSS_K)

--  Select 'PARWP_CALC_DELETE_D18_COST_ALLOCATION_EI_ASM' as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
