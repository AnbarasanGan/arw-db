DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_COST_QTY_PREPBOM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 02/10/2021
-- Description:	PRE-PBOM BoBs: Validate the different Cost sheet Quantities match the BOM Sheet. 
--              The same validation is done for Raw Material usage. 
--              The users have been manually updating the quantity and material usage cells on the cost sheets which over-rides the EXCEL formulas.
--              Also, sometimes the users copy values from a text file and paste it into the BOM sheet changing the cell from General to Text. This causes the UI import to read the data differently than shown in the file.
-- =============================================
-- =============================================
-- Changes
-- Date        CDSID    Feature   Description
-- ----------  -------- -------   -----------
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_COST_QTY_PREPBOM] 
-- Input Parameter
 @GUID       varchar(5000)
,@CDSID      varchar(30)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
SET NOCOUNT ON;

--******************
--Purchased Parts
--******************
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 S14.Source_c
		,S14.no_of_pieces
		,'The Purchased Parts "Number of Pieces per Sub-Assembly" does not match the BOM quantity. Verify the formula for "Number of pieces per Sub-Assembly" hasn''t been changed or verify the quantity on the BoM sheet doesn''t have a warning: "The Number in this cell is formatted as text or preceded by an apostrophe" '  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S14.ARWS14_CCS_PURCHASED_PARTS_K  
		,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'  
        ,'ERROR'                       
		,S14.sub_assembly_name
	    ,S14.row_idx                               as ARWE02_ROW_IDX
		,S14.part_index
		,S13.quantity
from PARWS22_CCS_COVER_PAGE_INFO                     S22
JOIN PARWS13_CCS_FORD_BOM_PARTS_INFO                 S13
  ON S13.Processing_ID     = S22.Processing_ID
 AND S13.file_name         = S22.filename  
JOIN PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14
  ON S14.Processing_ID     = S13.Processing_ID
 AND S14.filename          = S13.file_name
 AND S14.sub_assembly_name = S13.part_sub_assembly_name
 AND S14.part_index        = S13.part_index
where S22.Processing_ID = @GUID
  AND round(S14.no_of_pieces,9) != round(S13.quantity,9)
;

--******************
--Raw Materials
--******************
--Quantity
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 S15.Source_c
		,S15.no_of_pieces
		,'The Raw Materials "Number of Pieces per Sub-Assembly" does not match the BOM quantity. Verify the formula for "Number of pieces per Sub-Assembly" hasn''t been changed or verify the quantity on the BoM sheet doesn''t have a warning: "The Number in this cell is formatted as text or preceded by an apostrophe"'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S15.ARWS15_CCS_RAW_MATERIALS_K  
		,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO'  
        ,'ERROR'                       
		,S15.sub_assembly_name
	    ,S15.row_idx                               as ARWE02_ROW_IDX
		,S15.part_index
		,S13.quantity
from PARWS22_CCS_COVER_PAGE_INFO                     S22
JOIN PARWS13_CCS_FORD_BOM_PARTS_INFO                 S13
  ON S13.Processing_ID     = S22.Processing_ID
 AND S13.file_name         = S22.filename  
JOIN PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO   S15
  ON S15.Processing_ID     = S13.Processing_ID
 AND S15.filename          = S13.file_name
 AND S15.sub_assembly_name = S13.part_sub_assembly_name
 AND S15.part_index        = S13.part_index
where S22.Processing_ID = @GUID
  AND round(S15.no_of_pieces,9) != round(S13.quantity,9)
;

--******************
--Raw Materials
--******************
--Net Usage
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 S15.Source_c
		,S15.net_usage_per_piece
		,'The Raw Materials "Net Usage per piece" does not match the BOM Material Usage. Verify the formula for "Net Usage per piece" hasn''t been changed or verify the material usage on the BoM sheet doesn''t have a warning: "The Number in this cell is formatted as text or preceded by an apostrophe".'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S15.ARWS15_CCS_RAW_MATERIALS_K  
		,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO'  
        ,'ERROR'                       
		,S15.sub_assembly_name
	    ,S15.row_idx                               as ARWE02_ROW_IDX
		,S15.part_index
		,S13.material_usage
from PARWS22_CCS_COVER_PAGE_INFO                     S22
JOIN PARWS13_CCS_FORD_BOM_PARTS_INFO                 S13
  ON S13.Processing_ID     = S22.Processing_ID
 AND S13.file_name         = S22.filename  
JOIN PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO   S15
  ON S15.Processing_ID     = S13.Processing_ID
 AND S15.filename          = S13.file_name
 AND S15.sub_assembly_name = S13.part_sub_assembly_name
 AND S15.part_index        = S13.part_index
where S22.Processing_ID = @GUID
  AND round(S15.net_usage_per_piece,9) != round(S13.material_usage,9)
;

--******************
--Processing
--******************
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 S16.Source_c
		,S16.no_of_pieces_per_subassy
		,'The Processing "Number of Pieces per Sub-Assembly" does not match the BOM quantity. Verify the formula for "Number of pieces per Sub-Assembly" hasn''t been changed or verify the quantity on the BoM sheet doesn''t have a warning: "The Number in this cell is formatted as text or preceded by an apostrophe"'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S16.ARWS16_CCS_PROCESSING_PARTS_K  
		,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'  
        ,'ERROR'                       
		,S16.sub_assembly_name
	    ,S16.row_idx                               as ARWE02_ROW_IDX
		,S16.part_index
		,S13.quantity
from PARWS22_CCS_COVER_PAGE_INFO                     S22
JOIN PARWS13_CCS_FORD_BOM_PARTS_INFO                 S13
  ON S13.Processing_ID     = S22.Processing_ID
 AND S13.file_name         = S22.filename  
JOIN PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO   S16
  ON S16.Processing_ID     = S13.Processing_ID
 AND S16.filename          = S13.file_name
 AND S16.sub_assembly_name = S13.part_sub_assembly_name
 AND S16.part_index        = S13.part_index
where S22.Processing_ID = @GUID
  AND round(S16.no_of_pieces_per_subassy,9) != round(S13.quantity,9)
;


END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                  --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''  --Part_index
		,''  --Arrow value	
    ;

END CATCH;
GO
