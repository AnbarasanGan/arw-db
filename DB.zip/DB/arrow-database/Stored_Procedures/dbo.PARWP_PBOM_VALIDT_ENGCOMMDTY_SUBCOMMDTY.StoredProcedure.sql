DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_ENGCOMMDTY_SUBCOMMDTY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		rwesley2
-- Create date: 01/07/2020
-- Description:	Stored Procedure to Validate commodity on PBOM
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   02/26/2020  changed error message replace cover page wording with BoB Teardown Template
-- asolosky   03/20/2020  New validation that sub-Assembly name can't be > 25 characters
-- asolosky   04/23/2020  Sub-assembly greater than 25 validation.  Had to subtract 1 to display the correct row.
-- asolosky   04/30/2020  Moved the "greater than 25 char error" to PARWP_PBOM_VALIDT_SUB_ASSEMBLY
-- rwesley2   09-11-2020  US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10-20-2020  US1996362 Switch from E02 to E03 and include Excel column
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDT_ENGCOMMDTY_SUBCOMMDTY]
	-- Add the parameters for the stored procedure here
	   @GUID  varchar(500) -- Comes from Master
	  ,@CDSID varchar(30)
	  ,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- validate engineering commodity
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
      SELECT
	         Validate.[Source_c]                     as [ARWE03_SOURCE_C],
	         Validate.[commodity_name]               as [ARWE03_ERROR_VALUE],
	         'Engineering commodity name on the BoB Teardown Template does not match the selected Engineering Commodity Name set up for the Program'  as ARWE03_ERROR_VALUE,
	         Validate.[Processing_ID]                as [ARWE03_PROCESSING_ID],
	         Validate.[file_name]                    as [ARWE03_FILENAME],
	         OBJECT_NAME(@@PROCID)                   as [ARWE03_PROCEDURE_X],
	         @TIME_STAMP                             as [ARWE03_CREATE_S],
	         @CDSID                                  as [ARWE03_CREATE_USER_C],
	         @TIME_STAMP                             as [ARWE03_LAST_UPDT_S],
	         @CDSID                                  as [ARWE03_LAST_UPDT_USER_C],
	         Validate.[ARWS59_PBOM_PARTS]            as [ARWE03_BATCH_ERRORS_REF_K],
	         'PARWS59_PBOM_PARTS'                    as [ARWE03_STAGING_TABLE_X],
	         'ERROR'                                 as [ARWE03_ERROR_TYPE_X],
		     ''                                      as [ARWE03_EXCEL_TAB_X],
		     5                                       as ARWE03_ROW_IDX,
		     ''                                      as ARWE03_Part_Index,
		     Validate.User_Selected_ENRG_CMMDTY_X    as ARWE03_Arrow_value,
			 'B'                                     as ARWE03_COLUMN
       FROM 
       (
        SELECT Processing_ID,
		       Program,
		       commodity_name,
			   Sub_commodity_name, 
               User_Selected_ENRG_CMMDTY_X,
		       Source_c,
		       file_name,
			   row_idx,
               ARWS59_PBOM_PARTS,
			   row_number() over (partition by S59.Processing_ID, S59.file_name,s59.program,s59.commodity_name    Order by s59.program,s59.commodity_name) as rownum
          FROM [dbo].[PARWS59_PBOM_PARTS] s59
         WHERE  Processing_ID                = @GUID
   		   And  commodity_name !=  User_Selected_ENRG_CMMDTY_X              
       ) Validate
	   where rownum = 1
    ;

	    -- validate commodity scope
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
      SELECT
	         Validate.[Source_c]                      as [ARWE03_SOURCE_C],
	         Validate.[Sub_commodity_name]            as [ARWE03_ERROR_VALUE],
	         'Commodity Scope on the BoB Teardown Template does not match the selected Commodity Scope set up for the Program'  as [ARWE03_ERROR_VALUE],
	         Validate.[Processing_ID]                 as [ARWE03_PROCESSING_ID],
	         Validate.[file_name]                     as [ARWE03_FILENAME],
	         OBJECT_NAME(@@PROCID)                    as [ARWE03_PROCEDURE_X],
	         @TIME_STAMP                              as [ARWE03_CREATE_S],
	         @CDSID                                   as [ARWE03_CREATE_USER_C],
	         @TIME_STAMP                              as [ARWE03_LAST_UPDT_S],
	         @CDSID                                   as [ARWE03_LAST_UPDT_USER_C],
	         Validate.[ARWS59_PBOM_PARTS]             as [ARWE03_BATCH_ERRORS_REF_K],
	         'PARWS59_PBOM_PARTS'                     as [ARWE03_STAGING_TABLE_X],
	         'ERROR'                                  as [ARWE03_ERROR_TYPE_X],
		     ''                                       as [ARWE03_EXCEL_TAB_X],
		      6                                       as ARWE03_ROW_IDX,
		     ''                                       as ARWE03_Part_Index,
		     Validate.User_Selected_ENRG_SUB_CMMDTY_X as ARWE03_Arrow_value,
			 'B'                                      as ARWE03_COLUMN

       FROM 
       (
       SELECT Processing_ID,
		       Program,
               commodity_name,
		       Sub_Commodity_name,
			   User_Selected_ENRG_SUB_CMMDTY_X,
		       Source_c,
		       file_name,
			   row_idx,
               ARWS59_PBOM_PARTS,
			   row_number() over (partition by S59.Processing_ID, S59.file_name,s59.program,s59.sub_commodity_name    Order by s59.program,s59.sub_commodity_name) as rownum
          FROM [dbo].[PARWS59_PBOM_PARTS] s59
         WHERE Processing_ID                    = @GUID 
		   And Sub_Commodity_name !=  User_Selected_ENRG_SUB_CMMDTY_X                    
       ) Validate
	   where rownum = 1
    ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                       --source_c
             ,'Catch Error'                  --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                          --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()              --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS'
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE
			 ,''                               -- Column
END CATCH;



GO
