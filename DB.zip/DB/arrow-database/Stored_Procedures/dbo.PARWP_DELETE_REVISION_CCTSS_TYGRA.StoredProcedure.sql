DROP PROCEDURE IF EXISTS [dbo].[PARWP_DELETE_REVISION_CCTSS_TYGRA]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ============================================================================================
-- Author:		asolosky
-- Create date: 03/15/2021
-- Description:	This SP either deletes the Tygra associated tables or resets the revision.
-- Input Parameters:
--		 @ARWU01_CCTSS_K
--		,@DELETE_OR_REVISION
-- Output: None
--
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   05/19/2021   Add File type condition when deleting UB5 records for a BoB refresh.
-- Ashaik12   06/01/2021   US2545784 ,US2545786 ,US2545788 Add deletes based on Scope vs Current.
-- btemkow    10/08/2021   US2963522 removed a message that was used for testing
-- btemkow    2022-04-06   US3501484 updated status names
-- ============================================================================================

CREATE PROCEDURE [dbo].[PARWP_DELETE_REVISION_CCTSS_TYGRA] 
 @ARWU01_CCTSS_K      INT
,@DELETE_OR_REVISION VARCHAR(1)
,@file_type INT
,@CDSID varchar(MAX)

AS

SET NOCOUNT ON;
DECLARE @TIME_STAMP DATETIME = GETUTCDATE();
DECLARE @ARWA11_k   INT;
DECLARE @Comment    VARCHAR(1024) = 'The BoB has been associated with a new Tygra file revision.';
Select @ARWA11_k = ARWA11_CCTSS_STAT_K
   From PARWA11_CCTSS_STAT
  Where ARWA11_CCTSS_STAT_N = 'To be Reconciled'



IF (@DELETE_OR_REVISION ='D')
Begin
   Delete 
	 From [dbo].PARWUB6_CCTSS_TYGRA_FILE
    Where ARWU01_CCTSS_K = @ARWU01_CCTSS_K
   ;
   Delete 
	 From [dbo].PARWUB5_CCTSS_TYGRA_FILE_REC
    Where ARWU01_CCTSS_K = @ARWU01_CCTSS_K
   ;
--   Select cast(count(*) as varchar(30)) + ' PARWUB6_CCTSS_TYGRA_FILE';
End;


-- IF a BoB's SCOPE Tygra data is being refreshed then delete records related to Scope from U63 and UB5
IF (@DELETE_OR_REVISION ='V' and @file_type=1) --1 is scope
Begin

-- U63
MERGE  [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63_T
using
(
select
[ARWU63_VRNT_BOM_PART_END_ITM_K]
 from [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63
 JOIN [dbo].[PARWU04_CCTSS_VRNT_FLAT] U04
 ON U04.[ARWU04_CCTSS_VRNT_K]=U63.[ARWU04_CCTSS_VRNT_K]
 Where U04.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
 AND [ARWA57_END_ITM_MAP_TYPE_K] = @file_type
) SRC
ON SRC.[ARWU63_VRNT_BOM_PART_END_ITM_K] = U63_T.[ARWU63_VRNT_BOM_PART_END_ITM_K]
WHEN MATCHED THEN DELETE
;
-- UB5
MERGE  [dbo].PARWUB5_CCTSS_TYGRA_FILE_REC UB5_T
using
(
select
[ARWUB5_CCTSS_TYGRA_FILE_REC_K]
 from [dbo].PARWUB5_CCTSS_TYGRA_FILE_REC Ub5
 JOIN [dbo].[PARWUB3_TYGRA_FILE_REC] Ub3
 ON Ub5.[ARWUB3_TYGRA_FILE_REC_K]=Ub3.[ARWUB3_TYGRA_FILE_REC_K]
 JOIN [dbo].[PARWUB1_TYGRA_FILE] Ub1
 ON Ub1.[ARWUB1_TYGRA_FILE_K] = Ub3.[ARWUB1_TYGRA_FILE_K]
 Where Ub5.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
 AND [ARWA54_TYGRA_FILE_TYPE_K] = @file_type
) SRC
ON SRC.[ARWUB5_CCTSS_TYGRA_FILE_REC_K] = UB5_T.[ARWUB5_CCTSS_TYGRA_FILE_REC_K]
WHEN MATCHED THEN DELETE
;
-- INVALIDATE THE BoB if PBoM is loaded.
DECLARE @PBOM_IMPORTED INT
SET @PBOM_IMPORTED = (select CASE WHEN [ARWU01_PBOM_LAST_IMPT_FILE_N]!='' THEN 1 ELSE 0 END FROM [dbo].[PARWU01_CCTSS_FLAT] where ARWU01_CCTSS_K=@ARWU01_CCTSS_K)
if (@PBOM_IMPORTED=1)
Begin
-- INVALIDATE THE BoB
EXEC  [dbo].[PARWP_CCTSS_INSERT_BOB_STATUS]        @ARWU01_CCTSS_K, @CDSID, @TIME_STAMP, @ARWA11_k, @Comment;
End

End;

-- IF a BoB's CURRENT Tygra data is being refreshed then delete records related to CURRENT from U63,UB5,UA9 and UB0
IF (@DELETE_OR_REVISION ='V' and @file_type=2) --2 is current
Begin

-- U63
MERGE  [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63_T
using
(
select
[ARWU63_VRNT_BOM_PART_END_ITM_K]
 from [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63
 JOIN [dbo].[PARWU04_CCTSS_VRNT_FLAT] U04
 ON U04.[ARWU04_CCTSS_VRNT_K]=U63.[ARWU04_CCTSS_VRNT_K]
 Where U04.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
 AND [ARWA57_END_ITM_MAP_TYPE_K] = @file_type
) SRC
ON SRC.[ARWU63_VRNT_BOM_PART_END_ITM_K] = U63_T.[ARWU63_VRNT_BOM_PART_END_ITM_K]
WHEN MATCHED THEN DELETE
;
-- UB5
MERGE  [dbo].PARWUB5_CCTSS_TYGRA_FILE_REC UB5_T
using
(
select
[ARWUB5_CCTSS_TYGRA_FILE_REC_K]
 from [dbo].PARWUB5_CCTSS_TYGRA_FILE_REC Ub5
 JOIN [dbo].[PARWUB3_TYGRA_FILE_REC] Ub3
 ON Ub5.[ARWUB3_TYGRA_FILE_REC_K]=Ub3.[ARWUB3_TYGRA_FILE_REC_K]
 JOIN [dbo].[PARWUB1_TYGRA_FILE] Ub1
 ON Ub1.[ARWUB1_TYGRA_FILE_K] = Ub3.[ARWUB1_TYGRA_FILE_K]
 Where Ub5.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
 AND [ARWA54_TYGRA_FILE_TYPE_K] = @file_type
) SRC
ON SRC.[ARWUB5_CCTSS_TYGRA_FILE_REC_K] = UB5_T.[ARWUB5_CCTSS_TYGRA_FILE_REC_K]
WHEN MATCHED THEN DELETE
;

-- UB0
MERGE [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0_T
using
(
Select [ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
From [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0
JOIN [dbo].[PARWUA9_VRNT_END_ITM] UA9
ON UA9.[ARWUA9_VRNT_END_ITM_K] = UB0.[ARWUA9_VRNT_END_ITM_K]
JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
WHERE [ARWU01_CCTSS_K]=@ARWU01_CCTSS_K
) SRC
ON SRC.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K] = UB0_T.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
WHEN MATCHED THEN DELETE
;

-- UA9
MERGE [dbo].[PARWUA9_VRNT_END_ITM] UA9_T
using
(
Select [ARWUA9_VRNT_END_ITM_K]
From [dbo].[PARWUA9_VRNT_END_ITM] UA9
JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
WHERE [ARWU01_CCTSS_K]=@ARWU01_CCTSS_K
) SRC
ON SRC.[ARWUA9_VRNT_END_ITM_K] = UA9_T.[ARWUA9_VRNT_END_ITM_K]
WHEN MATCHED THEN DELETE
;

--    Select cast(count(*) as varchar(30)) + ' PARWUB5_CCTSS_TYGRA_FILE_REC';
End;
--rollback


GO
