DROP PROCEDURE If Exists [dbo].[PARWP_UI_VA_ASM_SUMMARY_READ_D04]
GO
/*
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =================================================================================================================================================
-- Author:		btemkow
-- Create date: 2021-12-02
-- Description:	
-- =================================================================================================================================================
-- Changes
-- =================================================================================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   04/04/2022  Remove the procedure.  Use PARWP_UI_VA_ASM_SUMMARY instead of this one.
-- =================================================================================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_VA_ASM_SUMMARY_READ_D04] 
-- Parameters for the stored procedure
@ARWU04_CCTSS_VRNT_K        int,
@ARWU06_CCTSS_DSGN_K        int  -- Lowest IDC design key passed by UI
AS
SET NOCOUNT ON;

SELECT D04.ROW_KEY
      ,D04.ARWU01_CCTSS_K
      ,D04.ARWU04_CCTSS_VRNT_K
      ,D04.ARWU09_CCTSS_VRNT_SUPL_K
      ,D04.ARWU17_BOM_SUB_ASSY_K
      ,A17.ARWA17_SUPL_N
      ,IsNull(U17.ARWU17_BOM_SUB_ASSY_N, 'Final Assembly') as ARWU17_BOM_SUB_ASSY_N
      ,D04.CAII_CHRYPKD
      ,D04.II_MANUAL_SEL_KEY
      ,D04.II_MANUAL_SEL_COMMENT
      ,D04.II_MANUAL_SEL_TYPE
      ,D04.VA_MANUAL_SEL_KEY
      ,D04.VA_MANUAL_SEL_COMMENT
      ,D04.VA_ASM
      ,D04.TOTAL_W_SUP_MRKUP
      ,D04.TOTAL_W_ADJ_MRKUP
      ,D04.ADJ_VA
      ,D04.ASM_DISPLAY_SEQ
      ,D04.BOB_DVNT_STATUS_KEY
      ,D04.BOB_DVNT_STATUS
      ,D04.BOB_DVNT_CMT
      ,D04.DA_DVNT_STATUS_KEY
      ,D04.DA_DVNT_STATUS
      ,D04.DA_DVNT_CMT
      ,D04.II_DVNT_STATUS_KEY
      ,D04.II_DVNT_STATUS
      ,D04.II_DVNT_CMT
      ,D04.VA_DVNT_STATUS_KEY
      ,D04.VA_DVNT_STATUS
      ,D04.VA_DVNT_CMT
      ,D04.VA_MIN_SUP_KEY
      ,D04.MIN_VA_AMT
      ,D04.VA_DELTA
      ,D04.ARWD04_CREATE_S
      ,D04.ARWD04_CREATE_USER_C 
  FROM PARWD04_VA_ASM_SUMMARY        D04
  JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT  U09  ON U09.ARWU09_CCTSS_VRNT_SUPL_K = D04.ARWU09_CCTSS_VRNT_SUPL_K
  JOIN PARWA17_SUPL                  A17  ON A17.ARWA17_SUPL_K            = U09.ARWA17_SUPL_K
  Left
  JOIN PARWU17_BOM_SUB_ASSY          U17  ON U17.ARWU17_BOM_SUB_ASSY_K = D04.ARWU17_BOM_SUB_ASSY_K
 WHERE D04.ARWU04_CCTSS_VRNT_K = @ARWU04_CCTSS_VRNT_K		
 ORDER BY ASM_DISPLAY_SEQ
;
GO
*/
