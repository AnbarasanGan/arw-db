DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_ASSEMBLY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 6/21/2019
-- Description:	validate DAII Adjustment Costs: assembly
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2  07/31/19     Added calculated field validations
-- rwesley2  08/05/2019   added  sub_assembly_name <> 'Final assembly' to Change Improvement ID Part Description Validation 
--                        because final assembly does not have a part description.
-- asamriya  09/10/2019   Added row_idx
-- rwesley2  09/13/2019   added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	 
-- ashaik12  10/17/2019   Changed filters on part description validations to match Sheet name as sub_assembly_name
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- ashaik12  12/25/2019   Removed Case when statements in Error Desc as we have tab name in display on UI.
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky  07/24/2020   US1771016 used the replace function for change_id and part_name to display a line feed
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  04/12/2021   US2430169 Added validation for Cost sheet exchange rate
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_ASSEMBLY] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--++++++++++++++++++++++++++++++++++++
-- Change improvement ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_improvement_id,char(10),'<LF>'),char(13),'<CR>')
      ,'Adjustment Costs for Assembly - Change ID not found in Adjustment Details'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS42_DAII_ASSEMBLY_PARTS_K]
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name  
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          change_improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS42_DAII_ASSEMBLY_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO]  s42
        WHERE Processing_ID= @GUID
			and s42.cost_type='Adjustment Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO] s35
               where s42.[change_improvement_id] = s35.change_id
				 and s42.[filename] = s35.[filename]
				 and s42.Processing_ID = s35.Processing_ID
              )                   
       ) Err
;

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_improvement_id,char(10),'<LF>'),char(13),'<CR>')
      ,'Improvement Costs for Assembly - Improvement ID not found in Improvement Ideas tab'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS42_DAII_ASSEMBLY_PARTS_K]
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx 
	  ,change_improvement_id
	  ,''  --No ARROW Value	   
   FROM 
       (
        SELECT 
		  Processing_ID,
          change_improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS42_DAII_ASSEMBLY_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO]  s42
        WHERE Processing_ID= @GUID
			and s42.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO s44
               where s42.[change_improvement_id] = s44.improvement_id
				 and s42.[filename] = s44.[filename]
				 and s42.Processing_ID = s44.Processing_ID
				 

)
                    
       ) Err

    ;
--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Change Improvement ID Part Description Validation 
--++++++++++++++++++++++++++++++++++++++++++++++++++
   Insert Into  [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  
      ,'Adjustment Costs for Assembly - Part Name does not match Adjustment Details part name'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.[ARWS42_DAII_ASSEMBLY_PARTS_K]
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [change_improvement_id],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS42_DAII_ASSEMBLY_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO]  s42
        WHERE Processing_ID= @GUID
			and s42.cost_type='Adjustment Costs'
	     	and s42.sub_assembly_name <> 'Adjustment Final Assembly'
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO] s35
               where s42.[change_improvement_id] = s35.change_id
			     and s42.[part_description] = s35.[part_name]
				 and s42.[filename] = s35.[filename]
				 and s42.Processing_ID = s35.Processing_ID
              )                  
       ) Err
;


   Insert Into  [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  
      ,'Improvement Costs for Assembly - Part Name does not match Improvement Ideas Part Name'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.[ARWS42_DAII_ASSEMBLY_PARTS_K]
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [change_improvement_id],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS42_DAII_ASSEMBLY_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO]  s42
        WHERE Processing_ID= @GUID
			and s42.cost_type='Improvement Costs'
	     	and s42.sub_assembly_name <> 'Improvement Final Assembly'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO s44
               where s42.[change_improvement_id] = s44.improvement_id
			     and s42.[part_description] = s44.[part_name]
				 and s42.[filename] = s44.[filename]
				 and s42.Processing_ID = s44.Processing_ID
              )                   
       ) Err
;

--++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.local_currency                    as ARWE02_ERROR_VALUE
	  ,'Assembly - Invalid Assembly Currency Code'  as ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS42_DAII_ASSEMBLY_PARTS_K      as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'    as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
			   change_improvement_id,
               local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS42_DAII_ASSEMBLY_PARTS_K,
			   row_idx
          FROM PARWS42_DAII_ASSEMBLY_PARTS_INFO S42
         WHERE Processing_ID= @GUID
	       and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where S42.[local_currency] = A29.[ARWA29_CRCY_C]
	             )	
                 
        ) Err
;
---------------------------------------------------------------------
--  START Calculated field validations
---------------------------------------------------------------------
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Machine / operation overhead costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.machine_op_overhead_costs         as ARWE02_ERROR_VALUE
	  ,'Assembly: Machine/operation overhead costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS42_DAII_ASSEMBLY_PARTS_K]    as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'    as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,'Total: ' + CAST(ERR.Calculated_value as Varchar(50))  -- ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS42_DAII_ASSEMBLY_PARTS_K],
			   [change_improvement_id],
			   machine_op_overhead_costs,
			   assembly_secs_operation*(machinehourly_operation_overhead/3600) as Calculated_value,
			   row_idx
         FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO] S42
        WHERE Processing_ID= @GUID
	      and  ABS((assembly_secs_operation*(machinehourly_operation_overhead/3600)) - (machine_op_overhead_costs)) > @threshold
 
        ) ERR
;
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Direct labor cost per operation [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.direct_labor_cost_op              as ARWE02_ERROR_VALUE
	  ,'Assembly: Direct labor cost per operation, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS42_DAII_ASSEMBLY_PARTS_K]    as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'    as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,'Total: ' + CAST(Err.Calculated_value as Varchar(50))  -- ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS42_DAII_ASSEMBLY_PARTS_K],
			   [change_improvement_id],
			   direct_labor_cost_op,
			   assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount as Calculated_value,
			   row_idx
         FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO] S42
        WHERE Processing_ID= @GUID
	      and ABS((assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount) - (direct_labor_cost_op)) > @threshold
         
        ) ERR
;
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Total labor costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.total_labor_costs                 as ARWE02_ERROR_VALUE
	  ,'Assembly: Total labor costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS42_DAII_ASSEMBLY_PARTS_K]    as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'    as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,'Total: ' + CAST(Err.Calculated_value as Varchar(50))  -- ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS42_DAII_ASSEMBLY_PARTS_K],
			   [change_improvement_id],
			   total_labor_costs,
			   ((assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount)*(1+[indirect_labor_costs])*(1+[fringes])) as Calculated_value,
			   row_idx
         FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO] S42
        WHERE Processing_ID= @GUID
	      and ABS(((assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount)*(1+[indirect_labor_costs])*(1+[fringes])) - (total_labor_costs)) > @threshold
        ) ERR
;
---------------------------------------------------------------------
--  END Calculated field validations
---------------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Assembly: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS42_DAII_ASSEMBLY_PARTS_K
	  ,'PARWS42_DAII_ASSEMBLY_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.change_improvement_id 
	  ,'' 
  FROM 
      (
        SELECT 
               S42.Processing_ID
              ,s42.exchange_rate
  		      ,s42.Source_c
  		      ,s42.filename
              ,s42.ARWS42_DAII_ASSEMBLY_PARTS_K
  		      ,s42.sub_assembly_name
  		      ,s42.change_improvement_id
			  ,s42.row_idx
			  ,S55.usd_per_local_currency
			  ,S55.supplier_picked_crcy_c
          FROM PARWS42_DAII_ASSEMBLY_PARTS_INFO S42 
		  Join PARWS55_DAII_EXCHANGE_RATE_TAB   S55
		    On S55.Processing_ID  = S42.Processing_ID
		   And S55.filename       = S42.filename
		   And S55.currency_code  = S42.local_currency
         WHERE S42.Processing_ID  = @GUID
		   and S42.exchange_rate != S55.usd_per_local_currency
      ) Err
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''                                --ARWE02_STAGING_TABLE_X
		,'PARWS42_DAII_ASSEMBLY_PARTS_INFO' --ARWE02_BATCH_ERRORS_K
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
		,0
		,''  --Part_index
		,''  --Arrow value	
;
END CATCH;	

GO
