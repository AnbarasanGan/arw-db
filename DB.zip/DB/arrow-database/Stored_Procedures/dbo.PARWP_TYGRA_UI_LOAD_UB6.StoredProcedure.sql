DROP PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_UB6]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load UB6 to associate Tygra file to BoBs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- rwesley2   06-10-2021  US2569418 add UB6 insert for BoB refresh
-- rwesley2   06-30-2021  US2623732 check U01 Tygra reqd flag and write a record where set to 1
-- rwesley2	  09-03-2021  US2835340    Manual SPs will continue to use NULL for U01 key. Only UI will use -1.
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_UB6] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
-- @GUID varchar(5000)
@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME
,@file_name varchar(MAX)
,@file_type int
,@version  int
,@ARWUB1_TYGRA_FILE_K  int
,@ARWU01_CCTSS_K int
,@load_to_pgm_name varchar(MAX) 

AS

SET NOCOUNT ON;



--set @file_name = 'U71X ACT Tygra 2.10.2020 - WS2 Hand Off.xlsx'
--set  @ARWA54_TYGRA_FILE_TYPE_K  = 1
--set @ARWUB1_TYGRA_FILE_REV_R  = 6
--
--set @ARWU31_CTSP_K = 35

--*****************************************************
-- Determine if this is an initial load or a single BoB load.
-- When initial load, the U01 key will be -1
-- When a single BoB load, the U01 key will have a value
--******************************************************

Begin
IF @arwu01_CCTSS_K IS NULL GOTO INITIAL_LOAD
ELSE GOTO BoB_LOAD
END


--******************************************************
-- this step is for initial load of Tygra file.
-- it assumes that BoBs already exist and associates the imported Tygra file with those BoBs 
-- 
 --******************************************************
 INITIAL_LOAD:
 MERGE INTO [dbo].[PARWUB6_CCTSS_TYGRA_FILE] ub6
USING (
select * from (
     select ARWU01_CCTSS_K 
      ,ARWA54_TYGRA_FILE_TYPE_K
	  ,@TIME_STAMP    as [ARWUB6_CREATE_S]
	  ,@CDSID         as [ARWUB6_CREATE_USER_C]
	  ,@TIME_STAMP    as [ARWUB6_LAST_UPDT_S]
	  ,@CDSID         as [ARWUB6_LAST_UPDT_USER_C]
	  ,[ARWUB1_TYGRA_FILE_K]
     from PARWUB1_TYGRA_FILE ub1
     join PARWU01_CCTSS_FLAT u01
	 on u01.[ARWU31_CTSP_N] = @load_to_pgm_name
where ub1.ARWUB1_TYGRA_FILE_K = @ARWUB1_TYGRA_FILE_K 
and ub1.ARWUB1_TYGRA_FILE_N = @file_name
and ub1.ARWA54_TYGRA_FILE_TYPE_K = @file_type
and ub1.ARWUB1_TYGRA_FILE_REV_R = @version
and u01.ARWU01_TYGRA_REQD_F = 1
)x
)y
on  ub6.[ARWU01_CCTSS_K]           = y.[ARWU01_CCTSS_K]
and ub6.[ARWA54_TYGRA_FILE_TYPE_K] = y.[ARWA54_TYGRA_FILE_TYPE_K]
and ub6.[ARWUB1_TYGRA_FILE_K] = y.[ARWUB1_TYGRA_FILE_K]
When NOT MATCHED THEN
     INSERT 
     VALUES (
	          y.ARWU01_CCTSS_K 
			 ,y.ARWA54_TYGRA_FILE_TYPE_K
	         ,y.ARWUB6_CREATE_S
	         ,y.ARWUB6_CREATE_USER_C
	         ,y.ARWUB6_LAST_UPDT_S
	         ,y.ARWUB6_LAST_UPDT_USER_C
	         ,y.ARWUB1_TYGRA_FILE_K
			 )
			 ;
GOTO EOJ;

-- Update a U01_K to use the new Ub1_K on subsequent load.  Assumes there is a UB6 record for the BoB
BoB_LOAD:
 MERGE INTO [dbo].[PARWUB6_CCTSS_TYGRA_FILE] ub6
USING (
select * from (
     select ARWU01_CCTSS_K 
      ,ARWA54_TYGRA_FILE_TYPE_K
	  ,@TIME_STAMP    as [ARWUB6_CREATE_S]
	  ,@CDSID         as [ARWUB6_CREATE_USER_C]
	  ,@TIME_STAMP    as [ARWUB6_LAST_UPDT_S]
	  ,@CDSID         as [ARWUB6_LAST_UPDT_USER_C]
	  ,[ARWUB1_TYGRA_FILE_K]
 from PARWUB1_TYGRA_FILE ub1
     join PARWU01_CCTSS_FLAT u01
	 on u01.[ARWU31_CTSP_N] = @load_to_pgm_name
where ub1.ARWUB1_TYGRA_FILE_K = @ARWUB1_TYGRA_FILE_K 
and ub1.ARWUB1_TYGRA_FILE_N = @file_name
and ub1.ARWA54_TYGRA_FILE_TYPE_K = @file_type
and ub1.ARWUB1_TYGRA_FILE_REV_R = @version
and u01.ARWU01_CCTSS_K = @arwu01_cctss_k
and u01.ARWU01_TYGRA_REQD_F = 1
)x
)y
on  ub6.[ARWU01_CCTSS_K]           = y.[ARWU01_CCTSS_K]
and ub6.[ARWA54_TYGRA_FILE_TYPE_K] = y.[ARWA54_TYGRA_FILE_TYPE_K]
When MATCHED THEN UPDATE 
			SET 
	          ARWUB1_TYGRA_FILE_K = y.[ARWUB1_TYGRA_FILE_K]
	        , ARWUB6_LAST_UPDT_S = @TIME_STAMP
	        , ARWUB6_LAST_UPDT_USER_C = @CDSID
			;

-- If the BoB isn't on the UB6, then insert it.  Assumes BoB content has been created
 MERGE INTO [dbo].[PARWUB6_CCTSS_TYGRA_FILE] ub6
USING (
select * from (
     select ARWU01_CCTSS_K 
      ,ARWA54_TYGRA_FILE_TYPE_K
	  ,@TIME_STAMP    as [ARWUB6_CREATE_S]
	  ,@CDSID         as [ARWUB6_CREATE_USER_C]
	  ,@TIME_STAMP    as [ARWUB6_LAST_UPDT_S]
	  ,@CDSID         as [ARWUB6_LAST_UPDT_USER_C]
	  ,[ARWUB1_TYGRA_FILE_K]
     from PARWUB1_TYGRA_FILE ub1
     join PARWU01_CCTSS_FLAT u01
	 on u01.[ARWU31_CTSP_N] = @load_to_pgm_name
where ub1.ARWUB1_TYGRA_FILE_K = @ARWUB1_TYGRA_FILE_K 
and ub1.ARWUB1_TYGRA_FILE_N = @file_name
and ub1.ARWA54_TYGRA_FILE_TYPE_K = @file_type
and ub1.ARWUB1_TYGRA_FILE_REV_R = @version
and u01.ARWU01_CCTSS_K = @arwu01_cctss_k
and u01.ARWU01_TYGRA_REQD_F = 1
)x
)y
on  ub6.[ARWU01_CCTSS_K]           = y.[ARWU01_CCTSS_K]
and ub6.[ARWA54_TYGRA_FILE_TYPE_K] = y.[ARWA54_TYGRA_FILE_TYPE_K]
and ub6.[ARWUB1_TYGRA_FILE_K] = y.[ARWUB1_TYGRA_FILE_K]
When NOT MATCHED THEN
     INSERT 
     VALUES (
	          y.ARWU01_CCTSS_K 
			 ,y.ARWA54_TYGRA_FILE_TYPE_K
	         ,y.ARWUB6_CREATE_S
	         ,y.ARWUB6_CREATE_USER_C
	         ,y.ARWUB6_LAST_UPDT_S
	         ,y.ARWUB6_LAST_UPDT_USER_C
	         ,y.ARWUB1_TYGRA_FILE_K
			 )
			 ;

EOJ: select 'SUCCESS'



GO
