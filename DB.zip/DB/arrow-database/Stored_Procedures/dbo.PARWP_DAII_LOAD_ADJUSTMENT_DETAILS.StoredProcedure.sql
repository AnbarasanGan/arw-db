SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 04/25/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
--              No deletes on the U36 and U37 tables.  It's be a pure insert/update just like the CCS PBOM
-- =============================================
-- Changes
-- Date        CDSID     Story      Description
-- ----------  --------  ---------  -----------
-- 07/12/2019  asolosky		         All deletes were removed from their load procedure and moved to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure
-- 07/18/2019  rwesley2			      added INSERT for U18 and U19 when type of change is ADD	
-- 07/23/2019  rwesley2			      removed INSERT for U19 per BTEMKOW	
-- 07/23/2019  ashaik12             Changed Join from V08 to V04 and added a Join to U18 table to get U18 Key for U37 Insert.
-- 07/24/2019  asolosky             U36/U37 table loads will be similar to PBOM loads. Only insert to U36 and insert/update to U37
--                                  Deletes on the U36 and U37 were removed.  Probably don't need all the table deletes in this procedure but no sense to move them back.
-- 07/30/2019  asolosky             Added Case statement in the U37 insert for empty lvl2 waterfall category.
-- 08/01/2019  asolosky             Removed Case statement in the U37 insert. We will not validate WF cat and not insert what the users enter.  Instead
--                                  both levels will be empty strings. 
-- 08/07/2019  ashaik12             Updated the Level 1 and Level 2 waterfall category logic.
-- 08/20/2019  ashaik12             Commented out filename in delete statements
-- 08/21/2019  rwesley			      Added rownum to U37 insert to eliminate duplicate row insert when multiple files are uploaded.  
-- 08/28/2019  rwesley			      Added CCTSS to U18 temp tbl build and U18 INSERT.  business rule from Glenn: can assign the sub-assembly 
--                                  by the first 2 characters of a part index for a given CCTSS. 	
-- 08/29/2019  ashaik12             Removed joins to stage table other than S34 in the deletes
-- 09/05/2019  asolosky             Added deletes for U73 and U74 tables. 
-- 11/21/2019  rwesley2             new business rule:  the first character of a part index defines the sub-assy  
-- 11/22/2019  rwesley2             business rule change: first look for part index match using first 2 characters of part index to find the sub-assy
--                                  if no matches, use first character of part index to find the sub-assy
-- 12/3/2019   ashaik12             Added another filter cndition for 1 char insert into u18
-- 01/14/2020  Ashaik12             Added Time_Stamp parameter and removed filter on Processing Status
-- 07/30/2020  Ashaik12   US1809333 Increase column sizes in temp table to match database column sizes.
-- 05/06/2020  btemkow    US3601073 Handle CIA ID Number
-- 05/23/2022  asolosky   US3612606 Removed the Delete for U73 and U74. Those deletes are now in PARWP_DAII_CONSL_DELETE_SUM_TBLS
--                                           
-- =============================================

CREATE or ALTER PROCEDURE  [dbo].[PARWP_DAII_LOAD_ADJUSTMENT_DETAILS] 
-- Input Parameter
@GUIDIN   Varchar(5000),
@CDSID	  Varchar(30),
@CCTSS_K  Int,
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

----------------------------------------------------------------------------------------------------- 
--Delete Section
-----------------------------------------------------------------------------------------------------

--DELETE: using Merge statement to Delete data in the PARWU38_SUPL_DSGN_ADJ_PART table.  This will handle reloading of a file.
MERGE INTO PARWU38_PURC_PART_DSGN_ADJ   U38_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K 
        From PARWS34_DAII_COVER_PAGE_INFO       S34 
        

      -- Join with Supplier Quote View
        JOIN dbo.PARWV04_DSGN_SUPL V04
         ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
        AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
        AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
        AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
        AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
        AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
        AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
        AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
        AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
        AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
        AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

       Where S34.Processing_ID               = @GUIDIN
         And S34.Skip_loading_due_to_error_f         = 0
		 
      ) as U38_Source
 ON ( 
         U38_Target.ARWU08_CCTSS_DSGN_SUPL_K          = U38_Source.ARWU08_CCTSS_DSGN_SUPL_K
    )
WHEN MATCHED THEN DELETE;

--DELETE: PARWU39_RAW_MTRL_DSGN_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU39_RAW_MTRL_DSGN_ADJ   U39_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K 
        From PARWS34_DAII_COVER_PAGE_INFO     S34 
      
       
       -- Join with Design and Supplier View
        JOIN PARWV04_DSGN_SUPL   V04
          ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
         AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
         AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
         AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
         AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
         AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
         AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
         AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
         AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
         AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
         AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N
       Where S34.Processing_ID               = @GUIDIN
         And S34.Skip_loading_due_to_error_f         = 0
	  
      ) as U39_Source
 ON (U39_Target.ARWU08_CCTSS_DSGN_SUPL_K = U39_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;


--DELETE: PARWU40_PROCG_DSGN_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU40_PROCG_DSGN_ADJ U40_target
USING
  (select  
          v04.ARWU08_CCTSS_DSGN_SUPL_K
     From PARWS34_DAII_COVER_PAGE_INFO       S34 

      
    -- Join with Supplier Qoute View
     JOIN dbo.PARWV04_DSGN_SUPL V04
    ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C
    
      where S34.Processing_ID             = @GUIDIN
        AND S34.Skip_loading_due_to_error_f         = 0

      ) as u40_source
 
ON (u40_target.ARWU08_CCTSS_DSGN_SUPL_K = u40_source.ARWU08_CCTSS_DSGN_SUPL_K)
when MATCHED THEN DELETE
;

--DELETE: PARWU41_ASSY_DSGN_ADJ table. This will handle reloading of a file.
MERGE INTO PARWU41_ASSY_DSGN_ADJ   U41_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
       

      -- Join with Supplier Quote View
        JOIN PARWV04_DSGN_SUPL   V04
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.VARIANT
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	     AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f         = 0

      ) as U41_Source
 ON (U41_Target.ARWU08_CCTSS_DSGN_SUPL_K = U41_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

--DELETE: Final Assembly using Merge statement to Delete data in the PARWU43_FNL_ASSY_DSGN_ADJ table. This will handle reloading of a file.
MERGE INTO PARWU43_FNL_ASSY_DSGN_ADJ   U43_Target
Using
	 ( Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
       

      -- Join with Supplier Quote View
    JOIN [dbo].[PARWV04_DSGN_SUPL]   V04
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V04.[ENG_SUB_CMMDTY_DESC]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.[CTSP_REGION_CODE]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f         = 0

      ) as U43_Source
 ON ( 
         U43_Target.ARWU08_CCTSS_DSGN_SUPL_K = U43_Source.ARWU08_CCTSS_DSGN_SUPL_K
    )
WHEN MATCHED THEN DELETE;

-- Delete for PARWU42_MFG_MRKP_DSGN_ADJ
MERGE INTO [dbo].PARWU42_MFG_MRKP_DSGN_ADJ U42_Target
USING
(
SELECT V04.ARWU08_CCTSS_DSGN_SUPL_K as [ARWU08_CCTSS_DSGN_SUPL_K]
  from [dbo].PARWS34_DAII_COVER_PAGE_INFO            S34
 

  -- SUPPLIER QUOTE VIEW
  JOIN dbo.PARWV04_DSGN_SUPL V04
      ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C
  
 where S34.Processing_ID               = @GUIDIN
   AND S34.Skip_loading_due_to_error_f         = 0

) as U42_SOURCE
ON
(
U42_Target.[ARWU08_CCTSS_DSGN_SUPL_K]=U42_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K]
--AND U52_Target.[ARWA38_MFG_MRKP_TYP_K] = U52_Source.[ARWA38_MFG_MRKP_TYP_K]
)
WHEN MATCHED THEN DELETE;

--Delete for PARWU44_FNLASSY_MRKP_DSGN_ADJ
MERGE INTO  [dbo].PARWU44_FNLASSY_MRKP_DSGN_ADJ U44_Target
USING
(
Select V04.ARWU08_CCTSS_DSGN_SUPL_K
     -- ,ARWA38_MFG_MRKP_TYP_K 
  From PARWV04_DSGN_SUPL V04
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
        --     ,A38.ARWA38_MFG_MRKP_TYP_K 
        from [dbo].PARWS34_DAII_COVER_PAGE_INFO cover_page_stage
        
      where cover_page_stage.Processing_ID               = @GUIDIN
        AND cover_page_stage.Skip_loading_due_to_error_f         = 0

      ) Staging
   -- ON Staging.Eng_commodity_name    = V04.[ENG_CMMDTY_DESC]
   ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X]     = V04.[ENG_SUB_CMMDTY_DESC]
   AND Staging.[User_Selected_CTSP_N]               = V04.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]        = V04.[CTSP_REGION_CODE]
   AND Staging.[User_Selected_VEH_MAKE_N]           = V04.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]            = V04.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]         = V04.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]       = V04.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]         = V04.[VARIANT]
   AND Staging.[User_Selected_SUPL_N]               = V04.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]         = V04.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]               = V04.ARWA17_SUPL_C
) as U44_SOURCE
ON (U44_Target.[ARWU08_CCTSS_DSGN_SUPL_K] = U44_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K]
    -- AND U54_Target.ARWA38_MFG_MRKP_TYP_K = U54_Source.ARWA38_MFG_MRKP_TYP_K
	)
WHEN MATCHED THEN DELETE;

----------------------------------------------------------------------------------------------------- 
--End Delete Section
-----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------- 
--Insert Section
-----------------------------------------------------------------------------------------------------

--=============================================================================================
--=============================================================================================
--  U18 and U19 INSERT 
-- TABLE variables to hold new Part Index
 DECLARE @new_part_index TABLE (
         NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
        ,NEW_PART_NAME VARCHAR (256) NOT NULL
		,NEW_DESIGN_MAKE VARCHAR (32) NOT NULL
		,NEW_DESIGN_MODEL VARCHAR (32) NOT NULL
		,NEW_MY VARCHAR (7) NOT NULL
		,NEW_CCTSS int NOT NULL
	    ,row_idx INT
		                        )
 	;
-- get new part index from s35 that is not on u18 when type of change is ADD    
-- when skip loading flag is not 0, nothing is loaded to the temp table, so nothing is inserted to u18 and subsequently u19.
INSERT INTO @new_part_index
    SELECT  not_matched_PI
         ,part_name
     	 ,[User_Selected_VEH_MAKE_N]
     	 ,[User_Selected_VEH_MDL_N]
     	 ,[User_Selected_VEH_MDL_YR_C]
     	 ,[ARWU01_CCTSS_K]
         ,[row_idx]
	   from
  (
       SELECT s35.part_index as not_matched_PI
	         ,s35.part_name
			 ,s34.[User_Selected_VEH_MAKE_N]
			 ,s34.[User_Selected_VEH_MDL_N]
			 ,s34.[User_Selected_VEH_MDL_YR_C]
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,s35.[row_idx]
			 ,row_number() over (Partition by s35.part_index  order by S35.[row_idx]) as rownum
       FROM [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO] S35
	   LEFT JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S35.Processing_ID
        and S34.filename            = S35.filename
	          
	   LEFT join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u06_view.[ARWU01_CCTSS_K] = U18.[ARWU01_CCTSS_K]
		 AND S35.[part_index] = U18.ARWU18_BOM_PART_IX_N

       WHERE s35.Processing_ID       =  @GUIDIN
	     and s35.type_of_change  = 'ADD'
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S34.Skip_loading_due_to_error_f = 0
		)STG
   Where rownum = 1;

-- check for part index match using first 2 characters 
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID       as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) = substring(npi.NEW_BOM_PART_IX_N,1,2)
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;

-- deleting and reloading the temp table to make sure any parts inserted from the 2 character match above don't get inserted again fromn the 1 character match
-- anything inserted to the u18 from the 2 character match will not be on the temp table
DELETE from @new_part_index
INSERT INTO @new_part_index
    SELECT  not_matched_PI
         ,part_name
     	 ,[User_Selected_VEH_MAKE_N]
     	 ,[User_Selected_VEH_MDL_N]
     	 ,[User_Selected_VEH_MDL_YR_C]
     	 ,[ARWU01_CCTSS_K]
         ,[row_idx]
	   from
  (
       SELECT s35.part_index as not_matched_PI
	         ,s35.part_name
			 ,s34.[User_Selected_VEH_MAKE_N]
			 ,s34.[User_Selected_VEH_MDL_N]
			 ,s34.[User_Selected_VEH_MDL_YR_C]
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,s35.[row_idx]
			 ,row_number() over (Partition by s35.part_index  order by S35.[row_idx]) as rownum
       FROM [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO] S35
	   LEFT JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S35.Processing_ID
        and S34.filename            = S35.filename
	          
	   LEFT join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u06_view.[ARWU01_CCTSS_K] = U18.[ARWU01_CCTSS_K]
		 AND S35.[part_index] = U18.ARWU18_BOM_PART_IX_N

       WHERE s35.Processing_ID       =  @GUIDIN
	     and s35.type_of_change  = 'ADD'
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S34.Skip_loading_due_to_error_f = 0
		)STG
   Where rownum = 1;

-- doing not DP because if only using first character from a directed part may get wrong sub-assy
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID      as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_BOM_PART_IX_N,1,1)
	   and substring(npi.NEW_BOM_PART_IX_N,1,2) <> 'DP'
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;

--=============================================================================================
--=============================================================================================

--PARWU36_CCTSS_DSGN_ADJ_GRP

INSERT INTO PARWU36_CCTSS_DSGN_ADJ_GRP
SELECT --ARWU36_CCTSS_DSGN_ADJ_GRP_K is an identity 
       V04.ARWU06_CCTSS_DSGN_K          AS ARWU06_CCTSS_DSGN_K
	  ,S35.tough_choice_grouping        AS ARWU36_CCTSS_DSGN_ADJ_GRP_X
	  ,1                                as [ARWU36_DSGN_ADJ_GRP_INCL_F]  -- default to Yes (1)
	  ,@TIME_STAMP
	  ,@CDSID
	  ,@TIME_STAMP
	  ,@CDSID
  From PARWS35_DAII_ADJUSTMENT_DETAILS_INFO   S35
  JOIN PARWS34_DAII_COVER_PAGE_INFO           S34
    ON S34.Processing_ID       = S35.Processing_ID
   AND S34.filename            = S35.filename

 -- Join with Design Supplier View
  JOIN PARWV04_DSGN_SUPL   V04
    ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
   AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
   AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
   AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
   AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
   AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
   AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
   AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
   AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N

Left Join PARWU37_CCTSS_DSGN_ADJ  U37
       ON U37.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
      And U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  = S35.change_id

  Where S34.Processing_ID               = @GUIDIN
    And S34.Skip_loading_due_to_error_f = 0
    And U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  is NULL  --change_id
    And not exists --Can't add a tough group if it already exists
       (Select 'X'
          From PARWU36_CCTSS_DSGN_ADJ_GRP U36_Check
	     Where U36_Check.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
		   And U36_Check.ARWU36_CCTSS_DSGN_ADJ_GRP_X = S35.tough_choice_grouping    
       )
Group by --Get distinct data to write into the U36 table.
       V04.ARWU06_CCTSS_DSGN_K          
	  ,S35.tough_choice_grouping
;   
	  
--PARWU37_CCTSS_DSGN_ADJ
INSERT INTO  PARWU37_CCTSS_DSGN_ADJ
select * from (
Select 
       ARWU06_CCTSS_DSGN_K
      ,ARWU37_CCTSS_DSGN_ADJ_ID_N
      ,ARWU36_CCTSS_DSGN_ADJ_GRP_K
	  ,ARWU18_BOM_PART_K
	  ,ARWA40_DSGN_ADJ_PART_CHG_TYP_K
	  ,ARWU37_CMPETV_DSGN_ATTR_X
	  ,ARWU37_FORD_INTD_DSGN_ATTR_X
	  ,ARWA19_LVL2_ADJ_CATG_K
	  ,ARWU37_SPEC_SDS_NUM_X
	  ,ARWU37_CCTSS_DSGN_ADJ_CMT_X
	  ,ARWU37_CREATE_S
	  ,ARWU37_CREATE_USER_C
	  ,ARWU37_LAST_UPDT_S
	  ,ARWU37_LAST_UPDT_USER_C
	  ,'' AS ARWU37_CIA_ID_NUM_X
From
(
SELECT --ARWU37_CCTSS_DSGN_ADJ_K is an identity 
       V04.ARWU06_CCTSS_DSGN_K                   AS ARWU06_CCTSS_DSGN_K
      ,S35.change_id                             AS ARWU37_CCTSS_DSGN_ADJ_ID_N
      ,U36.ARWU36_CCTSS_DSGN_ADJ_GRP_K           AS ARWU36_CCTSS_DSGN_ADJ_GRP_K
	  ,U18.ARWU18_BOM_PART_K                     AS ARWU18_BOM_PART_K
	  ,A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K        AS ARWA40_DSGN_ADJ_PART_CHG_TYP_K
	  ,S35.competitive_dsgn_attr                 AS ARWU37_CMPETV_DSGN_ATTR_X
	  ,S35.ford_intended_dsgn_attr               AS ARWU37_FORD_INTD_DSGN_ATTR_X
      ,CASE WHEN WF_CAT.ARWA18_LVL1_ADJ_CATG_ABBR_N is NULL then '' ELSE WF_CAT.ARWA18_LVL1_ADJ_CATG_ABBR_N   END         AS lvl1_waterfall_cat  --See change modification for 08/01/2019 for explanation
	  ,CASE WHEN WF_CAT.ARWA19_LVL2_ADJ_CATG_N is NULL then ''      ELSE WF_CAT.ARWA19_LVL2_ADJ_CATG_N  END               AS lvl2_waterfall_cat
      --lvl1
--      ,Case When S35.lvl1_waterfall_cat = 'Base_Design'  
--            Then Case When S35.lvl2_waterfall_cat = '' 
--      	              Then ''
--                      Else S35.lvl1_waterfall_cat
--      		     End
--            ELSE S35.lvl1_waterfall_cat
--       End lvl1_waterfall_cat
--      --lvl2
--      ,Case When S35.lvl2_waterfall_cat = 'N/A' or S35.lvl2_waterfall_cat = '' 
--      	    Then Case When S35.lvl1_waterfall_cat = 'Base_Design' 
--      			      Then '' 
--      				  Else S35.lvl1_waterfall_cat 
--			     End
--      	    Else S35.lvl2_waterfall_cat 
--       End as lvl2_waterfall_cat
	  ,S35.ford_spec_sds                         AS ARWU37_SPEC_SDS_NUM_X
	  ,S35.comments                              AS ARWU37_CCTSS_DSGN_ADJ_CMT_X
	  ,@TIME_STAMP                              AS ARWU37_CREATE_S
	  ,@CDSID                                    AS ARWU37_CREATE_USER_C
	  ,@TIME_STAMP                              AS ARWU37_LAST_UPDT_S
	  ,@CDSID                                    AS ARWU37_LAST_UPDT_USER_C
	  ,ROW_NUMBER() OVER (PARTITION by V04.ARWU06_CCTSS_DSGN_K, S35.change_id  ORDER by S35.change_id ) as rownum  

  From PARWS35_DAII_ADJUSTMENT_DETAILS_INFO  S35
  JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
    ON S34.Processing_ID       = S35.Processing_ID
   AND S34.filename            = S35.filename

 -- Join with Supplier Quote View
  JOIN [dbo].[PARWV04_DSGN_SUPL]   V04
    ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
   AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
   AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
   AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
   AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
   AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
   AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
   AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
   AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N

   JOIN [dbo].[PARWU18_BOM_PART] U18
     ON U18.ARWU01_CCTSS_K             = V04.ARWU01_CCTSS_K
    and U18.ARWU18_BOM_PART_IX_N       = S35.part_index 

--Design Adjustment Group
  Join PARWU36_CCTSS_DSGN_ADJ_GRP  U36
    ON U36.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
   And U36.ARWU36_CCTSS_DSGN_ADJ_GRP_X = S35.tough_choice_grouping
--Part Change Type
  Join PARWA40_DSGN_ADJ_PART_CHG_TYP  A40
    On A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X = S35.type_of_change

	LEFT JOIN PARWV07_LVL1_LVL2_CAT WF_CAT
	ON S35.lvl1_waterfall_cat = WF_CAT.ARWA18_LVL1_ADJ_CATG_ABBR_N
	AND S35.lvl2_waterfall_cat = WF_CAT.ARWA19_LVL2_ADJ_CATG_N

 Where S34.Processing_ID               = @GUIDIN
   And S34.Skip_loading_due_to_error_f = 0
   And not exists --Insert if it doesn't already exist
      (Select 'X'
        From PARWU37_CCTSS_DSGN_ADJ U37_check
	   Where U37_check.ARWU06_CCTSS_DSGN_K        = V04.ARWU06_CCTSS_DSGN_K 
	     and U37_check.ARWU37_CCTSS_DSGN_ADJ_ID_N = S35.change_id            
      )
) U37_Data
--Level1, Level2 category   
  Join PARWV07_LVL1_LVL2_CAT  V07
    ON U37_Data.lvl1_waterfall_cat   = V07.ARWA18_LVL1_ADJ_CATG_ABBR_N
   And U37_Data.lvl2_waterfall_cat   = V07.ARWA19_LVL2_ADJ_CATG_N

   where rownum = 1
) final
;

GO
