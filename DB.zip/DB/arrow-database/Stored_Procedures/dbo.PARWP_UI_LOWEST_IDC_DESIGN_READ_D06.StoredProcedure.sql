DROP PROCEDURE If Exists [dbo].[PARWP_UI_LOWEST_IDC_DESIGN_READ_D06]
GO
/*
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =================================================================================================================================================
-- Author:		svallur5
-- Create date: 2021-12-13
-- Description:	
-- =================================================================================================================================================
-- Changes
-- =================================================================================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   04/04/2022  Remove the procedure.  Use PARWP_UI_LOWEST_IDC_DESIGN instead of this one.
-- =================================================================================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_LOWEST_IDC_DESIGN_READ_D06] 
-- Parameters for the stored procedure
@ARWU01_CCTSS_K        int
AS
SET NOCOUNT ON;


SELECT * FROM PARWD06_LOWEST_IDC_DESIGN
WHERE ARWU01_CCTSS_K = @ARWU01_CCTSS_K;		

GO
*/
