DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_CHANGE_ID]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		rwesley2
-- Create date: 10/17/2019
-- Description:	checks for duplicate change IDs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- Ashaik12   01/14/2020  Added Time_Stamp parameter and removed filter on Processing Status
-- rwesley2   05/13/2020  US1600015 VA multitab changes
-- Ashaik12   09/30/2020  US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_VA_VALIDT_CHANGE_ID] 
-- Input Parameter
 @Processing_ID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP DATETIME

AS
BEGIN TRY
	SET NOCOUNT ON;
	INSERT INTO PARWE02_BATCH_ERRORS
    Select 
		 STAGING.Source_c
		,STAGING.change_id
		,'Duplicate Change ID found in file'
		,@Processing_ID
		,filename
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP 
		,@CDSID
		,STAGING.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]  as ARWE02_BATCH_ERRORS_REF_K
		,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'           as ARWE02_STAGING_TABLE_X
		,'WARNING'
        ,STAGING.sheet_name                        as ARWE02_EXCEL_TAB_X
	    ,row_idx                                   as ARWE02_ROW_IDX
		,[change_id]
		,'' -- no arrow value
    FROM
    (	
	  SELECT
             S46.*
	        ,COUNT([change_id]) OVER (PARTITION BY S46.filename, s46.processing_ID, S46.change_id,s46.sheet_name) chg_id_count
            ,ROW_NUMBER() OVER (PARTITION BY S46.filename, s46.processing_ID, S46.change_id,s46.sheet_name  ORDER BY S46.change_id) AS rownum
	    FROM [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
	    JOIN [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
	      ON S45.Processing_ID       = S46.Processing_ID
         AND S45.filename            = S46.filename
	   Where S46.Processing_ID       = @Processing_ID
	    
	) STAGING
	Where chg_id_count > 1 
	and rownum > 1;


DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
-------------Change_id-------------------
-- Line Feed validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(change_id,char(10),'<LF>')           as [ARWE02_ERROR_VALUE],  --replace line feed with <LF>
	       'A change id can''t have an imbedded line feed <LF>'       as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       filename                                     as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K          as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'         as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       sheet_name                                   as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   replace(change_id,char(10),'<LF>')           as [ARWE02_Part_Index],
		   ''                                           as [ARWE02_ARROW_Value]
      FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO
     WHERE Processing_ID                        = @Processing_ID
	   and NullIf(PATINDEX(@pat10,change_id),0) > 0  --Looking for Line Feed 
    ;

DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
-- Carriage Return validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                 as [ARWE02_SOURCE_C],
	       replace(change_id,char(13),'<CR>')      as [ARWE02_ERROR_VALUE],  --replace carriage return with <CR>
	       'A change id can''t have an imbedded carriage return <CR>' as [ARWE02_ERROR_X],
	       Processing_ID                            as [ARWE02_PROCESSING_ID],
	       filename                                 as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                    as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                              as [ARWE02_CREATE_S],
           @CDSID                                   as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                              as [ARWE02_LAST_UPDT_S],
	       @CDSID                                   as [ARWE02_LAST_UPDT_USER_C],
	       ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K      as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'     as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                  as [ARWE02_ERROR_TYPE_X],
	       sheet_name                               as [ARWE02_EXCEL_TAB_X],
	       row_idx                                  as [ARWE02_ROW_IDX],
		   replace(change_id,char(13),'<CR>')       as [ARWE02_Part_Index],
		   ''                                       as [ARWE02_ARROW_Value]
      FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO
     WHERE Processing_ID                        = @Processing_ID
       and NullIf(PATINDEX(@pat13,change_id),0) > 0  --Looking for carriage 
    ;
END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
        ,'SYSTEM'
		,0                                 --row_idx
		,'' -- part index
		,'' -- arrow value
;
END CATCH;


GO
