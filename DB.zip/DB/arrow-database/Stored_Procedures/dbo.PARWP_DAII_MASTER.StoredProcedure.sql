SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASOLOSKY
-- Create date: 06/24/2019
-- Description:	Master Procedure to call Design Adjustment and Improvement Stored Procedures
--              Copied from the CCS Master procedure
-- =============================================
-- Changes
-- =============================================
-- Author     Date     User Story  Description
-- ------     -----    ----------  -----------
-- ASHAIK12  07/18                 Added the FILE_TYPE variable , GET_CCTSS_K procedure and the Load U73 Procedure
-- asolosky  07/19/2019	           Added PARWP_DAII_SCRUB_MARKUPS
-- asolosky  07/22/2019	           Added PARWP_DAII_VALIDT_PURCH_CMMDTY and PARWP_DAII_VALIDT_BNCHMK_VRNT
-- asolosky  08/01/2019	           Commented out the PARWP_DAII_VALIDT_WF_CTGRY procedure. The load procedure will default to 
--                                 empty string for lvl1 and lvl1
-- asamriya  08/22/2019            Added Parameter for Import Processing Status and 
-- asolosky  08/28/2019            Added PARWP_DAII_IMPRV_DELETE
-- asolosky  09/05/2019            Moved the PARWP_GET_CCTSS_KEY procedure so it's before the load and added the @CCTSS_K parameter to 
--                                 the PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure.
-- rwesley2  09/12/2019            Added PARWP_DAII_VALIDT_IMPROVEMENT_IDEAS
-- rwesley2	  09/17/2019           Added variables for upper/lower limits on SPs Assembly, Processing, Purchased Parts, and Raw Materials
-- asolosky   10/03/2019           Added PARWP_DAII_LOAD_U57_DSGN_SUB_ASSY to the consolidation
-- rwesley2	 10/08/2019	           removing upper/lower bound and changing to a comparison to a dollar value	 
-- ashaik12  10/10/2019            Adding PARWP_LOAD_U28_DMMY_SUB_ASSY_MRKUP 
-- rwesley2   10/11/2019            adding PARWP_DAII_LOAD_EXCHG_RATE
-- rwesley2  10/18/2019            added PARWP_DAII_VALIDT_CHANGE_ID and PARWP_DAII_VALIDT_IMPROVEMENT_ID
-- ashaik12  10/25/2019            Add validation for -- If quoted flag is YES check if the part made it to final table
-- rwesley2  11/08/2019            added scrub for special characters on staged tables 
-- ashaik12  11/14/2019            Added new procedure that load U85,U86 and U87 tables on import
-- ashaik12  11/23/2019            Added new procedure that validates added parts, validation to check if the added part is being binned to multiple sub-assemblies. 
-- asolosky	 11/26/2019            Removed PARWP_DAII_VALIDT_PART_NAME since the validation was moved to PARWP_DAII_VALIDT_PART_INDEX.
-- asolosky  12/09/2019            Added PARWP_DAII_UPDT_PARWS55_DAII_EXCHANGE_RATE_TAB Procedure.
-- ashaik12  01/14/2020            Added Time_Stamp parameter
-- ashaik12  02/11/2020            Added if/else logic to handle BoB versioning ('Pre PBOM' vs. 'PBOM and DA UI')
-- btemkow   02/14/2020            Added to and adjusted the sub-procedures in the 'PBOM and DA UI' branch
-- rwesley2  03/16/2020 US1500845  added imprv_supplier_delete to pre pbom so that changes to originator will be picked up.  This SP is already in PBOM section. 
-- asolosky  05/05/2020 US1575405  commented out the PARWP_DAII_LOAD_MFG_MARKUPS procedure.  Adding the multiple sub-assembly sheets
--                                  would cause an issue loading this table and the UI doesn't use these markups.  The UI uses the CCS markups.
-- ASHAIK12  06/03/2020            Add new Sub Assembly Validation for Post PBoM Load
-- asolosky  06/25/2020            Added the PARWP_DAII_SCRUB_SPCL_CHARS to code for PBOM Version. The scrub was changed to remove a line feed or carriage return at the end of character columns.
-- Asolosky  07/16/2020 US1774947  Remove procedure PARWP_DAII_VALIDT_QUOTED_PART_MISSING.  It was in the PRE-PBOM and PBOM section
-- Asolosky  07/27/2020 US1771016  Added PARWP_DAII_VALIDT_PART_NAME to the Pre PBOM section
-- Asolosky  09/04/2020 US1859270  Remove PARWP_LOAD_U28_DMMY_SUB_ASSY_MRKUP as it is not needed anymore
-- Asolosky  09/11/2020 US1910882  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12  12/12/2020 US2137799  Added new procedure to validate total after loading the base tables.
-- Asolosky  01/19/2021 US2164194  Changed the threshold from a dynamic number, which was in the UpperBound and LowerBound function, to a static number.
-- Asolosky  02/12/2021 US2267676  Replaced the 5 Pre Load DA Summary Validation procedures with PARWP_DA_VALIDT_SUMMARY_PRE, which included validation for markups
--                                 Replaced the 5 Pre Load II Summary Validation procedures with PARWP_II_VALIDT_SUMMARY_PRE, which included validation for markups
-- Asolosky  01/07/2022 US3190190  Added new logic (PARWP_CALC_MASTER_LOAD_PRIMARY) for populating the Calc tables at the end of the procedure 
-- Asolosky  05/23/2022 US3612606  Moved the DAII consolidation summary to PARWP_DAIICT_SUMMARY so it can be called from
--                                 multiple places.
-- Asolosky  06/02/2022 US3690513  Added procedure, PARWP_DA_DEL_TYP_COPY_FROM_GCS, to copy GCS purchpart, raw and processing data  
--                                 to equivalent DA tables when DA part is type Delete.  This will create a zero balance for the part.
-- =============================================
--DROP PROCEDURE [dbo].[PARWP_DAII_MASTER] 

CREATE or ALTER PROCEDURE [dbo].[PARWP_DAII_MASTER] 
	-- Add the parameters for the stored procedure here
@GUIDIN varchar(500), 
@CDSID  varchar(8),
@result varchar(MAX) Output

AS
Begin
 DECLARE @Processing_Status_x Varchar(500)
 DECLARE @CCTSS_K INT
 DECLARE @FILE_TYPE VARCHAR(50)
 DECLARE @Import_Status Varchar(500)
 DECLARE @threshold DECIMAL(5,3)
 DECLARE @TIME_STAMP DATETIME
 DECLARE @BoB_version VARCHAR(500)
 DECLARE @Error VARCHAR(500)
 DECLARE @Calculated_Value DECIMAL(38,18)
 DECLARE @Staging_Value DECIMAL(38,18)
 DECLARE @File_Name VARCHAR(500)
 DECLARE @Ref_K INT
 DECLARE @V_Threshold_A DECIMAL(38,18)
 DECLARE @AtLeast1_file_loaded int = 0;
 DECLARE @Primary_output_error VARCHAR(5000);
 DECLARE @u01_Study Varchar(100);
 DECLARE @T08_CCTSS_DSGN_SUPL  dbo.PARWT08_CCTSS_DSGN_SUPL;

 SET NOCOUNT ON;
 SET @Import_Status = 'Regular'
 SET @result       = '';
 SET @TIME_STAMP = GETUTCDATE()
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));


SELECT @BoB_version = (
	select u01.ARWA46_CCTSS_IMPT_VER_N 
	from PARWS34_DAII_COVER_PAGE_INFO s34
	join PARWU01_CCTSS_FLAT u01
		on s34.User_Selected_CTSP_N = u01.ARWU31_CTSP_N
		and s34.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.User_Selected_CTSP_Region_C = u01.ARWA06_RGN_C
		and s34.User_Selected_BNCMK_VRNT_N = u01.ARWU01_BNCHMK_VRNT_N
	where s34.Processing_ID = @GUIDIN
	group by u01.ARWA46_CCTSS_IMPT_VER_N
);

Select @V_Threshold_A = (Select ARWT01_THRESHOLD_A from PARWT01_THRESHOLD);

EXEC [dbo].[PARWP_GET_CCTSS_KEY]    @GUIDIN, @CCTSS_K OUTPUT,@FILE_TYPE='DAII';
Set @u01_Study = (Select U01.ARWU31_CTSP_N    + ' ' +
                         U01.ARWA06_RGN_C     + ' ' +
                   	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                    from PARWU01_CCTSS_FLAT U01
                   where U01.ARWU01_CCTSS_K = @CCTSS_K
 				 );

IF @BoB_version = 'Pre PBOM'  -- PRE PBoM


BEGIN -- Start of Validations that belong to PRE PBoM load
 
	 -- scrub for special characters on stage tables
	 EXEC [dbo].[PARWP_DAII_SCRUB_SPCL_CHARS]         @GUIDIN, @CDSID;
 
	 --Cover Page
	 EXEC [dbo].[PARWP_DAII_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_DAII_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP; 
	 EXEC [dbo].[PARWP_DAII_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_DAII_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;

	 EXEC [dbo].[PARWP_DAII_VALIDT_SUPPLIER]              @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages
	 EXEC [dbo].[PARWP_DAII_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages
 
	 EXEC [dbo].[PARWP_DAII_VALIDT_DUP_BOB]               @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_DAII_VALIDT_PURCH_CMMDTY]          @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning message

	 --Adjustment Details Validation
	 EXEC [dbo].[PARWP_DAII_VALIDT_TYPE_OF_CHANGE]       @GUIDIN, @CDSID, @TIME_STAMP;   --PRE PBOM only
	 EXEC [dbo].[PARWP_DAII_VALIDT_CHANGE_ID]            @GUIDIN, @CDSID, @TIME_STAMP;

	 --Improvement Ideas Validation
	 EXEC [dbo].[PARWP_DAII_VALIDT_IMPROVEMENT_IDEAS]      @GUIDIN, @CDSID, @TIME_STAMP; --PRE PBOM only
	 EXEC [dbo].[PARWP_DAII_VALIDT_IMPROVEMENT_ID]         @GUIDIN, @CDSID, @TIME_STAMP;

	  --Exchange Rate tab Validations
	 EXEC [dbo].[PARWP_DAII_VALIDT_CRNCY_CODE]            @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_DAII_VALIDT_SUPL_CRNCY]            @GUIDIN, @CDSID, @TIME_STAMP;

   	--Supplier Quote Validation 
	 EXEC [dbo].[PARWP_DAII_VALIDT_PART_INDEX]            @GUIDIN, @CDSID, @TIME_STAMP; --PRE PBOM only
	 EXEC [dbo].[PARWP_DAII_VALIDT_PART_NAME]             @GUIDIN, @CDSID, @TIME_STAMP; --PRE PBOM only
	 EXEC [dbo].[PARWP_DAII_VALIDT_PURCHASED_PARTS]       @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_RAW_MATERIALS]         @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_PROCESSING_COSTS]      @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_ASSEMBLY]              @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_MFG_MARKUP]            @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_DAII_VALIDT_BOM_QUOTED]            @GUIDIN, @CDSID, @TIME_STAMP;

	 -- Validate new part indexes coming from DA or II
	 EXEC [dbo].[PARWP_DAII_VALIDT_ADDED_PARTS]           @GUIDIN, @CDSID, @TIME_STAMP; --PRE PBOM only

	 -- Summary Data Validation
	 EXEC [dbo].[PARWP_DA_VALIDT_SUMMARY_PRE]             @GUIDIN, @CDSID,@TIME_STAMP,@V_Threshold_A;
	 EXEC [dbo].[PARWP_II_VALIDT_SUMMARY_PRE]             @GUIDIN, @CDSID,@TIME_STAMP,@V_Threshold_A;

	  BEGIN TRY
   
	   BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

		  --Update the S34 cover page table's error flag
		 EXEC [dbo].[PARWP_DAII_UPDATE_S34_COVER_ERROR_FLAG]           @GUIDIN;
 
		 --Load DAII
		 EXEC [dbo].[PARWP_DAII_LOAD_ADJUSTMENT_DETAILS]               @GUIDIN, @CDSID, @CCTSS_K, @TIME_STAMP;	--PRE PBOM only       -- U36,U37
       EXEC [dbo].[PARWP_DAII_CONSL_DELETE_SUM_TBLS]                 @CCTSS_K; --It will also be performed in PARWP_DAIICT_SUMMARY but I need the U73, U74 deleted before loading.
		 EXEC [dbo].[PARWP_DAII_LOAD_PURCHASED_PARTS]                  @GUIDIN, @CDSID, @TIME_STAMP; --U38
		 EXEC [dbo].[PARWP_DAII_LOAD_RAW_MTRLS]                        @GUIDIN, @CDSID, @TIME_STAMP; --U39
		 EXEC [dbo].[PARWP_DAII_LOAD_U40_PROCESSING_COSTS]		         @GUIDIN, @CDSID, @TIME_STAMP; --U40
		 EXEC [dbo].[PARWP_DAII_LOAD_ASSEMBLY]                         @GUIDIN, @CDSID, @TIME_STAMP; --U41
		 EXEC [dbo].[PARWP_DAII_LOAD_EXCHG_RATE] 	                     @GUIDIN, @CDSID, @TIME_STAMP; --U22
--		 EXEC [dbo].[PARWP_DAII_LOAD_MFG_MARKUPS]                      @GUIDIN, @CDSID, @TIME_STAMP;

		--Delete Improvement Idea Supplier Quotes
		 EXEC [dbo].[PARWP_DAII_IMPRV_DELETE]                          @GUIDIN, @CDSID;

		 --Delete Supplier-originated Improvement Ideas
  		 EXEC [dbo].[PARWP_DAII_IMPRV_SUPL_DELETE]                     @GUIDIN;
		  
		 --Load Improvement Ideas
		 EXEC [dbo].[PARWP_DAII_LOAD_DSGN_IMPRV_GRP]		               @GUIDIN, @CDSID, @TIME_STAMP; --U46
		 EXEC [dbo].[PARWP_DAII_LOAD_U48_PURC_PART]		               @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U49_RAW_MTRLS]		               @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U50_PROCESSING_COSTS]	            @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U51U53_ASSY]		                  @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U52U54_MFG_MRKP]	               @GUIDIN, @CDSID, @TIME_STAMP;
													       															       
		 -- Load DA Consolidation Tool data	
       -- There is no commit or catch in PARWP_DAIICT_SUMMARY
       EXEC [dbo].[PARWP_DAIICT_SUMMARY]                             @CCTSS_K, @CDSID, @TIME_STAMP;	       

	   -- Load Tradeoff tables
		 EXEC [dbo].[PARWP_DAII_LOAD_CCTSS_TRDOFF]                     @GUIDIN, @CDSID, @TIME_STAMP;  --PRE PBOM only --U85,U87

		 EXEC [dbo].[PARWP_DAII_UPDT_LAST_IMPT]                        @GUIDIN, @CDSID, @Import_Status;  

   -- POST LOAD VALIDATION CHECK
		--DA
		EXEC [dbo].[PARWP_DAW_VALIDT_SUMMARY_CST_POST] @GUIDIN,@CCTSS_K,@V_Threshold_A,@Error OUTPUT,@Calculated_Value OUTPUT,@Staging_Value OUTPUT,@File_Name OUTPUT,@Ref_K OUTPUT
    
		 IF @Error != ''  --Check if the post load summary validation generated an error 
			   Set @result        =  '***Post Load Error: Arrow calculated DA Total $' +CAST(@Calculated_Value as varchar(50)) +' using data loaded into base tables did not equal to Total on Summary sheet $'+CAST(@Staging_Value as varchar(50)) +' for Processing ID '+@GUIDIN ;

	-- DA Type=Delete; copy GCS/CCS to DA for purch part, raw, processing if there's a DA type=DELETE. This will zero out the GCS cost
	-- Must be done after post validation or an email will happen every time because of the copy.
      Insert into @T08_CCTSS_DSGN_SUPL 
      Select U08.ARWU08_CCTSS_DSGN_SUPL_K
        From PARWS34_DAII_COVER_PAGE_INFO S34
        JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT U08
          ON U08.ARWA03_ENRG_SUB_CMMDTY_X    = S34.User_Selected_ENRG_SUB_CMMDTY_X
         AND U08.ARWU31_CTSP_N					= S34.User_Selected_CTSP_N           
         AND U08.ARWA06_RGN_C						= S34.User_Selected_CTSP_Region_C    
         AND U08.ARWU01_BNCHMK_VRNT_N 			= S34.User_Selected_BNCMK_VRNT_N     
         AND U08.ARWA14_VEH_MAKE_N				= S34.User_Selected_VEH_MAKE_N       
         AND U08.ARWA34_VEH_MDL_N				= S34.User_Selected_VEH_MDL_N        
         AND U08.ARWA35_DSGN_VEH_MDL_VRNT_X	= S34.User_Selected_VEH_MDL_VRNT_X   
         AND U08.ARWA35_DSGN_VEH_MDL_YR_C		= S34.User_Selected_VEH_MDL_YR_C     
         AND U08.ARWA17_SUPL_N					= S34.User_Selected_SUPL_N           
         AND U08.ARWA17_SUPL_C					= S34.User_Selected_SUPL_C           
         AND U08.ARWA28_CNTRY_N					= S34.User_Selected_SUPL_CNTRY_N     
       Where S34.Processing_ID               = @GUIDIN
         AND S34.Skip_loading_due_to_error_f = 0;	
   	EXEC [dbo].[PARWP_DA_DEL_TYP_COPY_FROM_GCS]     @CCTSS_K, @T08_CCTSS_DSGN_SUPL, @CDSID, @TIME_STAMP;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table load for Calculations
--++++++++++++++++++++++++++++++++++++++++++++++++
	Set @AtLeast1_file_loaded = (Select Count(*) 
	                               From PARWS34_DAII_COVER_PAGE_INFO S34 
							      Where S34.Processing_ID               = @GUIDIN
								    and S34.Skip_loading_due_to_error_f = 0
							    );
	If IsNULL(@AtLeast1_file_loaded,0) > 0
       BEGIN
          exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
               @U01_k                = @CCTSS_K
             , @U06_k                = -1
             , @U04_k                = -1
             , @CDSID                = @CDSID
             , @TRIGGER              = 'DAW IMPORT'
             , @Primary_output_error = @Primary_output_error OUTPUT
          ;          
          If @Primary_output_error = ''
             Begin
                COMMIT TRANSACTION
                If @result = ''
				     Set @result = 'SUCCESS';
				Else Set @result = @result;  --Didn't need the ELSE but wanted to show there would be a POST load calculation error at this point
             End
          Else
             Begin
                Rollback
				If @result = ''
                     Set @result = 'Master Load Primary Error: ' + @Primary_output_error;
				Else Set @result = SUBSTRING(CONCAT('Master Load Primary Error: ', @Primary_output_error, ' ', @result),1,5000);  
             End
       End
	ELSE
	   BEGIN
          Set @result = 'SUCCESS'; --All files in the batch had a validation error. There should be no data to commit at this point but we should have something to match the begin transaction.
          COMMIT TRANSACTION;
	   End
    --End of: If IsNULL(@AtLeast1_file_loaded,0) > 0
	 END TRY

	 --CATCH
	 BEGIN CATCH
	   Rollback;

       Set @result = 'DAW_MASTER SYSTEM ERROR(Pre PBOM): ' +              
    	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
    	             ' |Study: '         + ISNULL(@u01_Study, '') +
    				 ' |Processing Id: ' + @GUIDIN +
    	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
    --	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
    	             ' |CDS: '           + @CDSID +
    	             ' |Procedure: '     + ERROR_PROCEDURE() + 
    				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
    				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
   
	    Set @Import_Status = 'Processing_Error';

		INSERT INTO PARWE02_BATCH_ERRORS
		SELECT  
			 'SYSTEM'                          --source_c
			,'Catch Error'                     --error_value
			,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
			,@GUIDIN                           --Processing_id
			,'UNKNOWN'                         --Filename
			,ERROR_PROCEDURE()                 --Procedure_x
			,@TIME_STAMP 
			,@CDSID
			,@TIME_STAMP
			,@CDSID
			,NULL 
			,NULL
			--ARWE02_BATCH_ERRORS_K (Identity key)
			,'ERROR'
			,'DAII MASTER PROCEDURE'
			,0                                 --row_idx
		    ,''  --Part_index
		    ,''  --Arrow value
			;

		 EXEC [dbo].[PARWP_DAII_UPDT_LAST_IMPT]                        @GUIDIN, @CDSID, @Import_Status;

	  END CATCH;


--RETURN @result
END;




ELSE --@BoB_version = 'PBOM and DA UI'

BEGIN -- Start of Validations that belong to 'PBOM and DA UI' load

	-- scrub for special characters on stage tables 
    EXEC [dbo].[PARWP_DAII_SCRUB_SPCL_CHARS]         @GUIDIN, @CDSID;
	
	--Cover Page validations, same as 'Pre PBOM' 
	EXEC [dbo].[PARWP_DAII_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_DAII_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP; 
	EXEC [dbo].[PARWP_DAII_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_DAII_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;

	EXEC [dbo].[PARWP_DAII_VALIDT_SUPPLIER]              @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages
	EXEC [dbo].[PARWP_DAII_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages
 
	EXEC [dbo].[PARWP_DAII_VALIDT_DUP_BOB]               @GUIDIN, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_DAII_VALIDT_PURCH_CMMDTY]          @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning message

	--Check for duplicate Change IDs/Improvement IDs in file, same as 'Pre PBOM'
	EXEC [dbo].[PARWP_DAII_VALIDT_CHANGE_ID]            @GUIDIN, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_DAII_VALIDT_IMPROVEMENT_ID]         @GUIDIN, @CDSID, @TIME_STAMP;
	
	--For 'PBOM and DA UI' Design Adjustment Details and Ford-originated Improvement Ideas must match Arrow
	EXEC [dbo].[PARWP_DAII_VALIDT_DSGN_ADJ]               @GUIDIN, @CDSID, @TIME_STAMP;  --PBOM only
	EXEC [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_FORD]        @GUIDIN, @CDSID, @TIME_STAMP;  --PBOM only

	--For 'PBOM and DA UI' validate Supplier-originated Improvement Ideas and added BOM parts
	EXEC [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_SUPL]        @GUIDIN, @CDSID, @TIME_STAMP;  --PBOM only

	-- Sub - Assembly validation
	EXEC [dbo].[PARWP_DAII_VALIDT_SUB_ASSEMBLY]           @GUIDIN, @CDSID, @TIME_STAMP;  --PBOM only

	--Exchange Rate tab Validations, same as 'Pre PBOM'
	EXEC [dbo].[PARWP_DAII_VALIDT_CRNCY_CODE]            @GUIDIN, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_DAII_VALIDT_SUPL_CRNCY]            @GUIDIN, @CDSID, @TIME_STAMP;

	--Supplier Quote Validation, same as 'Pre PBOM'
	 EXEC [dbo].[PARWP_DAII_VALIDT_PURCHASED_PARTS]       @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_RAW_MATERIALS]         @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_PROCESSING_COSTS]      @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_ASSEMBLY]              @GUIDIN, @CDSID, @TIME_STAMP,@threshold=0.005;
	 EXEC [dbo].[PARWP_DAII_VALIDT_MFG_MARKUP]            @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_DAII_VALIDT_BOM_QUOTED]            @GUIDIN, @CDSID, @TIME_STAMP;

	 -- Summary Data Validation, same as 'Pre PBOM'
	 EXEC [dbo].[PARWP_DA_VALIDT_SUMMARY_PRE]             @GUIDIN, @CDSID,@TIME_STAMP,@V_Threshold_A;
	 EXEC [dbo].[PARWP_II_VALIDT_SUMMARY_PRE]             @GUIDIN, @CDSID,@TIME_STAMP,@V_Threshold_A;

	BEGIN TRY
	BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

		  --Update the S34 cover page table's error flag
		 EXEC [dbo].[PARWP_DAII_UPDATE_S34_COVER_ERROR_FLAG]           @GUIDIN;

		 --Load DAII
											       
		--Delete Design Adjustment Supplier Quotes
		--Note: This procedure contains delete logic pulled from PARWP_DAII_LOAD_ADJUSTMENT_DETAILS in 'Pre PBOM'
		 EXEC [dbo].[PARWP_DAII_ADJ_DELETE]                            @GUIDIN, @CDSID, @CCTSS_K, @TIME_STAMP;	  --PBOM only
       EXEC [dbo].[PARWP_DAII_CONSL_DELETE_SUM_TBLS]                 @CCTSS_K; --It will also be performed in PARWP_DAIICT_SUMMARY but I need the U73, U74 deleted before loading.
		--Load Design Adjustment Supplier Quotes		 												       
		 EXEC [dbo].[PARWP_DAII_LOAD_PURCHASED_PARTS]                  @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_RAW_MTRLS]                        @GUIDIN, @CDSID, @TIME_STAMP;   
		 EXEC [dbo].[PARWP_DAII_LOAD_U40_PROCESSING_COSTS]		       @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_ASSEMBLY]                         @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_EXCHG_RATE] 	                   @GUIDIN, @CDSID, @TIME_STAMP;
	--	 EXEC [dbo].[PARWP_DAII_LOAD_MFG_MARKUPS]                      @GUIDIN, @CDSID, @TIME_STAMP;

		--Delete Improvement Idea Supplier Quotes
		 EXEC [dbo].[PARWP_DAII_IMPRV_DELETE]                          @GUIDIN, @CDSID;

		 --Delete and Load Supplier-originated Improvement Ideas
		 EXEC [dbo].[PARWP_DAII_IMPRV_SUPL_DELETE]                     @GUIDIN;
		 EXEC [dbo].[PARWP_DAII_LOAD_DSGN_IMPRV_GRP]		           @GUIDIN, @CDSID, @TIME_STAMP;

		 --Load Improvement Idea Supplier Quotes
		 EXEC [dbo].[PARWP_DAII_LOAD_U48_PURC_PART]		               @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U49_RAW_MTRLS]		               @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U50_PROCESSING_COSTS]	           @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U51U53_ASSY]		               @GUIDIN, @CDSID, @TIME_STAMP;
		 EXEC [dbo].[PARWP_DAII_LOAD_U52U54_MFG_MRKP]	               @GUIDIN, @CDSID, @TIME_STAMP;
	
		 -- Load DA Consolidation Tool data	- Performs DAII_CONSL_DELETE_SUM_TBLS and U57, U73, U74 summary loads
       -- There is no commit or catch in PARWP_DAIICT_SUMMARY
       EXEC [dbo].[PARWP_DAIICT_SUMMARY]                             @CCTSS_K, @CDSID, @TIME_STAMP;	      

		 -- Load Tradeoff tables for Supplier-originated II only
		 EXEC [dbo].[PARWP_DAII_LOAD_TRDOFF_IMPRV_SUPL]	               @GUIDIN, @CDSID, @TIME_STAMP;   --PBOM only

		EXEC [dbo].[PARWP_DAII_UPDT_LAST_IMPT]                        @GUIDIN, @CDSID, @Import_Status;

   -- POST LOAD VALIDATION CHECK
		--DA
		EXEC [dbo].[PARWP_DAW_VALIDT_SUMMARY_CST_POST] @GUIDIN,@CCTSS_K,@V_Threshold_A,@Error OUTPUT,@Calculated_Value OUTPUT,@Staging_Value OUTPUT,@File_Name OUTPUT,@Ref_K OUTPUT
    
		 IF @Error != ''  --Check if the post load summary validation generated an error 
			   Set @result =  '***Post Load Error: Arrow calculated DA Total $' +CAST(@Calculated_Value as varchar(50)) +' using data loaded into base tables did not equal to Total on Summary sheet $'+CAST(@Staging_Value as varchar(50)) +' for Processing ID '+@GUIDIN ; 
--		Set @result = '***Post Load Error: Arrow calculated DA Total $' + '0' + ' using data loaded into base tables did not equal to Total on Summary sheet $'+ '0'  +' for Processing ID '+@GUIDIN ;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- DA Type=Delete; copy GCS/CCS to DA for purch part, raw, processing when there's a DA type of DELETE. This will zero out the GCS cost
-- Must be done after post validation or an email will happen every time because of the copy.
--++++++++++++++++++++++++++++++++++++++++++++++++
      Insert into @T08_CCTSS_DSGN_SUPL 
      Select U08.ARWU08_CCTSS_DSGN_SUPL_K
        From PARWS34_DAII_COVER_PAGE_INFO S34
        JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT U08
          ON U08.ARWA03_ENRG_SUB_CMMDTY_X    = S34.User_Selected_ENRG_SUB_CMMDTY_X
         AND U08.ARWU31_CTSP_N					= S34.User_Selected_CTSP_N           
         AND U08.ARWA06_RGN_C						= S34.User_Selected_CTSP_Region_C    
         AND U08.ARWU01_BNCHMK_VRNT_N 			= S34.User_Selected_BNCMK_VRNT_N     
         AND U08.ARWA14_VEH_MAKE_N				= S34.User_Selected_VEH_MAKE_N       
         AND U08.ARWA34_VEH_MDL_N				= S34.User_Selected_VEH_MDL_N        
         AND U08.ARWA35_DSGN_VEH_MDL_VRNT_X	= S34.User_Selected_VEH_MDL_VRNT_X   
         AND U08.ARWA35_DSGN_VEH_MDL_YR_C		= S34.User_Selected_VEH_MDL_YR_C     
         AND U08.ARWA17_SUPL_N					= S34.User_Selected_SUPL_N           
         AND U08.ARWA17_SUPL_C					= S34.User_Selected_SUPL_C           
         AND U08.ARWA28_CNTRY_N					= S34.User_Selected_SUPL_CNTRY_N     
       Where S34.Processing_ID               = @GUIDIN
         AND S34.Skip_loading_due_to_error_f = 0;	
   	EXEC [dbo].[PARWP_DA_DEL_TYP_COPY_FROM_GCS]     @CCTSS_K, @T08_CCTSS_DSGN_SUPL, @CDSID, @TIME_STAMP;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table load for Calculations
--++++++++++++++++++++++++++++++++++++++++++++++++
	Set @AtLeast1_file_loaded = (Select Count(*) 
	                               From PARWS34_DAII_COVER_PAGE_INFO S34 
							      Where S34.Processing_ID               = @GUIDIN
								    and S34.Skip_loading_due_to_error_f = 0
							    );
    --select 'files loaded ' + cast(@AtLeast1_file_loaded as varchar(10));
	If IsNULL(@AtLeast1_file_loaded,0) > 0
       BEGIN
          exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
               @U01_k                = @CCTSS_K
             , @U06_k                = -1
             , @U04_k                = -1
             , @CDSID                = @CDSID
             , @TRIGGER              = 'DAW IMPORT'
             , @Primary_output_error = @Primary_output_error OUTPUT
          ;          
          If @Primary_output_error = ''
             Begin
                COMMIT TRANSACTION
                If @result = ''
				     Set @result = 'SUCCESS';
				Else Set @result = @result;  --Didn't need the ELSE but wanted to show there would be a POST load calculation error at this point
             End
          Else
             Begin
                Rollback
				If @result = ''
                     Set @result = 'Master Load Primary Error: ' + @Primary_output_error;
				Else Set @result = SUBSTRING(CONCAT('Master Load Primary Error: ', @Primary_output_error, ' ', @result),1,5000);  
             End
       End
	ELSE
	   BEGIN
          Set @result = 'SUCCESS'; --All files in the batch had a validation error. There should be no data to commit at this point but we should have something to match the begin transaction.
          COMMIT TRANSACTION;
	   End
    --End of: If IsNULL(@AtLeast1_file_loaded,0) > 0
	END TRY
 

--CATCH
	BEGIN CATCH
	   Rollback;

       Set @result = 'DAW_MASTER SYSTEM ERROR: ' +              
    	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
    	             ' |Study: '         + ISNULL(@u01_Study, '') +
    				 ' |Processing Id: ' + @GUIDIN +
    	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
    --	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
    	             ' |CDS: '           + @CDSID +
    	             ' |Procedure: '     + ERROR_PROCEDURE() + 
    				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
    				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
    
	    Set @Import_Status = 'Processing_Error';

		INSERT INTO PARWE02_BATCH_ERRORS
		SELECT  
			 'SYSTEM'                          --source_c
			,'Catch Error'                     --error_value
			,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
			,@GUIDIN                           --Processing_id
			,'UNKNOWN'                         --Filename
			,ERROR_PROCEDURE()                 --Procedure_x
			,@TIME_STAMP 
			,@CDSID
			,@TIME_STAMP
			,@CDSID
			,NULL 
			,NULL
			--ARWE02_BATCH_ERRORS_K (Identity key)
			,'ERROR'
			,'DAII MASTER PROCEDURE'
			,0                                 --row_idx
			,'' --part index
			,'' --arrow value
			;

		 EXEC [dbo].[PARWP_DAII_UPDT_LAST_IMPT]                        @GUIDIN, @CDSID, @Import_Status;

	  END CATCH;	
--	  RETURN @result

END

END




GO
