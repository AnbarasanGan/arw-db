DROP PROCEDURE IF EXISTS  [dbo].[PARWP_TYGRA_UI_LOAD_STAGE_TBLS_PROC_TBL] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load S61 and S62 from PARWP05_TYGRA_LOAD processing table
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_STAGE_TBLS_PROC_TBL] 
	-- Add the parameters for the stored procedure here

-- Input Parameter

@processing_id varchar(MAX)


AS

DECLARE @TYGRA_ID_K int
--DECLARE @U41_ProgramNm varchar(MAX);
--DECLARE @BCJU41_FileNameSPTygra Varchar(MAX);
--DECLARE @BCJU41_WRKSHP_NUM_C  Varchar(MAX);
--DECLARE @BCJU41_WRKSHP_STATUS_C Varchar(MAX)
--DECLARE @guid uniqueidentifier = NEWID();
--DECLARE @BCJU51_VERSION_F INT;
--
--SELECT @guid as 'GUID'






-- S61 load
INSERT INTO PARWS61_TYGRA_TITLE_PAGE
select * from (
select  
p05.Processing_ID            as processing_id
 ,'TYGRA'+' '+'-'+' '+ p05.File_source  as source
,p05.bcju41_programnm        as program
,[BCJU45_CCM_X]              as CCM
,a06.ACTA06_ACT_REGION_N     as region
,[BCJU45_SERIES_X]           as series 
,[BCJU45_TAKE_RATE_A]        as take_rate
,[BCJU45_ENGINE_X]           as engine
,[BCJU45_TRANS_X]            as transmission
,[BCJU45_DESC_X]             as description
,ISNULL([BCJU41_DATEOFDATAPULL_X],'1900-01-01')   as data_pull_date  ------data pull date goes here
,u41.[BCJU41_FileNameSPTygra]    as filename 
,1                           as row_indx ----row index goes here
,getutcdate()                as create_dt
,p05.CREATE_USER_C           as create_user
,getutcdate()                as update_dt
,p05.CREATE_USER_C           as update_user
,[BCJU45_CM_PGM_X]           as CM_PROGRAM
,[BCJU45_CM_NCKNM_N]         as CM_NICKNAME
,[BCJU45_CM_MDLYR_A]         as CM_MDLYR
from [dbo].[PBCJU45_TYGRA_HEADER_SYN] u45
join [dbo].[PBCJU41_TYGRA_SYN] u41
on u45.[BCJU41_TYGRA_ID_K] = u41.[BCJU41_TYGRA_ID_K]
left join [dbo].[PACTA06_ACT_REGION_SYN] a06
on u45.[ACTA06_ACT_REGION_K] = a06.[ACTA06_ACT_REGION_K]
join PARWP05_TYGRA_LOAD  p05
on u45.[BCJU41_TYGRA_ID_K] = p05.[BCJU41_TYGRA_ID_K]
 where p05.Processing_ID = @processing_id
)x
 ;

 
-- s62 load
INSERT INTO PARWS62_TYGRA_SUMMARY
select * from (
select  
  p05.processing_id           as processing_id
 ,'TYGRA'+' '+'-'+' '+ p05.File_source  as source
 ,p05.bcju41_programnm        as vehicle_name
 ,[BCJU44_fldPMT]             as PMT  
 ,[BCJU44_fldcm1]             as CM1
 ,BCJU44_fldcm2               as CM2
 ,BCJU44_fldcm3               as CM3
 ,BCJU44_fldcm4               as CM4
 ,BCJU44_fldcm5               as CM5 
 ,[BCJU44_fldcm6]             as CM6
 ,[BCJU44_fldcm7]             as CM7
 ,[BCJU44_fldcm8]             as CM8
 ,[BCJU44_fldcm9]             as CM9
 ,[BCJU44_NO_CM_F]            as nonCM
 ,[BCJU44_fldEngCom]          as eng_commodity
 ,[BCJU44_fldPre]             as Surrogate_Part_Prefix
 ,[BCJU44_fldBase]            as Surrogate_Part_Base 
 ,[BCJU44_fldSuf]             as Surrogate_Part_Suffix 
 ,[BCJU44_fldParDes]          as Surrogate_Part_Desc
 ,[BCJU44_fldPLPre]           as Start_Point_Part_Prefix
 ,[BCJU44_fldPLBase]          as Start_Point_Part_Base
 ,[BCJU44_fldPLSuf]           as Start_Point_Part_Suffix
 ,[BCJU44_fldPartDes]         as Start_Point_Part_Desc
 ,[BCJU44_fldFinSurPrg]       as Finance_Surrogate_Program
 ,[BCJU44_fldSurrUSD]         as Surrogate_Cost  --var to dec
 ,[BCJU44_fldPLCPSC]          as Start_Point_CPSC --varchar
 ,[BCJU44_fldStPtvsVP]        as Start_Point_Vehicle_Price  --var to dec
 ,[BCJU44_fldspe]             as Start_Point_Efficiency  -- var to dec
 ,[BCJU44_fldQty]             as Finance_Surrogate_Quantity  --decimal
 ,[BCJU44_fldPrtLevQty]       as Start_Point_Quantity --dec
 ,[BCJU44_fldLAttTotal]       as Compatibilities  --dec
 ,[BCJU44_fldlatttoteff]      as Compatibilities_Efficiency
 ,[BCJU44_fldMEV]             as MEV   --var to dec
 ,[BCJU44_fldRAttTot]         as Job1_Attributes
 ,[BCJU44_fldRAttTotEff]      as Job1_Attributes_Efficiency
 ,[BCJU44_fldJ1Target]        as Job1_Target --var to dec
 ,[BCJU44_fldpartlevci]      as WS2_Part_Level_Commonality
 ,[BCJU44_fldprteffmeth]      as WS2_Part_Level_Eff_Methodology_Calculation 
 ,[BCJU44_fldprtreduct]       as Part_Level_Reduction
 ,[BCJU44_fldBoBPIAEI]        as BoB_PIA_End_Item
 ,[BCJU44_fldbobnm]           as BoB_Enrg_Sub_commodity
 ,ISNULL([BCJU44_fldctvm],0)  as Commerical_TVM  --[BCJU44_fldCommercialTVMPct] or [BCJU44_fldctvm] or fldctvmcpct
 ,ISNULL([BCJU44_flddtvm],0)  as Design_TVM  --[BCJU44_fldDesignTVMPct] or [BCJU44_flddtvm] or flddtvmpct
 ,cast([BCJU44_flduniqid] as INT)  as Tygra_Unique_ID
 ,u41.[BCJU41_FileNameSPTygra]    as filename 
 ,ISNULL(BCJU44_ROW_ID_F,1)   as row_indx 
 ,getutcdate()                as create_dt
 ,p05.CREATE_USER_C           as create_user
 ,getutcdate()                as update_dt
 ,p05.CREATE_USER_C           as update_user
 ,BCJU44_fldcm10              as NON_CM1
 ,BCJU44_fldcm11              as NON_CM2
 ,BCJU44_fldcm12              as NON_CM3
 ,BCJU44_fldcm13              as NON_CM4
 ,BCJU44_fldcm14              as NON_CM5
 ,BCJU44_fldcm15              as NON_CM6
 ,NULL                        as NON_CM7
 ,NULL                        as NON_CM8
 ,NULL                        as NON_CM9
 ,[BCJU44_sur_pgm_cmdty]      as Surrogate_Program_Used_for_Commodity_Start_Point 
 ,[BCJU44_fldwcat]            as WCAT_Category  
 ,[BCJU44_fldlatt1]           as Compatibilities1
 ,[BCJU44_fldlatt1wcat]       as Compatibilities1_WCAT
 ,[BCJU44_fldlatt1des]        as Compatibilities1_Desc
 ,[BCJU44_fldlatt2]           as Compatibilities2
 ,[BCJU44_fldlatt2wcat]       as Compatibilities2_WCAT
 ,[BCJU44_fldlatt2des]        as Compatibilities2_Desc
 ,[BCJU44_fldlatt3]           as Compatibilities3
 ,[BCJU44_fldlatt3wcat]       as Compatibilities3_WCAT 
 ,[BCJU44_fldlatt3des]        as Compatibilities3_Desc
 ,[BCJU44_fldratt1]           as Job1_Attributes1
 ,[BCJU44_fldratt1wcat]       as Job1_Attributes1_WCAT
 ,[BCJU44_fldratt1des]        as Job1_Attributes1_Desc
 ,[BCJU44_fldratt2]           as Job1_Attributes2
 ,[BCJU44_fldratt2wcat]       as Job1_Attributes2_WCAT
 ,[BCJU44_fldratt2des]        as Job1_Attributes2_Desc 
 ,[BCJU44_fldratt3]           as Job1_Attributes3
 ,[BCJU44_fldratt3wcat]       as Job1_Attributes3_WCAT
 ,[BCJU44_fldratt3des]        as Job1_Attributes3_Desc
 ,[BCJU44_fldplatth]          as Platform_Tophat
 ,[BCJU44_fldmfgreg]          as MFG_Region
 ,[BCJU44_fldstvssudes]       as ST_v_SU_Desc
 ,[BCJU44_fldcomments]        as Comments
 ,[BCJU44_FB_PN_PLN_C]        as FEDEBOM_PN_Plan
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLPre] else [BCJU44_fldnewprtpre]  END  as FEDEBOM_Planned_Prefix
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLBase] else [BCJU44_fldnewprtbase] END    as FEDEBOM_Planned_Base
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLSuf] else [BCJU44_fldnewprtsuff] END    as FEDEBOM_Planned_Suffix 
 ,[BCJU44_FB_VAR_CNT_F]       as FEDEBOM_Variant_Cnt
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldBoBPIAEI]  else [BCJU44_FB_BOB_PIA_EI_X] END   as FEDEBOM_bob_pia_ei

 from [dbo].[PBCJU44_TYGRA_DETAILS_SYN] u44
 join [dbo].[PBCJU41_TYGRA_SYN] u41
on u44.[BCJU41_TYGRA_ID_K] = u41.[BCJU41_TYGRA_ID_K]
join PARWP05_TYGRA_LOAD p05
on u44.[BCJU41_TYGRA_ID_K] = p05.[BCJU41_TYGRA_ID_K]
  where p05.Processing_ID = @processing_id
 )x
 ;








GO


