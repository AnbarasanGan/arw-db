DROP PROCEDURE [dbo].[PARWP_DAII_UPDATE_S34_COVER_ERROR_FLAG]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 06/28/2019
-- Description:	Select the DAII COVER PAGE staging records and join to the error table in order to find errors
--              If the error_type_x is 'ERROR' or 'SYSTEM', set the skip_load_f to 1 (YES)
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 09/11/2020  Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_UPDATE_S34_COVER_ERROR_FLAG] 
-- Input Parameter
@GUIDIN Varchar(5000)

AS

SET NOCOUNT ON;

     --	Merge on Cover page to stop processing a file if there's an error 
     MERGE INTO PARWS34_DAII_COVER_PAGE_INFO S34_TARGET
     USING
     (Select * From
         (Select 
                 S34.Processing_ID
               , S34.filename
               , row_number() over (partition by S34.Processing_ID, S34.filename Order by E02.ARWE02_ERROR_TYPE_X) as rownum
               , ARWE02_ERROR_TYPE_X
               , CASE WHEN ARWE02_ERROR_TYPE_X in ('ERROR','SYSTEM') Then 1 Else 0  END Skip_loading_f
            From PARWS34_DAII_COVER_PAGE_INFO S34
       LEFT JOIN PARWE02_BATCH_ERRORS         E02
              ON E02.ARWE02_PROCESSING_ID = S34.Processing_ID  
             AND E02.ARWE02_FILENAME      = S34.filename
           WHERE S34.PROCESSING_ID        = @GUIDIN
          ) Stg_Err
        Where rownum = 1
      ) S34_SOURCE

      on (S34_TARGET.Processing_ID = S34_SOURCE.Processing_ID AND
          S34_TARGET.FILENAME      = S34_SOURCE.FILENAME
         )
    when MATCHED THEN
         UPDATE SET          
     	    S34_TARGET.Skip_loading_due_to_error_f = IsNull(Skip_loading_f,0)
;

GO
