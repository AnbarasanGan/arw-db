DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_PART_NAME]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 07/24/2020
-- Description:	checks for part name
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_VALIDT_PART_NAME] 
-- Input Parameter
 @Processing_ID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP    DATETIME

AS
BEGIN TRY
SET NOCOUNT ON;

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Err.[Source_c]                            as [ARWE02_SOURCE_C],
	         replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>')    as [ARWE02_ERROR_VALUE],
	         'Part Name does not match the Arrow part name'                 as [ARWE02_ERROR_X],
	         Err.[Processing_ID]                       as [ARWE02_PROCESSING_ID],
	         Err.[filename]                            as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                     as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                               as [ARWE02_CREATE_S],
	         @CDSID                                    as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                               as [ARWE02_LAST_UPDT_S],
	         @CDSID                                    as [ARWE02_LAST_UPDT_USER_C],
	         Err.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'    as [ARWE02_STAGING_TABLE_X],
	         'ERROR'                                   as [ARWE02_ERROR_TYPE_X],
	         Err.sheet_name                            as [ARWE02_EXCEL_TAB_X],
	         Err.row_idx,
		     change_id,
		     ARWU18_BOM_PART_X  -- ARROW Value
       FROM 
       (
        SELECT 
               S35.Processing_ID,
		       Case When S35.part_name = '' Then '<Blank>' Else S35.part_name End as part_name,
			   S35.part_index,
			   S35.change_id,
		       U18.ARWU18_BOM_PART_X,
		       S35.Source_c,
		       S35.filename,
               ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K,
			   s35.sheet_name,
		       S35.row_idx
			--   CASE WHEN S35.part_name != U18.ARWU18_BOM_PART_X then 'ERROR' ELSE '' END as is_Error
          FROM [dbo].PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
		  JOIN PARWS34_DAII_COVER_PAGE_INFO               S34
            ON S34.Processing_ID              = S35.Processing_ID
           AND S34.filename                   = S35.filename
 		  JOIN PARWU01_CCTSS_FLAT   U01    
            ON U01.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
           AND U01.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
           AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
           AND U01.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N
 		  JOIN PARWU18_BOM_PART U18
 		    ON U18.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
 		   AND U18.ARWU18_BOM_PART_IX_N = S35.part_index
         WHERE S35.Processing_ID        = @Processing_ID
		   and s35.type_of_change      in ('DELETE','MODIFY')
		   and S35.part_name           != U18.ARWU18_BOM_PART_X
       ) Err
;

DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
-------------Part_Name-------------------
-- Line Feed validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(part_name,char(10),'<LF>')           as [ARWE02_ERROR_VALUE],  --replace line feed with <LF>
	       'A part name can''t have an imbedded line feed <LF>'       as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       filename                                     as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K        as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'       as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       sheet_name                                   as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   replace(change_id,char(10),'<LF>'),
		   ''  -- ARROW Value

      FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO
     WHERE Processing_ID                        =  @Processing_ID
	   and NullIf(PATINDEX(@pat10,part_name),0) > 0  --Looking for Line Feed 
    ;

-- Carriage Return validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                 as [ARWE02_SOURCE_C],
	       replace(part_name,char(13),'<CR>')      as [ARWE02_ERROR_VALUE],  --replace carriage return with <CR>
	       'A part name can''t have an imbedded carriage return <CR>' as [ARWE02_ERROR_X],
	       Processing_ID                            as [ARWE02_PROCESSING_ID],
	       filename                                 as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                    as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                              as [ARWE02_CREATE_S],
           @CDSID                                   as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                              as [ARWE02_LAST_UPDT_S],
	       @CDSID                                   as [ARWE02_LAST_UPDT_USER_C],
	       ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K    as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'   as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                  as [ARWE02_ERROR_TYPE_X],
	       sheet_name                               as [ARWE02_EXCEL_TAB_X],
	       row_idx                                  as [ARWE02_ROW_IDX],
		   replace(change_id,char(13),'<CR>'),
		   ''  -- ARROW Value
      FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO
     WHERE Processing_ID                        =  @Processing_ID
       and NullIf(PATINDEX(@pat13,part_name),0) > 0  --Looking for carriage 
    ;
END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
        ,'SYSTEM'
		,0                                 --row_idx
        ,''                                --Part_index
	    ,''                                --Arrow value
;
END CATCH;	



GO
