DROP PROCEDURE IF EXISTS [dbo].[PARWP_TYGRA_UI_GET_FILE_LIST_UI] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Get tygra file(s) to process
-- business rules: returned list of files from ACT based on Program name. SP is used in the UI
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2	  05-06-2021  US2458193 use SYNONYM for linked server name 
-- rwesley2	  07-29-2021  US2747200 replace global temp table with processing table
--                        changed global temp to local temp. renamed SP because it can only be used with the new
--                        SP using the processing table. These SPs end wtih _PROC_TBL. Will not work the old process.
-- rwesley    09-15-2021  US2879211 - load Curent files.  Added TYGRA_FILE_TYPE_N to temp table and insert.  Using ACT
--                        V54 to verify whether a file is CURRENT or SCOPE  
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_FILE_LIST_UI] 

-- Add the parameters for the stored procedure here

-- Input Parameter
@U41_ProgramNm varchar(50) 

AS
SET NOCOUNT ON;
 
CREATE TABLE #file_list (
         BCJU41_ProgramNm   varchar(50)   
        ,TYGRA_FILE_TYPE_N varchar(50)
        ,BCJU41_WRKSHP_NUM_C  varchar(50)      
        ,BCJU41_WRKSHP_STATUS_C varchar(10)
		,BCJU41_FileNameSPTygra Varchar(1000)
	    ,BCJU51_VERSION_F  INT
		,BCJU41_TygraSPFileLastModifiedDtTm datetime
        ,BCJU41_TYGRA_ID_K INT
		                        )
 	;

---******************************************************
-- in UI user selects program.  Program is passed to ACT V53 and a list of file names is returned to UI. 
 --******************************************************

-- returns all distinct files
INSERT INTO #file_list
select 
v53.[BCJU41_ProgramNm]    
,case when (v54.[BCJU41_WRKSHP_NUM_C] = 'Post WS3' and v54.[BCJU41_WRKSHP_STATUS_C] = 'Frozen') then 'Current'
  else 'Scope'
  end as TYGRA_FILE_TYPE_N
,v53.[BCJU41_WRKSHP_NUM_C]        
,v53.[BCJU41_WRKSHP_STATUS_C]   
,v53.[BCJU41_FileNameSPTygra]    
,v53.[BCJU51_VERSION_F]
,v53.[BCJU41_TygraSPFileLastModifiedDtTm] 
,v53.[BCJU41_TYGRA_ID_K]
 from [dbo].[PBCJV53_TYGRA_ARROW_LNK_SYN] v53
 left join [dbo].[PBCJV54_TYGRA_VOLTRON_SYN] v54
 on v53.[BCJU41_TYGRA_ID_K] = v54.[BCJU41_TYGRA_ID_K]
where v53.BCJU41_ProgramNm = @U41_ProgramNm 
;

-- displays list for user to select from
select * from  #file_list



GO


