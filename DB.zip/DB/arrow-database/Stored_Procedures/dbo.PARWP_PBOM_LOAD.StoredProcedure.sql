DROP PROCEDURE [dbo].[PARWP_PBOM_LOAD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2019
-- Description:	Select the records in the Staging table for the import Processing_id. These staging records will be loaded into Arrow.
--              If CCS is present then Insert
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
--              The numeric data, like quantity, is varchar in the staging table. It must be converted to a float 
--              and truncated to 9 decimal places before inserting into Arrow.  Depth is no longer considered numeric.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 02/25/2020  rwesley2           added PBOM 5.5 load for end item tables (A47 & U63)
-- 05/08/2020  ASHAIK12           US1542194 -- Update U63 insert to include [ARWU04_CCTSS_VRNT_K] key
-- 05/14/2020  asolosky US1616235 add diameter to the U19 insert
-- 05/22/2020  asolosky US1592745 Added sub_assembly_idx_c to the U17 insert.
--                                Also removed all the not exists from U17, U18, U19 since this code is insert only.
-- 03/18/2021  asolosky US2385952 Table PARWU63_BOM_PART_END_ITM was changed to PARWU63_VRNT_BOM_PART_END_ITM
-- 03/18/2021  asolosky US2563353 25 sub assemblies.  Changed the U17 insert to use the function PARWF_ASSIGN_ARWU17_SEQ_R to populate ARWU17_BOM_SUB_ASSY_SEQ_R
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_PBOM_LOAD] 
-- Input Parameter
 @Processing_ID Varchar(5000)
,@CDSID	        Varchar(30)
,@TIME_STAMP    DATETIME
,@CCTSS_K       Int
AS

Declare @PBOM_Available               Varchar(1) = 'N';
Declare @CCS_DAII_VA_QUOTES_Available Varchar(1) = 'N';
Declare @DA_II_VA_PARTS_AVAILABLE     Varchar(1) = 'N';


SET NOCOUNT ON;
-----------------------------------------------------------------------------------------------------   
execute PARWP_PBOM_AVAILABLE                 @CCTSS_K, @PBOM_Available OUTPUT;
execute PARWP_PBOM_AVAILABLE_FOR_SUPL_QUOTES @CCTSS_K, @CCS_DAII_VA_QUOTES_Available OUTPUT;
execute PARWP_PBOM_AVAILABLE_WITH_BOM_PARTS  @CCTSS_K, @DA_II_VA_PARTS_AVAILABLE OUTPUT;


--Determine if Kill and Fill can be done.  Both have to be 'N' to delete

If  @CCS_DAII_VA_QUOTES_Available = 'N' --No GCS,CCS,DAII,VA supplier files have been imported for the file
and @DA_II_VA_PARTS_AVAILABLE     = 'N' --No DA,II,VA parts have been entered 
  Begin
   if @PBOM_Available = 'Y'             --If PBOM is Available, delete so it can be re-inserted
      Execute PARWP_PBOM_DELETE @CCTSS_K
  End;

--Insert all data when it doesn't exist.  
--It's easier to have one set of inserts rather than one for insert only, another for Kill and fill and another for new inserts when supplier data is available

--PARWU17_BOM_SUB_ASSY
INSERT INTO PARWU17_BOM_SUB_ASSY
Select 
     --Null as ARWU17_BOM_SUB_ASSY_K : Table has an Identity clause which will create the primary key 
	   @CCTSS_K
      ,dbo.PARWF_ASSIGN_ARWU17_SEQ_R(sub_assembly_idx_c) as ARWU17_BOM_SUB_ASSY_SEQ_R  --Function call to get seq_r
	  ,S59.sub_assembly_name   as ARWU17_BOM_SUB_ASSY_N
	  ,@TIME_STAMP             as ARWU17_CREATE_S
	  ,@CDSID                  as ARWU17_CREATE_USER_C
	  ,@TIME_STAMP             as ARWU17_LAST_UPDT_S
	  ,@CDSID                  as ARWU17_LAST_UPDT_USER_C
	  ,S59.sub_assembly_idx_c  as ARWU17_BOM_SUB_ASSY_IX_C 
  FROM 
      (--InLine view used to get unique sub-assemblies
       select  S59.row_idx
             , S59.sub_assembly_name
			 , S59.sub_assembly_idx_c
       	     , ROW_NUMBER() over (partition by S59.sub_assembly_name order by S59.row_idx) as rownum
         FROM PARWS59_PBOM_PARTS  S59
        Where S59.Processing_ID = @Processing_ID
       ) S59
 Where rownum = 1 --get unique sub_assemblies
 ;
--  Select 'After U17 insert, rowcount: ' + cast(@@ROWCOUNT  as varchar(500));
-----------------------------------------------------------------------------------------------------
--PARWU18_BOM_PART
INSERT INTO PARWU18_BOM_PART
SELECT 
       --Null as ARWU18_BOM_PART_K : Table has an Identity clause which will create the primary key 
       @CCTSS_K                  as ARWU01_CCTSS_K
      ,S59.part_index            as ARWU18_BOM_PART_IX_N
      ,U17.ARWU17_BOM_SUB_ASSY_K as ARWU17_BOM_SUB_ASSY_N
      ,S59.row_idx               as ARWU18_BOM_PART_DSPLY_SEQ_R
      ,S59.part_name             as ARWU18_BOM_PART_X
      ,@TIME_STAMP               as ARWU18_CREATE_S
      ,@CDSID                    as ARWU18_CREATE_USER_C
      ,@TIME_STAMP               as ARWU18_LAST_UPDT_S
      ,@CDSID                    as ARWU18_LAST_UPDT_USER_C	 
 FROM 
     (
      select part_index
            ,row_idx
			,part_name
			,sub_assembly_name
			,Processing_ID
            ,ROW_NUMBER() over (partition by part_index order by row_idx) as rownum
        FROM PARWS59_PBOM_PARTS  
       Where Processing_ID = @Processing_ID
	 ) S59
 Join PARWU17_BOM_SUB_ASSY U17 ON U17.ARWU01_CCTSS_K        = @CCTSS_K
                              And U17.ARWU17_BOM_SUB_ASSY_N = S59.sub_assembly_name
Where S59.Processing_ID = @Processing_ID
  and rownum = 1
 ;
--  Select 'After U18 insert, rowcount: ' + cast(@@ROWCOUNT  as varchar(500));
-----------------------------------------------------------------------------------------------------

--PARWU19_DSGN_PART
INSERT INTO PARWU19_DSGN_PART
SELECT 
       --Null as ARWU19_DSGN_PART_K : Table has an Identity clause which will create the primary key 
       U06.ARWU06_CCTSS_DSGN_K                 as ARWU06_CCTSS_DSGN_K	        
	  ,U18.ARWU18_BOM_PART_K                   as ARWU18_BOM_PART_K
	  ,CAST(S59.quantity AS Float)             as ARWU19_DSGN_PART_Q
	  ,CAST(S59.material_usage AS Float)       as ARWU19_DSGN_PART_MTRL_USG_Q
	  ,A27.ARWA27_UOM_K                        as ARWA27_UOM_K 
	  ,S59.material_spec                       as ARWU19_DSGN_PART_MTRL_SPEC_X
	  ,CAST(S59.material_thickness AS Float)   as ARWU19_DSGN_PART_MTRL_THK_Q
	  ,CAST(S59.length AS Float)               as ARWU19_DSGN_PART_LEN_Q
	  ,CAST(S59.width AS Float)                as ARWU19_DSGN_PART_WID_Q
	  ,ISNULL(S59.depth,'')                    as ARWU19_DSGN_PART_MTRL_DEPTH_Q	  
	  ,ISNULL(S59.cmmdty_spec1,'')             as ARWU19_CMMDTY_SPCFC1_X
	  ,ISNULL(S59.cmmdty_spec2,'')             as ARWU19_CMMDTY_SPCFC2_X
	  ,ISNULL(S59.cmmdty_spec3,'')             as ARWU19_CMMDTY_SPCFC3_X
	  ,ISNULL(S59.comments,'')                 as ARWU19_DSGN_PART_CMT_X
	  ,@TIME_STAMP                             as ARWU19_CREATE_S
	  ,@CDSID                                  as ARWU19_CREATE_USER_C
	  ,@TIME_STAMP                             as ARWU19_LAST_UPDT_S
	  ,@CDSID                                  as ARWU19_LAST_UPDT_USER_C
	  ,CAST(diameter  AS Float)                as ARWU19_DSGN_PART_DIA_Q
  FROM PARWS59_PBOM_PARTS       S59
  Join PARWU06_CCTSS_DSGN_FLAT  U06 ON U06.ARWU01_CCTSS_K            = @CCTSS_K
                                   and U06.ARWU14_CCTSS_DSGN_DSPLY_N = S59.design_name
  Join PARWU18_BOM_PART         U18 ON U18.ARWU01_CCTSS_K            = @CCTSS_K 
                                   and U18.ARWU18_BOM_PART_IX_N      = S59.part_index
  Join PARWA27_UOM              A27 ON A27.ARWA27_UOM_c              = S59.uom
  Where S59.Processing_ID = @Processing_ID
;
-- Select 'After U19 insert, rowcount: ' + cast(@@ROWCOUNT  as varchar(500));
-----------------------------------------------------------------------------------------------------
--  a47 load from s59
MERGE INTO [dbo].[PARWA47_FORD_END_ITM] a47 
USING
(
SELECT distinct(s59.end_item_prefix)
               ,s59.end_item_base
	           ,s59.end_item_suffix
FROM  [dbo].[PARWS59_PBOM_PARTS] s59
where s59.Processing_ID = @Processing_ID 
and (    s59.[end_item_base]   <> '')
) X
ON  a47.ARWA47_FORD_END_ITM_PREF_N = x.end_item_prefix
and a47.ARWA47_FORD_END_ITM_BSE_N  = x.end_item_base
and a47.ARWA47_FORD_END_ITM_SFX_N  = x.end_item_suffix
When NOT Matched then
 Insert Values (end_item_prefix
		       ,end_item_base
		       ,end_item_suffix
		       ,'9999-12-31 00:00:00.000'
		       ,@TIME_STAMP
		       ,@CDSID   
		       ,@TIME_STAMP
	           ,@CDSID   
		       ) 
;
-----------------------------------------------------------------------------------------------------
-- U63 load
Declare @ARWA57_END_ITM_MAP_TYPE_K INT;
Select @ARWA57_END_ITM_MAP_TYPE_K=( SELECT [dbo].[PARWF_ARWA57_TYPE_X] ('Scope') ); --Function call


MERGE INTO [dbo].PARWU63_VRNT_BOM_PART_END_ITM u63
USING
(
select distinct(u18.ARWU18_BOM_PART_K)
	           ,a47.ARWA47_FORD_END_ITM_K
			   ,U04.[ARWU04_CCTSS_VRNT_K]
from PARWS59_PBOM_PARTS s59
JOIN PARWU18_BOM_PART u18
  on u18.ARWU01_CCTSS_K    = @CCTSS_K
 and s59.part_index        = u18.ARWU18_BOM_PART_IX_N
JOIN PARWA47_FORD_END_ITM a47
  on s59.end_item_prefix   = a47.ARWA47_FORD_END_ITM_PREF_N
 and s59.end_item_base     = a47.ARWA47_FORD_END_ITM_BSE_N
 and s59.end_item_suffix   = a47.ARWA47_FORD_END_ITM_SFX_N
JOIN [dbo].[PARWU04_CCTSS_VRNT] U04
  ON U04.[ARWU04_BNCHMK_F] = 1  -- Data coming from the PBOM file will always be for the Benchmark Variant for which Flag is 1 
 AND U04.[ARWU01_CCTSS_K]  = @CCTSS_K
where Processing_ID        = @Processing_ID 
) X
ON  u63.ARWU04_CCTSS_VRNT_K       = x.ARWU04_CCTSS_VRNT_K
and u63.ARWU18_BOM_PART_K         = x.ARWU18_BOM_PART_K
and U63.ARWA57_END_ITM_MAP_TYPE_K = @ARWA57_END_ITM_MAP_TYPE_K
When NOT Matched then
Insert Values
 ( x.ARWU04_CCTSS_VRNT_K
  ,x.ARWU18_BOM_PART_K
  ,@ARWA57_END_ITM_MAP_TYPE_K
  ,x.ARWA47_FORD_END_ITM_K
  ,@TIME_STAMP
  ,@CDSID   
  ,@TIME_STAMP
  ,@CDSID  
 ) 
;





GO
