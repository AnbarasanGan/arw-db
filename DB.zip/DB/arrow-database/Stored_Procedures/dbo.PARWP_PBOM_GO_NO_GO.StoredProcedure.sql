DROP PROCEDURE [dbo].[PARWP_PBOM_GO_NO_GO]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 01/07/2020
-- Description:	Stored Procedure to determine whether to stop PBOM_master from running
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   09-11-2020  US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10-20-2020  US1996362  Switch from E02 to E03 and include Excel column
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_GO_NO_GO] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(500)  
	,@CDSID varchar(30)  
	,@TIME_STAMP DATETIME
--	,@SYSERROR INT  
--	,@VALIDTERROR INT 
	,@ERROR_TYPE varchar(50) OUTPUT
AS
BEGIN  TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @SYSERROR INT;  
DECLARE @VALIDTERROR INT;

set @ERROR_TYPE = 'NO ERRORS'

SET @Syserror =
(select count(*)
  from PARWS59_PBOM_PARTS   S59
  Join PARWE03_BATCH_PBOM_ERRORS E03   
    ON E03.ARWE03_PROCESSING_ID = S59.Processing_ID
WHERE S59.PROCESSING_ID = @GUID
   and ARWE03_ERROR_TYPE_X = 'ERROR'
   and ARWE03_SOURCE_C = 'SYSTEM'
group by ARWE03_ERROR_TYPE_X)
;

SET @VALIDTERROR =
(select count(*)
  from PARWS59_PBOM_PARTS   S59
  Join PARWE03_BATCH_PBOM_ERRORS E03   
    ON E03.ARWE03_PROCESSING_ID = S59.Processing_ID
WHERE S59.PROCESSING_ID = @GUID
   and ARWE03_ERROR_TYPE_X = 'ERROR'
   and ARWE03_SOURCE_C <> 'SYSTEM'
group by ARWE03_ERROR_TYPE_X)
;

If IsNull(@Syserror,0) > 0 
   SET @ERROR_TYPE = 'SYSTEM Error'
Else
if IsNull(@VALIDTERROR,0)  > 0 
   SET @ERROR_TYPE = 'Validation Error'
Else SET @ERROR_TYPE = 'No Error'
;

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS'
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE
			 ,''                               -- Column
END CATCH



GO
