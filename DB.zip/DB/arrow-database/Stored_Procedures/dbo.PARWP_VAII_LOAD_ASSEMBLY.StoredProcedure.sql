SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		ASHAIK12
-- Create date: 06/30/2022
-- Description:	Load Assembly and Final Assembly data from stage table to base table for improvement ideas
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/27/22    ASHAIK12  DE260318  Appending supplier key to fix pink screen
-- 07/28/2022  ASHAIK12  DE260907  Remove join on u07 key 
-- 08/04/22    ASHAIK12  US3906818 Fix U07 supplier key join from using ud2 to u09 view
-- =============================================
CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VAII_LOAD_ASSEMBLY] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO [dbo].[PARWUD7_ASSY_VRNT_IMPRV]
SELECT
       U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K                     AS ARWU09_CCTSS_VRNT_SUPL_K
	  ,ASSEMBLY_STAGE.row_idx                                AS ARWUD7_ASSY_COST_DSPLY_SEQ_R
	  ,UD2.ARWUD2_CCTSS_VRNT_IMPRV_K                           AS ARWUD2_CCTSS_VRNT_IMPRV_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')             AS ARWUD7_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')              AS ARWUD7_ASSY_OPER_X
	  
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_OPER_LOC_CNTRY_K
	   
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_LCL_CRCY_K 

	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWUD7_MACH_MAKE_MDL_X
      ,CASE WHEN ASSEMBLY_STAGE.capital_exp_for_machine = '' then '0.00'
	        else ltrim(rtrim(CAST(ASSEMBLY_STAGE.capital_exp_for_machine as decimal (28,9))) )     
	   END AS ARWUD7_CPTL_EXPNDTR_FOR_MACH_A
	  ,CASE WHEN ASSEMBLY_STAGE.machine_size = '' then  '0.00'
	        ELSE ltrim(rtrim(CAST(ASSEMBLY_STAGE.machine_size as decimal (19,9))   ))
       END AS ARWUD7_MACH_SIZE_IN_MET_TN_Q 
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWUD7_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWUD7_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWUD7_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWUD7_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWUD7_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWUD7_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWUD7_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWUD7_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWUD7_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWUD7_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWUD7_CREATE_S
	  ,@CDSID                                                    AS ARWUD7_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWUD7_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWUD7_LAST_UPDT_USER_C

       From PARWS53_VA_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
        JOIN dbo.PARWS45_VA_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename
   JOIN [dbo].[PARWS67_VA_IMPROVEMENT_IDEAS_INFO]  S67
    ON COVER_PAGE_STAGE.Processing_ID       = S67.Processing_ID
   AND COVER_PAGE_STAGE.filename            = S67.filename
   AND ASSEMBLY_STAGE.change_id = S67.improvement_id

  JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]    U09_VRNT
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
		 AND COVER_PAGE_STAGE.User_Selected_ENRG_CMMDTY_X        = U09_VRNT.ARWA02_ENRG_CMMDTY_X
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U09_VRNT.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U09_VRNT.ARWA06_RGN_C
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U09_VRNT.ARWU01_BNCHMK_VRNT_N
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U09_VRNT.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U09_VRNT.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U09_VRNT.ARWA28_CNTRY_N
		 AND COVER_PAGE_STAGE.User_selected_WALK_VRNT_X          = U09_VRNT.ARWU04_VRNT_N

  JOIN [dbo].[PARWUD2_CCTSS_VRNT_IMPRV] UD2
       ON U09_VRNT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
	AND UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N =  (CASE 
	      WHEN S67.originator = 'Supplier'
		      THEN  ASSEMBLY_STAGE.change_id + '#' + CONVERT(VARCHAR,U09_VRNT.[ARWU07_CCTSS_SUPL_K])  	            
		       ELSE ASSEMBLY_STAGE.change_id 
        END)

  

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency=CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
       JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''

  Where cover_page_stage.Processing_ID               = @GUIDIN
  AND ASSEMBLY_STAGE.sub_assembly_name <> 'Improvement Final Assembly'
    And cover_page_stage.Skip_loading_due_to_error_f = 0
	AND ASSEMBLY_STAGE.cost_type='Improvement Costs'
;
----------------------------------------------------------------------------------------------------- 
--Final Assembly
-----------------------------------------------------------------------------------------------------

INSERT INTO PARWUD8_FNL_ASSY_VRNT_IMPRV
SELECT  
       U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K                         AS ARWU09_CCTSS_VRNT_SUPL_K
      ,ASSEMBLY_STAGE.row_idx                                    AS ARWUD8_FNLASSYCOST_DSPLY_SEQ_R
	  ,UD2.ARWUD2_CCTSS_VRNT_IMPRV_K                               AS ARWUD2_CCTSS_VRNT_IMPRV_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')                 AS ARWUD8_FNL_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')                  AS ARWUD8_FNL_ASSY_OPER_X
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_OPER_LOC_CNTRY_K
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_LCL_CRCY_K 
	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWUD8_MACH_MAKE_MDL_X
      ,CASE WHEN ASSEMBLY_STAGE.capital_exp_for_machine = '' then '0.00'
	        else ltrim(rtrim(CAST(ASSEMBLY_STAGE.capital_exp_for_machine as decimal (28,9))) )     
	   END AS ARWUD8_CPTL_EXPNDTR_FOR_MACH_A
	  ,CASE WHEN ASSEMBLY_STAGE.machine_size = '' then  '0.00'
	        ELSE ltrim(rtrim(CAST(ASSEMBLY_STAGE.machine_size as decimal (19,9))   ))
       END AS ARWUD8_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWUD8_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWUD8_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWUD8_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWUD8_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWUD8_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWUD8_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWUD8_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWUD8_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWUD8_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWUD8_FNL_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWUD8_CREATE_S
	  ,@CDSID                                                    AS ARWUD8_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWUD8_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWUD8_LAST_UPDT_USER_C
  From PARWS53_VA_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN dbo.PARWS45_VA_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename
    JOIN [dbo].[PARWS67_VA_IMPROVEMENT_IDEAS_INFO]  S67
    ON COVER_PAGE_STAGE.Processing_ID       = S67.Processing_ID
   AND COVER_PAGE_STAGE.filename            = S67.filename
   AND ASSEMBLY_STAGE.change_id = S67.improvement_id


   JOIN  [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]   U09_VRNT
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = U09_VRNT.[ARWA03_ENRG_SUB_CMMDTY_X]
	  AND COVER_PAGE_STAGE.User_Selected_ENRG_CMMDTY_X        = U09_VRNT.ARWA02_ENRG_CMMDTY_X
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U09_VRNT.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U09_VRNT.[ARWA06_RGN_C]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U09_VRNT.ARWU01_BNCHMK_VRNT_N
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U09_VRNT.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U09_VRNT.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U09_VRNT.ARWA28_CNTRY_N
	  AND COVER_PAGE_STAGE.User_selected_WALK_VRNT_X          = U09_VRNT.ARWU04_VRNT_N

	   JOIN [dbo].[PARWUD2_CCTSS_VRNT_IMPRV] UD2
       ON U09_VRNT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
	   AND UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N =  (CASE 
	      WHEN S67.originator = 'Supplier'
		      THEN  ASSEMBLY_STAGE.change_id + '#' + CONVERT(VARCHAR,U09_VRNT.[ARWU07_CCTSS_SUPL_K])  	            
		       ELSE ASSEMBLY_STAGE.change_id 
        END)


 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency = CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''
  Where cover_page_stage.Processing_ID               = @GUIDIN
    And cover_page_stage.Skip_loading_due_to_error_f = 0
	And ASSEMBLY_STAGE.sub_assembly_name             = 'Improvement Final Assembly'
;


GO
