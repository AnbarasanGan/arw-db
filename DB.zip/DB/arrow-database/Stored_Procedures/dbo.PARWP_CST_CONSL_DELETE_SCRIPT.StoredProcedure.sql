DROP PROCEDURE [dbo].[PARWP_CST_CONSL_DELETE_SCRIPT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 08/13/2019
-- Description:	Delete Script for CCT and CCS tables.
--              Moving all CCT Delete Statements to prior to loading CCS tables to avoid having any orphaned records in CCT tables.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asolosky   08/22/2019  Delete statements for PARWU23_PURC_PART_COST, PARWU23_PURC_PART_COST, PARWU25_RAW_MTRL_COST, PARWU26_PROCG_COST, PARWU27_ASSY_COST,
--                        PARWU28_MFG_MRKP, PARWU29_FNL_ASSY_COST, PARWU30_FNL_ASSY_MRKP: Removed the join to the 2nd staging name (which included the filename)
--                        Removed the s22.Skip_loading_due_to_error_f = 0 from the where statements
-- asolosky   11/13/2019  Added updates for U06 and U08 tables. Set final assembly columns to zero. And U57
-- ashaik12   12/25/2019  Removed unwanted columns in the select from U56 delete
-- Ashaik12   01/10/2020  removed filter on Processing Status and added Skip_loading_due_to_error_f = 0 instead
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CST_CONSL_DELETE_SCRIPT] 
@GUIDIN        Varchar(5000),
@CDSID	       Varchar(30),
@CCTSS_K       Int
AS

SET NOCOUNT ON;

--********** Delete Statements for U55 and U56.  Update statement for U57 **********--

--DELETE: using Merge statement to Delete data in the [PARWU55_SUPL_DSGN_PART] table when it's reloaded.

MERGE INTO [dbo].[PARWU55_SUPL_DSGN_PART]   U55_Target
Using
(
Select U55.ARWU08_CCTSS_DSGN_SUPL_K
      ,U55.ARWU19_DSGN_PART_K
  From PARWU55_SUPL_DSGN_PART U55
 Join PARWU08_CCTSS_DSGN_SUPL U08
   On U08.ARWU08_CCTSS_DSGN_SUPL_K = U55.ARWU08_CCTSS_DSGN_SUPL_K
 Join PARWU06_CCTSS_DSGN      U06
   On U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
 Where U06.ARWU01_CCTSS_K = @CCTSS_K
) as U55_Source
ON (U55_Target.ARWU08_CCTSS_DSGN_SUPL_K=U55_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;



MERGE INTO [dbo].[PARWU56_SUPL_SUB_ASSY]   U56_Target
Using
(
Select 
ARWU08_CCTSS_DSGN_SUPL_K AS [ARWU08_CCTSS_DSGN_SUPL_K]
From
(
select 
 V13.ARWU08_CCTSS_DSGN_SUPL_K as ARWU08_CCTSS_DSGN_SUPL_K
,V13.ARWU17_BOM_SUB_ASSY_K
,V13.[ARWU17_BOM_SUB_ASSY_N]
FROM [dbo].[PARWV13_CCS_ASSEMBLY_FLAT] V13
JOIN [dbo].[PARWV20_MFG_MRKP] V20
ON V13.ARWU08_CCTSS_DSGN_SUPL_K=V20.[ARWU08_CCTSS_DSGN_SUPL_K]
AND V13.ARWU17_BOM_SUB_ASSY_K=V20.ARWU17_BOM_SUB_ASSY_K
WHERE V13.ARWU01_CCTSS_K=@CCTSS_K
) a
group by a.ARWU08_CCTSS_DSGN_SUPL_K 
,a.[ARWU17_BOM_SUB_ASSY_N]
,a.ARWU17_BOM_SUB_ASSY_K
) as U56_Source
ON (U56_Target.ARWU08_CCTSS_DSGN_SUPL_K=U56_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;


--U57 Update subassy columns to 0.  
MERGE INTO PARWU57_CCTSS_DSGN_SUB_ASSY   U57
Using
(
  Select ARWU06_CCTSS_DSGN_K
    FROM PARWU06_CCTSS_DSGN
   WHERE ARWU01_CCTSS_K = @CCTSS_K
) as U06
ON (U57.ARWU06_CCTSS_DSGN_K = U06.ARWU06_CCTSS_DSGN_K)
WHEN MATCHED THEN 
Update
Set U57.ARWU57_SUBASSY_ORIG_BOB_A      = 0
   ,U57.ARWU57_SUBASSY_ORIG_BOB_MRKP_P = 0
;


--********** Delete Statements for CCS related tables U23 - U30 **********--

----U24 DELETE before INSERT
MERGE INTO [dbo].[PARWU24_PURC_PART_COST_PARNT]  u24_target
Using
  (         select u24.ARWU24_PURC_PART_COST_PARNT_K
		          ,u23.[ARWU23_PURC_PART_COST_K]
		          ,V04.ARWU08_CCTSS_DSGN_SUPL_K
				  ,V04.ARWU31_CTSP_N
				  ,V04.ARWA34_VEH_MDL_N
				  ,V04.ARWA17_SUPL_N
             from [PARWS22_CCS_COVER_PAGE_INFO] s22
  -- Join with Supplier Qoute View to get child key
             JOIN [dbo].PARWV04_DSGN_SUPL V04
               on s22.[User_Selected_ENRG_SUB_CMMDTY_X] = v04.[ENG_SUB_CMMDTY_DESC]
            and s22.[User_Selected_CTSP_N]              = v04.ARWU31_CTSP_N
            and s22.[User_Selected_CTSP_Region_C]       = v04.[CTSP_REGION_CODE]
            and s22.[User_Selected_BNCMK_VRNT_N]        = v04.[VARIANT]     --BoB variant
            and s22.[User_Selected_VEH_MAKE_N]          = v04.ARWA14_VEH_MAKE_N
            and s22.[User_Selected_VEH_MDL_N]           = v04.ARWA34_VEH_MDL_N
			and s22.[User_Selected_VEH_MDL_YR_C]        = v04.[ARWA35_DSGN_VEH_MDL_YR_C]
            and s22.[User_Selected_VEH_MDL_VRNT_X]      = v04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
            AND s22.[User_Selected_SUPL_N]              = v04.ARWA17_SUPL_N
            AND S22.[User_Selected_SUPL_C]              = v04.ARWA17_SUPL_C
            AND S22.[User_Selected_SUPL_CNTRY_N]        = v04.ARWA28_CNTRY_N

           JOIN [dbo].[PARWU23_PURC_PART_COST] u23
		     on v04.[ARWU08_CCTSS_DSGN_SUPL_K]     = u23.[ARWU08_CCTSS_DSGN_SUPL_K]

		   Join [dbo].[PARWU24_PURC_PART_COST_PARNT] U24
		     on U24.ARWU23_PURC_PART_COST_K        = u23.ARWU23_PURC_PART_COST_K

		   where s22.[Processing_ID]             = @GUIDIN
             and s22.Skip_loading_due_to_error_f       = 0
 ) as u24_source
 ON (u24_target.ARWU24_PURC_PART_COST_PARNT_K  = u24_source.ARWU24_PURC_PART_COST_PARNT_K)
WHEN MATCHED THEN DELETE
;

-----U23 DELETE before INSERT
MERGE INTO [dbo].[PARWU23_PURC_PART_COST] u23_target
USING
  (select  
   V08.[ARWU08_CCTSS_DSGN_SUPL_K]
            ,V08.[ARWU17_BOM_SUB_ASSY_K] 
           from [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22           
           -- join to pbom view to get part_index 
           JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] v08
             on s22.[User_Selected_ENRG_SUB_CMMDTY_X] = v08.[ARWA03_ENRG_SUB_CMMDTY_X]
            and s22.[User_Selected_CTSP_N]            = v08.ARWU31_CTSP_N
            and s22.[User_Selected_CTSP_Region_C]     = v08.[ARWA06_RGN_C]
            and s22.[User_Selected_BNCMK_VRNT_N]      = V08.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
            and s22.[User_Selected_VEH_MAKE_N]        = v08.ARWA14_VEH_MAKE_N
            and s22.[User_Selected_VEH_MDL_N]         = v08.ARWA34_VEH_MDL_N
            and s22.[User_Selected_VEH_MDL_VRNT_X]    = V08.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
			and s22.[User_Selected_VEH_MDL_YR_C]      = v08.[ARWA35_DSGN_VEH_MDL_YR_C]
            AND s22.[User_Selected_SUPL_N]            = V08.ARWA17_SUPL_N
            AND S22.[User_Selected_SUPL_C]            = V08.ARWA17_SUPL_C
            AND S22.[User_Selected_SUPL_CNTRY_N]      = V08.ARWA28_CNTRY_N

           where s22.[Processing_ID]             = @GUIDIN
             and s22.Skip_loading_due_to_error_f       = 0
         ) as u23_source
 
   on ( 
       u23_target.[ARWU08_CCTSS_DSGN_SUPL_K] = u23_source.[ARWU08_CCTSS_DSGN_SUPL_K]
       )
when MATCHED THEN DELETE
;

-- U25 Delete
MERGE INTO [PARWU25_RAW_MTRL_COST]   U25_Target
Using
(
SELECT
  V08.ARWU08_CCTSS_DSGN_SUPL_K as ARWU08_CCTSS_DSGN_SUPL_K
 ,V08.ARWU17_BOM_SUB_ASSY_K as ARWU17_BOM_SUB_ASSY_K
 from [dbo].[PARWS22_CCS_COVER_PAGE_INFO] cover_page_stage

 -- Join with Supplier Qoute View
 JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08
 ON  cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]= V08.[ARWA03_ENRG_SUB_CMMDTY_X]
 --and cover_page_stage.Eng_commodity_name   = V08.ARWA02_ENRG_CMMDTY_X
 AND cover_page_stage.[User_Selected_CTSP_N]=V08.ARWU31_CTSP_N
 AND cover_page_stage.[User_Selected_CTSP_Region_C]=V08.[ARWA06_RGN_C]
 AND cover_page_stage.[User_Selected_VEH_MAKE_N]=V08.[ARWA14_VEH_MAKE_N]
 AND cover_page_stage.[User_Selected_VEH_MDL_N]=V08.[ARWA34_VEH_MDL_N]
 AND cover_page_stage.[User_Selected_VEH_MDL_YR_C]=V08.ARWA35_DSGN_VEH_MDL_YR_C
 AND cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]=V08.ARWA35_DSGN_VEH_MDL_VRNT_X
 AND cover_page_stage.[User_Selected_BNCMK_VRNT_N]=V08.[ARWU01_BNCHMK_VRNT_N]
 AND cover_page_stage.[User_Selected_SUPL_N]=V08.[ARWA17_SUPL_N]
 AND cover_page_stage.[User_Selected_SUPL_CNTRY_N]=V08.ARWA28_CNTRY_N
 AND cover_page_stage.[User_Selected_SUPL_C]   =V08.ARWA17_SUPL_C
 where cover_page_stage.Processing_ID               = @GUIDIN
   AND cover_page_stage.Skip_loading_due_to_error_f       = 0
      ) as U25_Source
 ON ( 
         U25_Target.[ARWU08_CCTSS_DSGN_SUPL_K] = U25_Source.ARWU08_CCTSS_DSGN_SUPL_K
    )
WHEN MATCHED THEN DELETE;


-----U26 DELETE before INSERT
MERGE INTO [dbo].[PARWU26_PROCG_COST] u26_target
USING
  (select  
          v08.[ARWU08_CCTSS_DSGN_SUPL_K]
         ,v08.[ARWU19_DSGN_PART_K] 
		 ,v08.[ARWU17_BOM_SUB_ASSY_K]
    from[dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22

 -- Join with Supplier Quote View
    JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08
      ON s22.User_Selected_ENRG_SUB_CMMDTY_X = V08.[ARWA03_ENRG_SUB_CMMDTY_X]
     AND s22.[User_Selected_CTSP_N]          = V08.ARWU31_CTSP_N
     AND s22.[User_Selected_CTSP_Region_C]   = V08.[ARWA06_RGN_C]
     AND s22.[User_Selected_VEH_MAKE_N]      = V08.[ARWA14_VEH_MAKE_N]
     AND s22.[User_Selected_VEH_MDL_N]       = V08.[ARWA34_VEH_MDL_N]
     AND s22.[User_Selected_VEH_MDL_YR_C]    = V08.ARWA35_DSGN_VEH_MDL_YR_C    
     AND s22.[User_Selected_VEH_MDL_VRNT_X]  = V08.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
     AND s22.[User_Selected_BNCMK_VRNT_N]    = V08.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
	 AND S22.[User_Selected_SUPL_N]          = V08.ARWA17_SUPL_N
     AND s22.[User_Selected_SUPL_CNTRY_N]    = V08.ARWA28_CNTRY_N
	 AND s22.[User_Selected_SUPL_C]          = V08.ARWA17_SUPL_C
  --   AND s16.supplier_name                 = V08.[ARWA17_SUPL_N]

   where s22.Processing_ID               = @GUIDIN
     AND s22.Skip_loading_due_to_error_f       = 0

         ) as u26_source
 
   on ( 
        u26_target.[ARWU08_CCTSS_DSGN_SUPL_K] = u26_source.[ARWU08_CCTSS_DSGN_SUPL_K]
       )
when MATCHED THEN DELETE
;

--DELETE: using Merge statement to Delete data in the PARWU27_ASSY_COST table when it's reloaded.
MERGE INTO PARWU27_ASSY_COST   U27_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From dbo.PARWS22_CCS_COVER_PAGE_INFO                  COVER_PAGE_STAGE
 
      -- Join with Supplier Quote View
        JOIN PARWV04_DSGN_SUPL   V04
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.VARIANT
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	     AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f       = 0
      ) as U27_Source
 ON (U27_Target.ARWU08_CCTSS_DSGN_SUPL_K = U27_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

-- U28
MERGE INTO [dbo].[PARWU28_MFG_MRKP] U28_Target
USING
(
SELECT
   SUPL_QUTE.ARWU08_CCTSS_DSGN_SUPL_K as [ARWU08_CCTSS_DSGN_SUPL_K]
 from [dbo].[PARWS22_CCS_COVER_PAGE_INFO] cover_page_stage

-- SUPPLIER QUOTE VIEW
JOIN [dbo].[PARWV09_CCS_BOM_SUB_ASSEMBLY] SUPL_QUTE
--ON cover_page_stage.Eng_commodity_name=SUPL_QUTE.ARWA02_ENRG_CMMDTY_X
ON cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]=SUPL_QUTE.[ARWA03_ENRG_SUB_CMMDTY_X]
AND cover_page_stage.[User_Selected_CTSP_N]=SUPL_QUTE.ARWU31_CTSP_N
AND cover_page_stage.[User_Selected_CTSP_Region_C]=SUPL_QUTE.[ARWA06_RGN_C]
AND cover_page_stage.[User_Selected_VEH_MAKE_N]=SUPL_QUTE.[ARWA14_VEH_MAKE_N]
AND cover_page_stage.[User_Selected_VEH_MDL_N]=SUPL_QUTE.[ARWA34_VEH_MDL_N]
AND cover_page_stage.[User_Selected_VEH_MDL_YR_C]=SUPL_QUTE.ARWA35_DSGN_VEH_MDL_YR_C
AND cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]=SUPL_QUTE.ARWA35_DSGN_VEH_MDL_VRNT_X
AND cover_page_stage.[User_Selected_BNCMK_VRNT_N]=SUPL_QUTE.[ARWU01_BNCHMK_VRNT_N]
AND cover_page_stage.[User_Selected_SUPL_N]=SUPL_QUTE.ARWA17_SUPL_N
AND cover_page_stage.[User_Selected_SUPL_CNTRY_N]=SUPL_QUTE.ARWA28_CNTRY_N
AND cover_page_stage.[User_Selected_SUPL_C]=SUPL_QUTE.ARWA17_SUPL_C

where cover_page_stage.Processing_ID               = @GUIDIN
  AND cover_page_stage.Skip_loading_due_to_error_f       = 0
) as U28_SOURCE
ON
(
U28_Target.[ARWU08_CCTSS_DSGN_SUPL_K]=U28_Source.[ARWU08_CCTSS_DSGN_SUPL_K]
)
WHEN MATCHED THEN DELETE;

--DELETE: using Merge statement to Delete data in the PARWU29_FNL_ASSY_COST table when it's reloaded.
MERGE INTO PARWU29_FNL_ASSY_COST   U29_Target
Using
	 ( Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From dbo.PARWS22_CCS_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    -- Join with Design and Supplier View
    JOIN [dbo].[PARWV04_DSGN_SUPL]   V04
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V04.[ENG_SUB_CMMDTY_DESC]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.[CTSP_REGION_CODE]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f       = 0
      ) as U29_Source
 ON ( 
         U29_Target.ARWU08_CCTSS_DSGN_SUPL_K = U29_Source.ARWU08_CCTSS_DSGN_SUPL_K
    )
WHEN MATCHED THEN DELETE;


-- U30

MERGE INTO [dbo].[PARWU30_FNL_ASSY_MRKP] U30_Target
USING
(
Select V04.ARWU08_CCTSS_DSGN_SUPL_K
  From PARWV04_DSGN_SUPL V04
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
       from [dbo].[PARWS22_CCS_COVER_PAGE_INFO]                           cover_page_stage
      where cover_page_stage.Processing_ID               = @GUIDIN
        AND cover_page_stage.Skip_loading_due_to_error_f       = 0
      ) Staging
   ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X] = V04.[ENG_SUB_CMMDTY_DESC]
   AND Staging.[User_Selected_CTSP_N]           = V04.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]    = V04.[CTSP_REGION_CODE]
   AND Staging.[User_Selected_VEH_MAKE_N]       = V04.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]        = V04.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]     = V04.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]   = V04.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]     = V04.[VARIANT]
   AND Staging.[User_Selected_SUPL_N]           = V04.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]     = V04.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]           = V04.ARWA17_SUPL_C
) as U30_SOURCE
ON (U30_Target.[ARWU08_CCTSS_DSGN_SUPL_K] = U30_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K])
WHEN MATCHED THEN DELETE;

--**********Update Statements for U06 and U08 to set columns to zero **********-

MERGE INTO [dbo].PARWU06_CCTSS_DSGN U06_Target
USING
(
Select U06.ARWU06_CCTSS_DSGN_K
  From PARWU06_CCTSS_DSGN_FLAT U06  --This is a view
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]

       from [dbo].[PARWS22_CCS_COVER_PAGE_INFO]  cover_page_stage
      where cover_page_stage.Processing_ID               = @GUIDIN
        AND cover_page_stage.Skip_loading_due_to_error_f       = 0
   --There could be more than 1 design in a processing batch.  We only need the unique design key so the group by is needed.
   group by User_Selected_CTSP_N, User_Selected_CTSP_Region_C, Eng_commodity_name, User_Selected_ENRG_SUB_CMMDTY_X, User_Selected_BNCMK_VRNT_N,
	        User_Selected_VEH_MAKE_N, User_Selected_VEH_MDL_N, User_Selected_VEH_MDL_YR_C, User_Selected_VEH_MDL_VRNT_X

      ) Staging
    ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X]= U06.ARWA03_ENRG_SUB_CMMDTY_X
   AND Staging.[User_Selected_CTSP_N]           = U06.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]    = U06.ARWA06_RGN_C
   AND Staging.[User_Selected_VEH_MAKE_N]       = U06.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]        = U06.ARWA34_VEH_MDL_N
   AND Staging.[User_Selected_VEH_MDL_YR_C]     = U06.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]   = U06.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]     = U06.ARWU01_BNCHMK_VRNT_N
) as U06_SOURCE
ON (U06_Target.ARWU06_CCTSS_DSGN_K = U06_SOURCE.ARWU06_CCTSS_DSGN_K)
WHEN MATCHED THEN 
Update
Set U06_Target.ARWU06_FNLASSY_ORIG_BOB_A      = 0
   ,U06_Target.ARWU06_FNLASSY_ORIG_BOB_MRKP_P = 0
;

MERGE INTO [dbo].PARWU08_CCTSS_DSGN_SUPL U08_Target
USING
(
Select U08.ARWU08_CCTSS_DSGN_SUPL_K
  From PARWU08_CCTSS_DSGN_SUPL_FLAT U08   --This is a view
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
       from [dbo].[PARWS22_CCS_COVER_PAGE_INFO]                           cover_page_stage
      where cover_page_stage.Processing_ID               = @GUIDIN
        AND cover_page_stage.Skip_loading_due_to_error_f       = 0
      ) Staging
    ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X]= U08.ARWA03_ENRG_SUB_CMMDTY_X
   AND Staging.[User_Selected_CTSP_N]           = U08.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]    = U08.ARWA06_RGN_C
   AND Staging.[User_Selected_VEH_MAKE_N]       = U08.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]        = U08.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]     = U08.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]   = U08.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]     = U08.ARWU01_BNCHMK_VRNT_N
   AND Staging.[User_Selected_SUPL_N]           = U08.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]     = U08.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]           = U08.ARWA17_SUPL_C
) as U08_SOURCE
ON (U08_Target.[ARWU08_CCTSS_DSGN_SUPL_K] = U08_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K])
WHEN MATCHED THEN 
Update
Set U08_Target.ARWU08_FNL_ASSY_DIR_LBR_A    = 0
   ,U08_Target.ARWU08_FNL_ASSY_DIR_FRNG_A   = 0
   ,U08_Target.ARWU08_FNL_ASSY_INDIR_LBR_A  = 0
   ,U08_Target.ARWU08_FNL_ASSY_INDIR_FRNG_A = 0
   ,U08_Target.ARWU08_FNL_ASSY_OVRHD_A      = 0
   ,U08_Target.ARWU08_FNL_ASSY_MISC_A       = 0
   ,U08_Target.ARWU08_FNL_ASSY_TOT_A        = 0
   ,U08_Target.ARWU08_FNL_ASSY_TOT_W_MRKP_A = 0
;


GO
