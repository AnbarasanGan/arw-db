SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 07/22/2022
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/26/2022  ASHAIK12  DE260310  Change U85 benchmark flag to 0
-- 07/27/2022    ASHAIK12  DE260318  Appending supplier key to fix pink screen
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VAII_LOAD_TRDOFF_IMPRV_SUPL] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--**********************************
-- Insert into U85
--********************************** 

DECLARE @ARWA31_CONFID_LVL_K INT =(select ARWA31_CONFID_LVL_K FROM PARWA31_CONFID_LVL where ARWA31_CONFID_LVL_X ='High');
DECLARE @ARWA43_TRDOFF_AGRMT_FORUM_K INT =(select ARWA43_TRDOFF_AGRMT_FORUM_K FROM PARWA43_TRDOFF_AGRMT_FORUM where ARWA43_TRDOFF_AGRMT_FORUM_N='To be determined')


INSERT INTO [PARWU85_CCTSS_TRDOFF]
select ARWU01_CCTSS_K
      ,0                               AS ARWU85_BNCHMK_F
      ,improvement_idea_grouping       AS ARWU85_CCTSS_TRDOFF_X
	  ,''                              AS ARWU85_CCTSS_TRDOFF_RTNLE_X
	  ,''                              AS ARWU85_CCTSS_TRDOFF_DATA_SRC_X
	  ,1                               AS ARWU85_CCTSS_TRDOFF_INCLD_F
	  ,[ARWA31_CONFID_LVL_K]           AS ARWA31_CONFID_LVL_K
	  ,0                               AS ARWU85_TRDOFF_AGRMT_BFR_MP_F
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]   AS ARWA43_TRDOFF_AGRMT_FORUM_K
	  ,@TIME_STAMP                     AS ARWU85_CREATE_S
      ,@CDSID                          AS ARWU85_CREATE_USER_C
      ,@TIME_STAMP                     AS ARWU85_LAST_UPDT_S
      ,@CDSID                          AS ARWU85_LAST_UPDT_USER_C
from (
   SELECT  
          U01.ARWU01_CCTSS_K 
   	     ,CASE WHEN S67.improvement_idea_grouping = '' 
   	           THEN 'UNASSIGNED' 
   			   ELSE S67.improvement_idea_grouping  
   	      END AS improvement_idea_grouping
   	     ,@ARWA31_CONFID_LVL_K AS [ARWA31_CONFID_LVL_K]
   	     ,@ARWA43_TRDOFF_AGRMT_FORUM_K AS [ARWA43_TRDOFF_AGRMT_FORUM_K]
     FROM [dbo].[PARWS67_VA_IMPROVEMENT_IDEAS_INFO] S67
     JOIN [dbo].[PARWS45_VA_COVER_PAGE_INFO]        S45
       ON S45.Processing_ID       = S67.Processing_ID
      AND S45.filename            = S67.filename

     JOIN PARWU01_CCTSS_FLAT   U01
       ON U01.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
      AND U01.ARWA06_RGN_C               = S45.User_Selected_CTSP_Region_C
	  AND U01.[ARWA02_ENRG_CMMDTY_X]     = S45.[User_Selected_ENRG_CMMDTY_X]
      AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S45.User_Selected_ENRG_SUB_CMMDTY_X 
      AND U01.ARWU01_BNCHMK_VRNT_N       = S45.User_Selected_BNCMK_VRNT_N
    Where S45.Processing_ID               = @GUIDIN
      And S45.Skip_loading_due_to_error_f = 0
	  And S67.originator = 'Supplier'
      And not exists --Can't add a trade off if it already exists
         (Select 'X'
            From PARWU85_CCTSS_TRDOFF U85_Check
	       Where U85_Check.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
		   AND ARWU85_BNCHMK_F = 0
		   And U85_Check.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S67.improvement_idea_grouping='' THEN 'UNASSIGNED' ELSE S67.improvement_idea_grouping END
         )
	)x
Group by --Get distinct data to write into the table
       ARWU01_CCTSS_K          
	  ,improvement_idea_grouping
	  ,ARWA31_CONFID_LVL_K
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]
	 ;



--**********************************
-- Insert into UD3
--********************************** 

INSERT INTO [dbo].PARWUD3_VRNT_IMPRV_TRDOFF
SELECT UD2.ARWUD2_CCTSS_VRNT_IMPRV_K   AS ARWUD2_CCTSS_VRNT_IMPRV_K
      ,U85.ARWU85_CCTSS_TRDOFF_K       AS ARWU85_CCTSS_TRDOFF_K
	  ,@TIME_STAMP                     AS ARWUD3_CREATE_S
      ,@CDSID                          AS ARWUD3_CREATE_USER_C
      ,@TIME_STAMP                     AS ARWUD3_LAST_UPDT_S
      ,@CDSID                          AS ARWUD3_LAST_UPDT_USER_C
FROM [dbo].[PARWS67_VA_IMPROVEMENT_IDEAS_INFO] S67
     JOIN [dbo].[PARWS45_VA_COVER_PAGE_INFO]        S45
       ON S45.Processing_ID       = S67.Processing_ID
      AND S45.filename            = S67.filename

 -- Join with Variant/Supplier Flat View
   JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view
    ON S45.Eng_SubCommodity_name        = u09_view.[ARWA03_ENRG_SUB_CMMDTY_X]
	AND S45.User_Selected_ENRG_CMMDTY_X = u09_view.ARWA02_ENRG_CMMDTY_X
    AND S45.User_Selected_CTSP_N         = u09_view.ARWU31_CTSP_N
    AND S45.User_Selected_CTSP_Region_C  = u09_view.[ARWA06_RGN_C]
    AND S45.User_Selected_BNCMK_VRNT_N   = u09_view.[ARWU01_BNCHMK_VRNT_N]     --BoB variant
    AND S45.User_Selected_SUPL_N         = u09_view.ARWA17_SUPL_N
    AND S45.User_Selected_SUPL_CNTRY_N   = u09_view.ARWA28_CNTRY_N
    AND S45.User_Selected_SUPL_C         = u09_view.ARWA17_SUPL_C
    AND S45.User_selected_WALK_VRNT_X    = u09_view.ARWU04_VRNT_N

   JOIN PARWUD2_CCTSS_VRNT_IMPRV UD2
   ON UD2.ARWU04_CCTSS_VRNT_K = u09_view.ARWU04_CCTSS_VRNT_K
   AND UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N = (CASE 
	      WHEN S67.originator = 'Supplier'
		      THEN  s67.improvement_id + '#' + CONVERT(VARCHAR,UD2.[ARWU07_CCTSS_SUPL_K])
			  ELSE s67.improvement_id
        END)
   AND UD2.[ARWU07_CCTSS_SUPL_K] = u09_view.[ARWU07_CCTSS_SUPL_K]

   JOIN PARWU85_CCTSS_TRDOFF U85
   ON  U85.ARWU01_CCTSS_K = u09_view.ARWU01_CCTSS_K
   AND U85.ARWU85_BNCHMK_F=0
   AND U85.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S67.improvement_idea_grouping='' THEN 'UNASSIGNED' ELSE S67.improvement_idea_grouping END


    Where S45.Processing_ID               = @GUIDIN 
    And S45.Skip_loading_due_to_error_f = 0
	And S67.originator = 'Supplier'
    AND not exists --Can't add if it already exists
       (
	     Select 'X'
          From PARWUD3_VRNT_IMPRV_TRDOFF UD3_check
	     Where UD3_check.ARWUD2_CCTSS_VRNT_IMPRV_K = UD2.ARWUD2_CCTSS_VRNT_IMPRV_K 
       )
	GROUP BY UD2.ARWUD2_CCTSS_VRNT_IMPRV_K,U85.ARWU85_CCTSS_TRDOFF_K

	;

GO


