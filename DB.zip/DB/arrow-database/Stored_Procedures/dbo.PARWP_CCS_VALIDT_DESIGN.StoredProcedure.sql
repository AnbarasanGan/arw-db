DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_DESIGN]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 3/18/2019
-- Description:	validate design make, model, model year
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   07/22/2019  Added validation on design variant
-- Asolosky   09/10/2019  Added row_idx
-- Ashaik12   01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_DESIGN] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
    -- MAKE (Brand) validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
   SELECT Err.[Source_c]
	     ,Err.[design_Brand]  
	     ,'The Design Brand on the cover page does not match the selected Design Brand'
	     ,Err.[Processing_ID]
	     ,Err.[filename] 
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	     ,'PARWS22_CCS_COVER_PAGE_INFO'
		 ,'WARNING' as [ARWE02_ERROR_TYPE_X]
		 ,'Cover' as [ARWE02_EXCEL_TAB_X]
	     ,0                               as ARWE02_ROW_IDX
		 ,''
		 ,Err.User_Selected_VEH_MAKE_N  
   FROM 
       (
        SELECT 
               Processing_ID,
		       design_Brand,
			   User_Selected_VEH_MAKE_N,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
        FROM [dbo].[PARWS22_CCS_COVER_PAGE_INFO]    S22
		WHERE Processing_ID       = @GUID
          and design_Brand       != User_Selected_VEH_MAKE_N
       ) Err

--++++++++++++++++++++++++++++++++++++
    -- MAKE/MODEL (Brand/Model)validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
   SELECT Err.[Source_c]
	     ,Err.design_Model
	     ,'The Design Model on the cover page does not match the selected Design Model'
	     ,Err.[Processing_ID]
	     ,Err.[filename] 
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID  
	     ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	     ,'PARWS22_CCS_COVER_PAGE_INFO'
		 ,'WARNING' as [ARWE02_ERROR_TYPE_X]
		 ,'Cover' as [ARWE02_EXCEL_TAB_X]
  	     ,0                               as ARWE02_ROW_IDX
		 ,''
		 ,Err.User_Selected_VEH_MDL_N  
   FROM 
       (
        SELECT 
               Processing_ID,
		       design_Model,
			   User_Selected_VEH_MDL_N,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM [dbo].[PARWS22_CCS_COVER_PAGE_INFO] S22 
         WHERE Processing_ID       = @GUID
	       and design_Model       != User_Selected_VEH_MDL_N
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
    -- MODEL YEAR validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS] 
   SELECT Err.[Source_c]
	     ,Err.[design_model_year]
	     ,'The Design Model Year on the cover page does not match the selected Design Model Year'
	     ,Err.[Processing_ID]
	     ,Err.[filename] 
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	     ,'PARWS22_CCS_COVER_PAGE_INFO'
		 ,'WARNING' as [ARWE02_ERROR_TYPE_X]
		 ,'Cover' as [ARWE02_EXCEL_TAB_X]
	     ,0                              as ARWE02_ROW_IDX
		 ,''
		 ,Err.User_Selected_VEH_MDL_YR_C  

   FROM 
       (
        SELECT 
               Processing_ID,
		       design_model_year,
			   User_Selected_VEH_MDL_YR_C,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO s22
         WHERE Processing_ID       = @GUID
		   and design_model_year  != User_Selected_VEH_MDL_YR_C       
       ) Err

    ;
--++++++++++++++++++++++++++++++++++++
    -- Design Variant validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS] 
   SELECT Err.[Source_c]
	     ,Err.design_Var
	     ,'The Design Variant on the cover page does not match the selected Design Variant'
	     ,Err.[Processing_ID]
	     ,Err.[filename] 
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	     ,'PARWS22_CCS_COVER_PAGE_INFO'
		 ,'WARNING' as [ARWE02_ERROR_TYPE_X]
		 ,'Cover' as [ARWE02_EXCEL_TAB_X]
	     ,0                               as ARWE02_ROW_IDX
		 ,''
		 ,Err.User_Selected_VEH_MDL_VRNT_X  
   FROM 
       (
        SELECT 
               Processing_ID,
			   design_Var,
			   User_Selected_VEH_MDL_VRNT_X,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO s22
         WHERE Processing_ID       = @GUID
		   and design_Var         != User_Selected_VEH_MDL_VRNT_X       
       ) Err

    ;
END TRY

BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''                                --ARWE02_BATCH_ERRORS_REF_K
			 ,'PARWS22_CCS_COVER_PAGE_INFO'     --ARWE02_STAGING_TABLE_X
		     --ARWE02_BATCH_ERRORS_K Identity key 
			 ,'ERROR'                           --ARWE02_ERROR_TYPE_X
			 ,'SYSTEM'                          --ARWE02_EXCEL_TAB_X
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;


GO
