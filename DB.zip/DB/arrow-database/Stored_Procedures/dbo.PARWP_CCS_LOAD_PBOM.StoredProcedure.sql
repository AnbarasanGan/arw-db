DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_PBOM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 03/19/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 06/25/2019  rwesley2  N/A      changed ROW_NUMBER function to order by stage table row_idx col
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 06/26/2019  rwesley2  N/A      removed ROW_NUMBER function and changed to row_idx col for U17 and U18 INSERT
-- 07/02/2019  rwesley2			  removed row_idx from U17 load.  don't wnat row_idx on sub-asembly name.  only applies to part index	
-- 07/31/2019  asolosky	          Change to U17 Insert.  Added  Where rownum = 1 to the end of the select
-- 09/16/2019  ashaik12           Fixed U17 insert.
-- 12/11/2019  ashaik12           Remove update on Part Name in U18 insert. 
-- 12/26/2019  ashaik12           Refactor to use flat views
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- 02/18/2020  Asolosky US1359101 Depth changed from decimal to varchar.  Code was changed to remove rounding.
-- 02/21/2020  Asolosky DE154961  Removed all rounding from the U19 insert.  The code was rounding to 4 decimals.
--                                Let SQL Server auto round on insert/update. It will default to the column data type which is 19,9 at the time of the code change.
-- 05/18/2020  Asolosky US1616235 Default ARWU19_DSGN_PART_DIA_Q to 0 until the GCS template is updated with diameter
-- 05/19/2020  Asolosky US1625202 Allow diameter to be loaded from the staging table.
-- 06/01/2020  Asolosky US1655435 When a sub-assembly is added, a sub-assembly index must be created.
-- 12/02/2020  Asolosky US2096265 EDU CDx706 Roof Rack issue CCS PBOM data not loading. In the U18 merge, removed this from the join: S22.supplier_name = S13.supplier_name
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_PBOM] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP    DATETIME,
@CCTSS_K       INT
AS

SET NOCOUNT ON;
Declare @max_seq_r int;
set @max_seq_r = (select max(ARWU17_BOM_SUB_ASSY_SEQ_R) 
                    from PARWU17_BOM_SUB_ASSY 
				   Where ARWU01_CCTSS_K = @CCTSS_K 
				     and ARWU17_BOM_SUB_ASSY_SEQ_R  != 32767  --'Directed Parts'
				 );
-----------------------------------------------------------------------------------------------------   
--PARWU17_BOM_SUB_ASSY
--There is no way to update the PARWU17_BOM_SUB_ASSY and no way to delete so this is INSERT only

INSERT INTO PARWU17_BOM_SUB_ASSY
Select ARWU01_CCTSS_K
      ,Case when ARWU17_BOM_SUB_ASSY_N = 'Directed Parts'
	        then rank_num -- this is the max value for a small int=32767
			else ISNULL(@max_seq_r,0) + rank_num  --The seq_r will 
	   End ARWU17_BOM_SUB_ASSY_SEQ_R
	  ,ARWU17_BOM_SUB_ASSY_N 
	  ,@TIME_STAMP                  as ARWU17_CREATE_S
	  ,@CDSID as ARWU17_CREATE_USER_C
	  ,@TIME_STAMP                  as ARWU17_LAST_UPDT_S
	  ,@CDSID as ARWU17_LAST_UPDT_USER_C

	  ,CASE WHEN ARWU17_BOM_SUB_ASSY_N = 'Directed Parts' Then 'DP'
	        WHEN final_rank = 1 THEN 'A'
		    WHEN final_rank = 2 THEN 'B'
		    WHEN final_rank = 3 THEN 'C'
		    WHEN final_rank = 4 THEN 'D'
		    WHEN final_rank = 5 THEN 'E'
		    WHEN final_rank = 6 THEN 'F'
	   END ARWU17_BOM_SUB_ASSY_IX_C
--	  ,final_rank
--	  ,rank_num 
  FROM 
      ( --Final 

        --Rank all records from the UNION statements
        Select ARWU01_CCTSS_K, ARWU17_BOM_SUB_ASSY_SEQ_R, ARWU17_BOM_SUB_ASSY_N, rank_num
		     , ARWU17_BOM_SUB_ASSY_IX_C as IX_C
			 , row_Number() over (partition by ARWU01_CCTSS_K order by ISNULL(ARWU17_BOM_SUB_ASSY_IX_C,'ZZZZZZZ'), rank_num)   as final_rank
        From
            ( --SUB_Assembly 		
				  
		      --Current U17 records
              select --U17.ARWU17_BOM_SUB_ASSY_K
                     U17.ARWU01_CCTSS_K
                    ,U17.ARWU17_BOM_SUB_ASSY_SEQ_R
            	    ,U17.ARWU17_BOM_SUB_ASSY_N
            	    ,CASE WHEN ARWU17_BOM_SUB_ASSY_IX_C = 'A' THEN 1
            		      WHEN ARWU17_BOM_SUB_ASSY_IX_C = 'B' THEN 2
            		      WHEN ARWU17_BOM_SUB_ASSY_IX_C = 'C' THEN 3
            		      WHEN ARWU17_BOM_SUB_ASSY_IX_C = 'D' THEN 4
            		      WHEN ARWU17_BOM_SUB_ASSY_IX_C = 'E' THEN 5
            		      WHEN ARWU17_BOM_SUB_ASSY_IX_C = 'F' THEN 6
            	     END rank_num
            	    ,U17.ARWU17_BOM_SUB_ASSY_IX_C
               From PARWU17_BOM_SUB_ASSY  U17
              Where U17.ARWU01_CCTSS_K  = @CCTSS_K

          -- New sub-assemblies that are not Directed Parts
             Union
              Select 
            	   @CCTSS_K                                              as ARWU01_CCTSS_K
                  ,row_idx                                               as ARWU17_BOM_SUB_ASSY_SEQ_R
            	  ,part_sub_assembly_name                                as ARWU17_BOM_SUB_ASSY_N
            	  ,row_Number() over (partition by @CCTSS_K order by row_idx)  as rank_num
            	  ,null                                                  as ARWU17_BOM_SUB_ASSY_IX_C
              FROM 
                  (--InLine view used to determine which rows are unique sub-assemblies 
                   select  @CCTSS_K  as ARWU01_CCTSS_K
            	         , S13.row_idx
                         , S13.part_sub_assembly_name
                   	     , ROW_NUMBER() over (partition by S13.part_sub_assembly_name order by S13.row_idx) as rownum
            	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO S13
            		JOIN PARWS22_CCS_COVER_PAGE_INFO     S22
            		  ON S22.Processing_ID               = S13.Processing_ID
            		 And S22.filename                    = S13.file_name
            	   Where S22.Processing_ID               = @Processing_ID
            	     and S22.Skip_loading_due_to_error_f = 0
            		 and S13.part_sub_assembly_name     != 'Directed Parts'
            	     and NOT EXISTS   
            	          (Select 'X'
            	     	    From PARWU17_BOM_SUB_ASSY  SUB
            	     	   Where SUB.ARWU01_CCTSS_K        = @CCTSS_K
            	     		 and SUB.ARWU17_BOM_SUB_ASSY_N = S13.part_sub_assembly_name
            	     	  )
                   ) S13_DP
             Where rownum = 1

          -- New Directed Parts sub-assemblies
             UNION
              Select 
            	   @CCTSS_K                 as ARWU01_CCTSS_K
                  ,row_idx                  as ARWU17_BOM_SUB_ASSY_SEQ_R
            	  ,part_sub_assembly_name   as ARWU17_BOM_SUB_ASSY_N
            	  ,32767                    as rank_num            --Max smallint value
            	  ,null                     as ARWU17_BOM_SUB_ASSY_IX_C
              FROM 
                  (--InLine view used to determine which rows are unique sub-assemblies 
                   select  @CCTSS_K         as ARWU01_CCTSS_K
            	         , S13.row_idx
                         , S13.part_sub_assembly_name
                   	     , ROW_NUMBER() over (partition by S13.part_sub_assembly_name order by S13.row_idx) as rownum
            	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO S13
            		JOIN PARWS22_CCS_COVER_PAGE_INFO     S22
            		  ON S22.Processing_ID               = S13.Processing_ID
            		 And S22.filename                    = S13.file_name
            	   Where S22.Processing_ID               = @Processing_ID
            	     and S22.Skip_loading_due_to_error_f = 0
            		 and S13.part_sub_assembly_name      = 'Directed Parts'
            	     and NOT EXISTS   
            	          (Select 'X'
            	     	    From PARWU17_BOM_SUB_ASSY  SUB
            	     	   Where SUB.ARWU01_CCTSS_K        = @CCTSS_K
            	     		 and SUB.ARWU17_BOM_SUB_ASSY_N = S13.part_sub_assembly_name
            	     	  )
                  ) S13_DP
             Where rownum = 1
            ) SUB_Assembly

      ) Final
 Where IX_C is NULL  --this will include only new sub assemblies that don't exist in the database
-----------------------------------------------------------------------------------------------------
--PARWU18_BOM_PART
MERGE INTO PARWU18_BOM_PART   U18
USING
(Select 
	   ARWU01_CCTSS_K
	  ,part_index                       
	  ,ARWU17_BOM_SUB_ASSY_K           
      ,row_idx as seq_r
	  ,part_name
  From
 (--STAGING_WITH_SEQ
 Select STAGING_Remove_Dups.*
       ,U18.ARWU18_BOM_PART_DSPLY_SEQ_R_MAX
  From
    ( --STAGING_Remove_Dups
	  SELECT U01.ARWU01_CCTSS_K
			,S13.part_sub_assembly_name
			,S13.part_index
			,S13.part_name
			,S13.file_name
			,S13.supplier_name
			,S13.design_name
			,S22.supplier_name as supplier_nameS22
			,S22.design_Model
			,U17.ARWU17_BOM_SUB_ASSY_K
			--,U18.ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,ROW_NUMBER() OVER (PARTITION BY U01.ARWU01_CCTSS_K, U17.ARWU17_BOM_SUB_ASSY_K, part_index  ORDER BY S13.[row_idx] ) AS Part_index_rownum    --Use the ARWU17 in partition for row_number used with Max_seq_r
			,s13.row_idx
	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID       = S13.Processing_ID
		 AND S22.filename            = S13.file_name
	    JOIN [dbo].[PARWU01_CCTSS_FLAT] U01
	      ON U01.ARWU31_CTSP_N                 = S22.User_Selected_CTSP_N
         AND U01.[ARWA06_RGN_C]                = S22.User_Selected_CTSP_Region_C
		 AND U01.[ARWA03_ENRG_SUB_CMMDTY_X]    = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U01.[ARWU01_BNCHMK_VRNT_N]        = s22.User_Selected_BNCMK_VRNT_N
		JOIN PARWU17_BOM_SUB_ASSY             U17
		  ON U17.ARWU01_CCTSS_K        = U01.ARWU01_CCTSS_K
		 AND U17.ARWU17_BOM_SUB_ASSY_N = S13.part_sub_assembly_name
	   Where S22.Processing_ID               = @Processing_ID  
         and S22.Skip_loading_due_to_error_f = 0
   ) STAGING_Remove_Dups
Left Join (Select ARWU01_CCTSS_K
                 ,ARWU17_BOM_SUB_ASSY_K
                 ,MAX(ARWU18_BOM_PART_DSPLY_SEQ_R) as ARWU18_BOM_PART_DSPLY_SEQ_R_MAX
             from PARWU18_BOM_PART 
		 Group by ARWU01_CCTSS_K
                 ,ARWU17_BOM_SUB_ASSY_K
		 ) U18
     ON U18.ARWU01_CCTSS_K        = STAGING_Remove_Dups.ARWU01_CCTSS_K  
	And U18.ARWU17_BOM_SUB_ASSY_K = STAGING_Remove_Dups.ARWU17_BOM_SUB_ASSY_K

   Where Part_index_rownum = 1
 ) STAGING_WITH_SEQ

) STAGING
  ON (STAGING.ARWU01_CCTSS_K        = U18.ARWU01_CCTSS_K AND
    --  STAGING.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K AND
	  STAGING.part_index            = U18.ARWU18_BOM_PART_IX_N 
	 )
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 ( --Null as ARWU18_BOM_PART_K: Table has an Identity clause which will create the primary key 
	   ARWU01_CCTSS_K
	  ,part_index                       -- ARWU18_BOM_PART_IX_N
	  ,ARWU17_BOM_SUB_ASSY_K            -- ARWU17_BOM_SUB_ASSY_K
      ,seq_r                            -- ARWU18_BOM_PART_DSPLY_SEQ_R
	  ,part_name                        -- ARWU18_BOM_PART_X
	  ,@TIME_STAMP                     -- ARWU18_CREATE_S
	  ,@CDSID							-- ARWU18_CREATE_USER_C
	  ,@TIME_STAMP                     -- ARWU18_LAST_UPDT_S
	  ,@CDSID						    -- ARWU18_LAST_UPDT_USER_C
	 )
;
-----------------------------------------------------------------------------------------------------
--PARWU19_DSGN_PART
MERGE INTO PARWU19_DSGN_PART   U19
USING
     (	 Select Inner_Join.*
	           ,U18.ARWU18_BOM_PART_K
	 from
	  (
	  SELECT U06.ARWU06_CCTSS_DSGN_K	        
	        ,U06.ARWU01_CCTSS_K
			,U17.ARWU17_BOM_SUB_ASSY_K
			,Case
			   When S13.quantity is NULL Then 0
			   Else S13.quantity   
			 End quantity          --ARWU19_DSGN_PART_Q
			,Case
			   When S13.material_usage is NULL then 0
			   Else S13.material_usage 
			 End material_usage     --ARWU19_DSGN_PART_MTRL_USG_Q
			,A27.ARWA27_UOM_K                  --ARWA27_UOM_K
			,ISNULL(S13.material_spec,'')  as material_spec              --ARWU19_DSGN_PART_MTRL_SPEC_X

			,Case
			   When S13.material_thickness is Null Then 0
			   Else S13.material_thickness 
			 End material_thickness --ARWU19_DSGN_PART_MTRL_THK_Q
			,Case
			   When S13.length is Null Then 0
			   Else S13.length
			 End length             --ARWU19_DSGN_PART_LEN_Q
			,Case
			   When S13.width is Null Then 0
			   Else S13.width
			 End width              --ARWU19_DSGN_PART_WID_Q
			,S13.depth                   as depth         --ARWU19_DSGN_PART_MTRL_DEPTH_Q
			,ISNULL(S13.cmmdty_spec1,'') as cmmdty_spec1  --ARWU19_CMMDTY_SPCFC1_X
			,ISNULL(S13.cmmdty_spec2,'') as cmmdty_spec2  --ARWU19_CMMDTY_SPCFC2_X
			,ISNULL(S13.cmmdty_spec3,'') as cmmdty_spec3  --ARWU19_CMMDTY_SPCFC3_X
			,ISNULL(S13.comments,'')     as comments      --ARWU19_DSGN_PART_CMT_X
			,S13.part_index
			,S13.part_name
	        ,ROW_NUMBER() OVER (PARTITION BY U06.ARWU06_CCTSS_DSGN_K, S13.part_index   ORDER BY s13.[row_idx] ) AS rownum    --Use the ARWU17 in partition for row_number
			,commodity_name
			,Eng_SubCommodity_name
            ,Case
			   When S13.diameter is Null Then 0
			   Else S13.diameter
			 End diameter              --ARWU19_DSGN_PART_DIA_Q
	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID       = S13.Processing_ID
		 AND S22.filename            = S13.file_name

	    JOIN [dbo].[PARWU06_CCTSS_DSGN_FLAT]  U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
   	     AND U06.[ARWU01_BNCHMK_VRNT_N]	    = S22.User_Selected_BNCMK_VRNT_N
         AND U06.[ARWA06_RGN_C]             = S22.User_Selected_CTSP_Region_C
		 AND U06.[ARWA03_ENRG_SUB_CMMDTY_X] = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
         AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWA27_UOM                      A27
		  ON A27.ARWA27_UOM_C             = S13.uom 
	    Join PARWU17_BOM_SUB_ASSY             U17
		  ON U17.ARWU01_CCTSS_K        = U06.ARWU01_CCTSS_K
		 AND U17.ARWU17_BOM_SUB_ASSY_N = S13.part_sub_assembly_name
	   Where S22.Processing_ID         = @Processing_ID
	     AND S22.Skip_loading_due_to_error_f = 0
	   )Inner_join
	   Join PARWU18_BOM_PART                 U18
          ON U18.ARWU01_CCTSS_K        = Inner_join.ARWU01_CCTSS_K  
		 and U18.ARWU18_BOM_PART_IX_N  = Inner_join.part_index
	   Where rownum = 1
      ) STAGING
  ON (STAGING.ARWU06_CCTSS_DSGN_K   = U19.ARWU06_CCTSS_DSGN_K AND
	  STAGING.ARWU18_BOM_PART_K     = U19.ARWU18_BOM_PART_K 
	 )
WHEN MATCHED THEN
--Let SQL round the numeric values to match ARROW's datatype
     UPDATE SET          
	    U19.ARWU19_DSGN_PART_Q            = quantity  
	   ,U19.ARWU19_DSGN_PART_MTRL_USG_Q   = material_usage
	   ,U19.ARWA27_UOM_K                  = STAGING.ARWA27_UOM_K         
	   ,U19.ARWU19_DSGN_PART_MTRL_SPEC_X  = material_spec       
	   ,U19.ARWU19_DSGN_PART_MTRL_THK_Q   = material_thickness  
	   ,U19.ARWU19_DSGN_PART_LEN_Q        = length
	   ,U19.ARWU19_DSGN_PART_WID_Q        = width
	   ,U19.ARWU19_DSGN_PART_MTRL_DEPTH_Q = depth
	   ,U19.ARWU19_CMMDTY_SPCFC1_X        = cmmdty_spec1 
	   ,U19.ARWU19_CMMDTY_SPCFC2_X        = cmmdty_spec2 
	   ,U19.ARWU19_CMMDTY_SPCFC3_X        = cmmdty_spec3 
	   ,U19.ARWU19_DSGN_PART_CMT_X        = comments
	   ,U19.ARWU19_LAST_UPDT_S            = @TIME_STAMP
	   ,U19.ARWU19_LAST_UPDT_USER_C       = @CDSID
	   ,U19.ARWU19_DSGN_PART_DIA_Q        = diameter
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 ( --Null as ARWU19_DSGN_PART_K: Table has an Identity clause which will create the primary key 
        ARWU06_CCTSS_DSGN_K
	   ,ARWU18_BOM_PART_K
	   ,quantity            --ARWU19_DSGN_PART_Q
	   ,material_usage      --ARWU19_DSGN_PART_MTRL_USG_Q
	   ,STAGING.ARWA27_UOM_K--ARWA27_UOM_K
	   ,material_spec       --ARWU19_DSGN_PART_MTRL_SPEC_X
	   ,material_thickness  --ARWU19_DSGN_PART_MTRL_THK_Q
	   ,length              --ARWU19_DSGN_PART_LEN_Q
	   ,width               --ARWU19_DSGN_PART_WID_Q
	   ,depth               --ARWU19_DSGN_PART_MTRL_DEPTH_Q
	   ,cmmdty_spec1        --ARWU19_CMMDTY_SPCFC1_X
	   ,cmmdty_spec2        --ARWU19_CMMDTY_SPCFC2_X
	   ,cmmdty_spec3        --ARWU19_CMMDTY_SPCFC3_X
	   ,comments            --ARWU19_DSGN_PART_CMT_X	  
	   ,@TIME_STAMP         --ARWU18_CREATE_S
	   ,@CDSID				--ARWU18_CREATE_USER_C
	   ,@TIME_STAMP         --ARWU18_LAST_UPDT_S
	   ,@CDSID				--ARWU18_LAST_UPDT_USER_C
	   ,diameter            --ARWU19_DSGN_PART_DIA_Q

     )
;

GO
