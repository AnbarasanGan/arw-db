DROP PROCEDURE IF EXISTS [dbo].[PARWP_VA_VALIDT_MFG_MARKUP]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2019
-- Description:	Variant Adjustment Manufacturing Markup data Validation
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   08/06/2019  Replaced the manufacturing markup validation with a new query (2nd validation).  Had to bring all the data into 1 row
--                        in order to do the validation logic. Markup is only needed when raw, processing, assembly data is available (one of the 3)
--                        Only 1 validation message will be shown at a time because the data had to be brought into 1 record.
-- asamriya   09/10/2019  Added row_idx
-- Ashaik12   12/25/2019  Remove Case when statements in Error Descriptions.
-- Ashaik12   01/14/2020  Added Time_Stamp parameter and removed filter on Processing Status
-- Ashaik12   09/30/2020  US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value, fixed filter on sub assembly
-- Asolosky   03/09/2020  Copied the DAW markup validation and changed necessary columns to create the VAW markup validation.
--                        Replaced the manufacturing markup validations to verify Lowest IDC markups match Excel markups.  This is only a warning message.
--                        New validation for: 'Manufacturing Markup Type is Invalid.' Copied from DAW error logic.  It's an Error.
-- Asolosky   03/24/2021  US2402891 changed validation for VAW markups not matching CCS. Changed the Case so IsNull is now using -999999 instead of zero.
-- Asolosky   03/21/2022  DE248814 changed to use D06 Lowest IDC procedure
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_MFG_MARKUP] 

@GUID       varchar(5000),
@CDSID      varchar(30),
@TIME_STAMP DATETIME

AS
BEGIN TRY
SET NOCOUNT ON;

Declare @ARWU01_CCTSS_K   INT;
Declare @U06_IDC_K INT;
EXEC [dbo].[PARWP_GET_CCTSS_KEY]    @GUID, @ARWU01_CCTSS_K OUTPUT, @FILE_TYPE = 'VA'  --Get BoB key to pass into the PARWP_UI_LOWEST_IDC_DESIGN procedure



	-- find bob quote per design ends

SELECT @U06_IDC_K =	(Select ARWU06_CCTSS_DSGN_K 
                        from PARWD06_LOWEST_IDC_DESIGN D06
							  Where D06.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
							);

--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Description validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                            as ARWE02_SOURCE_C
	  ,ERR.manufacturing_markup_desc           as ARWE02_ERROR_VALUE
	  ,'Manufacturing Markups: Manufacturing Markup Type is Invalid.'  AS ARWE02_ERROR_X
	  ,ERR.Processing_ID                       as ARWE02_PROCESSING_ID
	  ,ERR.filename                            as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                   as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                             as ARWE02_CREATE_S
	  ,@CDSID                                  as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                             as ARWE02_LAST_UPDT_S
	  ,@CDSID                                  as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS54_VA_MFG_MARKUP_K]            as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS54_VA_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,''  --No part index
	  ,''  --No ARROW Value
  FROM 
      (
       SELECT 
               Processing_ID,
               manufacturing_markup_desc,
		       Processing_Status_x,
			   sub_assembly_name,
		       Source_c,
		       filename,
               ARWS54_VA_MFG_MARKUP_K,
			   row_idx 
         FROM PARWS54_VA_MANUFACTURING_MARKUPS_INFO S54
        WHERE Processing_ID= @GUID
	      and Not Exists
		      (Select 'X'
               from  [dbo].[PARWA38_MFG_MRKP_TYP] A38
               where A38.[ARWA38_MFG_MRKP_TYP_X] = S54.manufacturing_markup_desc 
			  )              
      ) ERR
;

--++++++++++++++++++++++++++++++++++++
    -- Final Assembly Manufacturing Markup Value: data check on Scrap, SG&A and Profit should match CCS
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                              as ARWE02_SOURCE_C
	  ,ERR.Excel_Value                           as ARWE02_ERROR_VALUE
	  ,ERR.Markup_Error                          as ARWE02_ERROR_X
	  ,ERR.Processing_ID                         as ARWE02_PROCESSING_ID
	  ,ERR.filename                              as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                     as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                               as ARWE02_CREATE_S
	  ,@CDSID                                    as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                               as ARWE02_LAST_UPDT_S
	  ,@CDSID                                    as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS54_VA_MFG_MARKUP_K                as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS54_VA_MANUFACTURING_MARKUPS_INFO'   as ARWE02_STAGING_TABLE_X
	  --ARWE02_BATCH_ERRORS_K  identity key
	  ,'WARNING'                                 as ARWE02_ERROR_TYPE_X
	  ,ERR.sub_assembly_name                     as ARWE02_EXCEL_TAB_X
	  ,0                                         as ARWE02_ROW_IDX     --hard coded as 0 since there's multiple row_idx.
	  ,''               --No part index
	  ,ERR.Markup_Value --ARROW Value
       FROM 
       ( --ERR Data
 Select STG.*
       ,V21.SCRP_MRKP_P
	   ,V21.SGA_Total_MRKP_P
	   ,V21.PROFIT_MRKP_P
	   ,Case When STG.Staging_SCRP_MRKP_P      != IsNull(V21.SCRP_MRKP_P,-999999) or 
	              STG.Staging_SGA_Total_MRKP_P != IsNull(V21.SGA_Total_MRKP_P,-999999) or 
				  STG.Staging_PROFIT_MRKP_P    != IsNull(V21.PROFIT_MRKP_P,-999999)
			--CCS data
	         Then Case When V21.SCRP_MRKP_P is Null or V21.SGA_Total_MRKP_P is Null or V21.PROFIT_MRKP_P is Null
			           Then 'Final Assembly Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter final assembly markups that must match VAW markups (even if no costs are present) and re-import. Next re-import your VAW file'
					   When V21.SCRP_MRKP_P = 0 and V21.SGA_Total_MRKP_P = 0 and V21.PROFIT_MRKP_P = 0 --Same message as above.  Broke this out separate so the logic is easier to understand.
					   Then 'Final Assembly Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter final assembly markups that must match VAW markups (even if no costs are present) and re-import. Next re-import your VAW file'
					   Else 'Final Assembly Markups do not match Lowest IDC GCS/CCS markups which belong to design: '
					        + STG.ARWA14_VEH_MAKE_N + ' ' + STG.ARWA34_VEH_MDL_N + 
					        '. ARROW will use the markups displayed in the ARROW VALUE column and not from the VALUE value column'
					   End
			 Else NULL
		End Markup_Error

		--Only using one of the ARWS43_DAII_MFG_MARKUP_K columns to use in the error record
	   ,Case When STG.Staging_PROFIT_MRKP_P    != V21.PROFIT_MRKP_P    Then PROFIT_ARWS54_VA_MFG_MARKUP_K
	         When STG.Staging_SCRP_MRKP_P      != V21.SCRP_MRKP_P      Then SCRP_ARWS54_VA_MFG_MARKUP_K
	         When STG.Staging_SGA_Total_MRKP_P != V21.SGA_Total_MRKP_P Then SGA_Total_ARWS54_VA_MFG_MARKUP_K
			 ELSE Null
        End ARWS54_VA_MFG_MARKUP_K

		--Markup_Value
		,    'GCS/CCS Scrap: '  + case When V21.SCRP_MRKP_P      is Null Then '<blank>' Else  cast(V21.SCRP_MRKP_P      as varchar(50)) End
		 + ', GCS/CCS Total: '  + case When V21.SGA_Total_MRKP_P is Null Then '<blank>' Else  cast(V21.SGA_Total_MRKP_P as varchar(50)) End
		 + ', GCS/CCS Profit: ' + case When V21.PROFIT_MRKP_P    is Null Then '<blank>' Else  cast(V21.PROFIT_MRKP_P    as varchar(50)) End 
		 as Markup_Value

		 --DA Staging data
		,    ' VA Scrap: '  + cast(STG.Staging_SCRP_MRKP_P      as varchar(50))  
		 +  ', VA Total: '  + cast(STG.Staging_SGA_Total_MRKP_P as varchar(50))  
		 + ', VA Profit: '  + cast(STG.Staging_PROFIT_MRKP_P    as varchar(50))
		 as Excel_Value

   From
       ( --Put the scrap,total and profit on the same record to make the validation easier
        Select U08.ARWU08_CCTSS_DSGN_SUPL_K
        	  ,U08.ARWU01_CCTSS_K
			  ,U08.ARWA14_VEH_MAKE_N
			  ,U08.ARWA34_VEH_MDL_N	
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_SCRP_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_SGA_Total_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_PROFIT_MRKP_P
        	  ,Sum(Case When manufacturing_markup_desc      = 'Scrap'        Then ARWS54_VA_MFG_MARKUP_K     Else 0 End)                   AS SCRP_ARWS54_VA_MFG_MARKUP_K
        	  ,Sum(Case When manufacturing_markup_desc      = 'SG&A - Total' Then ARWS54_VA_MFG_MARKUP_K     Else 0 End)                   AS SGA_Total_ARWS54_VA_MFG_MARKUP_K
        	  ,Sum(Case When manufacturing_markup_desc      = 'Profit'       Then ARWS54_VA_MFG_MARKUP_K     Else 0 End)                   AS PROFIT_ARWS54_VA_MFG_MARKUP_K
			  ,S45.Processing_ID  
			  ,S45.filename
			  ,S45.Source_c 
			  ,S54.sub_assembly_name		  
		 FROM PARWS45_VA_COVER_PAGE_INFO               S45
		 Join PARWS54_VA_MANUFACTURING_MARKUPS_INFO    S54
           ON S45.Processing_ID       = S54.Processing_ID
          AND S45.filename            = S54.filename  
        JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT   U08
          ON U08.ARWU31_CTSP_N                   = s45.User_Selected_CTSP_N            
         AND U08.ARWA06_RGN_C                    = s45.User_Selected_CTSP_Region_C     
         AND U08.ARWA03_ENRG_SUB_CMMDTY_X        = s45.User_Selected_ENRG_SUB_CMMDTY_X
         AND U08.ARWU01_BNCHMK_VRNT_N            = s45.User_Selected_BNCMK_VRNT_N       --BoB variant
         AND U08.ARWU06_CCTSS_DSGN_K             = @U06_IDC_K
         AND U08.ARWA17_SUPL_N                   = s45.User_Selected_SUPL_N 
         AND U08.ARWA28_CNTRY_N                  = s45.User_Selected_SUPL_CNTRY_N
         AND U08.ARWA17_SUPL_C                   = s45.User_Selected_SUPL_C
       WHERE S45.Processing_ID              = @GUID
		 and S54.sub_assembly_name          = 'Adjustment Final Assembly'
		 and S54.manufacturing_markup_desc in ('Scrap','SG&A - Total','Profit' ) --Final Assembly is the same no matter what version so it should always be validated
       Group by 
             u08.ARWU08_CCTSS_DSGN_SUPL_K
            ,u08.ARWU01_CCTSS_K
			,U08.ARWA14_VEH_MAKE_N
			,U08.ARWA34_VEH_MDL_N	
		    ,S45.Processing_ID  
		    ,S45.filename
			,S45.Source_c 
	        ,S54.sub_assembly_name 
      ) STG
    Left Join PARWV21_FINAL_ASSEMBLY_MFG_MRKP  V21
           ON V21.ARWU08_CCTSS_DSGN_SUPL_K = STG.ARWU08_CCTSS_DSGN_SUPL_K
    ) ERR
  Where Markup_Error is NOT NULL
;

--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Value: data check on Scrap, SG&A and Profit should match CCS
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                              as ARWE02_SOURCE_C
	  ,ERR.Excel_Value                           as ARWE02_ERROR_VALUE
	  ,ERR.Markup_Error                          as ARWE02_ERROR_X
	  ,ERR.Processing_ID                         as ARWE02_PROCESSING_ID
	  ,ERR.filename                              as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                     as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                               as ARWE02_CREATE_S
	  ,@CDSID                                    as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                               as ARWE02_LAST_UPDT_S
	  ,@CDSID                                    as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS54_VA_MFG_MARKUP_K                as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS54_VA_MANUFACTURING_MARKUPS_INFO'   as ARWE02_STAGING_TABLE_X
	  --ARWE02_BATCH_ERRORS_K  identity key
	  ,'WARNING'                                 as ARWE02_ERROR_TYPE_X
	  ,ERR.sub_assembly_name                     as ARWE02_EXCEL_TAB_X
	  ,0                                         as ARWE02_ROW_IDX  --hard coded as 0 since there's multiple row_idx.
	  ,''                --No part index
	  ,ERR.Markup_Value  --ARROW Value
       FROM 
       ( --ERR Data
 Select STG.*
       ,V20.SCRP_MRKP_P
	   ,V20.SGA_Total_MRKP_P
	   ,V20.PROFIT_MRKP_P
	   ,Case When STG.Staging_SCRP_MRKP_P      != IsNull(V20.SCRP_MRKP_P,-999999) or 
	              STG.Staging_SGA_Total_MRKP_P != IsNull(V20.SGA_Total_MRKP_P,-999999) or 
				  STG.Staging_PROFIT_MRKP_P    != IsNull(V20.PROFIT_MRKP_P,-999999)
			--CCS data
	         Then Case When V20.SCRP_MRKP_P is Null or V20.SGA_Total_MRKP_P is Null or V20.PROFIT_MRKP_P is Null
			           Then 'Manufacturing Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter Manufacturing markups that must match VAW markups (even if no costs are present) and re-import. Next re-import your VAW file'
					   When V20.SCRP_MRKP_P = 0 and V20.SGA_Total_MRKP_P = 0 and V20.PROFIT_MRKP_P = 0 --Same message as above.  Broke this out separate so the logic is easier to understand.
					   Then 'Manufacturing Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter Manufacturing markups that must match VAW markups (even if no costs are present) and re-import. Next re-import your VAW file'
					   Else 'Manufacturing Markups do not match Lowest IDC GCS/CCS markups which belong to design: '
					        + STG.ARWA14_VEH_MAKE_N + ' ' + STG.ARWA34_VEH_MDL_N + 
					        '. ARROW will use the markups displayed in the ARROW VALUE column and not from the Excel VALUE column'
					   End
			 Else NULL
		End Markup_Error

		--Only using one of the ARWS43_DAII_MFG_MARKUP_K columns to use in the error record
	   ,Case When STG.Staging_PROFIT_MRKP_P    != V20.PROFIT_MRKP_P    Then PROFIT_ARWS54_VA_MFG_MARKUP_K 
	         When STG.Staging_SCRP_MRKP_P      != V20.SCRP_MRKP_P      Then SCRP_ARWS54_VA_MFG_MARKUP_K 
	         When STG.Staging_SGA_Total_MRKP_P != V20.SGA_Total_MRKP_P Then SGA_Total_ARWS54_VA_MFG_MARKUP_K 
			 ELSE Null
        End ARWS54_VA_MFG_MARKUP_K

		--Markup_Value
		,     'GCS/CCS Scrap: ' + case When V20.SCRP_MRKP_P      is Null Then '<blank>' Else  cast(V20.SCRP_MRKP_P      as varchar(50)) End
		 +  ', GCS/CCS Total: ' + case When V20.SGA_Total_MRKP_P is Null Then '<blank>' Else  cast(V20.SGA_Total_MRKP_P as varchar(50)) End
		 + ', GCS/CCS Profit: ' + case When V20.PROFIT_MRKP_P    is Null Then '<blank>' Else  cast(V20.PROFIT_MRKP_P    as varchar(50)) End 
         as Markup_Value

		--DA Staging data
		,+   ' VA Scrap: '  + cast(STG.Staging_SCRP_MRKP_P      as varchar(50))  
		 +  ', VA Total: '  + cast(STG.Staging_SGA_Total_MRKP_P as varchar(50))  
		 + ', VA Profit: '  + cast(STG.Staging_PROFIT_MRKP_P    as varchar(50)) 
        as Excel_Value

   From
       ( --Put the scrap,total and profit on the same record to make the validation easier

        Select U08.ARWU08_CCTSS_DSGN_SUPL_K
        	  ,U08.ARWU06_CCTSS_DSGN_K AS ARWU06_CCTSS_DSGN_K
        	  ,U08.ARWU01_CCTSS_K			  
			  ,U08.ARWA14_VEH_MAKE_N
			  ,U08.ARWA34_VEH_MDL_N	
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value Else 0 End) AS Decimal(12,9)) AS Staging_SCRP_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value Else 0 End) AS Decimal(12,9)) AS Staging_SGA_Total_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value Else 0 End) AS Decimal(12,9)) AS Staging_PROFIT_MRKP_P
        	  ,Sum(Case When manufacturing_markup_desc      = 'Scrap'        Then ARWS54_VA_MFG_MARKUP_K     Else 0 End) AS SCRP_ARWS54_VA_MFG_MARKUP_K 
        	  ,Sum(Case When manufacturing_markup_desc      = 'SG&A - Total' Then ARWS54_VA_MFG_MARKUP_K     Else 0 End) AS SGA_Total_ARWS54_VA_MFG_MARKUP_K 
        	  ,Sum(Case When manufacturing_markup_desc      = 'Profit'       Then ARWS54_VA_MFG_MARKUP_K     Else 0 End) AS PROFIT_ARWS54_VA_MFG_MARKUP_K 
			  ,S45.Processing_ID  
			  ,S45.filename
			  ,S45.Source_c 
			  ,S54.sub_assembly_name
			  ,Substring(S54.sub_assembly_name,7,500)  AS sub_assembly_name_trunc
		 FROM PARWS45_VA_COVER_PAGE_INFO               S45
		 Join PARWS54_VA_MANUFACTURING_MARKUPS_INFO    S54
           ON S45.Processing_ID       = S54.Processing_ID
          AND S45.filename            = S54.filename  
        JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT              U08
          ON U08.ARWU31_CTSP_N                   = s45.User_Selected_CTSP_N            
         AND U08.ARWA06_RGN_C                    = s45.User_Selected_CTSP_Region_C     
         AND U08.ARWA03_ENRG_SUB_CMMDTY_X        = s45.User_Selected_ENRG_SUB_CMMDTY_X
         AND U08.ARWU01_BNCHMK_VRNT_N            = s45.User_Selected_BNCMK_VRNT_N       --BoB variant
         AND U08.ARWU06_CCTSS_DSGN_K             = @U06_IDC_K                           --Lowest IDC
         AND U08.ARWA17_SUPL_N                   = s45.User_Selected_SUPL_N 
         AND U08.ARWA28_CNTRY_N                  = s45.User_Selected_SUPL_CNTRY_N
         AND U08.ARWA17_SUPL_C                   = s45.User_Selected_SUPL_C
       WHERE S45.Processing_ID                = @GUID
		 and S54.sub_assembly_name         like 'Costs-%'  --Will not select records in old templates that don't have cost sheets broken out by sub-assembly. V2.3 started this break out by sub-assembly
		 and S54.manufacturing_markup_desc   in ('Scrap','SG&A - Total','Profit' )
       Group by 
             U08.ARWU08_CCTSS_DSGN_SUPL_K
            ,U08.ARWU06_CCTSS_DSGN_K
            ,U08.ARWU01_CCTSS_K
		    ,U08.ARWA14_VEH_MAKE_N
		    ,U08.ARWA34_VEH_MDL_N	
		    ,S45.Processing_ID  
		    ,S45.filename
			,S45.Source_c 
	        ,S54.sub_assembly_name
		    ,Substring(S54.sub_assembly_name,7,500) 			 
      ) STG
   Left JOIN PARWU17_BOM_SUB_ASSY   U17
		  ON U17.ARWU01_CCTSS_K           = STG.ARWU01_CCTSS_K
		 And U17.ARWU17_BOM_SUB_ASSY_N    = STG.sub_assembly_name_trunc
   Left Join PARWV20_MFG_MRKP  V20
          ON V20.ARWU08_CCTSS_DSGN_SUPL_K = STG.ARWU08_CCTSS_DSGN_SUPL_K
         And V20.ARWU17_BOM_SUB_ASSY_K    = U17.ARWU17_BOM_SUB_ASSY_K
    ) ERR
  Where Markup_Error is NOT NULL
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS54_VA_MANUFACTURING_MARKUPS_INFO'
		,'ERROR'
		,'SYSTEM'
		,0
		,''  --Part_index
		,''  --Arrow value	
;
END CATCH;	




GO
