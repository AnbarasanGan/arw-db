DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_BOM_PART_NAME]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 01/07/2020
-- Description:	Validate the PARWS59_PBOM_PARTS staging table's part_name
--              Display a warning message if the part name is duplicated within a sub-assembly
--              Note: Copied from the PARWP_CCS_VALIDT_BOM_PART procedure and modified.
-- =============================================
-- Changes
-- =============================================
-- Author   Date       User Story Description
-- ------   -----      ---------- ----------
-- asolosky 06/15/2020 US1689875  Part Name can't be empty
-- asolosky 07/16/2020 US1771016  Added error message for carriage return and line feed.
-- asolosky 08/24/2020 US1804570  Added error message for part name over 256 char.
-- rwesley2 09-11-2020 US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky 10/20/2020 US1996362  Switch from E02 to E03 and include Excel column
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_PBOM_VALIDT_BOM_PART_NAME] 
-- Input Parameter
 @Processing_ID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP    datetime

AS
BEGIN TRY
	SET NOCOUNT ON;

	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 STAGING.Source_c
		,STAGING.part_name 
		,'Duplicate part name found in file for a specific sub assembly' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,STAGING.ARWS59_PBOM_PARTS                 as ARWE03_BATCH_ERRORS_REF_K
		,'PARWS59_PBOM_PARTS'                      as ARWE03_STAGING_TABLE_X
		,'WARNING'
        ,STAGING.sub_assembly_name
	    ,row_idx                                   as ARWE03_ROW_IDX
		,STAGING.part_index                        as ARWE03_Part_Index
		,''                                        as ARWE03_Arrow_value -- no arow value
		,part_name_column                          as ARWE03_COLUMN
    FROM
    (	
	  SELECT
             S59.*
	        ,COUNT(part_name) OVER (PARTITION BY S59.design_name, S59.sub_assembly_name, S59.part_name) part_name_count
	    FROM PARWS59_PBOM_PARTS  S59
	   Where S59.Processing_ID = @Processing_ID    
	) STAGING
	Where part_name_count > 1 

	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                   as [ARWE03_SOURCE_C],
	       S59.part_name                                  as [ARWE03_ERROR_VALUE],
	       'The Part Name is empty and must be entered.'  as [ARWE03_ERROR_X],
	       S59.Processing_ID                              as [ARWE03_PROCESSING_ID],
	       S59.file_name                                  as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                          as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                    as [ARWE03_CREATE_S],
           @CDSID                                         as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                    as [ARWE03_LAST_UPDT_S],
	       @CDSID                                         as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                          as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                           as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                        as [ARWE03_ERROR_TYPE_X],
	        S59.sub_assembly_name                         as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                    as [ARWE03_ROW_IDX],
		   S59.part_index                                 as ARWE03_Part_Index,
		   ''                                             as ARWE03_Arrow_value,  --- no arrow value
		   part_name_column                               as ARWE03_COLUMN
      From(
           Select Source_c, part_index, part_name, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx, part_name_column,
       	          row_number() over (partition by file_name, part_index, part_name order by row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  
            WHERE Processing_ID  = @Processing_ID
       	      and part_name = ''
	      ) S59
     WHERE rownum     = 1  --A part can show up multiple times due to different designs in the PBOM file. We only want to display the error 1 time.
    ;

-- Line Feed validation
DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(part_name,char(10),'<LF>')          as [ARWE03_ERROR_VALUE],  --replace line feed with <LF>
	       'A part name can''t have an imbedded line feed <LF>'       as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   S59.part_index                               as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value, -- no arrow value
		   part_name_column                             as ARWE03_COLUMN
      FROM 
	       (Select Source_c, part_name, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx,part_index, part_name_column,
		           row_number() over (partition by file_name, part_index order by row_idx) as rownum
		      From PARWS59_PBOM_PARTS  
             Where Processing_ID         = @Processing_ID
		   ) S59
     WHERE rownum     = 1  --A part can show up multiple times due to different designs in the PBOM file. We only want to display the error 1 time.
       and NullIf(PATINDEX(@pat10,S59.part_name),0) > 0  --Looking for carriage 
    ;

-- Carriage Return validation
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(part_name,char(13),'<CR>')          as [ARWE03_ERROR_VALUE],  --replace carriage return with <CR>
	       'A part name can''t have an imbedded carriage return <CR>' as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   s59.part_index                               as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value, -- no arrow value
		   part_name_column                             as ARWE03_COLUMN
      FROM 
	       (Select Source_c, part_name, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx,part_index, part_name_column,
		           row_number() over (partition by file_name, part_index order by row_idx) as rownum
		      From PARWS59_PBOM_PARTS  
             Where Processing_ID         = @Processing_ID
		   ) S59
     WHERE rownum     = 1  --A part can show up multiple times due to different designs in the PBOM file. We only want to display the error 1 time.
       and NullIf(PATINDEX(@pat13,S59.part_name),0) > 0  --Looking for carriage 
    ;

--Error for part name over 256 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,part_name
		,'Part name can''t be more than 256 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value -- no arrow value
		,part_name_column                      as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @Processing_ID
    and DATALENGTH(part_name)  > 256;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''                                --ARWE03_BATCH_ERRORS_REF_K
		,'PARWS59_PBOM_PARTS'              --ARWE03_STAGING_TABLE_X
		--ARWE03_BATCH_ERRORS_K Identity key
		,'ERROR'                           --ARWE03_ERROR_TYPE_X
        ,'SYSTEM'                          --ARWE03_EXCEL_TAB_X
		,0                                 --row_idx
		,''                               -- part_index 
		,''                               -- ARROW_VALUE
    	,''  --column
;
END CATCH;	



GO
