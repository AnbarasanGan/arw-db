DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_FNL_ASM_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/18/2019
-- Description:	Validate if sum of Final Assembly unit cost is equal to the cost in Summary table. 

-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   03/10/2020  Fix Tab Name
-- rwesley2   05/13/2020  US1600015 VA multitab changes
-- Ashaik12   09/30/2020  US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12   14/12/2020  Use calculated unit cost instead of the staging value (the final value could be hardcoded)
-- Asolosky   01/19/2021  US2164194 Changed the threshold from a dynamic number which used the UpperBound and LowerBound function, to a static number.
--                        The static threshold number is passed in from the master procedure and is based on the PARWT01_THRESHOLD table.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_FNL_ASM_SUMMARY] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	 

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
 X.ARWE02_SOURCE_C
,X.ARWE02_ERROR_VALUE
,X.ARWE02_ERROR_X
,X.ARWE02_PROCESSING_ID
,X.ARWE02_FILENAME
,X.ARWE02_PROCEDURE_X
,X.ARWE02_CREATE_S
,X.ARWE02_CREATE_USER_C
,X.ARWE02_LAST_UPDT_S
,X.ARWE02_LAST_UPDT_USER_C
,X.ARWE02_BATCH_ERRORS_REF_K
,X.ARWE02_STAGING_TABLE_X
,'ERROR'
,'Adjustment Details(All Tabs) - Final Assembly Supplier Quote Summary' as ARWE02_EXCEL_TAB_X
,0                               as ARWE02_ROW_IDX
,'' --part index
,summed_cost as [ARWE02_ARROW_VALUE]
FROM
(
select 
Stage.Source_c AS [ARWE02_SOURCE_C],
Stage.final_assembly AS [ARWE02_ERROR_VALUE],
CASE WHEN Stage.final_assembly=S53.ASM_COST_CALCULATED THEN '' 
ELSE 'Final Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not changed in column S of the Adj sheet and/or column X/Z of Adjustment Final Assembly sheet' END AS ARWE02_ERROR_X  
,Stage.Processing_ID AS ARWE02_PROCESSING_ID
,Stage.filename AS ARWE02_FILENAME 
,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
,@TIME_STAMP  as [ARWE02_CREATE_S]
,@CDSID  as [ARWE02_CREATE_USER_C]
,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
,@CDSID as [ARWE02_LAST_UPDT_USER_C]
,Stage.ARWS45_VA_COVER_PAGE_INFO_K as [ARWE02_BATCH_ERRORS_REF_K]
,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X]
,S53.ASM_COST_CALCULATED as summed_cost
,Stage.final_assembly as s46_fnl_asm_smry_cost
from 
(
select SUM(final_assembly) as final_assembly , S45.filename,S45.Processing_ID,S45.Source_c,S45.ARWS45_VA_COVER_PAGE_INFO_K 
from PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
JOIN dbo.PARWS45_VA_COVER_PAGE_INFO                  S45
    ON S45.Processing_ID       = S46.Processing_ID
--   AND S34.Processing_Status_x = S35.Processing_Status_x
     AND S45.filename            = S46.filename
	 where S45.Skip_loading_due_to_error_f =0
   group by S45.filename,S45.Processing_ID,S45.Source_c,S45.ARWS45_VA_COVER_PAGE_INFO_K
   ) Stage
Join
   (
   select SUM(IsNUll(([assembly_secs_operation]*([machinehourly_operation_overhead]/3600)
				+(([assembly_secs_operation]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])*(1+[indirect_labor_costs])*(1+[fringes]))
				+[packaging_costs]+[logistics_cost]+[tax_duty_per_operation])*[exchange_rate],0)) as ASM_COST_CALCULATED 
				, S45.filename
				,S45.Processing_ID
				,S53.sub_assembly_name
FROM PARWS53_VA_ASSEMBLY_PARTS_INFO S53
JOIN PARWS45_VA_COVER_PAGE_INFO S45
ON S53.Processing_ID = S45.Processing_ID 
AND S53.filename= S45.filename
		 where S45.Skip_loading_due_to_error_f =0
		 and S53.sub_assembly_name ='Adjustment Final Assembly'
		 group by S45.filename,S45.Processing_ID,S53.sub_assembly_name
	) S53
	On Stage.filename = S53.filename
	AND Stage.Processing_ID = S53.Processing_ID	
	where Stage.Processing_ID=@GUID
	) X
	where X.ARWE02_ERROR_X!=''
	and 
	(
	ABS(summed_cost) <  ABS(s46_fnl_asm_smry_cost) - @V_Threshold_A
	  or 
    ABS(summed_cost) >  ABS(s46_fnl_asm_smry_cost) + @V_Threshold_A
	)
;   


END TRY

BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
	    ,0                                 --row_idx
		,''  --Part_index
		,''  --Arrow value	
;

END CATCH

GO
