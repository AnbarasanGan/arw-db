DROP PROCEDURE [dbo].[PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asamriya
-- Create date: 05/31/2019
-- Description:	First Merge statement Updates the column ARWU57_SUBASSY_ORIG_BOB_MRKP_P when matched, when not matched it inserts a row.
--              Second Merge statement updates the column ARWU57_SUBASSY_ORIG_BOB_A
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ashaik12   08/14/2019  Ignore 0's when doing the min.
-- ashaik12  08/22/2019   Changed the join from V09 to V08 to get the subblemblies for the design that have parts quoted.
-- ashaik12  11/5/2019	  Ignore 0's when getting the Min across suppliers for original BoB Amount calculation
-- Ashaik12  01/10/2020   Added TimeStamp parameter 
-- Ashaik12  11/30/2020   US2096264 -- Use calculated total instead of adding 6 columns to get the original bob amount
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY] 
-- Input Parameter
@CCTSS_K INT,
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME


AS

SET NOCOUNT ON;
-----------------------------------------------------------------------------------------------------  

MERGE INTO [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY]   U57
USING
(
select [ARWU01_CCTSS_K], 
[ARWU17_BOM_SUB_ASSY_K], 
[ARWU06_CCTSS_DSGN_K], 
min(1+[COMPOUNDED_TOTAL])  as comp_total_P
from
(
select [ARWU01_CCTSS_K], [ARWU17_BOM_SUB_ASSY_K], [ARWU06_CCTSS_DSGN_K], [COMPOUNDED_TOTAL]
from [dbo].[PARWV20_MFG_MRKP] V20
where V20.ARWU01_CCTSS_K=@CCTSS_K
and V20.[COMPOUNDED_TOTAL] !=0
Union ALL
select  V08.[ARWU01_CCTSS_K], V08.[ARWU17_BOM_SUB_ASSY_K], V08.[ARWU06_CCTSS_DSGN_K], [COMPOUNDED_TOTAL]
  from [dbo].[PARWV14_PROGRAM_MRKUP] V14
  Join [dbo].PARWV08_CCS_SUPL_QUOTE_FLAT V08
    on V08.[ARWU01_CCTSS_K] = V14.[ARWU01_CCTSS_K]
where V14.ARWU01_CCTSS_k = @CCTSS_K
and V14.[COMPOUNDED_TOTAL] !=0

) subAssby_union
group by [ARWU01_CCTSS_K], [ARWU17_BOM_SUB_ASSY_K], [ARWU06_CCTSS_DSGN_K]
) Comp_Tot_Part

  ON 
  
  (Comp_Tot_Part.ARWU06_CCTSS_DSGN_K  = U57.ARWU06_CCTSS_DSGN_K AND
	  Comp_Tot_Part.ARWU17_BOM_SUB_ASSY_K      = U57.ARWU17_BOM_SUB_ASSY_K 
	 )
	 
WHEN MATCHED THEN
     UPDATE SET          
	    U57.ARWU57_SUBASSY_ORIG_BOB_MRKP_P       = comp_total_P
	   ,U57.ARWU57_LAST_UPDT_S      = @TIME_STAMP 
	   ,U57.ARWU57_LAST_UPDT_USER_C = @CDSID
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 ( --Null as ARWU57_CCTSS_DSGN_SUB_ASSY_K: Table has an Identity clause which will create the primary key 
	   ARWU06_CCTSS_DSGN_K
	  ,ARWU17_BOM_SUB_ASSY_K            -- ARWU17_BOM_SUB_ASSY_K
	  ,0                                -- ARWU57_SUBASSY_ORIG_BOB_A
      ,comp_total_P                     -- ARWU57_SUBASSY_ORIG_BOB_MRKP_P
	  ,0                                -- ARWU57_MNLSLCT_PGM_MRKP_RATE_F
	  ,''                               -- ARWU57_MNLSLCT_PGM_MRKP_RATE_X  
	  ,@TIME_STAMP                     -- ARWU18_CREATE_S
	  ,@CDSID							-- ARWU18_CREATE_USER_C
	  ,@TIME_STAMP                     -- ARWU18_LAST_UPDT_S
	  ,@CDSID						    -- ARWU18_LAST_UPDT_USER_C
	 )
;


----------------------------------------------------------
-- Merge statement to insert [ARWU57_SUBASSY_ORIG_BOB_MRKP_P] 
----------------------------------------------------------

MERGE INTO [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY]   U57
USING
(
select isNULL(Min_Labor.Sub_Assembly_Labor*[ARWU57_SUBASSY_ORIG_BOB_MRKP_P],0) as ORIG_BOB_MRKP_A
,Min_Labor.ARWU06_CCTSS_DSGN_K
,Min_Labor.ARWU17_BOM_SUB_ASSY_K
FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] U57
JOIN
(
select min(NULLIF(X.Sub_Assembly_Labor,0)) as Sub_Assembly_Labor
,X.ARWU17_BOM_SUB_ASSY_N
,X.ARWU31_CTSP_N
,X.ARWU17_BOM_SUB_ASSY_K
,X.ARWU06_CCTSS_DSGN_K
from
(
select
 SUM(V13.[ASSEMBLY_COST_LoCur]*V13.ARWU33_CRCY_PER_USD_R) as Sub_Assembly_Labor
,[ARWU31_CTSP_N]
,[ARWU17_BOM_SUB_ASSY_N]
,V13.[ARWU17_BOM_SUB_ASSY_K]
,V13.ARWU06_CCTSS_DSGN_K
FROM [dbo].[PARWV13_CCS_ASSEMBLY_FLAT] V13
JOIN [dbo].[PARWV20_MFG_MRKP] V20
ON V13.ARWU08_CCTSS_DSGN_SUPL_K=V20.[ARWU08_CCTSS_DSGN_SUPL_K]
AND V13.ARWU17_BOM_SUB_ASSY_K=V20.ARWU17_BOM_SUB_ASSY_K
WHERE V13.[ARWU01_CCTSS_K]=@CCTSS_K
GROUP BY V13.[ARWU08_CCTSS_DSGN_SUPL_K],V13.[ARWU17_BOM_SUB_ASSY_K],[ARWU31_CTSP_N]
,[ARWU17_BOM_SUB_ASSY_N],V13.ARWU06_CCTSS_DSGN_K
) X
Group by X.ARWU17_BOM_SUB_ASSY_K,X.ARWU17_BOM_SUB_ASSY_N
,X.ARWU31_CTSP_N,X.ARWU06_CCTSS_DSGN_K

) Min_Labor

  ON Min_Labor.ARWU06_CCTSS_DSGN_K=U57.ARWU06_CCTSS_DSGN_K
  AND Min_Labor.ARWU17_BOM_SUB_ASSY_K=U57.ARWU17_BOM_SUB_ASSY_K
) U57_Source
ON U57.ARWU06_CCTSS_DSGN_K   =U57_Source.ARWU06_CCTSS_DSGN_K
AND U57.ARWU17_BOM_SUB_ASSY_K=U57_Source.ARWU17_BOM_SUB_ASSY_K
WHEN MATCHED THEN
     UPDATE SET 
	  U57.ARWU57_SUBASSY_ORIG_BOB_A=ORIG_BOB_MRKP_A
	 ,U57.ARWU57_LAST_UPDT_S      = @TIME_STAMP 
	 ,U57.ARWU57_LAST_UPDT_USER_C = @CDSID

	 ;


GO
