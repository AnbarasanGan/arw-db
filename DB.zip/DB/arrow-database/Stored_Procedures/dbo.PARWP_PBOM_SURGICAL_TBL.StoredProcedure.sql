DROP PROCEDURE [dbo].[PARWP_PBOM_SURGICAL_TBL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO






-- =============================================
-- Author:		ASHAIK12
-- Create date: 02/18/2020
-- Description:	 Populate a Global temp table that has the Missing Parts/Added Parts/Changed Parts indentified on a PBOM Import
--               And perform necessary actions

-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 04/03/2020  Ashaik12           Changed from float to decimal(19,9) when casting material usage
-- 04/14/2020  Ashaik12           Add logic to capture End Item Modifications.
-- 05/06/2020  Ashaik12           US1592741/US1592743 sub assembly surgical related changes.
-- 05/14/2020  Asolosky US1616235 added diameter to the modify query
-- 05/28/2020  Asolosky US1592745 Code change for the U17 table: Added 'Add Sub Assembly' for new sub-assemblies
--                                and added 'Modify Sub Assembly' to change the sub-assembly.
--                                Change the 'ADD' and 'Delete' selects to use AND S59.sub_assembly_idx_c = U19.ARWU17_BOM_SUB_ASSY_IX_C
--                                instead of joining by sub assembly name.
-- 06/12/202   Asolosky US1687560 Changed the 'Delete' code so the left join on S59 includes and S59.design_name = S59_Cover.design_name
--                                Added a not exists for 'Delete Sub Assembly'.  The user could delete the existing parts but add new part also. 
--                                The not exists checks for new adds in the sub assembly.
-- 09-11-2020  rwesley2 US1910880 Add part index and Arrow value to error. Write error to new E02 error table
-- 10/20/2020  Asolosky US1996362 Switch from E02 to E03 and include Excel column
-- 01/08/2020  Asolosky US2058803 Surgical Delete was not working when all the parts from a design were removed.
--                                Added the select to get the @u01_k, which is used in the delete.  Reworked the part_type = delete select to retrieve  
--                                the existing parts. Then left join to the staging table to see what what was removed from the PBOM import file.
-- 03/18/2021  asolosky US2385952 Table PARWU63_BOM_PART_END_ITM was changed to PARWU63_VRNT_BOM_PART_END_ITM
-- 03/22/2021  asolosky US2385952 'End Item Alignment Deleted' wasn't working correctly. Changed to select all ARROW parts/end items for a BoB. 
--                                When the Arrow part had end items and Excel didn't, they get marked for end item delete. 
-- 05/27/2021  asolosky US2406558 Removed the hard coded join in 'End Item Alignment Deleted'
--                                Changed from: JOIN PARWU63_VRNT_BOM_PART_END_ITM U63 ON U63.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K AND U63.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K AND U63.ARWA57_END_ITM_MAP_TYPE_K = 1
--                                Changed to:   JOIN PARWU63_VRNT_BOM_PART_END_ITM U63 ON U63.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K AND U63.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K AND U63.ARWA57_END_ITM_MAP_TYPE_K = @ARWA57_END_ITM_MAP_TYPE_K 
-- 07/14/2021  asolosky US2701682 Insert into S60 for Delete Sub Assembly could give a false message when the sub-assembly still has manage adjustments against it.
--                                Changed the query to see if there were sub-assemblys from deleted parts that still had manage adjustments.
--                                If found then new error message, 'Sub Assembly won''t be deleted because there are still Manage Adjustment parts assigned to this sub-assembly' 
-- 09/14/2021  asolosky US2873654 The word "Modify" was confusing to the users so it was changed to "Modify Part Dimension(s)"
-- =============================================

 CREATE PROCEDURE  [dbo].[PARWP_PBOM_SURGICAL_TBL] 
-- Input Parameter
 @Processing_ID Varchar(5000),
 @CDSID  varchar(8),
 @result int OUTPUT
 AS

 SET NOCOUNT ON;
 DECLARE @TIME_STAMP DATETIME = GETUTCDATE()
 set @result=0;
 Declare @u01_k int;
 Declare @filename Varchar(max);


BEGIN TRY
Declare @ARWA57_END_ITM_MAP_TYPE_K INT;
 Select @ARWA57_END_ITM_MAP_TYPE_K =( SELECT [dbo].[PARWF_ARWA57_TYPE_X] ('Scope') ); --Function call

 select @U01_k = u01.ARWU01_CCTSS_K
       ,@filename = S59.file_name
   FROM PARWS59_PBOM_PARTS s59 
   join PARWU01_CCTSS_FLAT U01
     ON U01.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
    and U01.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
    and U01.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
    and U01.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
  where S59.Processing_ID             = @Processing_ID
  group by u01.ARWU01_CCTSS_K, S59.file_name
;
INSERT INTO [PARWS60_PBOM_PARTS_MATRIX]
select 
X.ARWU06_CCTSS_DSGN_K,
ARWU17_BOM_SUB_ASSY_N,
X.ARWU14_CCTSS_DSGN_DSPLY_N,
X.ARWU18_BOM_PART_IX_N,
X.ARWU18_BOM_PART_X,
X.ARWU18_BOM_PART_K,
X.ARWU19_DSGN_PART_K,
X.file_name,
X.Processing_ID,
X.PART_TYPE,
X.row_idx,
@TIME_STAMP,
@CDSID,
@TIME_STAMP,
@CDSID,
sub_assembly_idx_c,
ARWU01_CCTSS_K
FROM 
(
--Delete
select 
ARWU06_CCTSS_DSGN_K,
ARWU17_BOM_SUB_ASSY_N,
ARWU14_CCTSS_DSGN_DSPLY_N,
ARWU18_BOM_PART_IX_N,
ARWU18_BOM_PART_X,
ARWU18_BOM_PART_K,
ARWU19_DSGN_PART_K,
file_name,
Processing_ID,
'Delete' as PART_TYPE,
row_idx,
ARWU17_BOM_SUB_ASSY_IX_C as sub_assembly_idx_c,
ARWU01_CCTSS_K
from
(
select U06.ARWU06_CCTSS_DSGN_K, U06.ARWU14_CCTSS_DSGN_DSPLY_N, U06.ARWU01_CCTSS_K
      ,U19.ARWU17_BOM_SUB_ASSY_N,u19.ARWU18_BOM_PART_IX_N, U19.ARWU18_BOM_PART_X, U19.ARWU18_BOM_PART_K, U19.ARWU19_DSGN_PART_K, U19.ARWU17_BOM_SUB_ASSY_IX_C
      ,@Processing_ID as Processing_ID
	  ,@filename      as file_name
      ,0           as row_idx
      ,S59.design_name
  FROM PARWU06_CCTSS_DSGN_FLAT U06
  JOIN PARWU19_DSGN_PART_BOM   U19 
    ON U19.ARWU06_CCTSS_DSGN_K = U06.ARWU06_CCTSS_DSGN_K
  LEFT JOIN PARWS59_PBOM_PARTS S59
    ON S59.Processing_ID                   = @Processing_ID
   and S59.User_Selected_CTSP_N            = U06.ARWU31_CTSP_N
   And S59.User_Selected_CTSP_Region_C     = u06.ARWA06_RGN_C
   And S59.User_Selected_ENRG_SUB_CMMDTY_X = u06.ARWA03_ENRG_SUB_CMMDTY_X
   And S59.User_Selected_BNCMK_VRNT_N      = U06.ARWU01_BNCHMK_VRNT_N
   And S59.design_name                     = U06.ARWU14_CCTSS_DSGN_DSPLY_N
   And S59.part_index                      = U19.ARWU18_BOM_PART_IX_N
   And S59.sub_assembly_idx_c              = U19.ARWU17_BOM_SUB_ASSY_IX_C
 where U06.ARWU01_CCTSS_K = @u01_k
   and S59.part_index     is NULL
) Del
--ADD
UNION
SELECT U06.ARWU06_CCTSS_DSGN_K,s59.sub_assembly_name,U06.ARWU14_CCTSS_DSGN_DSPLY_N, S59.part_index ,s59.[part_name], 
       U19.ARWU18_BOM_PART_K,U19.ARWU19_DSGN_PART_K,file_name,Processing_ID,'Add' as PART_TYPE,row_idx 
      ,S59.sub_assembly_idx_c,U06.ARWU01_CCTSS_K
  FROM PARWS59_PBOM_PARTS S59
  JOIN PARWU06_CCTSS_DSGN_FLAT U06
    on U06.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
   and u06.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
   and u06.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
   and u06.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
   and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
  LEFT JOIN PARWU19_DSGN_PART_BOM U19
    ON U06.ARWU06_CCTSS_DSGN_K       = U19.ARWU06_CCTSS_DSGN_K
   AND S59.part_index                = U19.ARWU18_BOM_PART_IX_N
   AND S59.sub_assembly_idx_c        = U19.ARWU17_BOM_SUB_ASSY_IX_C
 where S59.Processing_ID    = @Processing_ID
   and ARWU18_BOM_PART_IX_N is NULL
UNION
SELECT 
 U06.ARWU06_CCTSS_DSGN_K,U19.ARWU17_BOM_SUB_ASSY_N,U06.ARWU14_CCTSS_DSGN_DSPLY_N,S59.part_index ,U19.ARWU18_BOM_PART_X, 
 U19.ARWU18_BOM_PART_K,U19.ARWU19_DSGN_PART_K,file_name,Processing_ID,'Modify Part Dimension(s)' as PART_TYPE,row_idx 
,S59.sub_assembly_idx_c,U06.ARWU01_CCTSS_K
FROM PARWS59_PBOM_PARTS S59
JOIN PARWU06_CCTSS_DSGN_FLAT U06
on U06.ARWU31_CTSP_N = s59.User_Selected_CTSP_N
and u06.ARWA03_ENRG_SUB_CMMDTY_X = s59.User_Selected_ENRG_SUB_CMMDTY_X
and u06.ARWA06_RGN_C = s59.User_Selected_CTSP_Region_C
and u06.ARWU01_BNCHMK_VRNT_N = s59.User_Selected_BNCMK_VRNT_N
and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
JOIN PARWU19_DSGN_PART_BOM U19
ON U06.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
AND S59.part_index = U19.ARWU18_BOM_PART_IX_N
where S59.Processing_ID =@Processing_ID
and ( ROUND(CAST(case when quantity='' then '0' else quantity end as decimal(19,9)),9) != ARWU19_DSGN_PART_Q
or ROUND(CAST(case when [material_usage]='' then '0' else [material_usage] END as decimal(19,9)),9) ! = ARWU19_DSGN_PART_MTRL_USG_Q 
or material_spec != U19.ARWU19_DSGN_PART_MTRL_SPEC_X
or uom ! = U19.ARWA27_UOM_C
or ROUND(CAST(case when material_thickness='' THEN '0' else material_thickness END as decimal(19,9)),9) != U19.ARWU19_DSGN_PART_MTRL_THK_Q 
or ROUND(CAST(case when length='' then '0' else length end as decimal(19,9)),9) != U19.ARWU19_DSGN_PART_LEN_Q 
or ROUND(CAST(case when width='' then '0' else width end as decimal(19,9)),9) != U19.ARWU19_DSGN_PART_WID_Q 
or depth != U19.ARWU19_DSGN_PART_MTRL_DEPTH_Q 
or [cmmdty_spec1] ! = U19.ARWU19_CMMDTY_SPCFC1_X
or [cmmdty_spec2] ! = U19.ARWU19_CMMDTY_SPCFC2_X
or [cmmdty_spec3] ! = U19.ARWU19_CMMDTY_SPCFC3_X
or ROUND(CAST(case when diameter ='' then '0' else diameter end as decimal(19,9)),9) != U19.ARWU19_DSGN_PART_DIA_Q)
UNION
SELECT 
 U06.ARWU06_CCTSS_DSGN_K,U19.ARWU17_BOM_SUB_ASSY_N,U06.ARWU14_CCTSS_DSGN_DSPLY_N,S59.part_index ,U19.ARWU18_BOM_PART_X, 
 U19.ARWU18_BOM_PART_K,U19.ARWU19_DSGN_PART_K,file_name,Processing_ID,'Update Part Description' as PART_TYPE,row_idx 
,S59.sub_assembly_idx_c,U06.ARWU01_CCTSS_K
FROM PARWS59_PBOM_PARTS S59
JOIN PARWU06_CCTSS_DSGN_FLAT U06
on U06.ARWU31_CTSP_N = s59.User_Selected_CTSP_N
and u06.ARWA03_ENRG_SUB_CMMDTY_X = s59.User_Selected_ENRG_SUB_CMMDTY_X
and u06.ARWA06_RGN_C = s59.User_Selected_CTSP_Region_C
and u06.ARWU01_BNCHMK_VRNT_N = s59.User_Selected_BNCMK_VRNT_N
and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
JOIN PARWU19_DSGN_PART_BOM U19
ON U06.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
AND S59.part_index = U19.ARWU18_BOM_PART_IX_N
where S59.Processing_ID =@Processing_ID
and part_name ! = U19.ARWU18_BOM_PART_X
UNION
SELECT 
 U06.ARWU06_CCTSS_DSGN_K,U19.ARWU17_BOM_SUB_ASSY_N,U06.ARWU14_CCTSS_DSGN_DSPLY_N,S59.part_index ,U19.ARWU18_BOM_PART_X, 
 U19.ARWU18_BOM_PART_K,U19.ARWU19_DSGN_PART_K,file_name,Processing_ID,'Update Part Comments' as PART_TYPE,row_idx
,S59.sub_assembly_idx_c,U06.ARWU01_CCTSS_K
FROM PARWS59_PBOM_PARTS S59
JOIN PARWU06_CCTSS_DSGN_FLAT U06
on U06.ARWU31_CTSP_N = s59.User_Selected_CTSP_N
and u06.ARWA03_ENRG_SUB_CMMDTY_X = s59.User_Selected_ENRG_SUB_CMMDTY_X
and u06.ARWA06_RGN_C = s59.User_Selected_CTSP_Region_C
and u06.ARWU01_BNCHMK_VRNT_N = s59.User_Selected_BNCMK_VRNT_N
and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
JOIN PARWU19_DSGN_PART_BOM U19
ON U06.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
AND S59.part_index = U19.ARWU18_BOM_PART_IX_N
where S59.Processing_ID =@Processing_ID
and comments ! = U19.ARWU19_DSGN_PART_CMT_X
UNION
SELECT 
 U06.ARWU06_CCTSS_DSGN_K,U19.ARWU17_BOM_SUB_ASSY_N,U06.ARWU14_CCTSS_DSGN_DSPLY_N,S59.part_index ,U19.ARWU18_BOM_PART_X, 
 U19.ARWU18_BOM_PART_K,U19.ARWU19_DSGN_PART_K,file_name,Processing_ID,'End Item Alignment Modified' as PART_TYPE,row_idx 
,S59.sub_assembly_idx_c,U06.ARWU01_CCTSS_K
FROM PARWS59_PBOM_PARTS S59
JOIN PARWU06_CCTSS_DSGN_FLAT       U06
  on U06.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
 and u06.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
 and u06.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
 and u06.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
 and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
JOIN [dbo].PARWU19_DSGN_PART_BOM   U19
  ON U06.[ARWU01_CCTSS_K]          = U19.[ARWU01_CCTSS_K]
 AND U06.ARWU06_CCTSS_DSGN_K       = U19.ARWU06_CCTSS_DSGN_K
 AND S59.part_index                = U19.ARWU18_BOM_PART_IX_N
JOIN [dbo].[PARWU04_CCTSS_VRNT]    U04
  ON U04.[ARWU01_CCTSS_K]          = U06.ARWU01_CCTSS_K
 AND U04.[ARWU04_BNCHMK_F]         = 1  -- Data coming from the PBOM file will always be for the Benchmark Variant for which Flag is 1
JOIN PARWU63_VRNT_BOM_PART_END_ITM U63
  ON U63.ARWU04_CCTSS_VRNT_K       = U04.ARWU04_CCTSS_VRNT_K
 AND U63.ARWU18_BOM_PART_K         = U19.ARWU18_BOM_PART_K
 AND U63.ARWA57_END_ITM_MAP_TYPE_K = @ARWA57_END_ITM_MAP_TYPE_K
JOIN PARWA47_FORD_END_ITM          A47
  ON A47.ARWA47_FORD_END_ITM_K     = U63.ARWA47_FORD_END_ITM_K

where S59.Processing_ID =@Processing_ID
  and (   S59.end_item_prefix != A47.ARWA47_FORD_END_ITM_PREF_N
  	   or S59.end_item_base   != A47.ARWA47_FORD_END_ITM_BSE_N
  	   or S59.end_item_suffix != A47.ARWA47_FORD_END_ITM_SFX_N
	  )
  and S59.end_item_base ! =''
UNION
SELECT U06.ARWU06_CCTSS_DSGN_K,s59.sub_assembly_name,U06.ARWU14_CCTSS_DSGN_DSPLY_N, S59.part_index ,s59.[part_name], 
       U19.ARWU18_BOM_PART_K,U19.ARWU19_DSGN_PART_K,file_name,Processing_ID,'End Item Alignment Added' as PART_TYPE,row_idx 
      ,S59.sub_assembly_idx_c,U06.ARWU01_CCTSS_K
FROM PARWS59_PBOM_PARTS S59
JOIN PARWU06_CCTSS_DSGN_FLAT U06
on U06.ARWU31_CTSP_N = s59.User_Selected_CTSP_N
and u06.ARWA03_ENRG_SUB_CMMDTY_X = s59.User_Selected_ENRG_SUB_CMMDTY_X
and u06.ARWA06_RGN_C = s59.User_Selected_CTSP_Region_C
and u06.ARWU01_BNCHMK_VRNT_N = s59.User_Selected_BNCMK_VRNT_N
and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
JOIN PARWU19_DSGN_PART_BOM U19
ON U06.ARWU06_CCTSS_DSGN_K = U19.ARWU06_CCTSS_DSGN_K
AND S59.part_index = U19.ARWU18_BOM_PART_IX_N
JOIN [dbo].[PARWU04_CCTSS_VRNT]    U04
  ON U04.[ARWU01_CCTSS_K]          = U06.ARWU01_CCTSS_K
 AND U04.[ARWU04_BNCHMK_F]         = 1  -- Data coming from the PBOM file will always be for the Benchmark Variant for which Flag is 1
Left JOIN PARWU63_VRNT_BOM_PART_END_ITM U63
  ON U63.ARWU04_CCTSS_VRNT_K       = U04.ARWU04_CCTSS_VRNT_K
 AND U63.ARWU18_BOM_PART_K         = U19.ARWU18_BOM_PART_K
 AND U63.ARWA57_END_ITM_MAP_TYPE_K = @ARWA57_END_ITM_MAP_TYPE_K
where S59.Processing_ID =@Processing_ID
and U63.ARWU18_BOM_PART_K is NULL
and (S59.end_item_base!='' and S59.end_item_suffix!='')
UNION
select 
       prts.ARWU06_CCTSS_DSGN_K ,
       prts.[ARWU17_BOM_SUB_ASSY_N] ,
       prts.ARWU14_CCTSS_DSGN_DSPLY_N,
       prts.ARWU18_BOM_PART_IX_N,
       prts.ARWU18_BOM_PART_X,
       prts.[ARWU18_BOM_PART_K],
       prts.[ARWU19_DSGN_PART_K],
       S59.file_name ,
       S59.Processing_ID,
       'End Item Alignment Deleted' as PART_TYPE,
       0 as row_idx,
       S59.sub_assembly_idx_c, 
       prts.ARWU01_CCTSS_K
  FROM
(select U06.ARWU01_CCTSS_K, u06.ARWU06_CCTSS_DSGN_K
       ,U06.ARWU31_CTSP_N
       ,u06.ARWA06_RGN_C  
       ,u06.ARWA03_ENRG_SUB_CMMDTY_X 
       ,u06.ARWU01_BNCHMK_VRNT_N
       ,u06.ARWU14_CCTSS_DSGN_DSPLY_N
       ,U18.ARWU18_BOM_PART_K, U18.ARWU18_BOM_PART_IX_N, U18.ARWU18_BOM_PART_X
	   ,U19.ARWU19_DSGN_PART_K, U19.ARWU17_BOM_SUB_ASSY_N
	   ,ARWA47_FORD_END_ITM_PREF_N, ARWA47_FORD_END_ITM_BSE_N, a47.ARWA47_FORD_END_ITM_SFX_N
  from PARWU06_CCTSS_DSGN_FLAT u06      
  Join PARWU18_BOM_PART        U18
    On U18.ARWU01_CCTSS_K       = U06.ARWU01_CCTSS_K
  JOIN PARWU19_DSGN_PART_BOM U19
    ON U19.ARWU06_CCTSS_DSGN_K  = U06.ARWU06_CCTSS_DSGN_K
   And U19.ARWU18_BOM_PART_K    = U18.ARWU18_BOM_PART_K
  JOIN [dbo].[PARWU04_CCTSS_VRNT]    U04
    ON U04.[ARWU01_CCTSS_K]          = U06.ARWU01_CCTSS_K
   AND U04.[ARWU04_BNCHMK_F]         = 1  -- Data coming from the PBOM file will always be for the Benchmark Variant for which Flag is 1
  JOIN PARWU63_VRNT_BOM_PART_END_ITM U63
    ON U63.ARWU04_CCTSS_VRNT_K       = U04.ARWU04_CCTSS_VRNT_K
   AND U63.ARWU18_BOM_PART_K         = U19.ARWU18_BOM_PART_K
   AND U63.ARWA57_END_ITM_MAP_TYPE_K = @ARWA57_END_ITM_MAP_TYPE_K
  JOIN [dbo].[PARWA47_FORD_END_ITM]  A47
    on U63.[ARWA47_FORD_END_ITM_K] = A47.[ARWA47_FORD_END_ITM_K]
 where U06.ARWU01_CCTSS_K = @u01_k
) prts
LEFT JOIN PARWS59_PBOM_PARTS S59
  on s59.User_Selected_CTSP_N            = prts.ARWU31_CTSP_N
 and s59.User_Selected_CTSP_Region_C     = prts.ARWA06_RGN_C 
 and s59.User_Selected_ENRG_SUB_CMMDTY_X = prts.ARWA03_ENRG_SUB_CMMDTY_X
 and s59.User_Selected_BNCMK_VRNT_N      = prts.ARWU01_BNCHMK_VRNT_N
 and s59.design_name                     = prts.ARWU14_CCTSS_DSGN_DSPLY_N
 and S59.part_index                      = prts.ARWU18_BOM_PART_IX_N
WHERE S59.Processing_ID               = @Processing_ID
 and S59.end_item_prefix              = ''
 AND S59.end_item_base                = '' 
 AND S59.end_item_suffix              = ''
 and prts.ARWA47_FORD_END_ITM_PREF_N != ''
 and prts.ARWA47_FORD_END_ITM_BSE_N  != ''
 and prts.ARWA47_FORD_END_ITM_SFX_N  != ''

UNION
Select 0                   as ARWU06_CCTSS_DSGN_K
	  ,sub_assembly_name
	  ,''                  as ARWU14_CCTSS_DSGN_DSPLY_N 
	  ,''                  as part_index 
	  ,''                  as part_name
      ,0                   as ARWU18_BOM_PART_K
	  ,0                   as ARWU19_DSGN_PART_K
	  ,file_name
	  ,Processing_ID
	  ,'Add Sub Assembly'  as PART_TYPE
	  ,row_idx
	  ,sub_assembly_idx_c
	  ,ARWU01_CCTSS_K
  From
      (SELECT s59.sub_assembly_name
			 ,S59.part_index 
			 ,s59.part_name
			 ,file_name
			 ,Processing_ID
			 ,row_idx 
       	     ,row_number() over (partition by S59.sub_assembly_idx_c order by row_idx) as row_num
	         ,S59.sub_assembly_idx_c
			 ,U01.ARWU01_CCTSS_K
         FROM PARWS59_PBOM_PARTS   S59
         JOIN PARWU01_CCTSS_FLAT   U01
           on U01.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
          and U01.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
          and U01.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
          and U01.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
        where S59.Processing_ID  = @Processing_ID
          and NOT EXISTS   
               (Select 'X'
          	      From PARWU17_BOM_SUB_ASSY  SUB
          	     Where SUB.ARWU01_CCTSS_K           = U01.ARWU01_CCTSS_K
          		   and SUB.ARWU17_BOM_SUB_ASSY_IX_C = S59.sub_assembly_idx_c
          	    )
      ) S59
 Where row_num = 1
Union 
Select 0                      as ARWU06_CCTSS_DSGN_K
	  ,sub_assembly_name	  
	  ,''                     as ARWU14_CCTSS_DSGN_DSPLY_N 
	  ,''                     as part_index 			  
	  ,''                     as part_name			  
      ,0                      as ARWU18_BOM_PART_K
	  ,0                      as ARWU19_DSGN_PART_K
	  ,file_name
	  ,Processing_ID
	  ,'Modify Sub Assembly Name'  as PART_TYPE
	  ,row_idx
	  ,sub_assembly_idx_c
	  ,ARWU01_CCTSS_K

  From
      (SELECT s59.sub_assembly_name
			 ,S59.part_index 
			 ,s59.part_name
			 ,file_name
			 ,Processing_ID
			 ,row_idx
			 ,row_number() over (partition by S59.sub_assembly_idx_c order by row_idx) as row_num
	         ,S59.sub_assembly_idx_c
			 ,U01.ARWU01_CCTSS_K
         FROM PARWS59_PBOM_PARTS         S59
         JOIN PARWU01_CCTSS_FLAT   U01
           on U01.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
          and U01.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
          and U01.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
          and U01.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
         Join PARWU17_BOM_SUB_ASSY       U17
           on U17.ARWU01_CCTSS_K            = U01.ARWU01_CCTSS_K
          and U17.ARWU17_BOM_SUB_ASSY_IX_C  = S59.sub_assembly_idx_c
        where S59.Processing_ID      = @Processing_ID
          and S59.sub_assembly_name != U17.ARWU17_BOM_SUB_ASSY_N
      ) S59
 Where row_num = 1
) X
;

INSERT INTO [PARWS60_PBOM_PARTS_MATRIX]
select 
       ARWU06_CCTSS_DSGN_K,
       sub_assembly_name as ARWU17_BOM_SUB_ASSY_N,
       ''                as ARWU14_CCTSS_DSGN_DSPLY_N,
       ''                as ARWU18_BOM_PART_IX_N,
       ''                as ARWU18_BOM_PART_X,
       ARWU18_BOM_PART_K,
       ARWU19_DSGN_PART_K,
       file_name,
       Processing_ID,
       PART_TYPE,
       row_idx,
       @TIME_STAMP,
       @CDSID,
       @TIME_STAMP,
       @CDSID,
	   sub_assembly_idx_c,
       ARWU01_CCTSS_K
FROM
( 
 Select ARWU06_CCTSS_DSGN_K, sub_assembly_name, ARWU14_CCTSS_DSGN_DSPLY_N, part_index, part_name
       ,ARWU18_BOM_PART_K, ARWU19_DSGN_PART_K, file_name, Processing_ID
	   ,Case When ADJ_SUB_ARWU17_BOM_SUB_ASSY_K is Null
	         Then 'Delete Sub Assembly' 
		 	 Else 'Sub Assembly not deleted. Manage Adjustment part adds are still assigned to this sub-assembly.'
	    End as PART_TYPE 
	   ,row_idx
	   ,sub_assembly_idx_c, ARWU01_CCTSS_K
   from
  (select S60.ARWU06_CCTSS_DSGN_K
         ,S60.ARWU17_BOM_SUB_ASSY_N     as sub_assembly_name
         ,S60.ARWU14_CCTSS_DSGN_DSPLY_N
         ,S60.ARWU18_BOM_PART_IX_N      as part_index
         ,S60.ARWU18_BOM_PART_X         as part_name
         ,S60.ARWU18_BOM_PART_K
         ,S60.ARWU19_DSGN_PART_K
	     ,S60.file_name
	     ,S60.Processing_ID
	     ,-1                            as row_idx  -- So it'll sort first
	     ,ROW_NUMBER() over (partition by S60.ARWU17_BOM_SUB_ASSY_N order by S60.ARWU18_BOM_PART_X) as row_num
	     ,S60.sub_assembly_idx_c
	     ,S60.ARWU01_CCTSS_K
		 ,ADJ_SUB.ARWU17_BOM_SUB_ASSY_K as ADJ_SUB_ARWU17_BOM_SUB_ASSY_K
     from PARWS60_PBOM_PARTS_MATRIX S60
     Join PARWU18_BOM_PART          U18 ON U18.ARWU18_BOM_PART_K     = S60.ARWU18_BOM_PART_K
     Join PARWU17_BOM_SUB_ASSY      U17 ON U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
Left Join (--Design Adjustments
           select distinct
                  U17.ARWU17_BOM_SUB_ASSY_K
                 ,U17.ARWU17_BOM_SUB_ASSY_N
             from PARWS60_PBOM_PARTS_MATRIX S60
             Join PARWU37_CCTSS_DSGN_ADJ  U37 ON U37.ARWU06_CCTSS_DSGN_K   = S60.ARWU06_CCTSS_DSGN_K
             Join PARWU18_BOM_PART        U18 ON U18.ARWU18_BOM_PART_K     = U37.ARWU18_BOM_PART_K
             Join PARWU17_BOM_SUB_ASSY    U17 ON U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
            Where S60.Processing_ID  = @Processing_ID
              and S60.PART_TYPE      = 'Delete'
	       Union --Improvement Ideas
           select distinct
                  U17.ARWU17_BOM_SUB_ASSY_K
                 ,U17.ARWU17_BOM_SUB_ASSY_N
             from PARWS60_PBOM_PARTS_MATRIX S60
             Join PARWU46_CCTSS_DSGN_IMPRV  U46 ON U46.ARWU06_CCTSS_DSGN_K   = S60.ARWU06_CCTSS_DSGN_K
             Join PARWU18_BOM_PART          U18 ON U18.ARWU18_BOM_PART_K     = U46.ARWU18_BOM_PART_K
             Join PARWU17_BOM_SUB_ASSY      U17 ON U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
            Where S60.Processing_ID  = @Processing_ID
              and S60.PART_TYPE      = 'Delete'
	       Union --Variant Adjustments
           select distinct
                  U17.ARWU17_BOM_SUB_ASSY_K
                 ,U17.ARWU17_BOM_SUB_ASSY_N
             from PARWS60_PBOM_PARTS_MATRIX S60
			 Join PARWU04_CCTSS_VRNT        U04 ON U04.ARWU01_CCTSS_K        = S60.ARWU01_CCTSS_K
             Join PARWU65_CCTSS_VRNT_ADJ    U65 ON U65.ARWU04_CCTSS_VRNT_K   = U04.ARWU04_CCTSS_VRNT_K
             Join PARWU18_BOM_PART          U18 ON U18.ARWU18_BOM_PART_K     = U65.ARWU18_BOM_PART_K
             Join PARWU17_BOM_SUB_ASSY      U17 ON U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
            Where S60.Processing_ID  = @Processing_ID
              and S60.PART_TYPE      = 'Delete'
  		  ) ADJ_SUB
	   On ADJ_SUB.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
    Where S60.Processing_ID  = @Processing_ID
      and S60.PART_TYPE      = 'Delete'
      and not exists
	    (
          Select 'X'
            FROM PARWU19_DSGN_PART_FLAT u19
            join PARWS59_PBOM_PARTS     S59
              ON u19.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
             and u19.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
             and u19.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
             and u19.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
             and u19.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
             and U19.ARWU18_BOM_PART_IX_N      = S59.part_index
             and u19.ARWU17_BOM_SUB_ASSY_IX_C  = S59.sub_assembly_idx_c 
           Where S59.Processing_ID             = S60.Processing_ID
             and S59.sub_assembly_idx_c        = S60.sub_assembly_idx_c
           group by u19.ARWU17_BOM_SUB_ASSY_N
         )
      and not exists
	    (
          Select 'X'
            FROM PARWS60_PBOM_PARTS_MATRIX MTX
           Where MTX.Processing_ID             = S60.Processing_ID
             and MTX.sub_assembly_idx_c        = S60.sub_assembly_idx_c
			 and MTX.PART_TYPE      = 'Add'
         )
) sub
Where row_num = 1
)X;

SET @result=1
END TRY

BEGIN CATCH
 SET @result=0

 INSERT INTO PARWE03_BATCH_PBOM_ERRORS
 SELECT  
               'SYSTEM'                          --source_c
              ,'Catch Error'                     --error_value
              ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
              ,@Processing_ID								--Processing_id
              ,'UNKNOWN'                         --Filename
              ,ERROR_PROCEDURE()                 --Procedure_x
              ,@TIME_STAMP
              ,@CDSID
              ,@TIME_STAMP
              ,@CDSID
 			  ,''
 			  ,'PBOM Parts Matrix Table' 
 			  --ARWE03_BATCH_ERRORS_K Identity key 
 			  ,'ERROR'
 			  ,'SYSTEM'
 			  ,0                                -- row_idx
	          ,''                               -- part_index 
		      ,''                               -- ARROW_VALUE
              ,''                               -- Column
 END CATCH;

RETURN @result
;


GO
