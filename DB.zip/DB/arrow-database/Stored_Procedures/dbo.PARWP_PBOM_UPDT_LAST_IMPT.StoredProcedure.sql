DROP PROCEDURE [dbo].[PARWP_PBOM_UPDT_LAST_IMPT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Asolosky
-- Create date: 01/15/2019
-- Description:	load ARROW U01 BoB table with last import information
--              Code was copied from PARWP_CCS_UPDT_LAST_IMPT
-- IN parameter:  @GUIDIN  - Staging processing ID
--                @CDSID   - User that ran the file import
--                @TIME_STAMP - Time the user did the import
--                @PROCESSING_STATUS - Indicates what happened during proceesing. 'Regular','Processing_Error','Validation Error'
--                @CCTSS_K - BoB Program key
-- Out paramenter:@result - 1 indicates the program ran without any abnormal error. 0 indicates an abnormal error (system processin error)
-- How to run:
--   Declare @GUIDIN varchar(500);
--   Declare @CDSID  varchar(8);
--   Declare @TIME_STAMP datetime;
--   Declare @PROCESSING_STATUS Varchar(50)
--   Declare @CCTSS_K INT;
--   Declare @LAST_IMPT_result INT;
--   execute PARWP_PBOM_UPDT_LAST_IMPT 'F4A1CC72-30B9-49DA-8824-E2E2C1993BC9', 'ASOLOSKY', GETUTCDATE(),'Regular', 1, @LAST_IMPT_result OUTPUT;
--   select @LAST_IMPT_result as LAST_IMPT_result;
-- =============================================
-- Changes
-- Author    Date      User Story  Description
-- ------   --------   ----------  -----------
-- ASOLOSKY 07/18/2020 US1694181   Added Template version to the update
-- rwesley2 09-11-2020 US1910880   Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky 10/20/2020 US1996362   Switch from E02 to E03 and include Excel column
-- ASOLOSKY 10/26/2020 US1950592   Changed update of Template version to only happen when there's no error.
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_PBOM_UPDT_LAST_IMPT] 
-- Input Parameters
 @GUIDIN                 Varchar(5000)
,@CDSID	                 Varchar(30)
,@TIME_STAMP             datetime
,@PROCESSING_STATUS      Varchar(50)
,@CCTSS_K                int
,@LAST_IMPT_result       Varchar(20) Output

AS

SET NOCOUNT ON;
Set @LAST_IMPT_result = '';

Declare @file_name      Varchar(5000);
Declare @version        Varchar(max);

BEGIN TRY

--Get filename
SELECT TOP (1)
       @file_name = file_name,
	   @version   = TEMPLATE_VERSION
  From PARWS59_PBOM_PARTS
 Where Processing_ID = @GUIDIN; 

MERGE INTO PARWU01_CCTSS  U01_Target
USING
(
 select   
        U01.ARWU01_CCTSS_K   
	   ,A45.[ARWA45_PBOM_STAT_K] 
	   ,A45.[ARWA45_PBOM_STAT_N]
	   ,case when @PROCESSING_STATUS = 'Processing_Error' then 'Error'			
		     when @PROCESSING_STATUS = 'Regular'          then 'No Error'
		     else 'Error'  --When its a 'Validation Error'
		end AS PROCESSING_STATUS
	   ,U01.ARWA45_PBOM_STAT_K         as Current_Status
	   ,U01.[ARWU01_PBOM_LAST_IMPT_USER_C] as Current_Imp_User
	   ,U01.[ARWU01_PBOM_LAST_IMPT_S]      as Current_Imp_Timestamp
	   ,U01.[ARWU01_PBOM_LAST_IMPT_FILE_N] as Current_Imp_filename  
	   ,U01.[ARWA49_PBOM_FILE_VER_K]       as U01_ARWA49_PBOM_FILE_VER_K
	   ,A49.ARWA49_PBOM_FILE_VER_K         as A49_ARWA49_PBOM_FILE_VER_K
	    
   from PARWU01_CCTSS_FLAT U01
   JOIN PARWA45_PBOM_STAT A45			
	 ON A45.ARWA45_PBOM_STAT_N = case when @PROCESSING_STATUS = 'Processing_Error'  
		                              and U01.ARWA45_PBOM_STAT_K = (select ARWA45_PBOM_STAT_K 
									                                  from PARWA45_PBOM_STAT 
			                                                         where ARWA45_PBOM_STAT_N = 'Not Imported'
										                           )	
			                          then 'Not Imported'
			                          when @PROCESSING_STATUS = 'Regular' 
									  then 'Imported'
			                          else 'Import Error' --When its a 'Validation Error'
								 end
   Join PARWA49_PBOM_FILE_VER A49 on A49.ARWA49_PBOM_FILE_VER_N = @version

  Where U01.ARWU01_CCTSS_K = @CCTSS_K
) U01_Source
ON  U01_Target.ARWU01_CCTSS_K  =  U01_Source.ARWU01_CCTSS_K
WHEN MATCHED THEN
     UPDATE SET         	
	   
 U01_Target.ARWU01_PBOM_LAST_IMPT_FILE_N = case when PROCESSING_STATUS = 'No Error' 
                                                then @file_name
												else U01_Source.Current_Imp_filename 
										   end
,U01_Target.ARWU01_PBOM_LAST_IMPT_S      = case when PROCESSING_STATUS = 'No Error' 
                                                then @TIME_STAMP 
												else U01_Source.Current_Imp_Timestamp 
										   end
,U01_Target.ARWU01_PBOM_LAST_IMPT_USER_C = case when PROCESSING_STATUS = 'No Error' 
                                                then @CDSID 
												else U01_Source.Current_Imp_User 
										   end
,U01_Target.ARWA45_PBOM_STAT_K           = case when U01_Source.ARWA45_PBOM_STAT_N = 'Not Imported' and PROCESSING_STATUS = 'Error'
                                                then (select ARWA45_PBOM_STAT_K 
											            from PARWA45_PBOM_STAT 
											           where ARWA45_PBOM_STAT_N    = 'Not Imported'
											         )
										        when U01_Source.ARWA45_PBOM_STAT_N = 'Imported'     and PROCESSING_STATUS = 'Error' 
											    then (select ARWA45_PBOM_STAT_K 
											            from PARWA45_PBOM_STAT 
											    	   where ARWA45_PBOM_STAT_N    = 'Import Error'
											    	 )
										        when U01_Source.ARWA45_PBOM_STAT_N = 'Import Error' and PROCESSING_STATUS = 'Error' 
											    then (select ARWA45_PBOM_STAT_K 
											            from PARWA45_PBOM_STAT 
											    	   where ARWA45_PBOM_STAT_N    = 'Import Error'
											         )
										        else (select ARWA45_PBOM_STAT_K 
											            from PARWA45_PBOM_STAT
											    	   where ARWA45_PBOM_STAT_N    = 'Imported'
											    	  )
									       end
,U01_Target.ARWU01_LAST_UPDT_S			 = @TIME_STAMP
,U01_Target.ARWU01_LAST_UPDT_USER_C      = @CDSID
,U01_Target.ARWA49_PBOM_FILE_VER_K       = case when PROCESSING_STATUS = 'No Error' 
                                                then U01_Source.A49_ARWA49_PBOM_FILE_VER_K
												else U01_Source.U01_ARWA49_PBOM_FILE_VER_K 
										   end 
;

Set @LAST_IMPT_result = 'NO ERROR';
   
END TRY

--CATCH
BEGIN CATCH
   Rollback;
   Set @LAST_IMPT_result = 'SYSTEM ERROR';

  INSERT INTO PARWE03_BATCH_PBOM_ERRORS
  SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUIDIN                           --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE03_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'PARWP_PBOM_UPDT_LAST_IMPT'
        ,0                              as ARWE03_ROW_IDX	
		,''                               -- part_index 
		,''                               -- ARROW_VALUE	
		,''                               -- Column
  ;
END CATCH;

Return

GO
