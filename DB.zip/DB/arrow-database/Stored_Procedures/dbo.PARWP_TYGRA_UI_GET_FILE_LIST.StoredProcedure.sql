DROP PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_FILE_LIST]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Get tygra file(s) to process
-- business rules: returned list of files from ACT based on Program name
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2	  05-06-2021  US2458193 use SYNONYM for linked server name 
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_FILE_LIST] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@U41_ProgramNm varchar(50) 
--,@file_type     varchar(50)
--@GUID varchar(500) 

AS


SET NOCOUNT ON;

--DECLARE @U41_ProgramNm varchar(50);
--,@GUID varchar(500) 
--DECLARE @BCJU41_FileNameSPTygra Varchar(1000);  
CREATE TABLE ##file_list (
         BCJU41_ProgramNm   varchar(50)   
        ,BCJU41_WRKSHP_NUM_C  varchar(50)      
        ,BCJU41_WRKSHP_STATUS_C varchar(10)
		,BCJU41_FileNameSPTygra Varchar(1000)
	    ,BCJU51_VERSION_F  INT
		,BCJU41_TygraSPFileLastModifiedDtTm datetime
        ,BCJU41_TYGRA_ID_K INT
		,file_selected    varchar(1)
		                        )
 	;

---******************************************************
-- in UI user selects program.  Program is passed to ACT V53 and a list of file names is 
-- returned to UI. 
 --******************************************************
-- For testing. in prod this will be passed in from UI
--set @U41_ProgramNm = 'u71x' ; -- passed in from UI

-- returns all distinct files
INSERT INTO ##file_list
select 
[BCJU41_ProgramNm]     
,[BCJU41_WRKSHP_NUM_C]        
,[BCJU41_WRKSHP_STATUS_C]   
,[BCJU41_FileNameSPTygra]    
,[BCJU51_VERSION_F]
,[BCJU41_TygraSPFileLastModifiedDtTm] 
,[BCJU41_TYGRA_ID_K]
,'N'
 from [dbo].[PBCJV53_TYGRA_ARROW_LNK_SYN]
where BCJU41_ProgramNm = @U41_ProgramNm 
group by  [BCJU41_ProgramNm],[BCJU41_FileNameSPTygra],[BCJU41_WRKSHP_NUM_C],[BCJU41_WRKSHP_STATUS_C],[BCJU51_VERSION_F],[BCJU41_TygraSPFileLastModifiedDtTm],[BCJU41_TYGRA_ID_K]
--order by  [BCJU41_ProgramNm],[BCJU41_FileNameSPTygra],[BCJU41_WRKSHP_NUM_C],[BCJU41_WRKSHP_STATUS_C]
;

select * from  ##file_list


GO
