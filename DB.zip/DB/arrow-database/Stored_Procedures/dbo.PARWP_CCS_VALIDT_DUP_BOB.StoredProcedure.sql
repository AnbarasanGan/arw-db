DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_DUP_BOB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 05/01/2019
-- Description:	Stored Procedure to Validate if a BoB already exists for a Design and Supplier in the same Batch being processed.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   06/14/2019  Added dup check for user selected data
-- Asolosky   06/14/2019  Added design_model_year,design_Var,supplier_code to the partition by
-- Asolosky   09/10/2019  Added row_idx
-- Ashaik12   12/25/2019  Added supplier country to partition by
-- Ashaik12   01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_DUP_BOB] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(5000)
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
-- =============================================
-- Dup check against Cover Page select data
-- =============================================
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   X.Source_c                            as ARWE02_SOURCE_C
	  ,X.filename                            as ARWE02_ERROR_VALUE 
	  ,'A duplicate "Cover Page" - BoB (Program, Region, Sub-Commodity, Benchmark Variant Name), Design and Supplier was imported in the same batch. Only one can be imported per batch.' as ARWE02_ERROR_X
	  ,X.Processing_ID                       as ARWE02_PROCESSING_ID
	  ,X.filename                            as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,X.ARWS22_CCS_COVER_PAGE_INFO_K        as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS22_CCS_COVER_PAGE_INFO'         as ARWE02_STAGING_TABLE_X
	  -- Identity Key Column
	  ,'ERROR' as ARWE02_ERROR_TYPE
	  ,'Cover' as ARWE02_EXCEL_TAB
	  ,0                                     as ARWE02_ROW_IDX
	  ,''  --No part index
	  ,''  --No ARROW Value
	  FROM
	  (
select 
 COUNT(*) OVER (PARTITION BY Program,S22.Region,Eng_SubCommodity_name,Benchmark_Var_N,
                             design_Brand,design_Model,design_model_year,design_Var,
							 supplier_code, supplier_name,[supplier_country],Processing_ID) AS COUNT_BOB1
,filename
	  ,Program
	  ,S22.Region
	  ,Eng_SubCommodity_name
	  ,Benchmark_Var_N
	  ,design_Brand
	  ,design_Model
	  ,supplier_name
	  ,Source_c
	  ,Processing_ID
	  ,ARWS22_CCS_COVER_PAGE_INFO_K
from PARWS22_CCS_COVER_PAGE_INFO S22  
where Processing_ID=@GUID
) X
where COUNT_BOB1>1 ;

-- =============================================
-- Dup check against User select data
-- =============================================
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   X.Source_c                            as ARWE02_SOURCE_C
	  ,X.filename                            as ARWE02_ERROR_VALUE 
	  ,'A duplicate "User Selected File" - BoB (Program, Region, Sub-Commodity, Benchmark Variant Name), Design and Supplier was imported in the same batch. Only one can be imported per batch.' as ARWE02_ERROR_X
	  ,X.Processing_ID                       as ARWE02_PROCESSING_ID
	  ,X.filename                            as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,X.ARWS22_CCS_COVER_PAGE_INFO_K        as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS22_CCS_COVER_PAGE_INFO'         as ARWE02_STAGING_TABLE_X
	  -- Identity Key Column
	  ,'ERROR' as ARWE02_ERROR_TYPE
	  ,'Cover' as ARWE02_EXCEL_TAB
	  ,0                                     as ARWE02_ROW_IDX
	  ,''  --No part index
	  ,''  --No ARROW Value
	  FROM
	  (
select 
       COUNT(*) OVER (PARTITION BY User_Selected_CTSP_N, User_Selected_CTSP_Region_C, User_Selected_ENRG_SUB_CMMDTY_X, User_Selected_BNCMK_VRNT_N,
	                              User_Selected_VEH_MAKE_N,   User_Selected_VEH_MDL_N, User_Selected_VEH_MDL_YR_C, User_Selected_VEH_MDL_VRNT_X,
							      User_Selected_SUPL_CNTRY_N, User_Selected_SUPL_N,    User_Selected_SUPL_C 
			         ) AS COUNT_BOB1
      ,filename
	  ,Source_c
	  ,User_Selected_CTSP_N
	  ,User_Selected_CTSP_Region_C
	  ,User_Selected_ENRG_SUB_CMMDTY_X
	  ,User_Selected_BNCMK_VRNT_N
	  ,User_Selected_VEH_MAKE_N
	  ,User_Selected_VEH_MDL_N
	  ,User_Selected_SUPL_CNTRY_N
	  ,User_Selected_SUPL_C
	  ,User_Selected_SUPL_N
	  ,Processing_ID
	  ,ARWS22_CCS_COVER_PAGE_INFO_K
from PARWS22_CCS_COVER_PAGE_INFO S22  
where Processing_ID=@GUID
) X
where COUNT_BOB1>1 ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS22_CCS_COVER_PAGE_INFO'
			 --Identity Key Column
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;


GO
