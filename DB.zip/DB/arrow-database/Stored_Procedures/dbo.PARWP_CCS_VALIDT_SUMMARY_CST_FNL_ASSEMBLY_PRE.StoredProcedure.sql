DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUMMARY_CST_FNL_ASSEMBLY_PRE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/18/2019
-- Description:	Validate if sum of Final Assembly unit cost in usd is equal to the cost in Summary table. 
-- =============================================
-- Changes
-- =============================================
--                     User
-- Author   Date       Story     Description
-- ------   -----      --------  -----------
-- Ashaik12 01/10/2020           Added TimeStamp parameter
-- Asolosky 09/11/2020 US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky 12/14/2020 US2137799 Changed SUM(S17.unit_cost_usd) as summed_cost, to a formula that matched Excel. This was done in case the users over-wrote the Excel Formula.
-- Asolosky 01/19/2021 US2164194 Changed the threshold from a dynamic number which used the UpperBound and LowerBound function, to a static number.
--                               The static threshold number is passed in from the master procedure and is based on the PARWT01_THRESHOLD table.
-- Asolosky 01/21/2021 US2209131 Use ARWA10_COST_EST_PERFD_F instead of ARWA10_CCTSS_METHD_N like '%DEA%'
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUMMARY_CST_FNL_ASSEMBLY_PRE] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
    -- Sub-Assembly Name validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
 X.Source_c                     as ARWE02_SOURCE_C
,Cast(s21_cost as varchar(50))  as ARWE02_ERROR_VALUE
,'Final Assembly total in Supplier Quote Summary does not match calculated Final Assembly total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column X/Z of the Final Assembly sheet' as ARWE02_ERROR_X
,Processing_ID                  as [ARWE02_PROCESSING_ID]
,filename                       as [ARWE02_FILENAME]
,OBJECT_NAME(@@PROCID)          as [ARWE02_PROCEDURE_X]
,@TIME_STAMP                    as [ARWE02_CREATE_S]
,@CDSID                         as [ARWE02_CREATE_USER_C]
,@TIME_STAMP                    as [ARWE02_LAST_UPDT_S]
,@CDSID                         as [ARWE02_LAST_UPDT_USER_C]
,ARWS21_CCS_SUMMARY_K           as [ARWE02_BATCH_ERRORS_REF_K]
,'PARWS21_CCS_SUMMARY_TAB_INFO' as [ARWE02_STAGING_TABLE_X]
,'ERROR'
,sub_assembly_name  --Sheet Name
,0                               as ARWE02_ROW_IDX
,''                             --Part_index
,Cast(summed_cost as varchar(50))       --Arrow value	
FROM 
(
select 
       S21.[Source_c] 
      ,S17.sub_assembly_name
	  ,S22.[Processing_ID] 
	  ,S22.[filename] 
	  ,S21.[ARWS21_CCS_SUMMARY_K] 
      ,SUM(
	       CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and ARWA53_LGCY_CCS_PGM_N is NULL
		    	THEN IsNUll(((S17.assembly_secs_operation * (S17.machinehourly_operation_overhead/3600))
				            +(S17.total_labor_minutes*(S17.direct_hourly_labor_headcount/60)) 
						    + S17.packaging_costs  + S17.logistics_cost + S17.tax_duty_per_operation
						   )* S17.exchange_rate,0)	

		    	ELSE IsNUll(((S17.assembly_secs_operation * (S17.machinehourly_operation_overhead/3600))
				            +((S17.assembly_secs_operation * (S17.direct_hourly_labor_headcount/3600)*S17.direct_headcount)
							*(1+S17.indirect_labor_costs)*(1+S17.fringes))
							+ S17.packaging_costs  + S17.logistics_cost + S17.tax_duty_per_operation
						   )* S17.exchange_rate,0)		
	       END
	   )  as summed_cost
	  ,S21.cost as s21_cost
  from [dbo].[PARWS21_CCS_SUMMARY_TAB_INFO] S21
  JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO]  S22
    ON S21.Processing_ID = S22.Processing_ID
   AND S21.filename      = S22.filename
  JOIN [dbo].PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
    ON S22.Processing_ID = S17.Processing_ID
   and S22.filename      = S17.filename
   and S17.sub_assembly_name = 'Final Assembly'
   Join PARWU01_CCTSS_FLAT U01
     ON U01.ARWU31_CTSP_N            = User_Selected_CTSP_N
    And U01.ARWA06_RGN_C             = User_Selected_CTSP_Region_C
    And U01.ARWA03_ENRG_SUB_CMMDTY_X = User_Selected_ENRG_SUB_CMMDTY_X
    And U01.ARWU01_BNCHMK_VRNT_N     = User_Selected_BNCMK_VRNT_N
   LEFT JOIN PARWA53_LGCY_CCS_PGM A53 
     ON u01.ARWU31_CTSP_N = A53.[ARWA53_LGCY_CCS_PGM_N]
  where S21.cost_item like '%Final assembly'
    and S22.Processing_ID=@GUID
  group by S21.cost,S21.[Source_c],S17.sub_assembly_name,S22.[Processing_ID],S22.[filename],S21.[ARWS21_CCS_SUMMARY_K]
) X

where 
  (
      ABS(summed_cost) <  ABS(s21_cost) - @V_Threshold_A
	  or 
	  ABS(summed_cost) >  ABS(s21_cost) + @V_Threshold_A
   )
;

END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS21_CCS_SUMMARY_TAB_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;
GO
