DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_U57_DSGN_SUB_ASSY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 10/03/2019
-- Description:	In the design Adjustments/ Adjustment Summary UI,  not all Sub-Assemblies were showing at the bottom of the screen 
--              in the Markup section. We need to update the U57 again when the DAII import is run.
--              The same U57 merge from PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY was used excpet a 3rd union was added.
--              The 3rd union picks up parts added in the DA Excel file that didn't have a CCS markup. 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Story     Description
-- ------     -----       -----     -----------
-- Ashaik12   01/14/2020            Added Time_Stamp parameter 
-- Asolosky   09/23/2021  US2888066 Added code for Improvement Ideas missing markups. Re-wrote the code from
--                                  in-line views to CTEs in order to re-use the CTE data for the not exists 
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DAII_LOAD_U57_DSGN_SUB_ASSY] 
-- Input Parameter
@CCTSS_K INT,
@CDSID	 Varchar(30),
@TIME_STAMP DATETIME

AS
SET NOCOUNT ON;

With 
CCS_Markups_CTE AS
   (
    select ARWU01_CCTSS_K, ARWU17_BOM_SUB_ASSY_K, ARWU06_CCTSS_DSGN_K, COMPOUNDED_TOTAL
	      ,'CCS' as mrkup_type
      from PARWV20_MFG_MRKP V20
     where V20.ARWU01_CCTSS_K      = @CCTSS_K
       and V20.[COMPOUNDED_TOTAL] != 0
     group by ARWU01_CCTSS_K, ARWU17_BOM_SUB_ASSY_K, ARWU06_CCTSS_DSGN_K, COMPOUNDED_TOTAL
   )
,
Program_Markups_CTE AS
   (
    select V08.ARWU01_CCTSS_K, V08.ARWU17_BOM_SUB_ASSY_K, V08.ARWU06_CCTSS_DSGN_K, COMPOUNDED_TOTAL
	      ,'PGM' as mrkup_type 
      from PARWV14_PROGRAM_MRKUP       V14
      Join PARWV08_CCS_SUPL_QUOTE_FLAT V08 ON V08.ARWU01_CCTSS_K = V14.ARWU01_CCTSS_K
     where V14.ARWU01_CCTSS_k      = @CCTSS_K
       and V14.[COMPOUNDED_TOTAL] != 0
     group by V08.ARWU01_CCTSS_K, V08.ARWU17_BOM_SUB_ASSY_K, V08.ARWU06_CCTSS_DSGN_K, COMPOUNDED_TOTAL
   )
, 
DA_Markups_CTE AS
   (
    SELECT U06.ARWU01_CCTSS_K, U17.ARWU17_BOM_SUB_ASSY_K, U37.ARWU06_CCTSS_DSGN_K, 0 as COMPOUNDED_TOTAL
	      ,'DA' as mrkup_type
      FROM PARWU37_CCTSS_DSGN_ADJ  U37 
      Join PARWU06_CCTSS_DSGN      U06 ON U06.ARWU06_CCTSS_DSGN_K   = U37.ARWU06_CCTSS_DSGN_K
      Join PARWU18_BOM_PART        U18 ON U18.ARWU18_BOM_PART_K     = U37.ARWU18_BOM_PART_K
      Join PARWU17_BOM_SUB_ASSY    U17 ON U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
      Left 
      Join PARWU19_DSGN_PART       U19 ON U19.ARWU06_CCTSS_DSGN_K   = U06.ARWU06_CCTSS_DSGN_K
                                      And U19.ARWU18_BOM_PART_K     = U18.ARWU18_BOM_PART_K
     WHERE U06.ARWU01_CCTSS_K      = @CCTSS_K
	   and U19.ARWU19_DSGN_PART_K is NULL --Find DA parts don't have a corresponding record in the U19 which means they were a DA ADD
     group by U06.ARWU01_CCTSS_K, U17.ARWU17_BOM_SUB_ASSY_K, U37.ARWU06_CCTSS_DSGN_K
   )
, 
II_Markups_CTE AS
   (
    SELECT U06.ARWU01_CCTSS_K, U17.ARWU17_BOM_SUB_ASSY_K, U46.ARWU06_CCTSS_DSGN_K, 0 as COMPOUNDED_TOTAL
	      ,'II' as mrkup_type
      FROM PARWU46_CCTSS_DSGN_IMPRV U46 
      Join PARWU06_CCTSS_DSGN      U06 ON U06.ARWU06_CCTSS_DSGN_K   = U46.ARWU06_CCTSS_DSGN_K
      Join PARWU18_BOM_PART        U18 ON U18.ARWU18_BOM_PART_K     = U46.ARWU18_BOM_PART_K
      Join PARWU17_BOM_SUB_ASSY    U17 ON U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
      Left 
      Join PARWU19_DSGN_PART       U19 ON U19.ARWU06_CCTSS_DSGN_K   = U06.ARWU06_CCTSS_DSGN_K
                                      And U19.ARWU18_BOM_PART_K     = U18.ARWU18_BOM_PART_K
     WHERE U06.ARWU01_CCTSS_K      = @CCTSS_K
	   and U19.ARWU19_DSGN_PART_K is NULL --Find II parts don't have a corresponding record in the U19 which means they were a II ADD
     group by U06.ARWU01_CCTSS_K, U17.ARWU17_BOM_SUB_ASSY_K, U46.ARWU06_CCTSS_DSGN_K
   )
MERGE INTO PARWU57_CCTSS_DSGN_SUB_ASSY   U57
USING
(
select ARWU01_CCTSS_K 
      ,ARWU17_BOM_SUB_ASSY_K 
      ,ARWU06_CCTSS_DSGN_K 
      ,min(1+[COMPOUNDED_TOTAL])  as comp_total_P
from
(
 select *
   from CCS_Markups_CTE

 Union ALL
 select  *
   from Program_Markups_CTE

 Union ALL
 SELECT *
   from DA_Markups_CTE DA_CTE 
  Where NOT EXISTS -- Find subassemblies not already selected in the CCS_Markups_CTE.
        (select 'X'
           from CCS_Markups_CTE  CCS_CTE 
          where CCS_CTE.ARWU01_CCTSS_K        = DA_CTE.arwu01_cctss_k
	        and CCS_CTE.ARWU06_CCTSS_DSGN_K   = DA_CTE.ARWU06_CCTSS_DSGN_K
	        and CCS_CTE.ARWU17_BOM_SUB_ASSY_K = DA_CTE.ARWU17_BOM_SUB_ASSY_K 
            and CCS_CTE.COMPOUNDED_TOTAL     != 0
        )

 Union ALL
 SELECT *
   from II_Markups_CTE II_CTE 
  Where NOT EXISTS -- Find subassemblies not already selected in the CCS_Markups_CTE.
        (select 'X'
           from CCS_Markups_CTE  CCS_CTE 
          where CCS_CTE.ARWU01_CCTSS_K        = II_CTE.ARWU01_CCTSS_K
	        and CCS_CTE.ARWU06_CCTSS_DSGN_K   = II_CTE.ARWU06_CCTSS_DSGN_K
	        and CCS_CTE.ARWU17_BOM_SUB_ASSY_K = II_CTE.ARWU17_BOM_SUB_ASSY_K 
            and CCS_CTE.COMPOUNDED_TOTAL     != 0
        )
	and NOT EXISTS -- Find subassemblies not already selected in the DA_Markups_CTE.
        (select 'X'
           from DA_Markups_CTE   DA_CTE 
          where DA_CTE.ARWU01_CCTSS_K        = II_CTE.ARWU01_CCTSS_K
	        and DA_CTE.ARWU06_CCTSS_DSGN_K   = II_CTE.ARWU06_CCTSS_DSGN_K
	        and DA_CTE.ARWU17_BOM_SUB_ASSY_K = II_CTE.ARWU17_BOM_SUB_ASSY_K 
        )
) subAssby_union
group by ARWU01_CCTSS_K, ARWU17_BOM_SUB_ASSY_K, ARWU06_CCTSS_DSGN_K
) Comp_Tot_Part

  ON 
(Comp_Tot_Part.ARWU06_CCTSS_DSGN_K   = U57.ARWU06_CCTSS_DSGN_K AND
 Comp_Tot_Part.ARWU17_BOM_SUB_ASSY_K = U57.ARWU17_BOM_SUB_ASSY_K 
)
	 
WHEN MATCHED THEN
     UPDATE SET          
	    U57.ARWU57_SUBASSY_ORIG_BOB_MRKP_P       = comp_total_P
	   ,U57.ARWU57_LAST_UPDT_S      = @TIME_STAMP 
	   ,U57.ARWU57_LAST_UPDT_USER_C = @CDSID
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 ( --Null as ARWU57_CCTSS_DSGN_SUB_ASSY_K: Table has an Identity clause which will create the primary key 
	   ARWU06_CCTSS_DSGN_K
	  ,ARWU17_BOM_SUB_ASSY_K            -- ARWU17_BOM_SUB_ASSY_K
	  ,0                                -- ARWU57_SUBASSY_ORIG_BOB_A
      ,comp_total_P                     -- ARWU57_SUBASSY_ORIG_BOB_MRKP_P
	  ,0                                -- ARWU57_MNLSLCT_PGM_MRKP_RATE_F
	  ,''                               -- ARWU57_MNLSLCT_PGM_MRKP_RATE_X  
	  ,@TIME_STAMP                     -- ARWU18_CREATE_S
	  ,@CDSID							-- ARWU18_CREATE_USER_C
	  ,@TIME_STAMP                     -- ARWU18_LAST_UPDT_S
	  ,@CDSID						    -- ARWU18_LAST_UPDT_USER_C
	 )
;

GO
