DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_TYPE_OF_CHANGE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 06/25/2019
-- Description:	validate Design Adjustment Type of Change 
-- =============================================

-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asamriya  09/10/2019   Added row_idx
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- rwesley2  05/04/2020   US1575405 removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s35.sheet_name. 
--                        Only applies to DA not II
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_TYPE_OF_CHANGE] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
--++++++++++++++++++++++++++++++++++++
    -- type of change category validation
--++++++++++++++++++++++++++++++++++++
    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  Err.[type_of_change] as [ARWE02_ERROR_VALUE],
	  'Invalid Type of Change Category' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS35_DAS_ADJUSTMENT_DELTAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  Err.sheet_name as [ARWE02_EXCEL_TAB_X],
	  Err.row_idx,
	  change_id,  --Part index/change id
	  ''          --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
		  [type_of_change],
		  change_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K,
		  sheet_name,
		  row_idx
        FROM [dbo].PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
        WHERE Processing_ID=@GUID
	    and Not Exists
		      (Select 'X'
			     from  [dbo].[PARWA40_DSGN_ADJ_PART_CHG_TYP] a40
                where S35.[type_of_change] = a40.[ARWA40_DSGN_ADJ_PART_CHG_TYP_X]
              )
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
    -- multiple same Part Index must be under category MODIFY
--++++++++++++++++++++++++++++++++++++
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  Err.[type_of_change] as [ARWE02_ERROR_VALUE],
	  'Same part index occurs multiple times under different change types' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS35_DAS_ADJUSTMENT_DELTAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'WARNING' as [ARWE02_ERROR_TYPE_X],
	  Err.sheet_name as [ARWE02_EXCEL_TAB_X],
      Err.row_idx,
	  change_id,  --Part index/change id
	  ''          --No ARROW Value
       FROM 
       (
        SELECT s35.[filename]
		      ,s35.Source_c
		      ,s35.[Processing_ID]
		      ,s35.[part_index]
			  ,S35.change_id
		      ,s35.[type_of_change]
--		      ,s35.Processing_Status_x
              ,s35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		      ,COUNT(*) OVER (PARTITION BY 
		                 s35.[Processing_ID],s35.[part_index],s35.[filename]
			    	          ) AS PI_COUNT 
              ,S35.sheet_name
			  ,row_idx
        FROM [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO]  s35
        WHERE s35.Processing_ID       =  @GUID                  
		) Err   
   WHERE PI_COUNT > 1
     and ERR.[type_of_change] <> 'MODIFY' 
   ;

END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;


GO
