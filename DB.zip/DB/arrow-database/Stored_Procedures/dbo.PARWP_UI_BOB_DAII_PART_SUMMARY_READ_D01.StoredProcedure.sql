DROP PROCEDURE If Exists [dbo].[PARWP_UI_BOB_DAII_PART_SUMMARY_READ_D01]
GO
/*
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =================================================================================================================================================
-- Author:		btemkow
-- Create date: 2021-12-02
-- Description:	
-- =================================================================================================================================================
-- Changes
-- =================================================================================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky  04/04/2022   Not needed.  PARWP_UI_BOB_DAII_PART_SUMMARY will be used to read the data 
-- =================================================================================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_BOB_DAII_PART_SUMMARY_READ_D01] 
-- Parameters for the stored procedure
@ARWU06_CCTSS_DSGN_K        int
AS
SET NOCOUNT ON;


SELECT D01.ROW_KEY
      ,D01.ARWU06_CCTSS_DSGN_K
      ,D01.ARWU08_CCTSS_DSGN_SUPL_K
      ,CONCAT(COALESCE(U13.ARWU13_CCTSS_SUPL_DSPLY_N, A17.ARWA17_SUPL_N), ' (' , A28.ARWA28_ISO3_CNTRY_C, ')') AS ARWA17_SUPL_N
      ,D01.ARWU17_BOM_SUB_ASSY_K
      ,U17.ARWU17_BOM_SUB_ASSY_N
      ,D01.ARWU18_BOM_PART_K
      ,D01.ARWU18_BOM_PART_IX_N  --decided to leave this from the D01 table because of the sort
      ,U18.ARWU18_BOM_PART_X
      ,D01.GROUP_INDEX
      ,D01.CLUSTER_APPLICABLE_FLAG
      ,D01.GROUP_INDEX_BOM_PART_K
      ,D01.QTE_W_ADJ_MRKP
      ,D01.DA_PUR
      ,D01.DA_RAW
      ,D01.DA_PRO
      ,D01.DA_TOT_W_SUP_MRKP
      ,D01.DA_TOT_W_ADJ_MRKP
      ,D01.II_PUR
      ,D01.II_RAW
      ,D01.II_PRO
      ,D01.II_TOT_W_SUP_MRKP
      ,D01.II_TOT_W_ADJ_MRKP
      ,D01.ASM_DISPLAY_SEQ
      ,D01.PART_TXT_SORT
      ,D01.PART_NUM1_SORT
      ,D01.PART_NUM2_SORT
      ,D01.ADJ_BOB
      ,D01.BOB_MANUAL_SEL_KEY
      ,D01.BOB_MANUAL_SEL_COMMENT
      ,D01.MIN_DA
      ,D01.DA_MIN_SUP_KEY
      ,D01.ADJ_DA_BOB_AMT
      ,D01.ADJ_DA
      ,D01.DA_MANUAL_SEL_KEY
      ,D01.DA_MANUAL_SEL_COMMENT
      ,D01.DA_MANUAL_SEL_TYPE
      ,D01.CADA_AUTO
      ,D01.CAII_AUTO
      ,D01.CADA_CHRYPKD
      ,D01.DA_DELTA
      ,D01.II_MIN_SUP_KEY
      ,D01.II_MANUAL_SEL_KEY
      ,D01.II_MANUAL_SEL_COMMENT
      ,D01.II_MANUAL_SEL_TYPE
      ,D01.CAII_CHRYPKD
      ,D01.II_DELTA
      ,D01.DA_RATIO
      ,D01.II_RATIO
      ,D01.QTE_DVNT_STATUS_KEY
      ,D01.QTE_DVNT_STATUS
      ,D01.QTE_DVNT_CMT
      ,D01.DA_DVNT_STATUS_KEY
      ,D01.DA_DVNT_STATUS
      ,D01.DA_DVNT_CMT
      ,D01.II_DVNT_STATUS_KEY
      ,D01.II_DVNT_STATUS
      ,D01.II_DVNT_CMT
      ,D01.CHNG_TYPE
      ,D01.ARWD01_CREATE_S
      ,D01.ARWD01_CREATE_USER_C
  FROM PARWD01_BOB_DAII_PART_SUMMARY D01
  JOIN PARWU17_BOM_SUB_ASSY         U17     ON U17.ARWU17_BOM_SUB_ASSY_K    = D01.ARWU17_BOM_SUB_ASSY_K
  JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT U08     ON U08.ARWU08_CCTSS_DSGN_SUPL_K = D01.ARWU08_CCTSS_DSGN_SUPL_K
  JOIN PARWA17_SUPL                 A17     ON A17.ARWA17_SUPL_K            = U08.ARWA17_SUPL_K
  JOIN PARWA28_CNTRY                A28     ON A17.ARWA28_CNTRY_K           = A28.ARWA28_CNTRY_K
  JOIN PARWU18_BOM_PART             U18     ON U18.ARWU18_BOM_PART_K        = D01.ARWU18_BOM_PART_K
  LEFT 
  JOIN PARWU13_CCTSS_SUPL_DSPLY     U13     ON U13.ARWU07_CCTSS_SUPL_K      = U08.ARWU07_CCTSS_SUPL_K
 WHERE D01.ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K		
 ORDER BY D01.ASM_DISPLAY_SEQ, D01.PART_TXT_SORT, D01.PART_NUM1_SORT, D01.PART_NUM2_SORT, D01.ARWU18_BOM_PART_IX_N, D01.ARWU08_CCTSS_DSGN_SUPL_K
;
GO
*/
