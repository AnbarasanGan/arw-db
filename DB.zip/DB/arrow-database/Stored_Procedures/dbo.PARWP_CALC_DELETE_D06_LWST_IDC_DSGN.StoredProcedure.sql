DROP PROCEDURE If Exists [dbo].[PARWP_CALC_DELETE_D06_LWST_IDC_DSGN]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		svallur5
-- Create date: 12/03/2021
-- Description:	Procedure to Delete the D06 Lowest IDC Design Dump
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CALC_DELETE_D06_LWST_IDC_DSGN]
@ARWU01_CCTSS_K        int
AS
--Declare @Start_Time DATETIME = GETUTCDATE();

Begin
--  Select * FROM @T06_CCTSS_DSGN;

  Delete [PARWD06_LOWEST_IDC_DESIGN]
  WHERE ARWU01_CCTSS_K = @ARWU01_CCTSS_K
    

--  Select OBJECT_NAME(@@PROCID) as Procedure_Name 
 --       ,@@Rowcount                                 as Records_Deleted
 --       ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
