
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load S61 and S62 from PARWP05_TYGRA_LOAD processing table.  SP is used in UI
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
--rwesley2    10-27-2021  U2995475 added Try/Catch
-- ashaik12   02-15-2022  US3305905 Add CM10 to CM25
-- rwesley2   04-26-2022  US3482265 removed GETUTCDATE and replace with @TIME_STAMP for S61 an dS62 loads
-- ashaik12   09-20-2022  US4066530 added Stretch_Part_Level_Target column
-- =============================================

CREATE OR ALTER  PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_STAGE_TBLS_UI] 
	-- Add the parameters for the stored procedure here

-- Input Parameter

@processing_id varchar(MAX)
,@Tygra_id_k int
,@File_source varchar(max)
,@program_name varchar(max)
,@cdsid varchar(max)
,@TIME_STAMP datetime


AS

Begin Try
SET NOCOUNT ON;

-- S61 load
INSERT INTO PARWS61_TYGRA_TITLE_PAGE
select * from (
select  
@Processing_ID               as processing_id
 ,'TYGRA'+' '+'-'+' '+ @File_source  as source
,@program_name               as program
,[BCJU45_CCM_X]              as CCM
,a06.ACTA06_ACT_REGION_N     as region
,[BCJU45_SERIES_X]           as series 
,[BCJU45_TAKE_RATE_A]        as take_rate
,[BCJU45_ENGINE_X]           as engine
,[BCJU45_TRANS_X]            as transmission
,[BCJU45_DESC_X]             as description
,ISNULL([BCJU41_DATEOFDATAPULL_X],'1900-01-01')   as data_pull_date  ------data pull date goes here
,u41.[BCJU41_FileNameSPTygra]    as filename 
,1                           as row_indx ----row index goes here
,@TIME_STAMP                 as create_dt
,@cdsid                      as create_user
,@TIME_STAMP                as update_dt
,@cdsid                      as update_user
,[BCJU45_CM_PGM_X]           as CM_PROGRAM
,[BCJU45_CM_NCKNM_N]         as CM_NICKNAME
,[BCJU45_CM_MDLYR_A]         as CM_MDLYR
from [dbo].[PBCJU45_TYGRA_HEADER_SYN] u45
join [dbo].[PBCJU41_TYGRA_SYN] u41
on u45.[BCJU41_TYGRA_ID_K] = u41.[BCJU41_TYGRA_ID_K]
left join [dbo].[PACTA06_ACT_REGION_SYN] a06
on u45.[ACTA06_ACT_REGION_K] = a06.[ACTA06_ACT_REGION_K]
where u45.[BCJU41_TYGRA_ID_K] = @TYGRA_ID_K
 )x
 ;

 
-- s62 load
INSERT INTO PARWS62_TYGRA_SUMMARY
select * from (
select  
  @processing_id           as processing_id
 ,'TYGRA'+' '+'-'+' '+ @File_source   as source
 ,@program_name        as vehicle_name
 ,[BCJU44_fldPMT]             as PMT  
 ,[BCJU44_fldcm1]             as CM1
 ,BCJU44_fldcm2               as CM2
 ,BCJU44_fldcm3               as CM3
 ,BCJU44_fldcm4               as CM4
 ,BCJU44_fldcm5               as CM5 
 ,[BCJU44_fldcm6]             as CM6
 ,[BCJU44_fldcm7]             as CM7
 ,[BCJU44_fldcm8]             as CM8
 ,[BCJU44_fldcm9]             as CM9
 ,[BCJU44_NO_CM_F]            as nonCM
 ,[BCJU44_fldEngCom]          as eng_commodity
 ,[BCJU44_fldPre]             as Surrogate_Part_Prefix
 ,[BCJU44_fldBase]            as Surrogate_Part_Base 
 ,[BCJU44_fldSuf]             as Surrogate_Part_Suffix 
 ,[BCJU44_fldParDes]          as Surrogate_Part_Desc
 ,[BCJU44_fldPLPre]           as Start_Point_Part_Prefix
 ,[BCJU44_fldPLBase]          as Start_Point_Part_Base
 ,[BCJU44_fldPLSuf]           as Start_Point_Part_Suffix
 ,[BCJU44_fldPartDes]         as Start_Point_Part_Desc
 ,[BCJU44_fldFinSurPrg]       as Finance_Surrogate_Program
 ,[BCJU44_fldSurrUSD]         as Surrogate_Cost  --var to dec
 ,[BCJU44_fldPLCPSC]          as Start_Point_CPSC --varchar
 ,[BCJU44_fldStPtvsVP]        as Start_Point_Vehicle_Price  --var to dec
 ,[BCJU44_fldspe]             as Start_Point_Efficiency  -- var to dec
 ,[BCJU44_fldQty]             as Finance_Surrogate_Quantity  --decimal
 ,[BCJU44_fldPrtLevQty]       as Start_Point_Quantity --dec
 ,[BCJU44_fldLAttTotal]       as Compatibilities  --dec
 ,[BCJU44_fldlatttoteff]      as Compatibilities_Efficiency
 ,[BCJU44_fldMEV]             as MEV   --var to dec
 ,[BCJU44_fldRAttTot]         as Job1_Attributes
 ,[BCJU44_fldRAttTotEff]      as Job1_Attributes_Efficiency
 ,[BCJU44_fldJ1Target]        as Job1_Target --var to dec
 ,[BCJU44_fldpartlevci]      as WS2_Part_Level_Commonality
 ,[BCJU44_fldprteffmeth]      as WS2_Part_Level_Eff_Methodology_Calculation 
 ,[BCJU44_fldprtreduct]       as Part_Level_Reduction
 ,[BCJU44_fldBoBPIAEI]        as BoB_PIA_End_Item
 ,[BCJU44_fldbobnm]           as BoB_Enrg_Sub_commodity
 ,ISNULL([BCJU44_fldctvm],0)  as Commerical_TVM  --[BCJU44_fldCommercialTVMPct] or [BCJU44_fldctvm] or fldctvmcpct
 ,ISNULL([BCJU44_flddtvm],0)  as Design_TVM  --[BCJU44_fldDesignTVMPct] or [BCJU44_flddtvm] or flddtvmpct
 ,cast([BCJU44_flduniqid] as INT)  as Tygra_Unique_ID
 ,u41.[BCJU41_FileNameSPTygra]    as filename 
 ,ISNULL(BCJU44_ROW_ID_F,1)   as row_indx 
 ,@TIME_STAMP                 as create_dt
 ,@cdsid                      as create_user
 ,@TIME_STAMP                 as update_dt
 ,@cdsid                      as update_user
 ,BCJU44_fldcm10              as NON_CM1
 ,BCJU44_fldcm11              as NON_CM2
 ,BCJU44_fldcm12              as NON_CM3
 ,BCJU44_fldcm13              as NON_CM4
 ,BCJU44_fldcm14              as NON_CM5
 ,BCJU44_fldcm15              as NON_CM6
 ,NULL                        as NON_CM7
 ,NULL                        as NON_CM8
 ,NULL                        as NON_CM9
 ,[BCJU44_sur_pgm_cmdty]      as Surrogate_Program_Used_for_Commodity_Start_Point 
 ,[BCJU44_fldwcat]            as WCAT_Category  
 ,[BCJU44_fldlatt1]           as Compatibilities1
 ,[BCJU44_fldlatt1wcat]       as Compatibilities1_WCAT
 ,[BCJU44_fldlatt1des]        as Compatibilities1_Desc
 ,[BCJU44_fldlatt2]           as Compatibilities2
 ,[BCJU44_fldlatt2wcat]       as Compatibilities2_WCAT
 ,[BCJU44_fldlatt2des]        as Compatibilities2_Desc
 ,[BCJU44_fldlatt3]           as Compatibilities3
 ,[BCJU44_fldlatt3wcat]       as Compatibilities3_WCAT 
 ,[BCJU44_fldlatt3des]        as Compatibilities3_Desc
 ,[BCJU44_fldratt1]           as Job1_Attributes1
 ,[BCJU44_fldratt1wcat]       as Job1_Attributes1_WCAT
 ,[BCJU44_fldratt1des]        as Job1_Attributes1_Desc
 ,[BCJU44_fldratt2]           as Job1_Attributes2
 ,[BCJU44_fldratt2wcat]       as Job1_Attributes2_WCAT
 ,[BCJU44_fldratt2des]        as Job1_Attributes2_Desc 
 ,[BCJU44_fldratt3]           as Job1_Attributes3
 ,[BCJU44_fldratt3wcat]       as Job1_Attributes3_WCAT
 ,[BCJU44_fldratt3des]        as Job1_Attributes3_Desc
 ,[BCJU44_fldplatth]          as Platform_Tophat
 ,[BCJU44_fldmfgreg]          as MFG_Region
 ,[BCJU44_fldstvssudes]       as ST_v_SU_Desc
 ,[BCJU44_fldcomments]        as Comments
 ,[BCJU44_FB_PN_PLN_C]        as FEDEBOM_PN_Plan
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLPre] else [BCJU44_fldnewprtpre]  END  as FEDEBOM_Planned_Prefix
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLBase] else [BCJU44_fldnewprtbase] END    as FEDEBOM_Planned_Base
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldPLSuf] else [BCJU44_fldnewprtsuff] END    as FEDEBOM_Planned_Suffix 
 ,[BCJU44_FB_VAR_CNT_F]       as FEDEBOM_Variant_Cnt
 ,CASE WHEN ([BCJU44_fldnewprtpre] is NULL AND [BCJU44_fldnewprtbase] is NULL AND [BCJU44_fldnewprtsuff] is NULL) then [BCJU44_fldBoBPIAEI]  else [BCJU44_FB_BOB_PIA_EI_X] END   as FEDEBOM_bob_pia_ei
 ,[BCJU44_FLDCM10] as [CM10]
,[BCJU44_FLDCM11] as [CM11]
,[BCJU44_FLDCM12] as [CM12]
,[BCJU44_FLDCM13] as [CM13]
,[BCJU44_FLDCM14] as [CM14]
,[BCJU44_FLDCM15] as [CM15]
,[BCJU44_FLDCM16] as [CM16]
,[BCJU44_FLDCM17] as [CM17]
,[BCJU44_FLDCM18] as [CM18]
,[BCJU44_FLDCM19] as [CM19]
,[BCJU44_FLDCM20] as [CM20]
,[BCJU44_FLDCM21] as [CM21]
,[BCJU44_FLDCM22] as [CM22]
,[BCJU44_FLDCM23] as [CM23]
,[BCJU44_FLDCM24] as [CM24]
,[BCJU44_FLDCM25] as [CM25]
,[BCJU44_J1_TARGET_ALT] as [Stretch_Part_Level_Target]
 from [dbo].[PBCJU44_TYGRA_DETAILS_SYN] u44
 join [dbo].[PBCJU41_TYGRA_SYN] u41
on u44.[BCJU41_TYGRA_ID_K] = u41.[BCJU41_TYGRA_ID_K]
where  u44.[BCJU41_TYGRA_ID_K] = @Tygra_id_k

 )x
 ;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@processing_id                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWP_TYGRA_UI_LOAD_STAGE_TBLS_UI'
          --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	

GO


