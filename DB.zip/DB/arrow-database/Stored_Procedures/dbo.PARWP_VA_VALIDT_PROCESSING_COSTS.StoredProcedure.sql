SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 7/29/2019
-- Description:	validate VA Adjustment Costs: processing costs
-- Notes: not validating OP index or Op desc.  These are free-form enties and not required on CCS
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2  09/09/19     Added calculated field validations
-- Asolosky  09/10/2019   Added row_idx
-- rwesley2  09/13/2019   added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- asolosky  09/30/2019   Changed error messages to more descriptive
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky  07/24/2020   US1771016 used the replace function for change_id and part_name to display a line feed
-- Ashaik12  09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  04/12/2021   US2430172 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021   US2815039 Added a case statement in the first change id validation. Had to create the case by template version.
--                        When change id does not belong the BOM Sub Assembly display an error. This happens if the user does a copy paste from another sheet.
-- Asolosky  10/08/2021   US2954027 Added numeric validation on capital_exp_for_machine and machine_size
-- Asolosky  06/10/2022   US3700154 Added new error to reject a file if the supplier quoted a change id with a type of DELETE 
-- ASHAIK12  06/28/2022   US3778477 Add new validations for Variant Improvement Ideas
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VA_VALIDT_PROCESSING_COSTS] 

@GUID varchar(5000), 
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--++++++++++++++++++++++++++++++++++++
-- Change improvement ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>') 
	  ,Error_x                               as [ARWE02_ERROR_X] 
	  ,Processing_ID 
	  ,filename
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,ARWS52_VA_PROCESSING_PARTS_K
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'   
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,''
  FROM 
       (
        SELECT 
		       S52.Processing_ID,
               S52.change_id,
		       S52.Processing_Status_x,
		       S52.Source_c,
		       S52.filename,
               S52.ARWS52_VA_PROCESSING_PARTS_K,
		       S52.sub_assembly_name,
		       S52.row_idx,
		       Case When S45.TEMPLATE_VERSION < 'V2.5' --For old templates not broken out by sub-assembly
			        Then Case When coalesce(S46.change_id,'~') != S52.change_id  
			                  Then 'Adjustment Costs for Processing - Invalid Change ID.'					 
					          Else ''
						  End
				    Else -- Version >= 'V2.5'  New Template starts at V2.5
			             Case When Substring(S46.sheet_name,5,DATALENGTH(S46.sheet_name)) != Substring(S52.sub_assembly_name,7,DATALENGTH(S52.sub_assembly_name)) 
		                      Then 'Processing: Change Id was found on a different ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  When S46.sheet_name  is Null
			                  Then 'Processing: Change Id was not found on any ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  Else ''
						 End
		       End Error_x
          FROM PARWS52_VA_PROCESSING_PARTS_INFO   S52
          Join PARWS45_VA_COVER_PAGE_INFO         S45
		    ON S45.Processing_ID = S52.Processing_ID
		   and S45.filename      = S52.filename
		   and S52.cost_type='Adjustment Costs'
     Left Join PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
            ON S46.change_id     = S52.change_id
		   and S46.filename      = S52.filename
		   and S46.Processing_ID = S52.Processing_ID
         WHERE S52.Processing_ID = @GUID                    
       ) Err
 Where Error_x != ''
;

-- New validation for improvement ideas
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>') 
	  ,'Improvement Costs for Processing - Improvement ID was not found on the Improvement Ideas Sheet. Please do not copy/paste. Use the drop down to select the Improvement Id.' 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS52_VA_PROCESSING_PARTS_K
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'   
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx
      ,change_id
      ,''  --No ARROW Value
        FROM 
       (
        SELECT 
		  Processing_ID,
          change_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS52_VA_PROCESSING_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].PARWS52_VA_PROCESSING_PARTS_INFO s52
        WHERE Processing_ID= @GUID
		  and S52.cost_type='Improvement Costs'
	      and Not Exists
		      (Select 'X'
               from  [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s52.change_id =     s67.improvement_id
				 and s52.[filename] =    s67.[filename]
				 and s52.Processing_ID = s67.Processing_ID
              )
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
-- Change improvement ID Part Description validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  
	  ,'Adjustment Costs for Processing - Part Description does not match Adjustment Details Part Name.'
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID)  
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS52_VA_PROCESSING_PARTS_K]
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name   
	  ,row_idx
	  ,change_id
	  ,''
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
         [ARWS52_VA_PROCESSING_PARTS_K],
		 sub_assembly_name,
		 row_idx,
		 change_id
        FROM [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] s52
        WHERE Processing_ID= @GUID
	and S52.cost_type='Adjustment Costs'
	   and Not Exists
		      (Select 'X'
               from [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
               where s52.[change_id] = s46.[change_id]
			     and s52.part_description=s46.part_name
				 and s52.[filename] = s46.[filename]
				 and s52.Processing_ID=s46.Processing_ID

)
                    
       ) Err

    ;

-- New validation for improvement ideas
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>') 
	  ,'Improvement Costs for Processing -  Part Description does not match Part Name on Improvement Ideas tab' 
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID)  
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS52_VA_PROCESSING_PARTS_K
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,ERR.row_idx  
      ,change_id
      ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  change_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS52_VA_PROCESSING_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].PARWS52_VA_PROCESSING_PARTS_INFO s52
        WHERE Processing_ID= @GUID
		  and S52.cost_type='Improvement Costs'
	      and Not Exists
		      (Select 'X'
               from  [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s52.change_id =      s67.improvement_id
			     and s52.part_description=s67.part_name
				 and s52.[filename] =     s67.[filename]
				 and s52.Processing_ID=   s67.Processing_ID
)
                    
       ) Err

    ;
--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Currency Code validation
-- note: not validating the code is associated with correct country
--++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,ISNULL(Err.[local_currency],0)  
	  ,'Processing - Invalid Currency Code.'   
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP    
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS52_VA_PROCESSING_PARTS_K]
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO' 
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx
	  ,change_id
	  ,''
       FROM 
       (
        SELECT 
          Processing_ID,
          [local_currency],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS52_VA_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  row_idx,
		  change_id
        FROM [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] s52
        WHERE Processing_ID= @GUID
			and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s52.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;
-----------------------------------------------------------------------------
--  START calculated field validations
-----------------------------------------------------------------------------
--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Machine /operation overhead costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.machine_op_overhead_costs
	  ,'Processing - Machine/operation overhead costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS52_VA_PROCESSING_PARTS_K]
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx
	  ,[change_id]
      ,'Calculated:' + CAST(Err.Calculated_value as Varchar(50))--ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS52_VA_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  [change_id],
		  machine_op_overhead_costs,
		  case when no_of_pieces_per_cycle=0 then 0 else (((cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle) ) end  as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] s52
        WHERE Processing_ID= @GUID
			and case when no_of_pieces_per_cycle=0 then 0 
			else ABS((((cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle) ) - (machine_op_overhead_costs)) end > @threshold
       ) Err
    ;
--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Direct labor cost per piece [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.direct_hourly_labor_cost
	  ,'Processing - Direct labor cost per piece, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS52_VA_PROCESSING_PARTS_K]
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx
	  ,[change_id]
      ,'Calculated:' + CAST(Err.Calculated_value as Varchar(50))--ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS52_VA_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  [change_id],
		  direct_hourly_labor_cost,
		  case when no_of_pieces_per_cycle=0 then 0 else (((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)) end as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] s52
        WHERE Processing_ID= @GUID
			and case when no_of_pieces_per_cycle=0 then 0 
			else ABS((((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)) - ([direct_hourly_labor_cost])) end > @threshold    
       ) Err
    ;
--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Total labor costs [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.total_labor_costs
	  ,'Processing - Total labor costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
 	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS52_VA_PROCESSING_PARTS_K]
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx
	  ,[change_id]
      ,'Calculated:' + CAST(Err.Calculated_value as Varchar(50))--ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS52_VA_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  [change_id],
		  total_labor_costs,
		  case when no_of_pieces_per_cycle=0 then 0 else (((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)*(1+indirect_labor_costs)*(1+fringes)) end as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] s52
        WHERE Processing_ID= @GUID
			and case when no_of_pieces_per_cycle=0 then 0 
			else ABS((((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)*(1+indirect_labor_costs)*(1+fringes)) - (total_labor_costs)) end > @threshold
	  
       ) Err
    ;
-----------------------------------------------------------------------------
--  END calculated field validations
-----------------------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Processing: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS52_VA_PROCESSING_PARTS_K
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.change_id 
	  ,'' 
  FROM 
      (
        SELECT 
               S52.Processing_ID
              ,s52.exchange_rate
  		      ,s52.Source_c
  		      ,s52.filename
              ,s52.ARWS52_VA_PROCESSING_PARTS_K
  		      ,s52.sub_assembly_name
  		      ,s52.change_id
			  ,s52.row_idx
			  ,S57.usd_per_local_currency
			  ,S57.supplier_picked_crcy_c
          FROM PARWS52_VA_PROCESSING_PARTS_INFO S52 
		  Join PARWS57_VA_EXCHANGE_RATE_TAB     S57
		    On S57.Processing_ID  = S52.Processing_ID
		   And S57.filename       = S52.filename
		   And S57.currency_code  = S52.local_currency
         WHERE S52.Processing_ID  = @GUID
		   and S52.exchange_rate != S57.usd_per_local_currency
      ) Err
;

--Numeric check on capital_exp_for_machine
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,capital_exp_for_machine
      ,'Processing: Capital Expenditure for machine has to be a number or you can leave it empty.' as [ARWE02_ERROR_X]
	  ,Processing_ID
	  ,filename 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,ARWS52_VA_PROCESSING_PARTS_K
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'
	  ,'ERROR'
	  ,sub_assembly_name
	  ,row_idx                 as ARWE02_ROW_IDX
	  ,change_id 
	  ,'' 
  FROM PARWS52_VA_PROCESSING_PARTS_INFO
 WHERE Processing_ID  = @GUID
   and dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(capital_exp_for_machine) = 0  --0 = Not Numeric, 1 = Numeric, Empty is considered Numeric (1)
;

--Numeric check on Machine Size
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,machine_size
      ,'Processing: Machine size has to be a number or you can leave it empty.' as [ARWE02_ERROR_X]
	  ,Processing_ID
	  ,filename 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,ARWS52_VA_PROCESSING_PARTS_K
	  ,'PARWS52_VA_PROCESSING_PARTS_INFO'
	  ,'ERROR'
	  ,sub_assembly_name
	  ,row_idx                 as ARWE02_ROW_IDX
	  ,change_id 
	  ,'' 
  FROM PARWS52_VA_PROCESSING_PARTS_INFO
 WHERE Processing_ID  = @GUID
   and dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(machine_size) = 0  --0 = Not Numeric, 1 = Numeric, Empty is considered Numeric (1)
;
--++++++++++++++++++++++++++++++++++++
-- DA type DELETE validation
--+++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
       S52.Source_c
      ,S52.change_id 
      ,'This Part Index is being deleted. Remove it from Processing. Please quote only the Assembly and Final Assembly adjustment for the DELETE.' AS ARWE02_ERROR_X 
      ,S52.Processing_ID
      ,S52.filename
      ,OBJECT_NAME(@@PROCID) 
      ,@TIME_STAMP 
      ,@CDSID   
      ,@TIME_STAMP   
      ,@CDSID  
      ,S52.ARWS52_VA_PROCESSING_PARTS_K 
      ,'PARWS52_VA_PROCESSING_PARTS_INFO'     
      ,'ERROR'
      ,S52.sub_assembly_name 
      ,S52.row_idx
      ,S52.change_id
      ,''  --No ARROW Value
  FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
  Join PARWS52_VA_PROCESSING_PARTS_INFO   S52  ON S52.Processing_ID  = S46.Processing_ID
                                              AND S52.filename       = S46.filename
	 								                   AND S52.change_id      = S46.change_id
 WHERE S46.Processing_ID  = @GUID          
   AND S46.type_of_change = 'DELETE'
	AND S52.cost_type      = 'Adjustment Costs'
;

END TRY
BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
	         ,@CDSID  
             ,@TIME_STAMP
	         ,@CDSID  
			 ,''
			 ,'PARWS52_VA_PROCESSING_PARTS_INFO' ,
			 --ARWE02_BATCH_ERRORS_K Identity key
			 'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
			 ,''
			 ,''
END CATCH;



GO
