DROP PROCEDURE IF EXISTS  [dbo].[PARWP_TYGRA_MASTER_PROC_TBL] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2020
-- Description:	Master Procedure to call Tygra store procedures
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12   04/14/2021   Add call to new SP that delete's UB5 mappings when a Commodity data is refreshed.
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- rwesley2   05-21-2021  DEFECT US2555418 add @load_to_pgm_name to UB2 SP 
-- rwesley2   05-24-2021  US2559784 pass @version into PARWP_TYGRA_LOAD_FILE_REC , this is the UB3 load  
-- ashaik12   06-03-2021  Added arguments to PARWP_DELETE_REVISION_CCTSS_TYGRA
-- rwesley2   06-09-2021  US2604963 Add tygra file version number to UB2 input parameters
-- rwesley2	  07-29-2021  US2747200 replace global temp table with processing table
--                        changed global temp to local temp. renamed SP because it can only be used with the new
--                        SP using the processing table. These SPs end wtih _PROC_TBL. Will not work the old process.
-- rwesley2	  09-03-2021  US2835340 remove processing ID creation and accept from UI 
--                        SP used NULL for u01 key to indicate an initial load.  UI can't pass a NULL.  Changig U01 key to 
--                        -1 (negative 1) for initial load logic 
-- rwesley2  09-17-2021  US2891597 add branching logic for initial load and BoB refresh. For BoB refresh pass in U01 key.
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_MASTER_PROC_TBL] 
	-- Add the parameters for the stored procedure here

@processing_id varchar(max),
@ARWU01_CCTSS_K int,
@load_to_pgm_name varchar(MAX),
@result int Output



AS
Begin  
DECLARE @TIME_STAMP    DATETIME    = GETUTCDATE();
DECLARE @TYGRA_ERROR_TYPE varchar(MAX);
DECLARE @GUID  varchar(MAX) = (select Processing_ID from PARWP05_TYGRA_LOAD where processing_id = @processing_id);
DECLARE @CDSID  varchar(MAX) = (select CREATE_USER_C from PARWP05_TYGRA_LOAD  where processing_id = @processing_id);    -- = 'rwesley2'
DECLARE @file_name varchar(MAX) = (select BCJU41_FileNameSPTygra from PARWP05_TYGRA_LOAD  where processing_id = @processing_id);
DECLARE @file_type int = (select ARWA54_TYGRA_FILE_TYPE_K from PARWP05_TYGRA_LOAD  where processing_id = @processing_id);
DECLARE @version  int = (select BCJU51_VERSION_F from PARWP05_TYGRA_LOAD  where processing_id = @processing_id)
DECLARE @ARWUB1_TYGRA_FILE_K  int = (select ARWUB1_TYGRA_FILE_K from PARWP05_TYGRA_LOAD  where processing_id = @processing_id);
--DECLARE @guid uniqueidentifier = NEWID();    


 SET @result = 0;

 SET NOCOUNT ON;
-- SET @TIME_STAMP = GETUTCDATE()
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));


--Title Page validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_TITLE_PAGE]              @GUID,  @CDSID, @TIME_STAMP; 
--Parts(detail) validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_PARTS]                   @GUID,@CDSID, @TIME_STAMP; 
-- Missing program validation
 EXEC [dbo].[PARWP_TYGRA_VALIDT_MISSING_PROGRAM]         @GUID,@CDSID, @TIME_STAMP; 
-- Missing CCM
 EXEC [dbo].[PARWP_TYGRA_VALIDT_MISSING_CCM]            @GUID, @CDSID, @TIME_STAMP; 
-- check for special character in parts columns
 EXEC [dbo].[PARWP_TYGRA_VALIDT_PARTS_SPCL_CHARS]        @GUID, @CDSID, @TIME_STAMP; 

-- only continue to table load SPs if there are WARNING or no errors
 EXEC [dbo].[PARWP_TYGRA_GO_NO_GO]                        @GUID,  @CDSID, @TIME_STAMP, @TYGRA_ERROR_TYPE OUTPUT   

select @TYGRA_ERROR_TYPE 

 IF @TYGRA_ERROR_TYPE = 'SYSTEM Error'  -- Capture System error from S61. If system errors don't load tables
 Begin
    Set @result        = 0;  --The UI needs this set to 0 for an unexpected (system) error.
--	Set @IMPORT_STATUS = 'Processing_Error';
    GOTO EOJ          
 End

 IF @TYGRA_ERROR_TYPE = 'Validation Error'  -- Capture Validation error frmo S61. If validation errors don't load tables
 Begin
    Set @result        = 1;   --The UI needs this set to 1 to display validation ERRORs .
--	Set @IMPORT_STATUS = 'Validation Error';
    GOTO EOJ          
 End


 BEGIN TRY
    BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

	-- Execute the delete revision procedure to delete the mappings for a BoB when the user wants to reload the data.
	IF @ARWU01_CCTSS_K <> -1  --is NOT NULL 
	BEGIN
	EXEC [dbo].[PARWP_DELETE_REVISION_CCTSS_TYGRA] @ARWU01_CCTSS_K,'V',@file_type,@CDSID
	END

-- execute TYGRA Load UB tables stored procedures
   select 'TYGRA Load UB tables'
-- UB2 laod
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILECCM]                  @GUID, @CDSID, @load_to_pgm_name, @version, @TIME_STAMP ; 
   select count(*),'ub2' from [dbo].[PARWUB2_TYGRA_FILE_CCM]
   where [ARWUB2_LAST_UPDT_S] = @time_stamp
---- UB3 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILE_REC]                 @GUID, @CDSID, @ARWU01_CCTSS_K,@version , @TIME_STAMP;  
    select count(*),'ub3' from [dbo].[PARWUB3_TYGRA_FILE_REC] 
   where [ARWUB3_LAST_UPDT_S] = @time_stamp
-- UB4 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILE_REC_CCM]             @GUID, @CDSID, @ARWU01_CCTSS_K,  @TIME_STAMP,@load_to_pgm_name;  
       select count(*),'ub4' from [dbo].[PARWUB4_TYGRA_FILE_REC_CCM] 
   where [ARWUB4_LAST_UPDT_S] = @time_stamp
-- load UB6

  EXEC [dbo].[PARWP_TYGRA_UI_LOAD_UB6]    @CDSID, @TIME_STAMP, @file_name, @file_type, @version, @ARWUB1_TYGRA_FILE_K , @ARWU01_CCTSS_K, @load_to_pgm_name ;
      select count(*),'ub6' from [dbo].[PARWUB6_CCTSS_TYGRA_FILE] 
  where [ARWUB6_LAST_UPDT_S] = @time_stamp

   COMMIT TRANSACTION; 
 END TRY
 
 --CATCH
 BEGIN CATCH
   Rollback;
   Set @result = 0;

    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'TYGRA MASTER PROCEDURE'
        ,0                              as ARWE02_ROW_IDX	
	    ,' '                               -- part_index 
	    ,' '                               -- ARROW_VALUE
	;

  END CATCH;	

EOJ:  
    select 'SUCCESS'

--   EXEC @ret_code = [dbo].[PARWP_PBOM_UPDT_LAST_IMPT]  @GUIDIN, @CDSID, @TIME_STAMP, @IMPORT_STATUS, @CCTSS_K, @LAST_IMPT_result Output;
--	-- When there's a System error in PARWP_PBOM_UPDT_LAST_IMPT, the @result must return to the UI with an error (result=0)
--	If @LAST_IMPT_result = 'SYSTEM ERROR'
--	   set @result = 0;
--    RETURN @result
--END;

END;


GO


