DROP PROCEDURE If Exists [dbo].[PARWP_CALC_DELETE_D01_BOB_DAII_PART_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		btemkow
-- Create date: 2021-12-02
-- Description:	
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
--
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CALC_DELETE_D01_BOB_DAII_PART_SUMMARY]
--@ARWU06_CCTSS_DSGN_K        int
@T06_CCTSS_DSGN  [dbo].[PARWT06_CCTSS_DSGN] READONLY
AS
--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

  With
   DESIGNS AS
   (
    SELECT ARWU06_CCTSS_DSGN_K
      FROM @T06_CCTSS_DSGN
   )
   Delete PARWD01_BOB_DAII_PART_SUMMARY
     From PARWD01_BOB_DAII_PART_SUMMARY     D01
	 Join DESIGNS                  DSGN 
       ON DSGN.ARWU06_CCTSS_DSGN_K      = D01.ARWU06_CCTSS_DSGN_K               
    ;

--DELETE FROM PARWD01_BOB_DAII_PART_SUMMARY
--WHERE ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K


--  Select 'PARWP_CALC_DELETE_D01_BOB_DAII_PART_SUMMARY' as Procedure_Name 
 --       ,@@Rowcount                                 as Records_Deleted
 --       ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
