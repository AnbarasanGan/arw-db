DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_SUPL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		btemkow
-- Create date: 2020-02-17
-- Description:	Validates Supplier-originated II
--              on the Improvement Ideas tab
--              during DAII import for 'PBOM and 
--               DA UI' version BoBs
-- =============================================
-- Changes
-- =============================================
-- Author     Date      User Story Description
-- ------     -----     ---------- -----------
-- Asolosky  07/29/2020 US1771016  Used the replace function to display a line feed. Also added error for: verify the improvement idea part index has 1 unique name.  
-- Asolosky  07/29/2020 US1782182  Added error for: verify the improvement idea part index has 1 unique name.  
-- Ashaik12  07/30/2020 US1809333  Increase column sizes in temp table to match database column sizes.
-- Asolosky  09/11/2020 US1910882  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
--DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_SUPL] 

CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_SUPL] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Part Name in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	--This validation can only be a WARNING, not an ERROR, because the BOM Part
	--may have been added for a Supplier-originated Improvement Idea
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S44.Source_c
		,replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>')
		,'Part Name does not match the Part Name in ARROW' 
		,S44.Processing_ID
		,S44.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'WARNING'
		,'Improvement Ideas'
		,S44.row_idx
		,S44.improvement_id
		,U18.ARWU18_BOM_PART_X  --No ARROW Value
	FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S44.Processing_ID = S34.Processing_ID
		AND S44.filename = S34.filename
		AND S44.originator = 'Supplier'
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU18_BOM_PART AS U18
		ON U06_FLAT.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K
		AND S44.part_index = U18.ARWU18_BOM_PART_IX_N
	WHERE S44.Processing_ID = @GUID 
		AND S44.part_name <> U18.ARWU18_BOM_PART_X

-- verify the improvement idea part index has 1 unique name.  If it has more, reject.  This only is for Supplier improvement ideas
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
 SELECT
	    Err.[Source_c]                        as [ARWE02_SOURCE_C]
	   ,replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>')     as [ARWE02_ERROR_VALUE]
	   ,'The new part index has 2 different part names. Please correct this so the part names are the same.'  as [ARWE02_ERROR_X]
	   ,Err.[Processing_ID]                   as [ARWE02_PROCESSING_ID]
	   ,Err.[filename]                        as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)                 as [ARWE02_PROCEDURE_X]
	   ,@TIME_STAMP                           as [ARWE02_CREATE_S]
	   ,@CDSID                                as [ARWE02_CREATE_USER_C]
	   ,@TIME_STAMP                           as [ARWE02_LAST_UPDT_S]
	   ,@CDSID                                as [ARWE02_LAST_UPDT_USER_C]
	   ,Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K]  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR'                               as [ARWE02_ERROR_TYPE_X]
	   ,'Improvement Ideas'                   as [ARWE02_EXCEL_TAB_X]
	   ,Err.row_idx
	   ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>')
	   ,''  --No ARROW Value
   FROM 
       (--find part_index that has more than one unique name
	    Select *
	          ,Count(*) over (partition by filename, part_index) cnt  
	      from  
               (--get unique part_index and part_name
                SELECT Source_c,
                       Processing_ID,
		               part_index,
		         	   part_name,
					   improvement_id,
		               Processing_Status_x,
		               filename,
                      [ARWS44_DAII_IMPROVEMENT_IDEA_K],
		               row_idx,
		         	  ROW_NUMBER() over (partition by filename, part_index, part_name Order by row_idx) rownum
                 FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO]     S44
                WHERE Processing_ID    = @GUID
				  and S44.originator   = 'Supplier'
	              and Not Exists
		               (Select 'X'
		         	     from [dbo].[PARWU18_BOM_PART] U18
                        where S44.[part_index]=U18.ARWU18_BOM_PART_IX_N
                       )                    
               ) uniq
         Where rownum = 1  --This filter will give the unique part_index and part_name row
	   ) ERR
	   Where cnt > 1 --When the part_index has a cnt > 1, there's rows with 2 different part names.
;

	--+++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Originator must be Ford or Supplier
	--+++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  CASE WHEN Err.[originator] = '' THEN '<Blank>'
	       ELSE Err.[originator]
	  END as [ARWE02_ERROR_VALUE],
	  'Improvement Idea Originator is not Ford or Supplier.' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  'Improvement Ideas' as [ARWE02_EXCEL_TAB_X],
	  Err.row_idx,
	  improvement_id,
	  ''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
		  originator,
		  part_index,
		  improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS44_DAII_IMPROVEMENT_IDEA_K],
		  row_idx
        FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO]     S44
        WHERE Processing_ID = @GUID
	    and originator not in ('Ford','Supplier')
                    
       ) Err


	--+++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Index must be at least 2 chars
	--+++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  S44.[Source_c] as [ARWE02_SOURCE_C],
	  S44.[part_index] as [ARWE02_ERROR_VALUE],
	  'Part Index is Less than 2 Characters' as  [ARWE02_ERROR_X],
	  S44.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  S44.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
      @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  S44.[ARWS44_DAII_IMPROVEMENT_IDEA_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  'Improvement Ideas' as [ARWE02_EXCEL_TAB_X],
	  S44.row_idx as [ARWE02_ROW_IDX],
	  S44.improvement_id,
	  ''  --No ARROW Value
       FROM 
         [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
        WHERE Processing_ID         = @GUID
		and len(S44.part_index) <= 1

	--++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Index 1st character must be alpha
	--++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       S44.Source_c                                 as [ARWE02_SOURCE_C],
	       replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')  as [ARWE02_ERROR_VALUE],
	       'The Part index does not follow proper naming standards. In this case the first position of the part index is not a character [A-Z]. Part Example A1.1' 
		                                                as [ARWE02_ERROR_X],
	       S44.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       S44.filename                                 as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       S44.ARWS44_DAII_IMPROVEMENT_IDEA_K           as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'        as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       'Improvement Ideas'                          as [ARWE02_EXCEL_TAB_X],
	       S44.row_idx                                  as [ARWE02_ROW_IDX],
	       S44.improvement_id,
	       ''  --No ARROW Value
      FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
     WHERE Processing_ID = @GUID
	   and substring(S44.part_index,1,1) not like '%[a-z]%'



	--++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: New Part Index has no Sub Assembly
	--++++++++++++++++++++++++++++++++++++++++++

	 DECLARE @new_part_index TABLE (
			 NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
			,NEW_CCTSS int NOT NULL
			,row_idx INT
			,Processing_ID varchar(500)
			,filename varchar(500)
			,Ref_k int
			,Error_Flag VARCHAR(50)
			,improvement_id Varchar(5000)
			)

	-- get new part index from S44 that is not on u18.  
	INSERT INTO @new_part_index
       SELECT S44.part_index as not_matched_PI
			 ,u06_view.[ARWU01_CCTSS_K]
 	         ,s44.[row_idx]
			 ,S44.Processing_ID
			 ,s44.filename
			 ,s44.ARWS44_DAII_IMPROVEMENT_IDEA_K
			 ,'' as Error_Flag
			 ,S44.improvement_id
       FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
	   JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO      S34
         on S34.Processing_ID       = S44.Processing_ID
        and S34.filename            = S44.filename
	           
	   join [dbo].[PARWU06_CCTSS_DSGN_FLAT] u06_view       
	     on s34.[User_Selected_CTSP_N]            = u06_view.[ARWU31_CTSP_N]
		and s34.[User_Selected_CTSP_Region_C]     = u06_view.[ARWA06_RGN_C]
		and s34.[User_Selected_VEH_MAKE_N]        = u06_view.ARWA14_VEH_MAKE_N
		and s34.[User_Selected_VEH_MDL_N]         = u06_view.ARWA34_VEH_MDL_N
		and s34.[User_Selected_VEH_MDL_YR_C]      = u06_view.ARWA35_DSGN_VEH_MDL_YR_C
		and s34.[User_Selected_ENRG_SUB_CMMDTY_X] = u06_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s34.[User_Selected_BNCMK_VRNT_N]      = u06_view.[ARWU01_BNCHMK_VRNT_N]
		and s34.[User_Selected_VEH_MDL_VRNT_X]    = u06_view.ARWA35_DSGN_VEH_MDL_VRNT_X
		
	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u06_view.[ARWU01_CCTSS_K] = U18.[ARWU01_CCTSS_K]
		 AND S44.[part_index] = U18.ARWU18_BOM_PART_IX_N

       WHERE s44.Processing_ID       =  @GUID
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL


	-- Validate for 2 character match
	MERGE INTO @new_part_index temp_table
	USING
	(
	select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
	from @new_part_index npi
	JOIN PARWU18_BOM_PART U18
	ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
	AND   substring(npi.NEW_BOM_PART_IX_N,1,2) = substring(U18.[ARWU18_BOM_PART_IX_N],1,2)
	JOIN PARWU17_BOM_SUB_ASSY U17
	ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
	where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
	group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
	) X
	ON (
	temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
	AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
	AND temp_table.filename = X.filename
	AND temp_table.row_idx= X.row_idx
	)
	WHEN MATCHED THEN UPDATE
	SET Error_Flag = '2 Char Pass'
	;

	-- Validate for 1 character
	MERGE INTO @new_part_index temp_table
	USING
	(
	select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
	from @new_part_index npi
	JOIN PARWU18_BOM_PART U18
	ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
	AND   substring(npi.NEW_BOM_PART_IX_N,1,1) = substring(U18.[ARWU18_BOM_PART_IX_N],1,1)
	JOIN PARWU17_BOM_SUB_ASSY U17
	ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
	where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
	and npi.Error_Flag !='2 Char Pass'
	and substring(npi.NEW_BOM_PART_IX_N,1,2) <> 'DP'
	and substring(U18.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
	group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
	) X
	ON (
	temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
	AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
	AND temp_table.filename = X.filename
	AND temp_table.row_idx= X.row_idx
	)
	WHEN MATCHED THEN UPDATE
	SET Error_Flag = '1 Char Pass'
	;


	MERGE INTO @new_part_index temp_table
	USING
	(
		  SELECT npi.NEW_CCTSS        as ARWU01_CCTSS_K
				,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
				,npi.filename
				,npi.row_idx
		  FROM  @new_part_index npi
		  LEFT JOIN [PARWU18_BOM_PART] U18
			on u18.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
			and substring(u18.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_BOM_PART_IX_N,1,1)
			WHERE npi.Error_Flag =''
			and u18.[ARWU18_BOM_PART_IX_N] is NULL
		) X

	ON (
	temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
	AND temp_table.NEW_BOM_PART_IX_N = X.ARWU18_BOM_PART_IX_N
	AND temp_table.filename = X.filename
	AND temp_table.row_idx= X.row_idx
	)
	WHEN MATCHED THEN UPDATE
	SET Error_Flag = 'No Sub-Assy'
	;

	INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	 select 
			'UI' AS [ARWE02_SOURCE_C] 
		   ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
		   ,'ARROW is Unable to determine which Sub-Assembly the Added Part should belong to. First and Second Characters match Part Indexes from multiple Sub Assemblies' as [ARWE02_ERROR_X]
		   ,Processing_ID as [ARWE02_PROCESSING_ID]
		   ,FileName as [ARWE02_FILENAME]
		   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
		   ,@TIME_STAMP  as [ARWE02_CREATE_S]
		   ,@CDSID  as [ARWE02_CREATE_USER_C]
		   ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
		   ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
		   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
		   ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X]
		   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
		   ,'Improvement Ideas' as [ARWE02_EXCEL_TAB_X]
		   ,row_idx as [ARWE02_ROW_IDX]
	       ,improvement_id
	       ,''  --No ARROW Value
	 from @new_part_index 
	 where Error_Flag=''

	 INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	 select 
			'UI' AS [ARWE02_SOURCE_C] 
		   ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
		   ,'Invalid Part Index: No Sub-Assembly found for ADD Part index' as [ARWE02_ERROR_X]
		   ,Processing_ID as [ARWE02_PROCESSING_ID]
		   ,FileName as [ARWE02_FILENAME]
		   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
		   ,@TIME_STAMP  as [ARWE02_CREATE_S]
		   ,@CDSID  as [ARWE02_CREATE_USER_C]
		   ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
		   ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
		   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
		   ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X]
		   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
		   ,'Improvement Ideas' as [ARWE02_EXCEL_TAB_X]
		   ,row_idx as [ARWE02_ROW_IDX]
	       ,improvement_id
	       ,''  --No ARROW Value
	 from @new_part_index 
	 where Error_Flag='No Sub-Assy'

END TRY

BEGIN CATCH
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,'' 
			 ,'PARWS34_DAII_COVER_PAGE_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH
GO
