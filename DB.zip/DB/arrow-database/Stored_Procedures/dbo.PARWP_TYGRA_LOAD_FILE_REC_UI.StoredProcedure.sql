SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/23/2020
-- Description:	Load the data in UB3 from S62 on TYGRA Load.  SP is used in the UI
-- User story:  US2196377
-- =============================================

-- Changes
-- =============================================
-- Author     Date        User Story   Description
-- ------     -----       ----------   ------------
-- rwesley2   02/09/2021  US2247535    A56 PIA_EI key to UB3
-- Ashaik12   03/09/2021               Use S64 table instead of M01
-- Ashaik12   03/24/2021               Multiply by negative sign on all amount columns
-- Ashaik12   04/15/2021  US2460657    Add changes to incorporate BOB PIA EI as a reference to A47 table.
-- rwesley2   04-20-2021  U2453456     use MAX length when declaring a variable  
-- rwesley2   04-20-2021  US2456446    add columns to UB3 load 
-- ASHAIK12   04-22-2021  US2478016    Add FEDEBOM PLANNED columns
-- ASHAIK12   04-22-2021  US2478016    Add FEDEBOM BOB PIA END ITEM Column as a reference to A47 table
-- ASHAIK12   04-23-2021               Make All A47 Joins to LEFT JOIN. JOIN for some reason made the query very slow.
-- ASHAIK12   04-29-2021               Change BoB Load to a merge to insert data for same commodity but multiple sub commodities.
-- rwesley2   05-10-2021  US2522370    Remove reference to U31 key and replace with new UB1 table and UB1 key
-- rwesley2   05-24-2021  US2559784    Pass in @version in S62 join to UB1 to prevent files with the same name but different 
--                                     version number from being loaded
-- ashaik12   06-22-2021  US2643625    Change initial load from insert to a merge.
-- rwesley2	  09-03-2021  US2835340    SP used NULL for u01 key to indicate an initial load.  UI can't pass a NULL.  Changig U01 key to 
--                                     -1 (negative 1) for initial load logic 
-- rwesley    09-30-2021  US2879211 - load Current files
-- rwesley2  10-22-2021  UB2995475    removed P05 join.  
--                                    Added S66 join. 
--                                 Removed branching logic and Created 1 MERGE to handle INSERT for initial load and BoB refresh 
-- ashaik12   09-20-2022  US4066530 added Stretch_Part_Level_Target column
-- ashaik12   09-22-2022  US4073150   Rename column name
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_LOAD_FILE_REC_UI] 
	-- Add the parameters for the stored procedure here
     @processing_id  varchar(MAX) 
	,@CDSID varchar(MAX)
	,@version INT
	,@TIME_STAMP DATETIME
AS

SET NOCOUNT ON;

-- Insert into A47 for missing Surrogate Prefix, Base and Suffix
MERGE INTO [dbo].[PARWA47_FORD_END_ITM] A47
USING
(
select * from
(
select 
 CASE WHEN [Surrogate_Part_Prefix] is NULL THEN '' ELSE substring([Surrogate_Part_Prefix],1,32) END as [Surrogate_Part_Prefix]
,CASE WHEN [Surrogate_Part_Base]   is NULL THEN '' ELSE substring([Surrogate_Part_Base]  ,1,32) END as [Surrogate_Part_Base]
,CASE WHEN [Surrogate_Part_Suffix] is NULL THEN '' ELSE substring([Surrogate_Part_Suffix],1,32) END as [Surrogate_Part_Suffix]
FROM [dbo].[PARWS62_TYGRA_SUMMARY] S62
where s62.[Processing_ID] = @processing_id
) X
group by [Surrogate_Part_Prefix],[Surrogate_Part_Base],[Surrogate_Part_Suffix]
) STAGING
ON (
A47.[ARWA47_FORD_END_ITM_PREF_N] =     STAGING.[Surrogate_Part_Prefix]
AND A47.[ARWA47_FORD_END_ITM_BSE_N]  = STAGING.[Surrogate_Part_Base]
AND A47.[ARWA47_FORD_END_ITM_SFX_N]  = STAGING.[Surrogate_Part_Suffix]
)
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 (  
	   CASE WHEN [Surrogate_Part_Prefix] is NULL THEN '' ELSE substring([Surrogate_Part_Prefix],1,32) END    -- [ARWA47_FORD_END_ITM_PREF_N]
	  ,CASE WHEN [Surrogate_Part_Base]   is NULL THEN '' ELSE substring([Surrogate_Part_Base],1,32)   END -- [ARWA47_FORD_END_ITM_BSE_N]
	  ,CASE WHEN [Surrogate_Part_Suffix] is NULL THEN '' ELSE substring([Surrogate_Part_Suffix],1,32) END  -- [ARWA47_FORD_END_ITM_SFX_N]
      ,'9999-12-31 00:00:00.000'  -- ARWA47_INACTV_S
	  ,@TIME_STAMP                -- ARWA47_CREATE_S
	  ,@CDSID					  -- ARWA47_CREATE_USER_C
	  ,@TIME_STAMP                -- ARWA47_LAST_UPDT_S
	  ,@CDSID					  -- ARWA47_LAST_UPDT_USER_C
	 )
;

-- Insert into A47 for missing Start Point Prefix, Base and Suffix
MERGE INTO [dbo].[PARWA47_FORD_END_ITM] A47
USING
(
select * from
(
select 
 CASE WHEN [Start_Point_Part_Prefix] is NULL THEN '' ELSE substring([Start_Point_Part_Prefix],1,32) END as [Start_Point_Part_Prefix]
,CASE WHEN [Start_Point_Part_Base]   is NULL THEN '' ELSE substring([Start_Point_Part_Base]  ,1,32) END as [Start_Point_Part_Base]
,CASE WHEN [Start_Point_Part_Suffix] is NULL THEN '' ELSE substring([Start_Point_Part_Suffix],1,32) END as [Start_Point_Part_Suffix]
FROM [dbo].[PARWS62_TYGRA_SUMMARY] S62
where s62.[Processing_ID] = @processing_id
) X
group by [Start_Point_Part_Prefix],[Start_Point_Part_Base],[Start_Point_Part_Suffix]
) STAGING
ON (
A47.[ARWA47_FORD_END_ITM_PREF_N] =     STAGING.[Start_Point_Part_Prefix]
AND A47.[ARWA47_FORD_END_ITM_BSE_N]  = STAGING.[Start_Point_Part_Base]
AND A47.[ARWA47_FORD_END_ITM_SFX_N]  = STAGING.[Start_Point_Part_Suffix]
)
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 (  
	   CASE WHEN [Start_Point_Part_Prefix] is NULL THEN '' ELSE substring([Start_Point_Part_Prefix],1,32) END  -- [ARWA47_FORD_END_ITM_PREF_N]
	  ,CASE WHEN [Start_Point_Part_Base]   is NULL THEN '' ELSE substring([Start_Point_Part_Base],1,32)   END  -- [ARWA47_FORD_END_ITM_BSE_N]
	  ,CASE WHEN [Start_Point_Part_Suffix] is NULL THEN '' ELSE substring([Start_Point_Part_Suffix],1,32) END  -- [ARWA47_FORD_END_ITM_SFX_N]
      ,'9999-12-31 00:00:00.000'  -- ARWA47_INACTV_S
	  ,@TIME_STAMP                -- ARWA47_CREATE_S
	  ,@CDSID					  -- ARWA47_CREATE_USER_C
	  ,@TIME_STAMP                -- ARWA47_LAST_UPDT_S
	  ,@CDSID					  -- ARWA47_LAST_UPDT_USER_C
	 )
;


-- Insert into A47 for missing FEDEBOM PLANNED Prefix, Base and Suffix
MERGE INTO [dbo].[PARWA47_FORD_END_ITM] A47
USING
(
select * from
(
select 
 CASE WHEN [FEDEBOM_Planned_Prefix] is NULL THEN '' ELSE substring([FEDEBOM_Planned_Prefix],1,32) END as [FEDEBOM_PLANNED_Prefix]
,CASE WHEN [FEDEBOM_Planned_Base]   is NULL THEN '' ELSE substring([FEDEBOM_Planned_Base]  ,1,32) END as [FEDEBOM_PLANNED_Base]
,CASE WHEN [FEDEBOM_Planned_Suffix] is NULL THEN '' ELSE substring([FEDEBOM_Planned_Suffix],1,32) END as [FEDEBOM_PLANNED_Suffix]
FROM [dbo].[PARWS62_TYGRA_SUMMARY] S62
where s62.[Processing_ID]=@processing_id
) X
group by [FEDEBOM_Planned_Prefix],[FEDEBOM_Planned_Base],[FEDEBOM_Planned_Suffix]
) STAGING
ON (
A47.[ARWA47_FORD_END_ITM_PREF_N] =     STAGING.[FEDEBOM_PLANNED_Prefix]
AND A47.[ARWA47_FORD_END_ITM_BSE_N]  = STAGING.[FEDEBOM_PLANNED_Base]
AND A47.[ARWA47_FORD_END_ITM_SFX_N]  = STAGING.[FEDEBOM_PLANNED_Suffix]
)
When NOT MATCHED THEN
     INSERT 
     VALUES 
	 (  
	   CASE WHEN [FEDEBOM_Planned_Prefix] is NULL THEN '' ELSE substring([FEDEBOM_Planned_Prefix],1,32) END  -- [ARWA47_FORD_END_ITM_PREF_N]
	  ,CASE WHEN [FEDEBOM_Planned_Base]   is NULL THEN '' ELSE substring([FEDEBOM_Planned_Base],1,32)   END  -- [ARWA47_FORD_END_ITM_BSE_N]
	  ,CASE WHEN [FEDEBOM_Planned_Suffix] is NULL THEN '' ELSE substring([FEDEBOM_Planned_Suffix],1,32) END  -- [ARWA47_FORD_END_ITM_SFX_N]
      ,'9999-12-31 00:00:00.000'  -- ARWA47_INACTV_S
	  ,@TIME_STAMP                -- ARWA47_CREATE_S
	  ,@CDSID					  -- ARWA47_CREATE_USER_C
	  ,@TIME_STAMP                -- ARWA47_LAST_UPDT_S
	  ,@CDSID					  -- ARWA47_LAST_UPDT_USER_C
	 )
;


--******************************************************
-- loads the table for all Engineering Commodities.
 --******************************************************

MERGE INTO PARWUB3_TYGRA_FILE_REC UB3
USING
(
SELECT
[ARWUB3_TYGRA_FILE_REC_SEQ_R]
,[ARWUB3_VEH_N]
,[ARWA02_ENRG_CMMDTY_K]
,A47_SURGT.ARWA47_FORD_END_ITM_K AS [ARWA47_SURGT_END_ITM_K]
,[ARWUB3_SURGT_PART_X]
,[ARWUB3_FIN_SURGT_PGM_X]
,[ARWUB3_SURGT_A]
,A47_STRTG_PT.ARWA47_FORD_END_ITM_K AS [ARWA47_STRTG_PT_END_ITM_K] 
,[ARWUB3_STRTG_PT_PART_X]
,[ARWUB3_CPSC_X]
,[ARWUB3_STRTG_PT_VEH_A]
,[ARWUB3_STRTG_PT_EFIC_A]
,[ARWUB3_FIN_SURGT_Q]
,[ARWUB3_STRTG_PT_Q]
,[ARWUB3_LEFT_ATTR_A]
,[ARWUB3_LEFT_ATTR_EFIC_A]
,[ARWUB3_MEV_A]
,[ARWUB3_JOB1_ATTR_A]
,[ARWUB3_JOB1_ATTR_EFIC_A]
,[ARWUB3_JOB1_TRGT_A]
,[ARWUB3_PART_LVL_CMNLTY_X]
,[ARWUB3_PART_LVL_EFIC_METHD_X]
,[ARWUB3_TYGRA_UNIQ_ID_R]
,[ARWUB3_JOB_LAST_A]
,[ARWUB3_CREATE_S]
,[ARWUB3_CREATE_USER_C]
,[ARWUB3_LAST_UPDT_S]
,[ARWUB3_LAST_UPDT_USER_C]
,[ARWUB3_PART_LVL_REDN_P]
,A47_BOB_PIA_EI.ARWA47_FORD_END_ITM_K AS ARWA47_BOB_PIA_END_ITM_K
,[ARWUB3_SURGT_PGM_CMMDTY_STRTG_PT_X]
,[ARWUB3_WCAT_CATG_X]
,[ARWUB3_CMPTBL_1_A]
,[ARWUB3_CMPTBL_1_WCAT_X]
,[ARWUB3_CMPTBL_1_X]
,[ARWUB3_CMPTBL_2_A]
,[ARWUB3_CMPTBL_2_WCAT_X]
,[ARWUB3_CMPTBL_2_X]
,[ARWUB3_CMPTBL_3_A]
,[ARWUB3_CMPTBL_3_WCAT_X]
,[ARWUB3_CMPTBL_3_X]
,[ARWUB3_J1_ATTR_1_A]
,[ARWUB3_J1_ATTR_1_WCAT_X]
,[ARWUB3_J1_ATTR_1_X]
,[ARWUB3_J1_ATTR_2_A]
,[ARWUB3_J1_ATTR_2_WCAT_X]
,[ARWUB3_J1_ATTR_2_X]
,[ARWUB3_J1_ATTR_3_A]
,[ARWUB3_J1_ATTR_3_WCAT_X]
,[ARWUB3_J1_ATTR_3_X]
,[ARWUB3_PLATFORM_TOPHAT_X]
,[ARWUB3_MFG_RGN_X]
,[ARWUB3_STRTG_PT_VS_SURGT_X]
,[ARWUB3_ENRG_CMMDTY_CMT_X]
,[ARWUB3_FEDEBOM_PART_NUM_PLN_X]
,A47_FEDE_PLANNED.ARWA47_FORD_END_ITM_K AS [ARWA47_FEDEBOM_PLN_END_ITM_K]
,A47_FEDE_BOB_PIA_EI.ARWA47_FORD_END_ITM_K AS [ARWA47_FEDEBOM_BOB_PIA_END_ITM_K]
,[ARWUB1_TYGRA_FILE_K]
,[ARWUB3_STRETCH_PART_LVL_TRGT_A]
FROM
(
select   
 s62.[ARWS62_TYGRA_SUMMARY]           AS [ARWUB3_TYGRA_FILE_REC_SEQ_R]
, S62.Vehicle_name                     AS [ARWUB3_VEH_N]
, A02.ARWA02_ENRG_CMMDTY_K             AS [ARWA02_ENRG_CMMDTY_K]
--, A47_SURGT.[ARWA47_FORD_END_ITM_K]    AS [ARWA47_SURGT_END_ITM_K]
, coalesce(S62.[Surrogate_Part_Desc],'')            AS [ARWUB3_SURGT_PART_X]
, coalesce(S62.[Finance_Surrogate_Program]  ,'')    AS [ARWUB3_FIN_SURGT_PGM_X]
, -(CAST(coalesce(S62.[Surrogate_Cost],'0')  AS FLOAT))                AS [ARWUB3_SURGT_A]
--, A47_STRTG_PT.[ARWA47_FORD_END_ITM_K] AS [ARWA47_STRTG_PT_END_ITM_K]
, coalesce(S62.Start_Point_Part_Desc,'')            AS [ARWUB3_STRTG_PT_PART_X]
, coalesce(S62.[Start_Point_CPSC],'')               AS [ARWUB3_CPSC_X]
, -(CAST(coalesce(S62.Start_Point_Vehicle_Price,'0')  AS Decimal(19,9)))       AS [ARWUB3_STRTG_PT_VEH_A]
, -(CAST(coalesce(S62.Start_Point_Efficiency,'0') AS Decimal(19,9)))          AS [ARWUB3_STRTG_PT_EFIC_A]
, CAST(coalesce(S62.Finance_Surrogate_Quantity,'0') AS Decimal(19,9))      AS [ARWUB3_FIN_SURGT_Q]
, CAST(coalesce(S62.Start_Point_Quantity,'0')    AS Decimal(19,9))         AS [ARWUB3_STRTG_PT_Q]
, -(CAST(coalesce(S62.Compatibilities,'0')  AS Decimal(19,9)))                 AS [ARWUB3_LEFT_ATTR_A]
, -(CAST(coalesce(S62.Compatibilities_Efficiency,'0')  AS Decimal(19,9)))      AS [ARWUB3_LEFT_ATTR_EFIC_A]
, -(CAST(coalesce(S62.MEV ,'0') AS Decimal(19,9)))                             AS [ARWUB3_MEV_A]
, -(CAST(coalesce(S62.Job1_Attributes,'0') AS Decimal(19,9)))                  AS [ARWUB3_JOB1_ATTR_A]
, -(CAST(coalesce(S62.Job1_Attributes_Efficiency,'0')  AS Decimal(19,9)))       AS [ARWUB3_JOB1_ATTR_EFIC_A]
, -(CAST( coalesce(S62.Job1_Target ,'0') AS Decimal(19,9)))                     AS [ARWUB3_JOB1_TRGT_A]
, coalesce(S62.WS2_Part_Level_Commonality,'')       AS [ARWUB3_PART_LVL_CMNLTY_X]
, coalesce(S62.WS2_Part_Level_Eff_Methodology_Calculation,'') AS [ARWUB3_PART_LVL_EFIC_METHD_X]
, CAST(coalesce(S62.Tygra_Unique_ID,'0')  as INT)                AS [ARWUB3_TYGRA_UNIQ_ID_R]
, -(CAST(coalesce(S62.[Surrogate_Cost],'0') AS FLOAT) 
     - ((CAST(coalesce(S62.[Commerical_TVM],'0') AS Decimal(19,9))  
	 + CAST(coalesce(S62.[Design_TVM],'0') AS Decimal(19,9))) * CAST(coalesce(S62.[Surrogate_Cost],'0') AS Decimal(19,9)))) AS [ARWUB3_JOB_LAST_A]
, @TIME_STAMP                          AS [ARWUB3_CREATE_S]
, @CDSID                               AS [ARWUB3_CREATE_USER_C]
, @TIME_STAMP                          AS [ARWUB3_LAST_UPDT_S]
, @CDSID                               AS [ARWUB3_LAST_UPDT_USER_C]
,coalesce(s62.[Part_Level_Reduction],'0')              AS [ARWUB3_PART_LVL_REDN_P]
--,A47_BOB_PIA_EI.ARWA47_FORD_END_ITM_K AS ARWA47_BOB_PIA_END_ITM_K
,dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 1, '-') AS Prefix
,dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 2, '-') AS Base
,dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 3, '-') AS Suffix
,[Surrogate_Part_Prefix]
,[Surrogate_Part_Base]  
,[Surrogate_Part_Suffix]
,[Start_Point_Part_Prefix]
,[Start_Point_Part_Base]  
,[Start_Point_Part_Suffix]
,coalesce(s62.[Surrogate_Program_Used_for_Commodity_Start_Point],'')  as [ARWUB3_SURGT_PGM_CMMDTY_STRTG_PT_X]
,coalesce(s62.[WCAT_Category],'')                                     as [ARWUB3_WCAT_CATG_X]
,CAST(coalesce(S62.[Compatibilities1],'0')    AS Decimal(19,9))       as [ARWUB3_CMPTBL_1_A]
,coalesce(s62.[Compatibilities1_WCAT],'')                             as [ARWUB3_CMPTBL_1_WCAT_X]
,coalesce(s62.[Compatibilities1_Desc],'')                             as [ARWUB3_CMPTBL_1_X]
,CAST(coalesce(S62.[Compatibilities2],'0')    AS Decimal(19,9))       as [ARWUB3_CMPTBL_2_A]
,coalesce(s62.[Compatibilities2_WCAT],'')                             as [ARWUB3_CMPTBL_2_WCAT_X]
,coalesce(s62.[Compatibilities2_Desc],'')                             as [ARWUB3_CMPTBL_2_X]
,CAST(coalesce(S62.[Compatibilities3],'0')    AS Decimal(19,9))       as [ARWUB3_CMPTBL_3_A]
,coalesce(s62.[Compatibilities3_WCAT],'')                             as [ARWUB3_CMPTBL_3_WCAT_X]
,coalesce(s62.[Compatibilities3_Desc],'')                             as [ARWUB3_CMPTBL_3_X]
,CAST(coalesce(S62.[Job1_Attributes1],'0')    AS Decimal(19,9))       as [ARWUB3_J1_ATTR_1_A]
,coalesce(s62.[Job1_Attributes1_WCAT],'')                             as [ARWUB3_J1_ATTR_1_WCAT_X]
,coalesce(s62.[Job1_Attributes1_Desc],'')                             as [ARWUB3_J1_ATTR_1_X]
,CAST(coalesce(S62.[Job1_Attributes2],'0')    AS Decimal(19,9))       as [ARWUB3_J1_ATTR_2_A]
,coalesce(s62.[Job1_Attributes2_WCAT],'')                             as [ARWUB3_J1_ATTR_2_WCAT_X]
,coalesce(s62.[Job1_Attributes2_Desc],'')                             as [ARWUB3_J1_ATTR_2_X]
,CAST(coalesce(S62.[Job1_Attributes3],'0')    AS Decimal(19,9))       as [ARWUB3_J1_ATTR_3_A]
,coalesce(s62.[Job1_Attributes3_WCAT],'')                             as [ARWUB3_J1_ATTR_3_WCAT_X]
,coalesce(s62.[Job1_Attributes3_Desc],'')                             as [ARWUB3_J1_ATTR_3_X]
,coalesce(s62.[Platform_Tophat],'')                                   as [ARWUB3_PLATFORM_TOPHAT_X]
,coalesce(s62.[MFG_Region],'')                                        as [ARWUB3_MFG_RGN_X]
,coalesce(s62.[ST_v_SU_Desc],'')                                      as [ARWUB3_STRTG_PT_VS_SURGT_X]
,coalesce(s62.[Comments],'')                                          as [ARWUB3_ENRG_CMMDTY_CMT_X]
,coalesce(s62.FEDEBOM_PN_Plan,'')                                     as [ARWUB3_FEDEBOM_PART_NUM_PLN_X]
,FEDEBOM_Planned_Prefix
,FEDEBOM_Planned_Base  
,FEDEBOM_Planned_Suffix
,dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 1, '-') AS FEDE_BoB_Pia_Ei_Prefix
,dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 2, '-') AS FEDE_BoB_Pia_Ei_Base
,dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 3, '-') AS FEDE_BoB_Pia_Ei_Suffix
,B1.ARWUB1_TYGRA_FILE_K                AS [ARWUB1_TYGRA_FILE_K]
,-(CAST(coalesce(s62.[Stretch_Part_Level_Target],'0') AS Decimal(19,9)))  as [ARWUB3_STRETCH_PART_LVL_TRGT_A]
from [dbo].[PARWS62_TYGRA_SUMMARY] S62
JOIN PARWUB1_TYGRA_FILE B1 ON S62.file_name = B1.ARWUB1_TYGRA_FILE_N
and b1.ARWUB1_TYGRA_FILE_REV_R = @version 

JOIN [dbo].[PARWS64_TYGRA_ENRG_CMMDTY] S64 
ON S64.ARWS64_TYGRA_ENRG_CMMDTY_X = S62.Engineering_Commodity 
AND S64.[ARWS64_TYGRA_PROGRAM] = S62.Vehicle_name   
JOIN PARWA02_ENRG_CMMDTY A02 ON S64.ARWS64_ARROW_ENRG_CMMDTY_X = A02.ARWA02_ENRG_CMMDTY_X
where S62.Processing_ID = @processing_id
and A02.ARWA02_ENRG_CMMDTY_k in (select ARWA02_ENRG_CMMDTY_k FROM PARWU01_CCTSS_FLAT u01
                                                              join PARWS66_TYGRA_BOB s66
	                                                           on  s62.processing_id = s66.processing_id
	                                                           and u01.ARWU01_CCTSS_K = s66.ARWU01_CCTSS_K
															   group by ARWA02_ENRG_CMMDTY_k )
) S62
LEFT JOIN [PARWA47_FORD_END_ITM] A47_SURGT
ON  A47_SURGT.[ARWA47_FORD_END_ITM_PREF_N] = CASE WHEN [Surrogate_Part_Prefix] is NULL THEN '' ELSE substring([Surrogate_Part_Prefix],1,32) END
AND A47_SURGT.[ARWA47_FORD_END_ITM_BSE_N]  = CASE WHEN [Surrogate_Part_Base]   is NULL THEN '' ELSE substring([Surrogate_Part_Base]  ,1,32) END
AND A47_SURGT.[ARWA47_FORD_END_ITM_SFX_N]  = CASE WHEN [Surrogate_Part_Suffix] is NULL THEN '' ELSE substring([Surrogate_Part_Suffix],1,32) END

LEFT JOIN [PARWA47_FORD_END_ITM] A47_STRTG_PT
ON  A47_STRTG_PT.[ARWA47_FORD_END_ITM_PREF_N] = CASE WHEN [Start_Point_Part_Prefix] is NULL THEN '' ELSE substring([Start_Point_Part_Prefix],1,32) END
AND A47_STRTG_PT.[ARWA47_FORD_END_ITM_BSE_N]  = CASE WHEN [Start_Point_Part_Base]   is NULL THEN '' ELSE substring([Start_Point_Part_Base],1,32)   END
AND A47_STRTG_PT.[ARWA47_FORD_END_ITM_SFX_N]  = CASE WHEN [Start_Point_Part_Suffix] is NULL THEN '' ELSE substring([Start_Point_Part_Suffix],1,32) END

LEFT JOIN [PARWA47_FORD_END_ITM] A47_BOB_PIA_EI
ON  A47_BOB_PIA_EI.[ARWA47_FORD_END_ITM_PREF_N] = CASE WHEN Prefix is NULL THEN '' ELSE substring(Prefix,1,32) END
AND A47_BOB_PIA_EI.[ARWA47_FORD_END_ITM_BSE_N]  = CASE WHEN Base   is NULL THEN '' ELSE substring(Base,1,32)   END
AND A47_BOB_PIA_EI.[ARWA47_FORD_END_ITM_SFX_N]  = CASE WHEN Suffix is NULL THEN '' ELSE substring(Suffix,1,32) END

LEFT JOIN [PARWA47_FORD_END_ITM] A47_FEDE_PLANNED
ON  A47_FEDE_PLANNED.[ARWA47_FORD_END_ITM_PREF_N] = CASE WHEN FEDEBOM_Planned_Prefix is NULL THEN '' ELSE substring(FEDEBOM_Planned_Prefix,1,32) END
AND A47_FEDE_PLANNED.[ARWA47_FORD_END_ITM_BSE_N]  = CASE WHEN FEDEBOM_Planned_Base   is NULL THEN '' ELSE substring(FEDEBOM_Planned_Base,1,32)   END
AND A47_FEDE_PLANNED.[ARWA47_FORD_END_ITM_SFX_N]  = CASE WHEN FEDEBOM_Planned_Suffix is NULL THEN '' ELSE substring(FEDEBOM_Planned_Suffix,1,32) END

LEFT JOIN [PARWA47_FORD_END_ITM] A47_FEDE_BOB_PIA_EI
ON  A47_FEDE_BOB_PIA_EI.[ARWA47_FORD_END_ITM_PREF_N] = CASE WHEN FEDE_BoB_Pia_Ei_Prefix is NULL THEN '' ELSE substring(FEDE_BoB_Pia_Ei_Prefix,1,32) END
AND A47_FEDE_BOB_PIA_EI.[ARWA47_FORD_END_ITM_BSE_N]  = CASE WHEN FEDE_BoB_Pia_Ei_Base   is NULL THEN '' ELSE substring(FEDE_BoB_Pia_Ei_Base,1,32)   END
AND A47_FEDE_BOB_PIA_EI.[ARWA47_FORD_END_ITM_SFX_N]  = CASE WHEN FEDE_BoB_Pia_Ei_Suffix is NULL THEN '' ELSE substring(FEDE_BoB_Pia_Ei_Suffix,1,32) END

WHERE A47_BOB_PIA_EI.ARWA47_FORD_END_ITM_K is not null
  and A47_FEDE_BOB_PIA_EI.ARWA47_FORD_END_ITM_K is not null

) SRC
ON (SRC.[ARWUB1_TYGRA_FILE_K] = UB3.[ARWUB1_TYGRA_FILE_K]
AND SRC.[ARWUB3_TYGRA_FILE_REC_SEQ_R] = UB3.[ARWUB3_TYGRA_FILE_REC_SEQ_R])
WHEN NOT MATCHED THEN INSERT
VALUES
(
 SRC.[ARWUB3_TYGRA_FILE_REC_SEQ_R]
,SRC.[ARWUB3_VEH_N]
,SRC.[ARWA02_ENRG_CMMDTY_K]
,SRC.[ARWA47_SURGT_END_ITM_K]
,SRC.[ARWUB3_SURGT_PART_X]
,SRC.[ARWUB3_FIN_SURGT_PGM_X]
,SRC.[ARWUB3_SURGT_A]
,SRC.[ARWA47_STRTG_PT_END_ITM_K] 
,SRC.[ARWUB3_STRTG_PT_PART_X]
,SRC.[ARWUB3_CPSC_X]
,SRC.[ARWUB3_STRTG_PT_VEH_A]
,SRC.[ARWUB3_STRTG_PT_EFIC_A]
,SRC.[ARWUB3_FIN_SURGT_Q]
,SRC.[ARWUB3_STRTG_PT_Q]
,SRC.[ARWUB3_LEFT_ATTR_A]
,SRC.[ARWUB3_LEFT_ATTR_EFIC_A]
,SRC.[ARWUB3_MEV_A]
,SRC.[ARWUB3_JOB1_ATTR_A]
,SRC.[ARWUB3_JOB1_ATTR_EFIC_A]
,SRC.[ARWUB3_JOB1_TRGT_A]
,SRC.[ARWUB3_PART_LVL_CMNLTY_X]
,SRC.[ARWUB3_PART_LVL_EFIC_METHD_X]
,SRC.[ARWUB3_TYGRA_UNIQ_ID_R]
,SRC.[ARWUB3_JOB_LAST_A]
,SRC.[ARWUB3_CREATE_S]
,SRC.[ARWUB3_CREATE_USER_C]
,SRC.[ARWUB3_LAST_UPDT_S]
,SRC.[ARWUB3_LAST_UPDT_USER_C]
,SRC.[ARWUB3_PART_LVL_REDN_P]
,SRC.ARWA47_BOB_PIA_END_ITM_K
,SRC.[ARWUB3_SURGT_PGM_CMMDTY_STRTG_PT_X]
,SRC.[ARWUB3_WCAT_CATG_X]
,SRC.[ARWUB3_CMPTBL_1_A]
,SRC.[ARWUB3_CMPTBL_1_WCAT_X]
,SRC.[ARWUB3_CMPTBL_1_X]
,SRC.[ARWUB3_CMPTBL_2_A]
,SRC.[ARWUB3_CMPTBL_2_WCAT_X]
,SRC.[ARWUB3_CMPTBL_2_X]
,SRC.[ARWUB3_CMPTBL_3_A]
,SRC.[ARWUB3_CMPTBL_3_WCAT_X]
,SRC.[ARWUB3_CMPTBL_3_X]
,SRC.[ARWUB3_J1_ATTR_1_A]
,SRC.[ARWUB3_J1_ATTR_1_WCAT_X]
,SRC.[ARWUB3_J1_ATTR_1_X]
,SRC.[ARWUB3_J1_ATTR_2_A]
,SRC.[ARWUB3_J1_ATTR_2_WCAT_X]
,SRC.[ARWUB3_J1_ATTR_2_X]
,SRC.[ARWUB3_J1_ATTR_3_A]
,SRC.[ARWUB3_J1_ATTR_3_WCAT_X]
,SRC.[ARWUB3_J1_ATTR_3_X]
,SRC.[ARWUB3_PLATFORM_TOPHAT_X]
,SRC.[ARWUB3_MFG_RGN_X]
,SRC.[ARWUB3_STRTG_PT_VS_SURGT_X]
,SRC.[ARWUB3_ENRG_CMMDTY_CMT_X]
,SRC.[ARWUB3_FEDEBOM_PART_NUM_PLN_X]
,SRC.[ARWA47_FEDEBOM_PLN_END_ITM_K]
,SRC.[ARWA47_FEDEBOM_BOB_PIA_END_ITM_K]
,SRC.[ARWUB1_TYGRA_FILE_K]
,SRC.[ARWUB3_STRETCH_PART_LVL_TRGT_A]
)
;


EOJ: --select 'SUCCESS'


GO


