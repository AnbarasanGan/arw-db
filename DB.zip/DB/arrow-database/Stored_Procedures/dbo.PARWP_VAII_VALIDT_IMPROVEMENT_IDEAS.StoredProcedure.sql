SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		 ASHAIK12
-- Create date: 06/24/2022
-- Description: Validate that the Improvement Ideas matches what was entered into ARROW
--              from the Variant Improvement Ideas screen.
-- =============================================
-- CHANGES
-- Date			DSID	  Story   Description
-- ---------- -------- ------- -----------
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VAII_VALIDT_IMPROVEMENT_IDEAS] 
 @GUID       VARCHAR(5000) 
,@CDSID      VARCHAR(30)
,@TIME_STAMP DATETIME
AS
SET NOCOUNT ON;

BEGIN TRY

-- Validate Improvement Idea Part description
  INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  SELECT 
		   S67.Source_c                                                    as ARWE02_SOURCE_C
		  ,replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>')     as ARWE02_ERROR_VALUE
	     ,'Improvement Idea Name doesn''t match PBOM Part name in ARROW.' as ARWE02_ERROR_X
        ,S67.Processing_ID                                               as ARWE02_PROCESSING_ID
		  ,S67.filename                                                    as ARWE02_FILENAME
	     ,OBJECT_NAME(@@PROCID)                                           as ARWE02_PROCEDURE_X
        ,@TIME_STAMP                                                     as ARWE02_CREATE_S
	     ,@CDSID                                                          as ARWE02_CREATE_USER_C
	     ,@TIME_STAMP                                                     as ARWE02_LAST_UPDT_S
	     ,@CDSID                                                          as ARWE02_LAST_UPDT_USER_C
	     ,ARWS67_VA_IMPROVEMENT_IDEA_K                                    as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'                           as ARWE02_STAGING_TABLE_X
	     ,'ERROR'                                                         as ARWE02_ERROR_TYPE_X
	     ,'Improvement Ideas'                                             as ARWE02_EXCEL_TAB_X
	     ,S67.row_idx                                                         as ARWE02_ROW_IDX
	     ,improvement_id                                                  as ARWE02_Part_Index
	     ,ARWU18_BOM_PART_X                                               as ARWE02_ARROW_Value
    FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO   S67
    JOIN PARWS45_VA_COVER_PAGE_INFO          S45  ON S45.Processing_ID            = S67.Processing_ID
                                                 AND S45.filename                 = S67.filename
	 JOIN PARWU01_CCTSS_FLAT                  U01  ON U01.ARWU31_CTSP_N            = S45.User_Selected_CTSP_N
                                                 AND U01.ARWA06_RGN_C             = S45.User_Selected_CTSP_Region_C
                                                 AND U01.ARWA03_ENRG_SUB_CMMDTY_X = S45.User_Selected_ENRG_SUB_CMMDTY_X  
                                                 AND U01.ARWU01_BNCHMK_VRNT_N     = S45.User_Selected_BNCMK_VRNT_N
	 JOIN PARWU18_BOM_PART                    U18  ON U18.ARWU01_CCTSS_K           = U01.ARWU01_CCTSS_K 
		                                           AND u18.ARWU18_BOM_PART_IX_N     = S67.part_index
   WHERE S67.Processing_ID  = @GUID
	  and S67.part_name     != U18.ARWU18_BOM_PART_X
   ;                

-- validate Improvement Idea is Quoted
  INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
  SELECT 
		   S67.Source_c                                                     as ARWE02_SOURCE_C
		  ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_ERROR_VALUE
	     ,'Improvement ID not quoted'                                      as ARWE02_ERROR_X
        ,S67.Processing_ID                                                as ARWE02_PROCESSING_ID
		  ,S67.filename                                                     as ARWE02_FILENAME
	     ,OBJECT_NAME(@@PROCID)                                            as ARWE02_PROCEDURE_X
        ,@TIME_STAMP                                                      as ARWE02_CREATE_S
	     ,@CDSID                                                           as ARWE02_CREATE_USER_C
	     ,@TIME_STAMP                                                      as ARWE02_LAST_UPDT_S
	     ,@CDSID                                                           as ARWE02_LAST_UPDT_USER_C
	     ,ARWS67_VA_IMPROVEMENT_IDEA_K                                     as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'                            as ARWE02_STAGING_TABLE_X
	     ,'WARNING'                                                        as ARWE02_ERROR_TYPE_X
	     ,'Improvement Ideas'                                              as ARWE02_EXCEL_TAB_X
	     ,S67.row_idx                                                          as ARWE02_ROW_IDX
	     ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_Part_Index
	     ,''                                                               as ARWE02_ARROW_Value
    FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO   S67
   WHERE S67.Processing_ID  = @GUID
	  and S67.quoted         = 'No'	  
   ;

  INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  Select 
		   S67.Source_c                                                     as ARWE02_SOURCE_C
		  ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_ERROR_VALUE
		  ,'Quoted column must be Yes or No. The template has a formula in this column which was manually overridden. Please copy the formula from a valid "Quoted" cell and paste it into the cell with the error. This will automatically populate a Yes or No.' 
		                                                                    as ARWE02_ERROR_X
        ,S67.Processing_ID                                                as ARWE02_PROCESSING_ID
		  ,S67.filename                                                     as ARWE02_FILENAME
	     ,OBJECT_NAME(@@PROCID)                                            as ARWE02_PROCEDURE_X
        ,@TIME_STAMP                                                      as ARWE02_CREATE_S
	     ,@CDSID                                                           as ARWE02_CREATE_USER_C
	     ,@TIME_STAMP                                                      as ARWE02_LAST_UPDT_S
	     ,@CDSID                                                           as ARWE02_LAST_UPDT_USER_C
	     ,ARWS67_VA_IMPROVEMENT_IDEA_K                                     as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'                            as ARWE02_STAGING_TABLE_X
	     ,'ERROR'                                                          as ARWE02_ERROR_TYPE_X
	     ,'Improvement Ideas'                                              as ARWE02_EXCEL_TAB_X
	     ,S67.row_idx                                                          as ARWE02_ROW_IDX
	     ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_Part_Index
	     ,''                                                               as ARWE02_ARROW_Value
    FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO   S67
   WHERE S67.Processing_ID           = @GUID
	  and IsNull(quoted,'#!~&$') Not in ('Yes', 'No')	  
;

-- validate Improvement Idea Originator
  INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  SELECT 
		   S67.Source_c                                                     as ARWE02_SOURCE_C
	     ,CASE WHEN originator = '' 
		        THEN '<Blank>'
		        ELSE originator
	      END                                                              as ARWE02_ERROR_VALUE
	     ,'Improvement Idea Originator is not Ford or Supplier.'           as ARWE02_ERROR_X
        ,S67.Processing_ID                                                as ARWE02_PROCESSING_ID
		  ,S67.filename                                                     as ARWE02_FILENAME
	     ,OBJECT_NAME(@@PROCID)                                            as ARWE02_PROCEDURE_X
        ,@TIME_STAMP                                                      as ARWE02_CREATE_S
	     ,@CDSID                                                           as ARWE02_CREATE_USER_C
	     ,@TIME_STAMP                                                      as ARWE02_LAST_UPDT_S
	     ,@CDSID                                                           as ARWE02_LAST_UPDT_USER_C
	     ,ARWS67_VA_IMPROVEMENT_IDEA_K                                     as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'                            as ARWE02_STAGING_TABLE_X
	     ,'ERROR'                                                          as ARWE02_ERROR_TYPE_X
	     ,'Improvement Ideas'                                              as ARWE02_EXCEL_TAB_X
	     ,S67.row_idx                                                          as ARWE02_ROW_IDX
	     ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_Part_Index
	     ,''                                                               as ARWE02_ARROW_Value
    FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO   S67
   WHERE S67.Processing_ID      = @GUID
	  and S67.originator    not in ('Ford','Supplier')
   ;

  INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  SELECT
		    S67.Source_c                                                     as ARWE02_SOURCE_C
		   ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_ERROR_VALUE
	      ,'Part Index is Less than 2 Characters'                           as ARWE02_ERROR_X
         ,S67.Processing_ID                                                as ARWE02_PROCESSING_ID
		   ,S67.filename                                                     as ARWE02_FILENAME
	      ,OBJECT_NAME(@@PROCID)                                            as ARWE02_PROCEDURE_X
         ,@TIME_STAMP                                                      as ARWE02_CREATE_S
	      ,@CDSID                                                           as ARWE02_CREATE_USER_C
	      ,@TIME_STAMP                                                      as ARWE02_LAST_UPDT_S
	      ,@CDSID                                                           as ARWE02_LAST_UPDT_USER_C
	      ,ARWS67_VA_IMPROVEMENT_IDEA_K                                     as ARWE02_BATCH_ERRORS_REF_K
	      ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'                            as ARWE02_STAGING_TABLE_X
	      ,'ERROR'                                                          as ARWE02_ERROR_TYPE_X
	      ,'Improvement Ideas'                                              as ARWE02_EXCEL_TAB_X
	      ,S67.row_idx                                                          as ARWE02_ROW_IDX
	      ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_Part_Index
	      ,''                                                               as ARWE02_ARROW_Value
    FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO   S67
   WHERE S67.Processing_ID    = @GUID
	  and len(S67.part_index) <= 1
   ;

-- verify the improvement idea part index has 1 unique name.  If it has more, reject
  INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  SELECT
		   ERR.Source_c                                                     as ARWE02_SOURCE_C
		  ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_ERROR_VALUE
	     ,'The new part index has 2 different part names. Please correct this so the part names are the same.'  
		                                                                    as ARWE02_ERROR_X
        ,ERR.Processing_ID                                                as ARWE02_PROCESSING_ID
		  ,ERR.filename                                                     as ARWE02_FILENAME
	     ,OBJECT_NAME(@@PROCID)                                            as ARWE02_PROCEDURE_X
        ,@TIME_STAMP                                                      as ARWE02_CREATE_S
	     ,@CDSID                                                           as ARWE02_CREATE_USER_C
	     ,@TIME_STAMP                                                      as ARWE02_LAST_UPDT_S
	     ,@CDSID                                                           as ARWE02_LAST_UPDT_USER_C
	     ,ARWS67_VA_IMPROVEMENT_IDEA_K                                     as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'                            as ARWE02_STAGING_TABLE_X
	     ,'ERROR'                                                          as ARWE02_ERROR_TYPE_X
	     ,'Improvement Ideas'                                              as ARWE02_EXCEL_TAB_X
	     ,ERR.row_idx                                                          as ARWE02_ROW_IDX
	     ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>') as ARWE02_Part_Index
	     ,''                                                               as ARWE02_ARROW_Value
  FROM 
       (--find part_index that has more than one unique name
	    Select *
	          ,Count(*) over (partition by filename, part_index) cnt  
	      from  
               (--get unique part_index and part_name
                SELECT Source_c,
                       Processing_ID,
		                 part_index,
					        improvement_id,
		         	     part_name,
		                 Processing_Status_x,
		                 filename,
                       ARWS67_VA_IMPROVEMENT_IDEA_K,
		                 row_idx,
		         	     ROW_NUMBER() over (partition by filename, part_index, part_name Order by row_idx) rownum
                  FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO   S67
                 WHERE S67.Processing_ID    = @GUID
	                and Not Exists
		                (Select 'X'
		         	       from PARWU18_BOM_PART U18
                        where U18.ARWU18_BOM_PART_IX_N = S67.part_index
                      )                    
               ) uniq
         Where rownum = 1
	   ) ERR
 Where cnt > 1

END TRY
BEGIN CATCH
   INSERT INTO [dbo].PARWE02_BATCH_ERRORS
   SELECT  
           'SYSTEM'                          --source_c
          ,'Catch Error'                     --error_value
          ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
          ,@GUID                             --Processing_id
          ,'UNKNOWN'                         --Filename
          ,ERROR_PROCEDURE()                 --Procedure_x
          ,@TIME_STAMP 
          ,@CDSID
          ,@TIME_STAMP
          ,@CDSID
			 ,''
			 ,'PARWS67_VAII_IMPROVEMENT_IDEAS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		    ,''  --Part_index
		    ,''  --Arrow value	
END CATCH;


GO
