SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =============================================
-- Author:		ashaik12
-- Create date: 07/06/2022
-- Description:	checks for duplicate change IDs on Improvement ideas
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------

-- =============================================
CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VAII_VALIDT_IMPROVEMENT_ID] 
-- Input Parameter
 @Processing_ID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP DATETIME

AS
BEGIN TRY
	SET NOCOUNT ON;


-- Improvement Ideas
	INSERT INTO PARWE02_BATCH_ERRORS
    Select 
		 STAGING.Source_c
		,STAGING.[improvement_id]
		,'Duplicate Improvement ID found in file' 
		,@Processing_ID
		,filename
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP 
		,@CDSID
		,STAGING.[ARWS67_VA_IMPROVEMENT_IDEA_K] as ARWE02_BATCH_ERRORS_REF_K
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'    as ARWE02_STAGING_TABLE_X
		,'WARNING'
        ,'Improvement Ideas'
	    ,row_idx                                  as ARWE02_ROW_IDX
		,improvement_id
		,''  --No ARROW Value
    FROM
    (	
	  SELECT
             S67.Source_c, S67.improvement_id, S67.filename, S67.[ARWS67_VA_IMPROVEMENT_IDEA_K], S67.row_idx
	        ,COUNT([improvement_id]) OVER (PARTITION BY S67.filename, S67.processing_ID, S67.[improvement_id]) imprv_id_count
            ,ROW_NUMBER() OVER (PARTITION BY S67.filename, S67.processing_ID, S67.[improvement_id]  ORDER BY S67.[improvement_id]) AS rownum
	    FROM [dbo].[PARWS67_VA_IMPROVEMENT_IDEAS_INFO] s67
	    JOIN [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
	      ON s45.Processing_ID       = S67.Processing_ID
         AND s45.filename            = S67.filename
	   Where S67.Processing_ID       = @Processing_ID
	    
	) STAGING
	Where imprv_id_count > 1 
	and rownum > 1

DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
-------------Change_id-------------------
-- Line Feed validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(improvement_id,char(10),'<LF>')      as [ARWE02_ERROR_VALUE],  --replace line feed with <LF>
	       'An improvement id can''t have an imbedded line feed <LF>'       as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       filename                                     as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       [ARWS67_VA_IMPROVEMENT_IDEA_K]               as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'        as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       'Improvement Ideas'                          as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   replace(improvement_id,char(10),'<LF>'),
		   ''  --No ARROW Value
      FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO
     WHERE Processing_ID                        = @Processing_ID
	   and NullIf(PATINDEX(@pat10,improvement_id),0) > 0  --Looking for Line Feed 
    ;

DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
-- Carriage Return validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                 as [ARWE02_SOURCE_C],
	       replace(improvement_id,char(13),'<CR>')  as [ARWE02_ERROR_VALUE],  --replace carriage return with <CR>
	       'An improvement id can''t have an imbedded carriage return <CR>' as [ARWE02_ERROR_X],
	       Processing_ID                            as [ARWE02_PROCESSING_ID],
	       filename                                 as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                    as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                              as [ARWE02_CREATE_S],
           @CDSID                                   as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                              as [ARWE02_LAST_UPDT_S],
	       @CDSID                                   as [ARWE02_LAST_UPDT_USER_C],
	       [ARWS67_VA_IMPROVEMENT_IDEA_K]           as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'    as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                  as [ARWE02_ERROR_TYPE_X],
	       'Improvement Ideas'                      as [ARWE02_EXCEL_TAB_X],
	       row_idx                                  as [ARWE02_ROW_IDX],
		   replace(improvement_id,char(13),'<CR>'),
		   ''  --No ARROW Value
      FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO
     WHERE Processing_ID                        = @Processing_ID
       and NullIf(PATINDEX(@pat13,improvement_id),0) > 0  --Looking for carriage 
    ;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO' 
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
        ,'SYSTEM'
		,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
;
END CATCH;	






GO
