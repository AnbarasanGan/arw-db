DROP PROCEDURE IF EXISTS [dbo].[PARWP_UI_LOWEST_IDC_DESIGN]
GO
/****** Object:  StoredProcedure [dbo].[PARWP_UI_LOWEST_IDC_DESIGN]    Script Date: 12/2/2021 2:11:15 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =================================================================================================================================================
-- Author:		svallur5
-- Create date: 2021-12-13
-- Description:	
-- =================================================================================================================================================
-- Changes
-- =================================================================================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- 
-- =================================================================================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_LOWEST_IDC_DESIGN] 
-- Parameters for the stored procedure
@ARWU01_CCTSS_K        int
AS
SET NOCOUNT ON;


SELECT * FROM PARWD06_LOWEST_IDC_DESIGN
WHERE ARWU01_CCTSS_K = @ARWU01_CCTSS_K;






GO
