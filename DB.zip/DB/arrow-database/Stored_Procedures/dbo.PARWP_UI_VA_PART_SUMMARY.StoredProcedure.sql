SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		rwesley2
-- Create date: 12/03/2021
-- Description:	Procedure to read the d03 va part summary dump
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- 07/21/2022 ASHAIK12 US3844013   Add columns related to VII
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_UI_VA_PART_SUMMARY]
@ARWU01_CCTSS_K      int,
@ARWU04_CCTSS_VRNT_K int,
@ARWU06_CCTSS_DSGN_K   INT -- not used.  added to satisfy UI calling requirements
AS
SET NOCOUNT ON;

--Declare @Start_Time DATETIME = GETUTCDATE();

Begin

SELECT ROW_KEY
      ,D03.ARWU01_CCTSS_K
      ,D03.ARWU04_CCTSS_VRNT_K
      ,D03.ARWU09_CCTSS_VRNT_SUPL_K
	  ,CONCAT(COALESCE(U13.ARWU13_CCTSS_SUPL_DSPLY_N, A17.ARWA17_SUPL_N), ' (' , A28.ARWA28_ISO3_CNTRY_C, ')') AS ARWA17_SUPL_N
      ,D03.ARWU17_BOM_SUB_ASSY_K
      ,D03.ARWU18_BOM_PART_K
	  ,U17.ARWU17_BOM_SUB_ASSY_N
      ,D03.ARWU18_BOM_PART_IX_N
	  ,U18.ARWU18_BOM_PART_X
      ,D03.CAII_CHRYPKD
      ,D03.GROUP_INDEX
      ,D03.CLUSTER_APPLICABLE_FLAG
      ,D03.II_MANUAL_SEL_KEY
      ,D03.II_MANUAL_SEL_COMMENT
      ,D03.II_MANUAL_SEL_TYPE
      ,D03.VA_MANUAL_SEL_KEY
      ,D03.VA_MANUAL_SEL_COMMENT
      ,D03.VA_PUR
      ,D03.VA_RAW
      ,D03.VA_PRO
      ,D03.TOTAL_W_SUP_MRKUP
      ,D03.TOTAL_W_ADJ_MRKUP
      ,D03.ADJ_VA
      ,D03.ASM_DISPLAY_SEQ
      ,D03.PART_TXT_SORT
      ,D03.PART_NUM1_SORT
      ,D03.PART_NUM2_SORT
      ,D03.MIN_VA_AMT
      ,D03.VA_MIN_SUP_KEY
      ,D03.VA_DELTA
      ,D03.QTE_DVNT_STATUS_KEY
      ,D03.QTE_DVNT_STATUS
      ,D03.QTE_DVNT_CMT
      ,D03.DA_DVNT_STATUS_KEY
      ,D03.DA_DVNT_STATUS
      ,D03.DA_DVNT_CMT
      ,D03.II_DVNT_STATUS_KEY
      ,D03.II_DVNT_STATUS
      ,D03.II_DVNT_CMT
      ,D03.VA_DVNT_STATUS_KEY
      ,D03.VA_DVNT_STATUS
      ,D03.VA_DVNT_CMT
      ,D03.CHNG_TYPE
      ,D03.ARWD03_CREATE_S
      ,D03.ARWD03_CREATE_USER_C 
      ,CAVA_AUTO
      ,CAVA_CHRYPKD
      ,VII_PUR
      ,VII_RAW
      ,VII_PRO
      ,VII_TOT_W_SUP_MRKP
      ,VII_TOT_W_ADJ_MRKP
      ,MIN_VII_AMT
      ,ADJ_VII
      ,CAVII_AUTO
      ,CAVII_CHRYPKD
      ,VII_MIN_SUP_KEY
      ,VII_MANUAL_SEL_KEY
      ,VII_MANUAL_SEL_COMMENT
      ,VII_DELTA
      ,VII_DVNT_STATUS_KEY
      ,VII_DVNT_STATUS
      ,VII_DVNT_CMT
  FROM PARWD03_VA_PART_SUMM          D03
  JOIN PARWU17_BOM_SUB_ASSY          U17  ON U17.ARWU17_BOM_SUB_ASSY_K    = D03.ARWU17_BOM_SUB_ASSY_K
  JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT  U09  ON U09.ARWU09_CCTSS_VRNT_SUPL_K = D03.ARWU09_CCTSS_VRNT_SUPL_K
  JOIN PARWA17_SUPL                  A17  ON A17.ARWA17_SUPL_K            = U09.ARWA17_SUPL_K
  JOIN PARWA28_CNTRY                 A28  ON A17.ARWA28_CNTRY_K           = A28.ARWA28_CNTRY_K
  JOIN PARWU18_BOM_PART              U18  ON U18.ARWU18_BOM_PART_K        = D03.ARWU18_BOM_PART_K
  LEFT 
  JOIN PARWU13_CCTSS_SUPL_DSPLY      U13  ON U13.ARWU07_CCTSS_SUPL_K      = U09.ARWU07_CCTSS_SUPL_K
 WHERE D03.ARWU01_CCTSS_K      = @ARWU01_CCTSS_K 
   and D03.ARWU04_CCTSS_VRNT_K = @ARWU04_CCTSS_VRNT_K
 ORDER BY ASM_DISPLAY_SEQ, PART_TXT_SORT, PART_NUM1_SORT, PART_NUM2_SORT, ARWU18_BOM_PART_IX_N
;

--    Select OBJECT_NAME(@@PROCID) as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;		




GO
