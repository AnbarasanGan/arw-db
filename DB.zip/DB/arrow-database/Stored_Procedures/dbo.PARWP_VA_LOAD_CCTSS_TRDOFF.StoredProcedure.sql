DROP PROCEDURE [dbo].[PARWP_VA_LOAD_CCTSS_TRDOFF]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		ashaik12
-- Create date: 12/04/2019
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 12/23/2019  ASHAIK12           Remove PROCESSING Filter
-- 01/03/2020  ASHAIK12           Refactored the Joins to get U04 key when joining on U65.
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_VA_LOAD_CCTSS_TRDOFF] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--**********************************
-- Insert into U85 when VAW file is imported
--********************************** 

INSERT INTO [PARWU85_CCTSS_TRDOFF]
select ARWU01_CCTSS_K
	  ,0                               AS [ARWU85_BNCHMK_F]  -- Defaulting to 0 for VA load. 
      ,CASE WHEN [ARWU85_CCTSS_TRDOFF_X]='' THEN 'UNASSIGNED' ELSE [ARWU85_CCTSS_TRDOFF_X] END AS [ARWU85_CCTSS_TRDOFF_X]
	  ,''                              AS [ARWU85_CCTSS_TRDOFF_RTNLE_X]
	  ,''                              AS [ARWU85_CCTSS_TRDOFF_DATA_SRC_X]
	  ,1                               AS [ARWU85_CCTSS_TRDOFF_INCLD_F]
	  ,[ARWA31_CONFID_LVL_K]           AS [ARWA31_CONFID_LVL_K]
	  ,0                               AS [ARWU85_TRDOFF_AGRMT_BFR_MP_F]
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]   AS [ARWA43_TRDOFF_AGRMT_FORUM_K]
	  ,@TIME_STAMP                    AS [ARWU85_CREATE_S]
      ,@CDSID                          AS [ARWU85_CREATE_USER_C]
      ,@TIME_STAMP                    AS [ARWU85_LAST_UPDT_S]
      ,@CDSID                          AS [ARWU85_LAST_UPDT_USER_C]
from 
(
SELECT  
       u09_view.ARWU01_CCTSS_K         AS [ARWU01_CCTSS_K]
      ,S46.tough_choice_grouping       AS [ARWU85_CCTSS_TRDOFF_X]
	  ,''                              AS [ARWU85_CCTSS_TRDOFF_RTNLE_X]
	  ,''                              AS [ARWU85_CCTSS_TRDOFF_DATA_SRC_X]
	  ,1                               AS [ARWU85_CCTSS_TRDOFF_INCLD_F]
	  ,A31.ARWA31_CONFID_LVL_K         AS [ARWA31_CONFID_LVL_K]
	  ,0                               AS [ARWU85_TRDOFF_AGRMT_BFR_MP_F]
	  ,A43.ARWA43_TRDOFF_AGRMT_FORUM_K AS [ARWA43_TRDOFF_AGRMT_FORUM_K]
      ,@TIME_STAMP                    AS [ARWU85_CREATE_S]
      ,@CDSID                          AS [ARWU85_CREATE_USER_C]
      ,@TIME_STAMP                    AS [ARWU85_LAST_UPDT_S]
      ,@CDSID                          AS [ARWU85_LAST_UPDT_USER_C]
  FROM [dbo].PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
  JOIN PARWS45_VA_COVER_PAGE_INFO           S45
    ON S45.Processing_ID       = S46.Processing_ID
   AND S45.filename            = S46.filename

 -- Join with U09_Flat
  join [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view       
	     on S45.[User_Selected_CTSP_N]            = u09_view.ARWU31_CTSP_N
		and S45.[User_Selected_CTSP_Region_C]     = u09_view.[ARWA06_RGN_C]
        and S45.[User_selected_WALK_VRNT_X]       = u09_view.[ARWU04_VRNT_N]
		and S45.[User_Selected_ENRG_SUB_CMMDTY_X] = u09_view.ARWA03_ENRG_SUB_CMMDTY_X
		and S45.[User_Selected_BNCMK_VRNT_N]      = u09_view.ARWU01_BNCHMK_VRNT_N
		and s45.[User_Selected_SUPL_N]            = u09_view.[ARWA17_SUPL_N]
		and s45.[User_Selected_SUPL_CNTRY_N]      = u09_view.[ARWA28_CNTRY_N] 
		and s45.[User_Selected_SUPL_C]            = u09_view.[ARWA17_SUPL_C]
    

   JOIN PARWA31_CONFID_LVL A31
   ON A31.ARWA31_CONFID_LVL_X ='High'
   JOIN PARWA43_TRDOFF_AGRMT_FORUM A43
   ON A43.ARWA43_TRDOFF_AGRMT_FORUM_N='To be determined'
    
  Where S45.Processing_ID               = @GUIDIN 
    And S45.Skip_loading_due_to_error_f = 0
    And not exists --Can't add a tough group if it already exists
       (Select 'X'
          From PARWU85_CCTSS_TRDOFF U85_Check
	     Where U85_Check.ARWU01_CCTSS_K = u09_view.ARWU01_CCTSS_K
		   AND U85_Check.ARWU85_BNCHMK_F=0
		   And U85_Check.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S46.tough_choice_grouping='' THEN 'UNASSIGNED' ELSE S46.tough_choice_grouping END    
       )
) X
Group by --Get distinct data to write into the table
       ARWU01_CCTSS_K          
	  ,ARWU85_CCTSS_TRDOFF_X
	  ,ARWA31_CONFID_LVL_K
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]


-- Load U91

INSERT INTO [dbo].[PARWU91_VRNT_ADJ_TRDOFF]
SELECT U65.ARWU65_CCTSS_VRNT_ADJ_K     AS ARWU65_CCTSS_VRNT_ADJ_K
      ,U85.ARWU85_CCTSS_TRDOFF_K       AS ARWU85_CCTSS_TRDOFF_K
	  ,@TIME_STAMP                    AS ARWU86_CREATE_S
      ,@CDSID                          AS ARWU86_CREATE_USER_C
      ,@TIME_STAMP                    AS ARWU86_LAST_UPDT_S
      ,@CDSID                          AS ARWU86_LAST_UPDT_USER_C
FROM [dbo].PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
  JOIN PARWS45_VA_COVER_PAGE_INFO           S45
    ON S45.Processing_ID       = S46.Processing_ID
   AND S45.filename            = S46.filename

 -- Join with U09_Flat
  join [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view       
	     on S45.[User_Selected_CTSP_N]            = u09_view.ARWU31_CTSP_N
		and S45.[User_Selected_CTSP_Region_C]     = u09_view.[ARWA06_RGN_C]
        and S45.[User_selected_WALK_VRNT_X]       = u09_view.[ARWU04_VRNT_N]
		and S45.[User_Selected_ENRG_SUB_CMMDTY_X] = u09_view.ARWA03_ENRG_SUB_CMMDTY_X
		and S45.[User_Selected_BNCMK_VRNT_N]      = u09_view.ARWU01_BNCHMK_VRNT_N
		and s45.[User_Selected_SUPL_N]            = u09_view.[ARWA17_SUPL_N]
		and s45.[User_Selected_SUPL_CNTRY_N]      = u09_view.[ARWA28_CNTRY_N] 
		and s45.[User_Selected_SUPL_C]            = u09_view.[ARWA17_SUPL_C]

   JOIN PARWU65_CCTSS_VRNT_ADJ U65
   ON U65.ARWU04_CCTSS_VRNT_K = u09_view.ARWU04_CCTSS_VRNT_K
   AND U65.ARWU65_CCTSS_VRNT_ADJ_ID_N = S46.change_id

   JOIN PARWU85_CCTSS_TRDOFF U85
   ON  U85.ARWU01_CCTSS_K = u09_view.ARWU01_CCTSS_K
   AND U85.ARWU85_BNCHMK_F=0 
   AND U85.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S46.tough_choice_grouping='' THEN 'UNASSIGNED' ELSE S46.tough_choice_grouping END


    Where S45.Processing_ID               = @GUIDIN 
    And   S45.Skip_loading_due_to_error_f = 0
    AND not exists --Can't add if it already exists
       (
	     Select 'X'
          From [PARWU91_VRNT_ADJ_TRDOFF] U91_check
	     Where U91_check.ARWU65_CCTSS_VRNT_ADJ_K = U65.ARWU65_CCTSS_VRNT_ADJ_K
       )
	GROUP BY U65.ARWU65_CCTSS_VRNT_ADJ_K,U85.ARWU85_CCTSS_TRDOFF_K

;


GO
