DROP PROCEDURE [dbo].[PARWP_DAII_DATA_SCRUBBING]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ashaik12
-- Create date: 10/25/2019
-- Description:	DAII Post data load scrubbing to check if the part was quoted but missing in U73 for DA and U74 for II
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   11/12/2019   Change error description
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DAII_DATA_SCRUBBING] 

@GUID varchar(5000) ,
@CDSID varchar(30)

AS

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



  INSERT INTO [dbo].[PARWE01_BATCH_ERRORS]
  select * From
		(
		select 
		S35.Source_c as ARWE01_SOURCE_C
		,S35.change_id as ARWE01_ERROR_VALUE
		,'The Quoted Flag is Yes but the part is not quoted in ARROW' AS ARWE01_ERROR_X
		,S35.Processing_ID AS ARWE01_PROCESSING_ID
		,S35.filename AS ARWE01_FILENAME
		,object_name(@@PROCID) AS ARWE01_PROCEDURE_X
		,GETUTCDATE() AS ARWE01_CREATE_S
 		,@CDSID AS ARWE01_CREATE_USER_C
		,GETUTCDATE()  AS ARWE01_LAST_UPDT_S
		,@CDSID AS ARWE01_LAST_UPDT_USER_C
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K AS ARWE01_BATCH_ERRORS_REF_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO' AS ARWE01_STAGING_TABLE_X
		,'ERROR' AS ARWE01_ERROR_TYPE_X
		,'Adjustment Details' as ARWE01_EXCEL_TAB_X
		,S35.row_idx AS ARWE01_ROW_IDX
		from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
		JOIN PARWS34_DAII_COVER_PAGE_INFO S34
		ON S35.filename=S34.filename
		AND S34.Processing_ID=S35.Processing_ID
		JOIN dbo.PARWV04_DSGN_SUPL V04
         ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
        AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
        AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
        AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
        AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
        AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
        AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
        AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
        AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
        AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
        AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C
		JOIN PARWU37_CCTSS_DSGN_ADJ U37
		ON U37.ARWU37_CCTSS_DSGN_ADJ_ID_N = S35.change_id
		AND U37.ARWU06_CCTSS_DSGN_K = V04.ARWU06_CCTSS_DSGN_K
        where S35.Processing_ID=@GUID
		and S34.Skip_loading_due_to_error_f=0
		and S35.quoted='YES'
		and NOT EXISTS
		(
		select 'X' FROM PARWU73_SUPL_DSGN_ADJ U73
		where U73.ARWU37_CCTSS_DSGN_ADJ_K=U37.ARWU37_CCTSS_DSGN_ADJ_K
		AND U73.ARWU08_CCTSS_DSGN_SUPL_K = V04.ARWU08_CCTSS_DSGN_SUPL_K
		)
	) X
	;



	  INSERT INTO [dbo].[PARWE01_BATCH_ERRORS]
      select * From
		(
		select 
		 S44.Source_c as ARWE01_SOURCE_C
		,S44.improvement_id as ARWE01_ERROR_VALUE
		,'The Quoted Flag is Yes but the part is not quoted in ARROW' AS ARWE01_ERROR_X
		,S44.Processing_ID AS ARWE01_PROCESSING_ID
		,S44.filename AS ARWE01_FILENAME
		,object_name(@@PROCID) AS ARWE01_PROCEDURE_X
		,GETUTCDATE() AS ARWE01_CREATE_S
 		,@CDSID AS ARWE01_CREATE_USER_C
		,GETUTCDATE()  AS ARWE01_LAST_UPDT_S
		,@CDSID AS ARWE01_LAST_UPDT_USER_C
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K AS ARWE01_BATCH_ERRORS_REF_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' AS ARWE01_STAGING_TABLE_X
		,'WARNING' AS ARWE01_ERROR_TYPE_X
		,'Improvement Ideas' as ARWE01_EXCEL_TAB_X
		,S44.row_idx AS ARWE01_ROW_IDX
		from PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
		JOIN PARWS34_DAII_COVER_PAGE_INFO S34
		ON S44.filename=S34.filename
		AND S34.Processing_ID=S44.Processing_ID
		JOIN dbo.PARWV04_DSGN_SUPL V04
         ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
        AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
        AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
        AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
        AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
        AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
        AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
        AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
        AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
        AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
        AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C
		JOIN PARWU46_CCTSS_DSGN_IMPRV U46
		ON U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = S44.improvement_id
		AND U46.ARWU06_CCTSS_DSGN_K = V04.ARWU06_CCTSS_DSGN_K
        where S44.Processing_ID=@GUID
		and S34.Skip_loading_due_to_error_f=0
		and S44.quoted='YES'
		and NOT EXISTS
		(
		select 'X' FROM PARWU74_SUPL_DSGN_IMPRV U74
		where U74.ARWU46_CCTSS_DSGN_IMPRV_K=U46.ARWU46_CCTSS_DSGN_IMPRV_K
		AND U74.ARWU08_CCTSS_DSGN_SUPL_K = V04.ARWU08_CCTSS_DSGN_SUPL_K
		)
	) X
	;






GO
