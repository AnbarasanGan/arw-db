/****** Object:  StoredProcedure [dbo].[PARWP_UI_VA_SURGICAL]    Script Date: 7/5/2022 8:50:35 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO











-- ================================================================================================
-- Author:		kvijayab
-- Create date: 2020-Feb-24
-- Description:	
--		Add/Modify/Delete Variant Adjustments. 
--		Deletes the cost if applicable.
--		Obsoletes the manual overrides if applicable.
--		Called from the UI.
-- ================================================================================================
-- Changes
-- ================================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- kvijayab   Mar-9-2020  changed the override logic based on the surgery grid
-- ashaik12   04/03/2020  Added delete to the deviation status related table
-- kvijayab   May-18-2020  US1623968: Added the tradeoff surgery logic
-- kvijaayb	  Aug-11-2020  US1831307: Added logic to create/delete Directed Parts subassembly
-- ASHAIK12   JUN-08-2021  US2562033: Added insert for U63 for Scope and Current. Added Delete from U63 in @MODE='D'
-- ASHAIK12   JUL-15-2021  US2710839: Handle deletion of sub assembly through manage adjustments when the sub assembly has no more parts left.
-- Asolosky   OCT-08-2021  US2943318: Add new sub assemblies.  Remove hard coding for DP and allow the UI to pass in any sub-assembly.
-- kvijayab   Jan-07-2022  US3189710: Removed Transaction.
-- kvijayab   Apr-28-2022  US3555249: Added CIA ID
-- Ashaik12   Jun-23-2022  US3761285: Handle Varaint Improvement Ideas tables in Modify and Delete sections.
-- kvijayab   Jun-27-2022  US3674687: check if sub asm/part index is already created. If it is then use it.
-- ================================================================================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_UI_VA_SURGICAL] 
-- Input Parameters
@CCTSS_K INT,
@CCTSS_VRNT_K INT,
@MODE Varchar(1),
@BOM_PART_K INT,

@BOM_PART_IX_N VARCHAR(64), -- used to add part if it is not available
@BOM_SUB_ASSY_K INT,
@BOM_PART_X VARCHAR(256),
@A47_SCOPE_END_ITEM_K INT, -- A47 key for added Scope EI
@A47_CURRENT_END_ITEM_K INT, -- A47 key for added Current EI
@CCTSS_VRNT_ADJ_K INT,
@CCTSS_VRNT_ADJ_ID_N VARCHAR(64),
@DSGN_ADJ_PART_CHG_TYP_K INT,
@FORD_VRNT_DSGN_ATTR_X VARCHAR(2048),
@FORD_INTD_DSGN_ATTR_X VARCHAR(2048),
@SPEC_SDS_NUM_X VARCHAR(1024),
@CCTSS_VRNT_ADJ_CMT_X VARCHAR(1024),
@CIA_ID_NUM_X VARCHAR(16),
@CCTSS_TRDOFF_K INT,
@USER_CDSID VARCHAR(8),
@ARWU17_BOM_SUB_ASSY_IX_C VARCHAR(MAX),
@ARWU17_BOM_SUB_ASSY_N    VARCHAR(MAX),
-- output param
@RESULT VARCHAR(MAX) OUTPUT

AS

SET NOCOUNT ON;

BEGIN TRY
--  BEGIN TRANSACTION;

	DECLARE @CCTSS_VRNT_ADJ_GRP_K INT;
	DECLARE @VRNT_NAME VARCHAR (500);
	DECLARE @CHANGE_NAME VARCHAR (500);
	DECLARE @COMMENT VARCHAR (1500);

	-- return variant adj key. good for modify and delete.
	SET @RESULT = @CCTSS_VRNT_ADJ_K;

	SELECT @VRNT_NAME = IIF(ARWU04_VRNT_N = '', 'BLANK VARIANT', ARWU04_VRNT_N) FROM PARWU04_CCTSS_VRNT WHERE ARWU04_CCTSS_VRNT_K = @CCTSS_VRNT_K;

	-- check if sub asm is already created. If it is then use it starts.
	DECLARE @TEMP_BOM_SUB_ASSY_K INT = 0;
	SELECT @TEMP_BOM_SUB_ASSY_K = ARWU17_BOM_SUB_ASSY_K
	FROM PARWU17_BOM_SUB_ASSY WHERE ARWU01_CCTSS_K = @CCTSS_K AND ARWU17_BOM_SUB_ASSY_N = @ARWU17_BOM_SUB_ASSY_N;
	IF @MODE = 'A' AND @BOM_SUB_ASSY_K = -1 AND @TEMP_BOM_SUB_ASSY_K <> 0
	BEGIN  
		SET @BOM_SUB_ASSY_K = @TEMP_BOM_SUB_ASSY_K;
	END;
	-- check if sub asm is already created. If it is then use it ends.

	-- check if bom part is already created. If it is then use it starts.
	DECLARE @TEMP_BOM_PART_K INT = 0;
	SELECT @TEMP_BOM_PART_K = ARWU18_BOM_PART_K 
	FROM PARWU18_BOM_PART WHERE ARWU01_CCTSS_K = @CCTSS_K AND ARWU18_BOM_PART_IX_N = @BOM_PART_IX_N AND ARWU17_BOM_SUB_ASSY_K = @BOM_SUB_ASSY_K;
	IF @MODE = 'A' AND @BOM_PART_K = 0 AND @TEMP_BOM_PART_K <> 0
	BEGIN  
		SET @BOM_PART_K = @TEMP_BOM_PART_K;
	END;
	-- check if bom part is already created. If it is then use it ends.

	-- If a new adjustment is added
	IF @MODE = 'A'
	BEGIN  
		IF @BOM_PART_K = 0
		BEGIN
			-- if Directed Parts was not there before but now user wants to create it
			IF @BOM_SUB_ASSY_K = -1
			BEGIN
				-- Create New Sub Assembly from Design Manage Adjustments
				INSERT INTO PARWU17_BOM_SUB_ASSY
				  (
					ARWU01_CCTSS_K
				   ,ARWU17_BOM_SUB_ASSY_SEQ_R
				   ,ARWU17_BOM_SUB_ASSY_N 
				   ,ARWU17_CREATE_S, ARWU17_CREATE_USER_C, ARWU17_LAST_UPDT_S, ARWU17_LAST_UPDT_USER_C
				   ,ARWU17_BOM_SUB_ASSY_IX_C
				  ) 
				  VALUES (
					 @CCTSS_K
					,dbo.PARWF_ASSIGN_ARWU17_SEQ_R(@ARWU17_BOM_SUB_ASSY_IX_C)
					,@ARWU17_BOM_SUB_ASSY_N
					,GETUTCDATE(), @USER_CDSID, GETUTCDATE(), @USER_CDSID
					,@ARWU17_BOM_SUB_ASSY_IX_C
				);
				-- Get the Sub Assembly Key for the newly inserted Sub Assembly
				SELECT @BOM_SUB_ASSY_K = ARWU17_BOM_SUB_ASSY_K 
				  FROM PARWU17_BOM_SUB_ASSY
				 WHERE ARWU01_CCTSS_K = @CCTSS_K 
				   AND ARWU17_BOM_SUB_ASSY_N = @ARWU17_BOM_SUB_ASSY_N;
			END;
			DECLARE @BOM_PART_DSPLY_SEQ_R INT = 1;
			SELECT TOP 1 @BOM_PART_DSPLY_SEQ_R = (ARWU18_BOM_PART_DSPLY_SEQ_R + 1) FROM PARWU18_BOM_PART WHERE ARWU01_CCTSS_K = @CCTSS_K ORDER BY ARWU18_BOM_PART_DSPLY_SEQ_R DESC;
			INSERT INTO [dbo].[PARWU18_BOM_PART] (
				ARWU01_CCTSS_K, ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_DSPLY_SEQ_R, ARWU18_BOM_PART_X, 
				ARWU18_CREATE_S, ARWU18_CREATE_USER_C, ARWU18_LAST_UPDT_S, ARWU18_LAST_UPDT_USER_C
			) VALUES (
				@CCTSS_K, @BOM_PART_IX_N, @BOM_SUB_ASSY_K, @BOM_PART_DSPLY_SEQ_R, @BOM_PART_X, 
				GETUTCDATE(), @USER_CDSID, GETUTCDATE(), @USER_CDSID
			);
			SELECT @BOM_PART_K = ARWU18_BOM_PART_K FROM PARWU18_BOM_PART WHERE ARWU01_CCTSS_K = @CCTSS_K AND ARWU18_BOM_PART_IX_N = @BOM_PART_IX_N AND ARWU17_BOM_SUB_ASSY_K = @BOM_SUB_ASSY_K;
		END;
-- *******************************
		-- INSERT INTO U63 for Scope
		IF @A47_SCOPE_END_ITEM_K !=0
		BEGIN
	--	DECLARE @U04_S_K INT;
		DECLARE @A57_S_K INT;		
		
	--	SET @U04_S_K = (SELECT DISTINCT [ARWU04_CCTSS_VRNT_K] FROM PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K=(select ARWU01_CCTSS_K FROM PARWU18_BOM_PART where ARWU18_BOM_PART_K=@BOM_PART_K) and ARWU04_BNCHMK_F=1)
		SET @A57_S_K = (Select [ARWA57_END_ITM_MAP_TYPE_K] from PARWA57_END_ITM_MAP_TYPE where ARWA57_END_ITM_MAP_TYPE_X='Scope')
		
		INSERT INTO [dbo].[PARWU63_VRNT_BOM_PART_END_ITM]
		SELECT 
		@CCTSS_VRNT_K                 AS [ARWU04_CCTSS_VRNT_K]
		,@BOM_PART_K           AS [ARWU18_BOM_PART_K]
		,@A57_S_K                AS [ARWA57_END_ITM_MAP_TYPE_K]
		,@A47_SCOPE_END_ITEM_K AS [ARWA47_FORD_END_ITM_K]
		,GETUTCDATE()          AS [ARWU63_CREATE_S]
		,@USER_CDSID           AS [ARWU63_CREATE_USER_C]
		,GETUTCDATE()          AS [ARWU63_LAST_UPDT_S]
		,@USER_CDSID           AS  [ARWU63_LAST_UPDT_USER_C]
		END
		-- INSERT INTO U63 for Current
		IF @A47_CURRENT_END_ITEM_K !=0
		BEGIN
	--	DECLARE @U04_C_K INT;
		DECLARE @A57_C_K INT;		
		
	--	SET @U04_C_K = (SELECT DISTINCT [ARWU04_CCTSS_VRNT_K] FROM PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K=(select ARWU01_CCTSS_K FROM PARWU18_BOM_PART where ARWU18_BOM_PART_K=@BOM_PART_K) and ARWU04_BNCHMK_F=1)
		SET @A57_C_K = (Select [ARWA57_END_ITM_MAP_TYPE_K] from PARWA57_END_ITM_MAP_TYPE where ARWA57_END_ITM_MAP_TYPE_X='Current')
		
		INSERT INTO [dbo].[PARWU63_VRNT_BOM_PART_END_ITM]
		SELECT 
		@CCTSS_VRNT_K                 AS [ARWU04_CCTSS_VRNT_K]
		,@BOM_PART_K           AS [ARWU18_BOM_PART_K]
		,@A57_C_K                AS [ARWA57_END_ITM_MAP_TYPE_K]
		,@A47_CURRENT_END_ITEM_K AS [ARWA47_FORD_END_ITM_K]
		,GETUTCDATE()          AS [ARWU63_CREATE_S]
		,@USER_CDSID           AS [ARWU63_CREATE_USER_C]
		,GETUTCDATE()          AS [ARWU63_LAST_UPDT_S]
		,@USER_CDSID           AS  [ARWU63_LAST_UPDT_USER_C]
		END
-- *******************************
		-- get the min group id key
		SELECT @CCTSS_VRNT_ADJ_GRP_K = MIN(ARWU64_CCTSS_VRNT_ADJ_GRP_K) FROM [PARWU64_CCTSS_VRNT_ADJ_GRP];

		-- insert the new adjustment
		INSERT INTO [dbo].[PARWU65_CCTSS_VRNT_ADJ] (
			ARWU04_CCTSS_VRNT_K, ARWU65_CCTSS_VRNT_ADJ_ID_N, ARWU64_CCTSS_VRNT_ADJ_GRP_K, ARWU18_BOM_PART_K, ARWA40_DSGN_ADJ_PART_CHG_TYP_K, 
			ARWU65_FORD_INTD_DSGN_ATTR_X, ARWU65_FORD_VRNT_DSGN_ATTR_X, ARWA19_LVL2_ADJ_CATG_K, ARWU65_SPEC_SDS_NUM_X, ARWU65_CCTSS_VRNT_ADJ_CMT_X, ARWU65_CIA_ID_NUM_X, 
			ARWU65_CREATE_S, ARWU65_CREATE_USER_C, ARWU65_LAST_UPDT_S, ARWU65_LAST_UPDT_USER_C
		) VALUES (
			@CCTSS_VRNT_K, @CCTSS_VRNT_ADJ_ID_N, @CCTSS_VRNT_ADJ_GRP_K, @BOM_PART_K, @DSGN_ADJ_PART_CHG_TYP_K, 
			@FORD_INTD_DSGN_ATTR_X, @FORD_VRNT_DSGN_ATTR_X, 1, @SPEC_SDS_NUM_X, @CCTSS_VRNT_ADJ_CMT_X, @CIA_ID_NUM_X, 
			GETUTCDATE(), @USER_CDSID, GETUTCDATE(), @USER_CDSID
		);

		-- insert the tradeoff
		INSERT INTO [dbo].[PARWU91_VRNT_ADJ_TRDOFF]
		SELECT ARWU65_CCTSS_VRNT_ADJ_K, @CCTSS_TRDOFF_K AS ARWU85_CCTSS_TRDOFF_K, 
		GETUTCDATE() AS ARWU91_CREATE_S, @USER_CDSID AS ARWU91_CREATE_USER_C, GETUTCDATE() AS ARWU91_LAST_UPDT_S, @USER_CDSID AS ARWU91_LAST_UPDT_USER_C
		FROM [PARWU65_CCTSS_VRNT_ADJ] WHERE ARWU04_CCTSS_VRNT_K = @CCTSS_VRNT_K AND ARWU65_CCTSS_VRNT_ADJ_ID_N = @CCTSS_VRNT_ADJ_ID_N;

		-- set the result to latest variant adj key
		SELECT TOP 1 @RESULT = ARWU65_CCTSS_VRNT_ADJ_K FROM PARWU65_CCTSS_VRNT_ADJ 
		WHERE ARWU04_CCTSS_VRNT_K = @CCTSS_VRNT_K AND ARWU65_CCTSS_VRNT_ADJ_ID_N = @CCTSS_VRNT_ADJ_ID_N AND ARWU18_BOM_PART_K = @BOM_PART_K;

		SET @CHANGE_NAME = @CCTSS_VRNT_ADJ_ID_N;
		SELECT @COMMENT = CONCAT('VARIANT ADJUSTMENT (', @CHANGE_NAME, ') ADDED IN VARIANT (', @VRNT_NAME, ')');

		-- invalid bob if required
		EXEC [PARWP_CCTSS_UPDT_BOB_STAT] 
			@GUIDIN = 0,						-- PBOM_SURGICAL to Pass the Processing ID in case of PBoM import triggering the Update Procedure.
			@TRIGGER_SOURCE = 'VA',				-- To know if the PBoM surgical is calling or the UI (DA, II, VA)
			@CCTSS_K = @CCTSS_K,				-- UI to Pass BoB key in case of UI triggering the Procedure.
			@CCTSS_DSGN_K = 0,					-- UI to pass Design key in case of UI triggering the Procedure. 
			@CCTSS_VRNT_K = @CCTSS_VRNT_K,		-- UI to pass Variant key in case of UI triggering the Procedure.
			@BOM_PART_K = @BOM_PART_K,          -- UI to pass Part key in case of UI triggering the Procedure.
			@ADJ_KEY = @RESULT,					-- UI to pass U37 or U46 or U65 key in case of UI triggering the Procedure.
			@CDSID = @USER_CDSID,				-- Needs to be passed whoever is triggering.
			@COMMENT = @COMMENT
		;

		EXEC [PARWP_MNL_OVRIDE_SURGERY] 
			@CCTSS_K = @CCTSS_K,
			@CCTSS_DSGN_K = 0,
			@CCTSS_VRNT_K = @CCTSS_VRNT_K,
			@BOM_PART_K = @BOM_PART_K,
			@DATA_LEVEL = 4,	-- Bob = 1, DA = 2, II = 3, VA = 4;
			@PART_OVRIDE = 1,
			@SUBASM_OVRIDE = 1,
			@FNLASM_OVRIDE = 1,
			@USER_CDSID = @USER_CDSID
		;
	END;

	-- in both Modify and Delete mode, delete the cost and manual overrides
	IF @MODE = 'M' OR @MODE = 'D'
	BEGIN  

		DECLARE @EXTNG_DSGN_ADJ_PART_CHG_TYP_K INT;
		DECLARE @EXTNG_FORD_VRNT_DSGN_ATTR_X VARCHAR(2048);
		DECLARE @EXTNG_FORD_INTD_DSGN_ATTR_X VARCHAR(2048);
		DECLARE @ADJ_SURGERY_REQ BIT = 0;

		SELECT @EXTNG_DSGN_ADJ_PART_CHG_TYP_K = ARWA40_DSGN_ADJ_PART_CHG_TYP_K, 
			   @EXTNG_FORD_VRNT_DSGN_ATTR_X = ARWU65_FORD_VRNT_DSGN_ATTR_X,
			   @EXTNG_FORD_INTD_DSGN_ATTR_X = ARWU65_FORD_INTD_DSGN_ATTR_X
		FROM [dbo].[PARWU65_CCTSS_VRNT_ADJ] WHERE ARWU65_CCTSS_VRNT_ADJ_K = @CCTSS_VRNT_ADJ_K;

		-- in Delete mode surgery is required
		-- in Modify mode surgery is required only if change type, comp da or ford da is changed
		IF @MODE = 'D' OR @EXTNG_DSGN_ADJ_PART_CHG_TYP_K <> @DSGN_ADJ_PART_CHG_TYP_K OR @EXTNG_FORD_VRNT_DSGN_ATTR_X <> @FORD_VRNT_DSGN_ATTR_X OR @EXTNG_FORD_INTD_DSGN_ATTR_X <> @FORD_INTD_DSGN_ATTR_X
			SET @ADJ_SURGERY_REQ = 1;

		DECLARE @EXTNG_CCTSS_TRDOFF_INCLD_F INT;
		DECLARE @NEW_CCTSS_TRDOFF_INCLD_F INT;
		DECLARE @TOF_SURGERY_REQ BIT = 0;

		SELECT @EXTNG_CCTSS_TRDOFF_INCLD_F = ARWU85_CCTSS_TRDOFF_INCLD_F
		FROM PARWU91_VRNT_ADJ_TRDOFF U91
		JOIN PARWU85_CCTSS_TRDOFF U85 ON U85.ARWU85_CCTSS_TRDOFF_K = U91.ARWU85_CCTSS_TRDOFF_K
		WHERE ARWU65_CCTSS_VRNT_ADJ_K = @CCTSS_VRNT_ADJ_K;

		SELECT @NEW_CCTSS_TRDOFF_INCLD_F = ARWU85_CCTSS_TRDOFF_INCLD_F 
		FROM PARWU85_CCTSS_TRDOFF WHERE ARWU85_CCTSS_TRDOFF_K = @CCTSS_TRDOFF_K;

		-- if tradeoff is the only field changed and if from include/exclude to exclude/include
		IF @ADJ_SURGERY_REQ = 0 AND @EXTNG_CCTSS_TRDOFF_INCLD_F <> @NEW_CCTSS_TRDOFF_INCLD_F
			SET @TOF_SURGERY_REQ = 1;

		IF @ADJ_SURGERY_REQ = 1 OR @TOF_SURGERY_REQ = 1
		BEGIN

			SELECT @CHANGE_NAME = ARWU65_CCTSS_VRNT_ADJ_ID_N FROM PARWU65_CCTSS_VRNT_ADJ WHERE ARWU65_CCTSS_VRNT_ADJ_K = @CCTSS_VRNT_ADJ_K;
			IF @MODE = 'M' SELECT @COMMENT = CONCAT('VARIANT ADJUSTMENT (', @CHANGE_NAME, ') UPDATED IN VARIANT (', @VRNT_NAME, ')');
			IF @MODE = 'D' SELECT @COMMENT = CONCAT('VARIANT ADJUSTMENT (', @CHANGE_NAME, ') DELETED IN VARIANT (', @VRNT_NAME, ')');

			EXEC [PARWP_CCTSS_UPDT_BOB_STAT] 
				@GUIDIN = 0,							-- PBOM_SURGICAL to Pass the Processing ID in case of PBoM import triggering the Update Procedure.
				@TRIGGER_SOURCE = 'VA',					-- To know if the PBoM surgical is calling or the UI (DA, II, VA)
				@CCTSS_K = @CCTSS_K,					-- UI to Pass BoB key in case of UI triggering the Procedure.
				@CCTSS_DSGN_K = 0,						-- UI to pass Design key in case of UI triggering the Procedure. 
				@CCTSS_VRNT_K = @CCTSS_VRNT_K,			-- UI to pass Variant key in case of UI triggering the Procedure.
				@BOM_PART_K = @BOM_PART_K,              -- UI to pass Part key in case of UI triggering the Procedure.
				@ADJ_KEY = @RESULT,						-- UI to pass U37 or U46 or U65 key in case of UI triggering the Procedure.
				@CDSID = @USER_CDSID,					-- Needs to be passed whoever is triggering.
				@COMMENT = @COMMENT
			;

			-- delete cost only if main surgery is required
			IF @ADJ_SURGERY_REQ = 1
			BEGIN

				DELETE FROM [dbo].[PARWU66_PURC_PART_VRNT_ADJ]	WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
				DELETE FROM [dbo].[PARWU67_RAW_MTRL_VRNT_ADJ]	WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
				DELETE FROM [dbo].[PARWU68_PROCG_VRNT_ADJ]		WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
				DELETE FROM [dbo].[PARWU69_ASSY_VRNT_ADJ]		WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
				DELETE FROM [dbo].[PARWU71_FNL_ASSY_VRNT_ADJ]	WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
				DELETE FROM [dbo].[PARWU81_SUPL_VRNT_ADJ]		WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;

				-- Delete from Variant improvement ideas for the part for the variant only.
				DELETE FROM [PARWUD4_PURC_PART_VRNT_IMPRV] WHERE [ARWUD2_CCTSS_VRNT_IMPRV_K] in (SELECT [ARWUD2_CCTSS_VRNT_IMPRV_K] FROM PARWUD2_CCTSS_VRNT_IMPRV WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K AND ARWU04_CCTSS_VRNT_K=@CCTSS_VRNT_K);
				DELETE FROM [PARWUD5_RAW_MTRL_VRNT_IMPRV]  WHERE [ARWUD2_CCTSS_VRNT_IMPRV_K] in (SELECT [ARWUD2_CCTSS_VRNT_IMPRV_K] FROM PARWUD2_CCTSS_VRNT_IMPRV WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K AND ARWU04_CCTSS_VRNT_K=@CCTSS_VRNT_K);
				DELETE FROM [PARWUD6_PROCG_VRNT_IMPRV]     WHERE [ARWUD2_CCTSS_VRNT_IMPRV_K] in (SELECT [ARWUD2_CCTSS_VRNT_IMPRV_K] FROM PARWUD2_CCTSS_VRNT_IMPRV WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K AND ARWU04_CCTSS_VRNT_K=@CCTSS_VRNT_K);
				DELETE FROM [PARWUD7_ASSY_VRNT_IMPRV]      WHERE [ARWUD2_CCTSS_VRNT_IMPRV_K] in (SELECT [ARWUD2_CCTSS_VRNT_IMPRV_K] FROM PARWUD2_CCTSS_VRNT_IMPRV WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K AND ARWU04_CCTSS_VRNT_K=@CCTSS_VRNT_K);
				DELETE FROM [PARWUD8_FNL_ASSY_VRNT_IMPRV]  WHERE [ARWUD2_CCTSS_VRNT_IMPRV_K] in (SELECT [ARWUD2_CCTSS_VRNT_IMPRV_K] FROM PARWUD2_CCTSS_VRNT_IMPRV WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K AND ARWU04_CCTSS_VRNT_K=@CCTSS_VRNT_K);
				DELETE FROM [PARWUD9_SUPL_VRNT_IMPRV]      WHERE [ARWUD2_CCTSS_VRNT_IMPRV_K] in (SELECT [ARWUD2_CCTSS_VRNT_IMPRV_K] FROM PARWUD2_CCTSS_VRNT_IMPRV WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K AND ARWU04_CCTSS_VRNT_K=@CCTSS_VRNT_K);	


			END;

			EXEC [PARWP_MNL_OVRIDE_SURGERY] 
				@CCTSS_K = @CCTSS_K,
				@CCTSS_DSGN_K = 0,
				@CCTSS_VRNT_K = @CCTSS_VRNT_K,
				@BOM_PART_K = @BOM_PART_K,
				@DATA_LEVEL = 4,	-- Bob = 1, DA = 2, II = 3, VA = 4;
				@PART_OVRIDE = 1,
				@SUBASM_OVRIDE = 1,
				@FNLASM_OVRIDE = 1,
				@USER_CDSID = @USER_CDSID;
		END;
	END;

	-- In Modify mode, update the adjustment and tradeoff
	IF @MODE = 'M'
	BEGIN 
		-- update adjustment info
		UPDATE [dbo].[PARWU65_CCTSS_VRNT_ADJ]  
		SET ARWA40_DSGN_ADJ_PART_CHG_TYP_K = @DSGN_ADJ_PART_CHG_TYP_K, 
			ARWU65_FORD_INTD_DSGN_ATTR_X = @FORD_INTD_DSGN_ATTR_X, 
			ARWU65_FORD_VRNT_DSGN_ATTR_X = @FORD_VRNT_DSGN_ATTR_X, 
			ARWU65_SPEC_SDS_NUM_X = @SPEC_SDS_NUM_X, 
			ARWU65_CCTSS_VRNT_ADJ_CMT_X = @CCTSS_VRNT_ADJ_CMT_X, 
			ARWU65_CIA_ID_NUM_X = @CIA_ID_NUM_X,
			ARWU65_LAST_UPDT_S = GETUTCDATE(), 
			ARWU65_LAST_UPDT_USER_C = @USER_CDSID
		WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;

		-- update tradeoff info
		UPDATE [dbo].[PARWU91_VRNT_ADJ_TRDOFF] 
		SET ARWU85_CCTSS_TRDOFF_K = @CCTSS_TRDOFF_K, 
		ARWU91_LAST_UPDT_S = GETUTCDATE(), 
		ARWU91_LAST_UPDT_USER_C = @USER_CDSID
		WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
	END;

	-- In Delete mode, Delete the adjustment and tradeoff
	IF @MODE = 'D'
	BEGIN  
		-- delete tradeoff and adjustment
		DELETE FROM [dbo].[PARWU91_VRNT_ADJ_TRDOFF] WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;
		DELETE FROM [dbo].[PARWU65_CCTSS_VRNT_ADJ]  WHERE [ARWU65_CCTSS_VRNT_ADJ_K] = @CCTSS_VRNT_ADJ_K;

		DECLARE @U19_COUNT INT;
		DECLARE @U37_COUNT INT;
		DECLARE @U46_COUNT INT;
		DECLARE @U65_COUNT INT;
		DECLARE @UD2_COUNT INT;
		--DECLARE @U75_COUNT INT;
		--DECLARE @U78_COUNT INT;
		--DECLARE @U82_COUNT INT;

		-- check if bom part is still in use. delete if it is not.
		SELECT @U19_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU19_DSGN_PART]			WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;
		SELECT @U37_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU37_CCTSS_DSGN_ADJ]		WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
		SELECT @U46_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU46_CCTSS_DSGN_IMPRV]	WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
		SELECT @U65_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU65_CCTSS_VRNT_ADJ]		WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
		SELECT @UD2_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWUD2_CCTSS_VRNT_IMPRV]    WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;
		--SELECT @U75_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU75_DA_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
		--SELECT @U78_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU78_II_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;  
		--SELECT @U82_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU82_VA_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 

		-- if bompart (U18) is not from pbom(U19) / has no dsgnadj(U37) / has no ideas(U46) / has no vrnt adj(U65)  / has no vrnt ideas(UD2)
		-- then 
		--		delete all the manual overrides & corresponding statusus
		--		delete bom part end item associations
		--		delete bom part
		--		delete sub asm if there are no other bom parts under it
		IF ( (@U19_COUNT + @U37_COUNT + @U46_COUNT + @U65_COUNT + @UD2_COUNT) = 0)
		BEGIN

			DELETE FROM [PARWU75_DA_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
			DELETE FROM [PARWUA0_DA_MNLSLCT_BOM_PART_STAT] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;

			DELETE FROM [PARWU78_II_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
			DELETE FROM [PARWUA3_II_MNLSLCT_BOM_PART_STAT] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;

			DELETE FROM [PARWU82_VA_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
			DELETE FROM [PARWUA6_VA_MNLSLCT_BOM_PART_STAT] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 

			DELETE FROM [PARWUE0_VII_MNLSLCT_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K; 
			DELETE FROM [PARWUE3_VII_MNLSLCT_BOM_PART_STAT] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;

			-- DELETE FROM U63
			DELETE FROM PARWU63_VRNT_BOM_PART_END_ITM WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;
			
			SELECT @BOM_SUB_ASSY_K = ARWU17_BOM_SUB_ASSY_K FROM [PARWU18_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;
			DELETE FROM [dbo].[PARWU18_BOM_PART] WHERE [ARWU18_BOM_PART_K] = @BOM_PART_K;

			-- Delete the subassembly if there are no other parts under it
			DECLARE @U18_COUNT INT;
			SELECT @U18_COUNT = COUNT(ARWU18_BOM_PART_K) FROM [PARWU18_BOM_PART] WHERE [ARWU17_BOM_SUB_ASSY_K] = @BOM_SUB_ASSY_K;
			IF @U18_COUNT = 0
			Begin
				EXEC [dbo].[PARWP_UI_SUB_ASSY_DELETE] @BOM_SUB_ASSY_K
			End;
		END;
	END;

	--IF (@SPEC_SDS_NUM_X = '1') begin select 1/0 end;

  --COMMIT TRANSACTION;
END TRY

BEGIN CATCH;
  --ROLLBACK TRANSACTION;
	DECLARE @U01_Study VARCHAR(100) = (Select U01.ARWU31_CTSP_N    + ' ' +
                          U01.ARWA06_RGN_C     + ' ' +
                   	      substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	      substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                     from PARWU01_CCTSS_FLAT  U01
                    where U01.ARWU01_CCTSS_K = @CCTSS_K
 				  );

	Set @RESULT = 'VA SURGICAL SYSTEM ERROR: ' +              
	             'Study Key: '       + CAST(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@U01_Study, '') +
	             ' |Change ID: '     + ISNULL(@CCTSS_VRNT_ADJ_ID_N, '') +
	             ' |GMT Date/Time: ' + CONVERT(varchar, GETUTCDATE(), 120) +
	             ' |CDS: '           + @USER_CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + CAST(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
END CATCH;



GO
