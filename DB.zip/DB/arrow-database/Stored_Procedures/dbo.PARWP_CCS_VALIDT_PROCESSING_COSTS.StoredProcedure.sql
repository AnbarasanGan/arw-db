DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_PROCESSING_COSTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 4/10/2019
-- Description:	validate Processing Costs
-- Notes: not validating OP index or Op desc.  These are free-form enties and not required on CCS
-- =============================================
-- Changes
-- =============================================
--                      User
-- Author     Date      Story     Description
-- ------     -----     --------  -----------
-- ASHAIK12  06/25                Added validation for calculated field
-- ASHAIK12  07/16                Changed the round off check to 5 for Machine /operation overhead costs [LoCur/operation]  column validation
-- ASHAIK12  07/31                Changed Calculated field validations to WARNINGS
-- Asolosky  09/10/2019           Added row_idx
-- rwesley2  09/13/2019           added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019           changed warning to error for calculated field validations
-- asolosky  09/30/2019           Changed error messages to more descriptive
-- rwesley2  10/01/2019           temporarily changed error back to warning per Glenn 
-- rwesley2	 10/08/2019	          removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	          F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/10/2020           Added TimeStamp parameter and removed filter on Processing Status
-- Ashaik12  08/31/2020           Added formulas to handle different versions in validation of Total labor costs and Direct labor cost per piece .
-- Asolosky  09/11/2020 US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12  09/17/2020           For CCS 10.1 made formula changes to have division by 60
-- Asolosky  01/21/2021 US2209131 Use ARWA10_COST_EST_PERFD_F instead of ARWA10_CCTSS_METHD_N like '%DEA%'
-- Asolosky  04/07/2021 US2430167 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021 US2815039 Added a case statement in the first part index validation for Part Index does not belong the BOM Sub Assembly.
--                                This happens if the user does a copy paste from another sheet.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_PROCESSING_COSTS] 

@GUID varchar(5000), 
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
-- Part Index validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.Source_c
	  ,Err.part_index
	  ,Error_x   
	  ,Err.Processing_ID 
	  ,Err.filename 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS16_CCS_PROCESSING_PARTS_K
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'   
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,''  --No ARROW Value
 FROM 
       (
        SELECT 
		       s16.Processing_ID,
               s16.part_index,
		       s16.Processing_Status_x,
		       s16.Source_c,
		       s16.filename,
               s16.ARWS16_CCS_PROCESSING_PARTS_K,
		       s16.sub_assembly_name,
		       s16.row_idx,
		       Case When S13.part_sub_assembly_name != s16.sub_assembly_name 
		            Then 'Processing: Part Index was found on a different BOM Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the part index.'
			        When S13.part_sub_assembly_name is Null
		            Then 'Processing: Part Index was not found on any BOM Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the part index.'
		            Else ''
		       End Error_x
          FROM PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO s16
     Left Join PARWS13_CCS_FORD_BOM_PARTS_INFO                  s13
            ON s16.part_index    = s13.part_index
	       and s16.filename      = s13.file_name
		   and s16.Processing_ID = s13.Processing_ID
         WHERE s16.Processing_ID = @GUID                                     
       ) Err
 Where Error_x != ''
;

--++++++++++++++++++++++++++++++++++++
-- Part Description validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,Err.[part_description]  
	  ,'Processing: Part Description did not match the PBOM Part Name'  
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID)  
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS16_CCS_PROCESSING_PARTS_K]
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name   
	  ,row_idx                               as ARWE02_ROW_IDX  
	  ,Err.[part_index]  
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  part_index,
		  Processing_Status_x,
		  Source_c,
		  filename,
         [ARWS16_CCS_PROCESSING_PARTS_K],
		 sub_assembly_name,
		 row_idx
        FROM [dbo].[PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO] s16
        WHERE Processing_ID= @GUID
	      and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO] s13
               where s16.[part_index] = s13.[part_index]
			     and s16.part_description=s13.part_name
				 and s16.[filename] = s13.[file_name]
				 and s16.Processing_ID=s13.Processing_ID
              )
                    
       ) Err

    ;


--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Currency Code validation
-- note: not validating the code is associated with correct country
--++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,ISNULL(Err.[local_currency],0)  
	  ,'Processing: Invalid Currency Code'   
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP    
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS16_CCS_PROCESSING_PARTS_K]  
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO' 
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.[part_index]  
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [local_currency],
		  part_index,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS16_CCS_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  row_idx
         FROM [dbo].[PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO] s16
        WHERE Processing_ID= @GUID
		  and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s16.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Machine /operation overhead costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.machine_op_overhead_costs
	  ,'Processing: For Machine/operation overhead costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS16_CCS_PROCESSING_PARTS_K]
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.[part_index]  
	  ,'Calculated Value: ' +  CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS16_CCS_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  part_index,
		  machine_op_overhead_costs,
		  case when no_of_pieces_per_cycle=0 then 0 else (cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle  end as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO] s16
        WHERE Processing_ID= @GUID
		  and case when no_of_pieces_per_cycle=0 then 0 
				   else ABS(((cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle) - (machine_op_overhead_costs)) END > @threshold  
             
       ) Err
    ;

--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Direct labor cost per piece [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.direct_hourly_labor_cost
	  ,'Processing: For Direct labor cost per piece, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X] 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS16_CCS_PROCESSING_PARTS_K]
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.[part_index]  
	  ,'Calculated Value: ' +  CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
         SELECT 
          s22.Processing_ID,
          manufacturing_location,
		  s22.Processing_Status_x,
		  s22.Source_c,
		  s22.filename,
          [ARWS16_CCS_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  part_index,
		  direct_hourly_labor_cost,
		  case when no_of_pieces_per_cycle=0 
		       then 0 
			   else 
		            CASE When U01.ARWA10_COST_EST_PERFD_F = 1 and [ARWA53_LGCY_CCS_PGM_N] is NULL    
		       	         THEN NULL 
		       	         ELSE  (cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle  
					end
		  end as Calculated_value,
		  s16.row_idx
        FROM [dbo].[PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO] s16
		  JOIN PARWS22_CCS_COVER_PAGE_INFO S22 On s16.Processing_ID=s22.Processing_ID and s16.filename=s22.filename
		  JOIN PARWU01_CCTSS_FLAT u01 
			on s22.User_Selected_CTSP_N            = u01.ARWU31_CTSP_N 
	       and s22.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X    
		   and s22.User_Selected_CTSP_Region_C     = u01.ARWA06_RGN_C
		   and s22.User_Selected_BNCMK_VRNT_N      = u01.ARWU01_BNCHMK_VRNT_N
	      LEFT JOIN PARWA53_LGCY_CCS_PGM A53 ON u01.ARWU31_CTSP_N = A53.[ARWA53_LGCY_CCS_PGM_N]
        WHERE s22.Processing_ID= @GUID
	   ) Err
	   Where ABS(Calculated_value) - ABS(direct_hourly_labor_cost) > @threshold
    ;

--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Total labor costs [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.total_labor_costs
	  ,'Processing: The Calculated field Total labor costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X] 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS16_CCS_PROCESSING_PARTS_K]
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.[part_index]  
	  ,'Calculated Value: ' +  CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
        SELECT 
          s22.Processing_ID,
          manufacturing_location,
		  s22.Processing_Status_x,
		  s22.Source_c,
		  s22.filename,
          [ARWS16_CCS_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  part_index,
		  total_labor_costs,
		  direct_hourly_labor_headcount,
		  [total_labor_minutes],
		  case when no_of_pieces_per_cycle =0 
		       then 0 
			   else 
		            CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and [ARWA53_LGCY_CCS_PGM_N] is NULL    
		                 THEN direct_hourly_labor_headcount*[total_labor_minutes]/60 
		                 ELSE (((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)*(1+indirect_labor_costs)*(1+fringes) ) 
			        end 
		  end as Calculated_value,
		  s16.row_idx
        FROM [dbo].[PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO] s16
        JOIN PARWS22_CCS_COVER_PAGE_INFO S22 On s16.Processing_ID=s22.Processing_ID and s16.filename=s22.filename
		JOIN PARWU01_CCTSS_FLAT u01 
		  on s22.User_Selected_CTSP_N            = u01.ARWU31_CTSP_N 
		 and s22.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
		 and s22.User_Selected_CTSP_Region_C     = u01.ARWA06_RGN_C
		 and s22.User_Selected_BNCMK_VRNT_N      = u01.ARWU01_BNCHMK_VRNT_N
		LEFT JOIN PARWA53_LGCY_CCS_PGM A53 ON u01.ARWU31_CTSP_N = A53.[ARWA53_LGCY_CCS_PGM_N]
        WHERE s22.Processing_ID= @GUID	    			  
       ) Err
	   Where ABS(Calculated_value) - ABS(total_labor_costs) > @threshold
    ;

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Processing: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS16_CCS_PROCESSING_PARTS_K
	  ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,'' 
  FROM 
      (
        SELECT 
               S16.Processing_ID
              ,S16.exchange_rate
  		      ,S16.Source_c
  		      ,S16.filename
              ,S16.ARWS16_CCS_PROCESSING_PARTS_K
  		      ,S16.sub_assembly_name
  		      ,S16.part_index
			  ,S16.row_idx
			  ,S27.usd_per_local_currency
			  ,S27.supplier_picked_crcy_c
          FROM PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO   S16 
		  Join PARWS27_CCS_EXCHANGE_RATE_TAB                      S27
		    On S27.Processing_ID  = S16.Processing_ID
		   And S27.filename       = S16.filename
		   And S27.currency_code  = S16.local_currency
         WHERE S16.Processing_ID  = @GUID
		   and S16.exchange_rate != S27.usd_per_local_currency
      ) Err
;

END TRY
BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
	         ,@CDSID  
             ,@TIME_STAMP
	         ,@CDSID  
			 ,''
			 ,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO' ,
			 --ARWE02_BATCH_ERRORS_K Identity key
			 'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;



GO
