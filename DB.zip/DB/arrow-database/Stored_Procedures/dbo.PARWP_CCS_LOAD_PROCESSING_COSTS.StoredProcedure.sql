DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_PROCESSING_COSTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 04/11/2019
-- Description:	load ARROW U26 processing costs table 
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 05/20/2019  Asolosky  N/A      If source country is not found in the A28 table, use the empty string country record.
-- 06/13/2019  ASHAIK12  N/A      Make all join conditions from cover page columns to user selected columns. And Remove the join for Engineering Commodity.
-- 06/17/2019  asolosky  N/A      Change the delete from design_supplier/sub-assembly to just design_supplier
-- 06/25/2019  rwesley2  N/A      changed ROW_NUMBER function to order by stage table row_idx col
-- 06/26/2019  rwesley2  N/A      removed ROW_NUMBER function and replaced with row_idx col on U26 INSERT
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 07/16/2019  asolosky			  Removed the ISNULL functions.  All staging columns that were Varchar but the database had the types as
--                                numeric were change to use a case statement
--                                NOTE: The UI writes empty strings to the staging tables instead of NULLs.
-- 08/13/2019  ashaik12           Removed the Delete Statements
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- 08/27/2020  Ashaik12           Added Total Labor Minutes
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_PROCESSING_COSTS]
-- Input Parameter
@GUID          Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;




-------U26 INSERT

INSERT INTO [dbo].[PARWU26_PROCG_COST]
SELECT V08.ARWU08_CCTSS_DSGN_SUPL_K             as ARWU08_CCTSS_DSGN_SUPL_K
      ,V08.ARWU17_BOM_SUB_ASSY_K                as ARWU17_BOM_SUB_ASSY_K
      ,s16.row_idx                              as ARWU26_PROCG_COST_DSPLY_SEQ_R
	  ,V08.ARWU19_DSGN_PART_K                   as ARWU19_DSGN_PART_K
      ,s16.operation_index                      as ARWU26_PROCG_OPER_IX_C
      ,s16.operation_desc                       as ARWU26_PROCG_OPER_X

	  ,Case When A28.ARWA28_CNTRY_K is Null Then A28_EmptyStr.ARWA28_CNTRY_K Else A28.ARWA28_CNTRY_K  End as ARWA28_MFG_LOC_CNTRY_K

      ,A29.ARWA29_CRCY_K                        as ARWA29_LCL_CRCY_K
      ,s16.machine_make_model                   as ARWU26_MACH_MAKE_MDL_X
	  ,s16.capital_exp_for_machine    as ARWU26_CPTL_EXPNDTR_FOR_MACH_A
	  ,s16.machine_size as ARWU26_MACH_SIZE_IN_MET_TN_Q
	  ,s16.no_of_pieces_per_cycle              as ARWU26_PCS_PER_CYC_Q 
	  ,s16.cycle_time_sec                      as ARWU26_CYC_TIME_IN_SEC_Q
	  ,s16.machinehourly_operation_overhead    as ARWU26_MACH_OPER_OVRHD_HRLY_A
	  ,s16.direct_headcount                    as ARWU26_DIR_HDCNT_Q
	  ,s16.direct_hourly_labor_headcount       as ARWU26_DIR_HRLY_LBR_HDCNT_A
	  ,s16.indirect_labor_costs                as ARWU26_INDIR_LBR_PER_DIR_P
	  ,s16.fringes                             as ARWU26_FRNG_PER_DIR_LBR_P
	  ,s16.packaging_costs                     as ARWU26_PKNG_COST_PER_PCE_A
	  ,s16.logistics_cost                      as ARWU26_LGSTCS_COST_PER_PCE_A
	  ,s16.tax_duty_per_piece                  as ARWU26_TAX_AND_DUTY_PER_PCE_A
	  ,s16.licensing_costs                     as ARWU26_LICSNG_COST_PER_PCE_A
	  ,s16.comments                            as ARWU26_PROCG_ASSMP_CMT_X
      ,@TIME_STAMP                             as ARWU26_CREATE_S
      ,@CDSID                                  as ARWU26_CREATE_USER_C                              
      ,@TIME_STAMP                             as ARWU26_LAST_UPDT_S
      ,@CDSID                                  as ARWU26_LAST_UPDT_USER_C 
	  ,s16.[total_labor_minutes]               as ARWU26_TOT_LBR_MIN_Q          
 from [dbo].[PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO] s16
 JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
  ON s22.Processing_ID               = s16.Processing_ID
 AND s22.filename                    = s16.filename

 -- Join with Supplier Qoute View
      JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08
        ON s22.User_Selected_ENRG_SUB_CMMDTY_X  = V08.[ARWA03_ENRG_SUB_CMMDTY_X]
       AND s22.[User_Selected_CTSP_N]           = V08.ARWU31_CTSP_N
       AND s22.[User_Selected_CTSP_Region_C]    = V08.[ARWA06_RGN_C]
       AND s22.[User_Selected_VEH_MAKE_N]       = V08.[ARWA14_VEH_MAKE_N]
       AND s22.[User_Selected_VEH_MDL_N]        = V08.[ARWA34_VEH_MDL_N]
       AND s22.[User_Selected_VEH_MDL_YR_C]     = V08.ARWA35_DSGN_VEH_MDL_YR_C    
       AND s22.[User_Selected_VEH_MDL_VRNT_X]   = V08.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
       AND s22.[User_Selected_BNCMK_VRNT_N]     = V08.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
  											    
       AND S22.[User_Selected_SUPL_N]           = V08.ARWA17_SUPL_N
       AND s22.[User_Selected_SUPL_CNTRY_N]     = V08.ARWA28_CNTRY_N
       AND s22.[User_Selected_SUPL_C]           = V08.ARWA17_SUPL_C
       AND s16.part_index                       = V08.[ARWU18_BOM_PART_IX_N]
  
      JOIN [dbo].[PARWA29_CRCY] A29        ON s16.local_currency               = A29.ARWA29_CRCY_C

 Left JOIN [dbo].[PARWA28_CNTRY] A28   
        ON s16.[manufacturing_location]     = A28.ARWA28_CNTRY_N
      JOIN [dbo].PARWA28_CNTRY   A28_EmptyStr
        ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''
 where s22.Processing_ID               = @GUID
   AND s22.Skip_loading_due_to_error_f = 0
;


GO
