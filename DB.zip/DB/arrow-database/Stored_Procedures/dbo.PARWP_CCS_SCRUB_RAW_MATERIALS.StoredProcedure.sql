DROP PROCEDURE [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 04/15/2019
-- Description:	Set Warning message that a raw material cost does not have a processing cost 
-- =============================================
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   01/10/2020  Added TimeStamp parameter
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value. Changed the not exists because it wasn't working
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS] 
-- Input Parameter
 @GUID       varchar(5000) 
,@CDSID      varchar(30)
,@TIME_STAMP DATETIME

AS
	SET NOCOUNT ON;
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select  
		 Err.[Source_c]
        ,Err.[ARWU18_BOM_PART_IX_N]
		,'Raw Material Cost does not have a Processing Cost' as Error_Msg
        ,Err.[Processing_ID]
        ,Err.[Filename]
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
 		,@TIME_STAMP 
		,@CDSID
        ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
		,'Process and Raw Materials'
		--identity key place holder		
		,'WARNING'
		,'SubAssemly' + ' - ' + Err.[ARWU17_BOM_SUB_ASSY_N]
		,0 AS ARWE02_ROW_IDX
		,ARWU18_BOM_PART_IX_N
		,''  --No ARROW Value
    FROM
    (	
	  (SELECT U25.[ARWU08_CCTSS_DSGN_SUPL_K] 
	         ,u25.[ARWU19_DSGN_PART_K]
			 ,V08.[ARWU18_BOM_PART_IX_N]
			 ,V08.[ARWU17_BOM_SUB_ASSY_N]
			 ,s22.[Source_c]
			 ,s22.[Processing_ID]
			 ,s22.[filename]
			 ,s22.[ARWS22_CCS_COVER_PAGE_INFO_K]

	    FROM [dbo].[PARWU25_RAW_MTRL_COST] U25
	    JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08
	      ON U25.[ARWU08_CCTSS_DSGN_SUPL_K]    = V08.[ARWU08_CCTSS_DSGN_SUPL_K]
		 and U25.[ARWU19_DSGN_PART_K]          = V08.[ARWU19_DSGN_PART_K]
		JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
		  ON V08.ARWU31_CTSP_N                 = s22.[User_Selected_CTSP_N]
         AND V08.[ARWA06_RGN_C]                = s22.[User_Selected_CTSP_Region_C]
         AND V08.[ARWA03_ENRG_SUB_CMMDTY_X]    = s22.[User_Selected_ENRG_SUB_CMMDTY_X]
	     AND V08.ARWU01_BNCHMK_VRNT_N          = s22.[User_Selected_BNCMK_VRNT_N]
		 AND V08.[ARWA14_VEH_MAKE_N]           = s22.[User_Selected_VEH_MAKE_N]
         AND V08.[ARWA34_VEH_MDL_N]            = s22.[User_Selected_VEH_MDL_N]
         AND V08.[ARWA35_DSGN_VEH_MDL_YR_C]    = s22.[User_Selected_VEH_MDL_YR_C]
         AND V08.[ARWA35_DSGN_VEH_MDL_VRNT_X]  = s22.[User_Selected_VEH_MDL_VRNT_X]
	     AND V08.[ARWA17_SUPL_N]               = s22.[User_Selected_SUPL_N]
	     AND V08.ARWA28_CNTRY_N                = s22.[User_Selected_SUPL_CNTRY_N]
	     AND V08.ARWA17_SUPL_C			       = s22.[User_Selected_SUPL_C]
	     AND S22.Processing_ID                 = @GUID
        Where NOT EXISTS 	   
		  (SELECT 'x'
              FROM [dbo].[PARWU26_PROCG_COST] U26
             Where U26.[ARWU08_CCTSS_DSGN_SUPL_K] = V08.[ARWU08_CCTSS_DSGN_SUPL_K]
			   and U26.[ARWU17_BOM_SUB_ASSY_K]    = V08.ARWU17_BOM_SUB_ASSY_K
		       and U26.[ARWU19_DSGN_PART_K]       = V08.[ARWU19_DSGN_PART_K]
           )
	   )
 	) Err
;	

GO
