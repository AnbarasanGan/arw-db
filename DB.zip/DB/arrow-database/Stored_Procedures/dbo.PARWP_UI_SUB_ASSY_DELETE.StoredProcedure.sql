DROP PROCEDURE IF EXISTS [dbo].[PARWP_UI_SUB_ASSY_DELETE]
GO

/****** Object:  StoredProcedure [dbo].[PARWP_UI_SUB_ASSY_DELETE]    Script Date: 7/22/2021 12:26:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ================================================================================================
-- Author:		ASHAIK12
-- Create date: 2021-JUL-07
-- Description:	
--		Common SP to delete Sub Assembly when performing surgical actions.
-- ================================================================================================
-- Changes
-- ================================================================================================
-- Author     Date        Description
-- ------     -----       -----------

-- ================================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_SUB_ASSY_DELETE] 
-- Input Parameters

@BOM_SUB_ASSY_K INT

AS

SET NOCOUNT ON;


Delete From [dbo].[PARWU27_ASSY_COST] where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;

Delete From PARWU28_MFG_MRKP
  Where [ARWU17_BOM_SUB_ASSY_K]=@BOM_SUB_ASSY_K;

Delete From PARWU56_SUPL_SUB_ASSY
  Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;

 -- DELETE Tables that have ARWU57_CCTSS_DSGN_SUB_ASSY_K as a FK
Delete From PARWU59_MNLSLCT_SUB_ASSY
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWU60_MNLSLCT_SUB_ASSY_MRKP
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWU76_DA_MNLSLCT_SUB_ASSY
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWU79_II_MNLSLCT_SUB_ASSY
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWU96_MNLSLCT_SUB_ASSY_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWU97_MNLSLCT_SUBASSYMKRP_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWUA1_DA_MNLSLCT_SUB_ASSY_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);

Delete From PARWUA4_II_MNLSLCT_SUB_ASSY_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K IN 
	(Select ARWU57_CCTSS_DSGN_SUB_ASSY_K FROM [dbo].[PARWU57_CCTSS_DSGN_SUB_ASSY] 
		Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K);
-- DELETE U57
Delete From PARWU57_CCTSS_DSGN_SUB_ASSY
  Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;

Delete From PARWU83_VA_MNLSLCT_SUB_ASSY
  Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;

Delete From PARWUA7_VA_MNLSLCT_SUB_ASSY_STAT
  Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;

Delete from PARWUB0_VRNT_END_ITM_SUB_ASSY
Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;

Delete From PARWU17_BOM_SUB_ASSY
  Where [ARWU17_BOM_SUB_ASSY_K] =@BOM_SUB_ASSY_K;
GO


