DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_CRNCY_CODE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		asamriya
-- Create date: 07/22/2019
-- Description:	Stored Procedure to validate Exchange Rate Currency Code
--==============================================================================================
-- Changes
-- Date       CDSID     Description
-- -----      ------    ------------------------------------------------------------
-- 09/10/2019 asamriya  Added row_idx
-- 10/08/2019 Ashaik12  Added GUIDID and filename filter for last 4 validations.
-- 10/22/2019 Ashaik12  Changed Error Descriptions on Local Currency code validations
-- 10/22/2019 rwesley2  new validation where if a currency code is repeated it has to have the same exchange rate. could happen with EURO   new validation where if a currency code is repeated it has to have the same exchange rate. could happen with EURO 
-- 01/14/2020 Ashaik12  Added Time_Stamp parameter and removed filter on Processing Status
-- 01/27/2020 Ashaik12  Add new validation to check is the picked countries exchange rate value is 1
-- 09/11/2020 Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- 10/18/2020 Asolosky  US2982699 Fill in your currency of "Country" was not working with multiple files.  The 'partition by' only had processing_id. It was replaced with filename to fix the problem.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_CRNCY_CODE] 
	-- Add the parameters for the stored procedure here
	 @GUID varchar(500),
	 @CDSID varchar(8),
	 @TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c]                        as [ARWE02_SOURCE_C],
	         Validate.[currency_code]                   as [ARWE02_ERROR_VALUE],
	         'Exchange Rate Tab, Invalid Currency Code' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID]                   as [ARWE02_PROCESSING_ID],
	         Validate.[filename]                        as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                      as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                                as [ARWE02_CREATE_S],
	         @CDSID                                     as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                                as [ARWE02_LAST_UPDT_S],
	         @CDSID                                     as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS55_DAII_EXCHANGE_RATE_TAB'           as [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
			 Validate.ROW_IDX                           as [ARWE02_ROW_IDX],
			 ''                                         as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   --Find all staging records where the Currency is not in the PARWA29_CRCY table
       (SELECT 
               Processing_ID,
		       currency_code,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS55_DAII_EXCHANGE_RATE_TAB_K],
			   ROW_IDX
          FROM [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
         WHERE Processing_ID= @GUID
	       and Not Exists
		      (Select 'X'
			     from  [dbo].[PARWA29_CRCY] CRNCY
                where S55.[currency_code]=CRNCY.ARWA29_CRCY_C
              )
        ) Validate;

-----------------------------------------------------------------------------------
--Exchange rate - Selected currency
-----------------------------------------------------------------------------------

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c]                        as [ARWE02_SOURCE_C],
	         Validate.supplier_picked_crcy_c            as [ARWE02_ERROR_VALUE],
	         'Fill in your currency of "Country", returned a currency code not identified by ARROW on line 11 and 12. Please recheck the value in your file. If there''s still a problem, contact ARROW support' as [ARWE02_ERROR_X], --'User Selected Currency: Invalid Country of Currency Code' 
	         Validate.[Processing_ID]                   as [ARWE02_PROCESSING_ID],
	         Validate.[filename]                        as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                      as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                                as [ARWE02_CREATE_S],
	         @CDSID                                     as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                                as [ARWE02_LAST_UPDT_S],
	         @CDSID                                     as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS55_DAII_EXCHANGE_RATE_TAB'           as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
			 11                                         as [ARWE02_ROW_IDX],
			 ''                                         as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   --Find all staging records where the Program is not in the Arrow A05 table
       (Select *
	      From
	   (SELECT 
               Processing_ID,
		       supplier_picked_crcy_c,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS55_DAII_EXCHANGE_RATE_TAB_K,
			   row_number() over (partition by filename, supplier_picked_crcy_c
			                          order by filename, supplier_picked_crcy_c) as rownum,
			   [ROW_IDX]
          FROM [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
         WHERE Processing_ID= @GUID
	       and Not Exists
		      (Select 'X'
			     from  [dbo].[PARWA29_CRCY] CRNCY
                where S55.supplier_picked_crcy_c=CRNCY.ARWA29_CRCY_C
              )
		) Val_Distinct
		Where rownum = 1
        ) Validate;

-----------------------------------------------------------------------------------
--Exchange rate - Picked Currency doesn't match a currency in exchange rate table
-----------------------------------------------------------------------------------

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  SELECT
	     Validate.[Source_c]                        as [ARWE02_SOURCE_C],
	     Validate.supplier_picked_crcy_c            as [ARWE02_ERROR_VALUE],
	     'Fill in your currency of "Country", populates a currency code on line 11 and 12. That currency code didn''t match a code in the supplier exchange rate starting at line 15. Please contact ARROW support if needed.'  as [ARWE02_ERROR_X],  -- 'The Supplier picked currency of country, does not match a currency in the supplier exchange rate tab'
	     Validate.[Processing_ID]                   as [ARWE02_PROCESSING_ID],
	     Validate.[filename]                        as [ARWE02_FILENAME],
	     OBJECT_NAME(@@PROCID)                      as [ARWE02_PROCEDURE_X],
	     @TIME_STAMP                                as [ARWE02_CREATE_S],
	     @CDSID                                     as [ARWE02_CREATE_USER_C],
	     @TIME_STAMP                                as [ARWE02_LAST_UPDT_S],
	     @CDSID                                     as [ARWE02_LAST_UPDT_USER_C],
	     Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	     'PARWS55_DAII_EXCHANGE_RATE_TAB'           as  [ARWE02_STAGING_TABLE_X],
	     'ERROR',
	     'Exchange Rates',
		 11                                         as [ARWE02_ROW_IDX],
		 ''                                         as [ARWE02_Part_Index],
		 ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   --Find all staging records where the Program is not in the Arrow A05 table
       (Select Top 1 *
          From
       (SELECT 
      		  Sum(Case When currency_code = supplier_picked_crcy_c Then 1 Else 0 End)
      		       over (Partition BY Processing_ID, filename) as sum_matched
             ,Processing_ID
             ,Source_c
             ,Processing_status_x
             ,currency_name
             ,currency_code
             ,local_currency_per_usd
             ,usd_per_local_currency
             ,filename
             ,ARWS55_DAII_EXCHANGE_RATE_TAB_K
             ,supplier_picked_crcy_c
			 ,ROW_IDX
        FROM PARWS55_DAII_EXCHANGE_RATE_TAB
       Where Processing_ID = @GUID
      ) S55
      Where Sum_matched = 0
	  ) Validate;


----------------------------------------------------------------------------------------------------------------------
--Exchange rate - Local Currency in Purchased Parts data does not have a Exchange Rate defined in Exchange rates tab.
----------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         Validate.local_currency as [ARWE02_ERROR_VALUE],
	         'Local Currency in Purchased Parts does not have an conversion value in Exchange rates Tab' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.ARWS39_DAII_PURCHASED_PARTS_K as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS39_DAII_PURCHASED_PARTS_INFO' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	          Validate.sub_assembly_name,
			 Validate.row_idx as [ARWE02_ROW_IDX],
		     Validate.change_improvement_id             as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   (SELECT 
               Processing_ID,
		       local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS39_DAII_PURCHASED_PARTS_K,
			   [row_idx],
			   change_improvement_id,
			   sub_assembly_name
          FROM 
		  [dbo].[PARWS39_DAII_PURCHASED_PARTS_INFO]  S39
         WHERE Processing_ID= @GUID
	       and NOT Exists
		      (Select 'X'
			     from [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
                where S55.currency_code=S39.local_currency
				and S55.Processing_ID = @GUID
				and S55.filename = S39.filename
              )
        ) Validate;

----------------------------------------------------------------------------------------------------------------------
--Exchange rate - Local Currency in Raw Materials data does not have a Exchange Rate defined in Exchange rates tab.
----------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         Validate.local_currency as [ARWE02_ERROR_VALUE],
	         'Local Currency in Raw Materials does not have an conversion value in Exchange rates Tab' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.ARWS40_DAII_RAW_MATERIALS_K as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS40_DAII_RAW_MATERIALS_INFO' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         Validate.sub_assembly_name,
			 Validate.row_idx as [ARWE02_ROW_IDX],
		     Validate.change_improvement_id             as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   (SELECT 
               Processing_ID,
		       local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS40_DAII_RAW_MATERIALS_K,
			   row_idx,
			   change_improvement_id,
			   sub_assembly_name
          FROM 
		  [dbo].[PARWS40_DAII_RAW_MATERIALS_INFO] S40
         WHERE 
		  Processing_ID= @GUID
	       and NOT Exists
		      (Select 'X'
			     from [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
                where S55.currency_code=S40.local_currency
				and S55.Processing_ID = @GUID
				and S55.filename = S40.filename
              )
        ) Validate;

----------------------------------------------------------------------------------------------------------------------
--Exchange rate - Local Currency in Processing data does not have a Exchange Rate defined in Exchange rates tab.
----------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         Validate.local_currency as [ARWE02_ERROR_VALUE],
	         'Local Currency in Processing does not have an conversion value in Exchange rates Tab' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.ARWS41_DAII_PROCESSING_PARTS_K as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS41_DAII_PROCESSING_PARTS_INFO' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         Validate.sub_assembly_name,
			 Validate.row_idx as [ARWE02_ROW_IDX],
		     Validate.change_improvement_id             as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   (SELECT 
               Processing_ID,
		       local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS41_DAII_PROCESSING_PARTS_K,
			   row_idx,
			   change_improvement_id,
			   sub_assembly_name
          FROM 
		  [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] S41
         WHERE  Processing_ID= @GUID
	       and NOT Exists
		      (Select 'X'
			     from [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
                where S55.currency_code=S41.local_currency
				and S55.Processing_ID = @GUID
				and S55.filename = S41.filename
              )
        ) Validate;


----------------------------------------------------------------------------------------------------------------------
--Exchange rate - Local Currency in Assembly data does not have a Exchange Rate defined in Exchange rates tab.
----------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
	         Validate.local_currency as [ARWE02_ERROR_VALUE],
	         'Local Currency in Assembly does not have an conversion value in Exchange rates Tab' as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.ARWS42_DAII_ASSEMBLY_PARTS_K as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS42_DAII_ASSEMBLY_PARTS_INFO' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         Validate.sub_assembly_name,
			 Validate.row_idx as [ARWE02_ROW_IDX],
		     Validate.change_improvement_id             as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   (SELECT 
               Processing_ID,
		       local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS42_DAII_ASSEMBLY_PARTS_K,
			   row_idx,
			   change_improvement_id,
			   sub_assembly_name
          FROM 
		  [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO] S42
         WHERE 
		 Processing_ID= @GUID
	       and NOT Exists
		      (Select 'X'
			     from [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] S55
                where S55.currency_code=S42.local_currency
				and S55.Processing_ID = @GUID
				and S55.filename = S42.filename
              )
        ) Validate;
----------------------------------------------------------------------------------------------------------------------
--Exchange rate - repeated currency codes must have the same exchange rate or else ERROR
----------------------------------------------------------------------------------------------------------------------
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
             Validate.currency_code   as [ARWE02_ERROR_VALUE],  
	        'There are different local currency per USD exchange rates ' + CAST(Validate.local_base as varchar(50)) + 
			  ' and ' + CAST(Validate.local_chg as varchar(50)) + ' on sheet row ' + cast(Validate.[ROW_IDX] as varchar(10)) as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS55_DAII_EXCHANGE_RATE_TAB' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
		     Validate.[ROW_IDX]                         as ARWE02_ROW_IDX,
		     ''                                         as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]
       FROM 
	   (
         select 
		 s55a.Processing_ID           as processing_ID
        ,s55a.Source_c                as source_c
        ,s55a.currency_code           as currency_code 
        ,s55a.local_currency_per_usd  as local_base
        ,s55a.usd_per_local_currency  as usd_base
        ,s55b.local_currency_per_usd  as local_chg 
        ,s55b.usd_per_local_currency  as usd_chg
        ,s55a.filename                as filename 
		,s55a.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWS55_DAII_EXCHANGE_RATE_TAB_K]
        ,s55a.ROW_IDX                 as  [ROW_IDX]
        from [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] s55a
        join [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] s55b
        on  s55a.Processing_ID = s55b.Processing_ID
        and s55a.Source_c = s55b.Source_c
        and s55a.currency_code = s55b.currency_code
        and s55a.filename = s55b.filename
        
      WHERE s55a.Processing_ID= @GUID
        and  s55a.local_currency_per_usd <> s55b.local_currency_per_usd
        and s55a.ROW_IDX <> s55b.ROW_IDX
    ) Validate 

UNION

      SELECT
	         Validate.[Source_c] as [ARWE02_SOURCE_C],
             Validate.currency_code   as [ARWE02_ERROR_VALUE],  
	         'There are different USD per local currency exchange rates ' + CAST(Validate.usd_base as varchar(50)) + 
			  ' and ' + CAST(Validate.usd_chg as varchar(50)) + ' on sheet row ' + cast(Validate.[ROW_IDX] as varchar(10)) as [ARWE02_ERROR_X],
	         Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	         Validate.[filename] as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP as [ARWE02_CREATE_S],
	         @CDSID as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	         @CDSID as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS55_DAII_EXCHANGE_RATE_TAB' as  [ARWE02_STAGING_TABLE_X],
	         'ERROR',
	         'Exchange Rates',
		      Validate.[ROW_IDX]                        as ARWE02_ROW_IDX,
		     ''                                         as [ARWE02_Part_Index],
		     ''                                         as [ARWE02_ARROW_Value]

       FROM 
	   (
         select 
		 s55a.Processing_ID           as processing_ID
        ,s55a.Source_c                as source_c
        ,s55a.currency_code           as currency_code 
        ,s55a.local_currency_per_usd  as local_base
        ,s55a.usd_per_local_currency  as usd_base
        ,s55b.local_currency_per_usd  as local_chg 
        ,s55b.usd_per_local_currency  as usd_chg
        ,s55a.filename                as filename 
		,s55a.[ARWS55_DAII_EXCHANGE_RATE_TAB_K] as [ARWS55_DAII_EXCHANGE_RATE_TAB_K]
        ,s55a.ROW_IDX                 as  [ROW_IDX]
        from [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] s55a
        join [dbo].[PARWS55_DAII_EXCHANGE_RATE_TAB] s55b
        on  s55a.Processing_ID = s55b.Processing_ID
        and s55a.Source_c = s55b.Source_c
        and s55a.currency_code = s55b.currency_code
        and s55a.filename = s55b.filename
        
      WHERE  s55a.Processing_ID= @GUID
        and s55a.usd_per_local_currency <> s55b.usd_per_local_currency
		and s55a.ROW_IDX <> s55b.ROW_IDX
    ) Validate;

-------------------------------------------------------------------------------
-- Check if the exchange rate value for the selected country is always 1
-------------------------------------------------------------------------------
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
[Source_c]                         as [ARWE02_SOURCE_C]
,usd_per_local_currency            as [ARWE02_ERROR_VALUE]
,'Currency Exchange Rate value for the Selected Country should be 1' as [ARWE02_ERROR_X]
,X.Processing_ID                   as [ARWE02_PROCESSING_ID]
,X.filename                        as [ARWE02_FILENAME]
,OBJECT_NAME(@@PROCID)             as [ARWE02_PROCEDURE_X]
,@TIME_STAMP                       as [ARWE02_CREATE_S]
,@CDSID                            as [ARWE02_CREATE_USER_C]
,@TIME_STAMP                       as [ARWE02_LAST_UPDT_S]
,@CDSID                            as [ARWE02_LAST_UPDT_USER_C]
,X.ARWS55_DAII_EXCHANGE_RATE_TAB_K as [ARWE02_BATCH_ERRORS_REF_K]
,'PARWS55_DAII_EXCHANGE_RATE_TAB'  as  [ARWE02_STAGING_TABLE_X]
,'ERROR' 
,'Exchange Rates'
,X.row_idx
,''                                as [ARWE02_Part_Index]
,''                                as [ARWE02_ARROW_Value]

From
(
select 
S34.processing_id,S55.[Source_c],supplier_picked_crcy_c,currency_code,usd_per_local_currency,S55.filename,ARWS55_DAII_EXCHANGE_RATE_TAB_K,S55.row_idx,
CASE WHEN supplier_picked_crcy_c=currency_code THEN CASE WHEN usd_per_local_currency=1 then 'No error' else 'Error' END END AS ERROR_X
 from PARWS34_DAII_COVER_PAGE_INFO S34 
JOIN PARWS55_DAII_EXCHANGE_RATE_TAB S55
ON  S34.Processing_ID = S55.Processing_ID
AND S34.filename = S55.filename
where S34.Processing_ID=@GUID
) X
where ERROR_X ='Error'
;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS55_DAII_EXCHANGE_RATE_TAB'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH








GO
