DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_U48_PURC_PART]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIk12
-- Create date: 06/27/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08-20-2019  ashaik12  na	      add logic to add supplier key to improvement id name when originator is SUPPLIER 
--                                and FORD when originator is FORD on the Join Condition to match on what is inserted in U46
-- 08-28-2019  asolosky           moved delete to PARWP_DAII_IMPRV_DELETE
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 07/28/2020  Ashaik12           US1798783 -- update CAST on U07_K to CONVERT
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_U48_PURC_PART] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--Delete moved to  PARWP_DAII_IMPRV_DELETE 


INSERT INTO [PARWU48_PURC_PART_DSGN_IMPRV]
SELECT --ARWU48_PURC_PART_DSGN_IMPRV_K is an identity 
        V04.ARWU08_CCTSS_DSGN_SUPL_K    AS ARWU08_CCTSS_DSGN_SUPL_K
	  ,S39.row_idx     AS [ARWU48_PURC_PART_DSPLY_SEQ_R]
      , U46.ARWU46_CCTSS_DSGN_IMPRV_K   AS ARWU46_CCTSS_DSGN_IMPRV_K
	  , S39.part_specification          AS [ARWU48_PURC_PART_SPEC_X]
	  , source_supplier                 AS [ARWU48_SRC_SUPL_N]

	  ,Case When LOC.ARWA28_CNTRY_K is Null then A28_EmptyStr.ARWA28_CNTRY_K Else LOC.ARWA28_CNTRY_K  End AS ARWA28_SRC_CNTRY_K

	  , A29.ARWA29_CRCY_K           AS ARWA29_LCL_CRCY_K
	  , no_of_pieces                AS [ARWU48_PCE_PER_SUB_ASSY_Q]
	  , purchased_price_per_piece   AS [ARWU48_PURC_PART_PER_PCE_A]
	  , inbound_packaging_costs     AS [ARWU48_INBND_PKNG_COST_PCE_A]
	  , inbound_logistics_costs     AS [ARWU48_INBND_LGSTCS_COST_PCE_A]
	  , tax_duty                    AS [ARWU48_TAX_AND_DUTY_PER_PCE_A]
	  , purchased_parts_markup_cost AS [ARWU48_PURC_PART_MRKP_P]  --purchased_parts_markup_cost should be renamed in the database as purchased_parts_markup_p
	  , comments                    AS [ARWU48_PURC_PART_ASSMP_CMT_X]
	  ,@TIME_STAMP                 AS ARWU48_CREATE_S
	  ,@CDSID                       AS ARWU48_CREATE_USER_C
	  ,@TIME_STAMP                 AS ARWU48_LAST_UPDT_S
	  ,@CDSID                       AS ARWU48_LAST_UPDT_USER_C

  From PARWS34_DAII_COVER_PAGE_INFO       S34 
  JOIN PARWS39_DAII_PURCHASED_PARTS_INFO  S39
    ON S39.Processing_ID       = S34.Processing_ID
   AND S39.filename            = S34.filename
  JOIN PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename
   AND S39.change_improvement_id = S44.improvement_id


 -- Join with Supplier Quote View
         JOIN dbo.PARWV04_DSGN_SUPL V04
    ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

--Design Adjustment Part
  Join [dbo].[PARWU46_CCTSS_DSGN_IMPRV]  U46
    ON U46.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
   AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  s39.change_improvement_id + '#' + CONVERT(VARCHAR,[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  s39.change_improvement_id  + '#' + 'Ford'	            
		  ELSE s39.change_improvement_id + '#' + 'UNK'   
        END)

 --Currency
     JOIN PARWA29_CRCY        A29          ON A29.ARWA29_CRCY_C = S39.local_currency

 --Source-Country
Left JOIN PARWA28_CNTRY       LOC          ON LOC.ARWA28_CNTRY_N = S39.source_country
     JOIN [dbo].PARWA28_CNTRY A28_EmptyStr ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C  = ''
   
  Where S34.Processing_ID       = @GUIDIN
	AND S39.cost_type='Improvement Costs'
	AND S34.Skip_loading_due_to_error_f = 0
;


GO
