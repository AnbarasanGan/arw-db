DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_TYPE_OF_CHANGE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2019
-- Description:	validate Variant Adjustment Type of Change 
-- =============================================
-- Author     Date      Description
-- ------     -----     -----------
-- Asolosky   09/10/2019   Added row_idx
-- Ashaik12   01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- rwesley2   05/08/2020   US1600015 removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s46.sheet_name.
-- Ashaik12   09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_TYPE_OF_CHANGE] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
--++++++++++++++++++++++++++++++++++++
    -- type of change category validation
--++++++++++++++++++++++++++++++++++++
    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  Err.[type_of_change] as [ARWE02_ERROR_VALUE],
	  'Invalid Type of Change Category:  ' + Err.[type_of_change] as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  Err.sheet_name as [ARWE02_EXCEL_TAB_X],
	  row_idx                               as ARWE02_ROW_IDX,
	  change_id,  --Part index/change id
	  ''          --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
		  [type_of_change],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K],
		  sheet_name,
		  row_idx,
		  change_id
        FROM [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] S46
        WHERE Processing_ID=@GUID
	    and Not Exists
		      (Select 'X'
			     from  [dbo].[PARWA40_DSGN_ADJ_PART_CHG_TYP] a40
                where S46.[type_of_change] = a40.[ARWA40_DSGN_ADJ_PART_CHG_TYP_X]
              )
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
-- if the same Part Index occurs multiple times it must be under category MODIFY
--++++++++++++++++++++++++++++++++++++
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  Err.[part_index] as [ARWE02_ERROR_VALUE],
	  'Same part index occurs multiple times under different change types:  ' + Err.[part_index] as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'WARNING' as [ARWE02_ERROR_TYPE_X],
	  Err.sheet_name as [ARWE02_EXCEL_TAB_X],
	  row_idx                               as ARWE02_ROW_IDX,
	  change_id,  --Part index/change id
	  ''          --No ARROW Value
       FROM 
       (
        SELECT s46.[filename]
		      ,s46.Source_c
		      ,s46.[Processing_ID]
		      ,s46.[part_index]
		      ,s46.[type_of_change]
              ,s46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
		      ,COUNT(*) OVER (PARTITION BY 
		                 s46.[Processing_ID],s46.[part_index],s46.[filename]
			    	          ) AS PI_COUNT 
              ,s46.sheet_name
			  ,row_idx
			  ,change_id
        FROM  [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
        WHERE s46.Processing_ID       =  @GUID                  
		) Err   
   WHERE PI_COUNT > 1
     and ERR.[type_of_change] <> 'MODIFY' 
       ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
			 ,''
			 ,''
END CATCH;




GO
