DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_ADDED_PARTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		Ashaik12
-- Create date: 11/23/2019
-- Description:	Check if the Added part is being matched under multiple sub assemblies when adding to U18 
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 12-03-2019  rwesley2           Added supplier information to join for insert to @new_part_index 
-- 12/10/2019  ASHAIK12           Add filename,row_idx to MERGE ON Clause
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 05/08/2020  rwesley2  US1600015 removed hard-coded value for ARWE01_EXCEL_TAB_X and replaced with s46.sheet_name. 
-- 07/30/2020  Ashaik12  US1809333  Increase column sizes in temp table to match database column sizes.
-- 09/30/2020  Ashaik12  US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_VA_VALIDT_ADDED_PARTS] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;
BEGIN TRY
--  U18 and U19 INSERT 
-- TABLE variables to hold new Part Index
 DECLARE @new_part_index TABLE (
         NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
      --  ,NEW_CHANGE_ID VARCHAR (16) NOT NULL
      --  ,NEW_PART_NAME VARCHAR (128) NOT NULL
		,NEW_CCTSS int NOT NULL
	    ,row_idx INT
		,Processing_ID varchar(500)
		,filename varchar(500)
		,Ref_k int
		,Error_Flag varchar(50)
		,sheet_name VARCHAR(500)
		                        )
 	;
-- get new part index from s46 that is not on u18 when type of change is ADD    
INSERT INTO @new_part_index
       SELECT S46.part_index as not_matched_PI
  	     --    ,S46.change_id
	      --   ,S46.part_name
			 ,u09_view.[ARWU01_CCTSS_K]
 	         ,S46.[row_idx]
			 ,S46.Processing_ID
			 ,S46.filename
			 ,S46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
			 ,''
			 ,s46.sheet_name
       FROM [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] S46
	   JOIN dbo.[PARWS45_VA_COVER_PAGE_INFO]      S45
         on S45.Processing_ID       = S46.Processing_ID
        and S45.filename            = S46.filename
	           
	   join [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view       
	     on S45.[User_Selected_CTSP_N]            = u09_view.ARWU31_CTSP_N
		and S45.[User_Selected_CTSP_Region_C]     = u09_view.[ARWA06_RGN_C]
        and S45.[User_selected_WALK_VRNT_X]       = u09_view.[ARWU04_VRNT_N]
		and S45.[User_Selected_ENRG_SUB_CMMDTY_X] = u09_view.ARWA03_ENRG_SUB_CMMDTY_X
		and S45.[User_Selected_BNCMK_VRNT_N]      = u09_view.ARWU01_BNCHMK_VRNT_N
		and s45.[User_Selected_SUPL_N]            = u09_view.[ARWA17_SUPL_N]
		and s45.[User_Selected_SUPL_CNTRY_N]      = u09_view.[ARWA28_CNTRY_N] 
		and s45.[User_Selected_SUPL_C]            = u09_view.[ARWA17_SUPL_C]
		
	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u09_view.[ARWU01_CCTSS_K] = U18.[ARWU01_CCTSS_K]
		 AND S46.[part_index] = U18.ARWU18_BOM_PART_IX_N

       WHERE S46.Processing_ID       =  @Processing_ID 
	     and S46.type_of_change  = 'ADD'
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
;

-- Validate for 2 character match
MERGE INTO @new_part_index temp_table
USING
(
select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
from @new_part_index npi
JOIN PARWU18_BOM_PART U18
ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
AND   substring(npi.NEW_BOM_PART_IX_N,1,2) = substring(U18.[ARWU18_BOM_PART_IX_N],1,2)
JOIN PARWU17_BOM_SUB_ASSY U17
ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
) X
ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = '2 Char Pass'
;


-- Validate for 1 character
MERGE INTO @new_part_index temp_table
USING
(
select U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N, count(distinct ARWU17_BOM_SUB_ASSY_N) as Sub_Assy_count,npi.filename,npi.row_idx
from @new_part_index npi
JOIN PARWU18_BOM_PART U18
ON npi.NEW_CCTSS = U18.ARWU01_CCTSS_K
AND   substring(npi.NEW_BOM_PART_IX_N,1,1) = substring(U18.[ARWU18_BOM_PART_IX_N],1,1)
JOIN PARWU17_BOM_SUB_ASSY U17
ON    U18.ARWU17_BOM_SUB_ASSY_K = U17.ARWU17_BOM_SUB_ASSY_K
where U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K 
and npi.Error_Flag !='2 Char Pass'
and substring(npi.NEW_BOM_PART_IX_N,1,2) <> 'DP'
and substring(U18.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
group by  U18.ARWU01_CCTSS_K, npi.NEW_BOM_PART_IX_N,npi.filename,npi.row_idx having count(distinct ARWU17_BOM_SUB_ASSY_N)=1
) X
ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.NEW_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = '1 Char Pass'
;



MERGE INTO @new_part_index temp_table
USING
(
      SELECT npi.NEW_CCTSS        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
			,npi.filename
			,npi.row_idx
      FROM  @new_part_index npi
	  LEFT JOIN [PARWU18_BOM_PART] U18
        on u18.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	    and substring(u18.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_BOM_PART_IX_N,1,1)
		WHERE npi.Error_Flag =''
		and u18.[ARWU18_BOM_PART_IX_N] is NULL
    ) X

ON (
temp_table.NEW_CCTSS = X.[ARWU01_CCTSS_K]
AND temp_table.NEW_BOM_PART_IX_N = X.ARWU18_BOM_PART_IX_N
AND temp_table.filename = X.filename
AND temp_table.row_idx= X.row_idx
)
WHEN MATCHED THEN UPDATE
SET Error_Flag = 'No Sub-Assy'
;


INSERT INTO [dbo].PARWE02_BATCH_ERRORS
 select 
        'UI' AS [ARWE02_SOURCE_C] 
       ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
	   ,'ARROW is Unable to determine which Sub-Assembly the Added Part should belong to. First and Second Characters match Part Indexes from multiple Sub Assemblies' as [ARWE02_ERROR_X]
	   ,Processing_ID as [ARWE02_PROCESSING_ID]
	   ,FileName as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP  as [ARWE02_CREATE_S]
       ,@CDSID  as [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
       ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
	   ,sheet_name as [ARWE02_EXCEL_TAB_X]
	   ,row_idx as [ARWE02_ROW_IDX]
	   ,NEW_BOM_PART_IX_N as [ARWE02_Part_Index]
	   ,'' as [ARWE02_ARROW_Value] --No ARROW Value
 from @new_part_index 
 where Error_Flag=''

 INSERT INTO [dbo].PARWE02_BATCH_ERRORS
 select 
        'UI' AS [ARWE02_SOURCE_C] 
       ,NEW_BOM_PART_IX_N as [ARWE02_ERROR_VALUE]
	   ,'Invalid Part Index: No Sub-Assembly found for ADD Part index' as [ARWE02_ERROR_X]
	   ,Processing_ID as [ARWE02_PROCESSING_ID]
	   ,FileName as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP  as [ARWE02_CREATE_S]
       ,@CDSID  as [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
       ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	   ,Ref_K  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR' as [ARWE02_ERROR_TYPE_X]
	   ,sheet_name as [ARWE02_EXCEL_TAB_X]
	   ,row_idx as [ARWE02_ROW_IDX]
	   ,NEW_BOM_PART_IX_N as [ARWE02_Part_Index]
	   ,'' as [ARWE02_ARROW_Value] --No ARROW Value
 from @new_part_index 
 where Error_Flag='No Sub-Assy'
 ;


END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@Processing_ID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
			 ,''  --Part_index
		     ,''  --Arrow value	

END CATCH
;



GO
