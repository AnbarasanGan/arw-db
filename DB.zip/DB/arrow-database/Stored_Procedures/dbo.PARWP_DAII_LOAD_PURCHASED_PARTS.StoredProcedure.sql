DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_PURCHASED_PARTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 04/25/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/12/2019  asolosky		      Moved the deletes to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_PURCHASED_PARTS] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO PARWU38_PURC_PART_DSGN_ADJ
SELECT --ARWU38_PURC_PART_DSGN_ADJ_K is an identity 
        V04.ARWU08_CCTSS_DSGN_SUPL_K AS ARWU08_CCTSS_DSGN_SUPL_K
	  , S39.row_idx                  AS ARWU38_PURC_PART_DSPLY_SEQ_R
      , U37.ARWU37_CCTSS_DSGN_ADJ_K  AS ARWU37_CCTSS_DSGN_ADJ_K
	  , S39.part_specification       AS ARWU38_PURC_PART_SPEC_X
	  , source_supplier              AS ARWU38_SRC_SUPL_N

	  ,Case When LOC.ARWA28_CNTRY_K is Null then A28_EmptyStr.ARWA28_CNTRY_K Else LOC.ARWA28_CNTRY_K  End AS ARWA28_SRC_CNTRY_K

	  , A29.ARWA29_CRCY_K                     AS ARWA29_LCL_CRCY_K
	  , isNULL(no_of_pieces,0)                AS ARWU38_PCE_PER_SUB_ASSY_Q
	  , isNULL(purchased_price_per_piece,0)   AS ARWU38_PURC_PART_PER_PCE_A
	  , isNULL(inbound_packaging_costs,0)     AS ARWU38_INBND_PKNG_COST_PCE_A
	  , isNULL(inbound_logistics_costs,0)     AS ARWU38_INBND_LGSTCS_COST_PCE_A
	  , isNULL(tax_duty,0)                    AS ARWU38_TAX_AND_DUTY_PER_PCE_A
	  , isNULL(purchased_parts_markup_cost,0) AS ARWU38_PURC_PART_MRKP_P  --purchased_parts_markup_cost should be renamed in the database as purchased_parts_markup_p
	  , comments                              AS ARWU38_PURC_PART_ASSMP_CMT_X
	  , @TIME_STAMP                          AS ARWU38_CREATE_S
	  , @CDSID                                AS ARWU38_CREATE_USER_C
	  , @TIME_STAMP                          AS ARWU38_LAST_UPDT_S
	  , @CDSID                                AS ARWU38_LAST_UPDT_USER_C

  From PARWS34_DAII_COVER_PAGE_INFO       S34 
  JOIN PARWS39_DAII_PURCHASED_PARTS_INFO  S39
    ON S34.Processing_ID       = S39.Processing_ID
   AND S34.filename            = S39.filename

 -- Join with Supplier Quote View
      JOIN dbo.PARWV04_DSGN_SUPL V04
         ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
        AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
        AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
        AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
        AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
        AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
        AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
        AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
        AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
        AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
        AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

--Design Adjustment Part
  Join PARWU37_CCTSS_DSGN_ADJ  U37
    ON U37.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
   And U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  = S39.change_improvement_id
 --Currency
     JOIN PARWA29_CRCY        A29          ON A29.ARWA29_CRCY_C = S39.local_currency
 --Source-Country
Left JOIN PARWA28_CNTRY       LOC          ON LOC.ARWA28_CNTRY_N = S39.source_country
     JOIN [dbo].PARWA28_CNTRY A28_EmptyStr ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C  = ''
   
  Where S34.Processing_ID               = @GUIDIN
	AND S34.Skip_loading_due_to_error_f = 0
	AND S39.cost_type                   = 'Adjustment Costs'
;

GO
