SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 04/15/2020
-- Description:	Stored Procedure to validate End Item Alignment on PBOM to check if Base or Suffix is not blank
-- =============================================
-- Changes
-- =============================================
-- Author     Date     User Story  Description
-- ------     -----    ----------  -----------
-- asolosky 08/24/2020 US1804570   Added error message for end items over 32 char.
-- rwesley2 09-11-2020 US1910880   Add part index and Arrow value to error. Write error to new E02 error table
-- rwesley2	10-05-2020 US1968317   validation for decimal and slash (/) in end items 	
-- rwesley2	10-13-2020 US1968317/DE192081 added partition to validation for decimal and slash (/) in end items to only select error message once
-- Asolosky 10-20-2020 US1996362   Switch from E02 to E03 and include Excel column
-- Asolosky 03-20-2021 US2145305   New validation to check if the BoB has Tygra data and if so, validate the end item matches a Tygra end item.
-- Asolosky 04-29-2021 US2145305   Tygra end item validation. Renamed ARWA47_STRTG_PT_END_ITM_K to ARWA47_FEDEBOM_PLN_END_ITM_K
--                                 and renamed #FORD_END_ITEM_STARTING_POINT to #FORD_END_ITEM_
-- Asolosky 06-14-2021 US2546663   Execute PARWP_UI_CCTSS_VRNT_END_ITM @CCTSS_K - Added HAS_BOM_PART {yes,no} to show if Variant/FileType/End Item appears in U63
-- Asolosky 08-19-2021 US2793155   Changed the error message for End Item validation.  It now give the users 3 options on how to fix the error.
-- Ashaik12 11-16-2021 US3069324   Eliminate the End Item Validation against Tygra if the benchmark variant has only the non-cm control model on it
-- ASHAIK12 08-02-2022 US3876967   Remove drop if exists and use create or alter
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_PBOM_VALIDT_END_ITEMS] 
	-- Add the parameters for the stored procedure here
	 @GUID       varchar(500)
	,@CDSID      varchar(30)
	,@TIME_STAMP DATETIME
AS
Declare @CCTSS_K INT;

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Validate base and suffix are not blank
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
      SELECT
	      Validate.[Source_c]                          as [ARWE03_SOURCE_C],
	      Validate.part_index                          as [ARWE03_ERROR_VALUE], 
	      'End Item Alignment Requires That Both Base and Suffix Cannot Be Blank.'  as [ARWE03_ERROR_x],
	      Validate.[Processing_ID]                     as [ARWE03_PROCESSING_ID],
	      Validate.[file_name]                         as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
	      @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      Validate.[ARWS59_PBOM_PARTS]                 as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx                                      as ARWE03_ROW_IDX,
		  Validate.part_index                          as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  end_item_base_column                         as ARWE03_COLUMN
       FROM 
	   (SELECT 
               Processing_ID,
			   sub_assembly_name,
               part_index,
               Source_c,
               file_name,
               row_idx,
			   end_item_base_column,
               ARWS59_PBOM_PARTS,
               User_Selected_CTSP_N,
               row_number() over (partition by S59.Processing_ID, S59.part_index   Order by s59.part_index) as rownum
          FROM PARWS59_PBOM_PARTS s59 
         WHERE Processing_ID = @GUID
         and (part_index!='' and (RTRIM(end_item_prefix)!='' or RTRIM(end_item_base)!='' or RTRIM(end_item_suffix)!='') ) --This determines if there is something in the end item
         and (RTRIM(end_item_base)='' or RTRIM(end_item_suffix)='') --This determines something is missing from the base or suffix

         ) Validate
		 where rownum=1
		;

--Error for end_item_prefix over 32 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,end_item_prefix
		,'End Item Prefix can''t be more than 32 characters.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,end_item_prefix_column                as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @GUID
    and DATALENGTH(end_item_prefix)  > 32;

--Error for end_item_base over 32 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,end_item_base
		,'End Item Base can''t be more than 32 characters.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,end_item_base_column                  as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @GUID
    and DATALENGTH(end_item_base)  > 32;
	
--Error for end_item_suffix over 32 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,end_item_suffix
		,'End Item Suffix can''t be more than 32 characters.' 
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,end_item_suffix_column                as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @GUID
    and DATALENGTH(end_item_suffix)  > 32;

-- validation for slash
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       Err.Source_c                                 as [ARWE03_SOURCE_C],
	       staging_data_error_value                     as [ARWE03_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE03_ERROR_X],
	       Err.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       Err.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       Err.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       Err.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE03_ROW_IDX],
		   Err.part_index                               as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value,
		   error_column_cell                            as ARWE03_COLUMN
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS59_PBOM_PARTS
              ,Source_c
			  ,sub_assembly_name
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then end_item_prefix
				    when error_col = 'match_position_base_slash'    then end_item_base 
				    when error_col = 'match_position_suffix_slash'  then end_item_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then 'End Item Prefix contains a slash'
				    when error_col = 'match_position_base_slash'    then 'End Item Base contains a slash'
				    when error_col = 'match_position_suffix_slash'  then 'End Item Suffix contains a slash'

			   END as error_msg
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then end_item_prefix_column
				    when error_col = 'match_position_base_slash'    then end_item_base_column
				    when error_col = 'match_position_suffix_slash'  then end_item_suffix_column	
			   END as error_column_cell
			  ,part_index
			 from 
             (SELECT 
 			         Processing_ID
				    ,file_name
				    ,ARWS59_PBOM_PARTS
                    ,Source_c
					,sub_assembly_name
					,row_idx
					,end_item_prefix	
					,end_item_prefix_column				     
					,Case when CHARINDEX('/',end_item_prefix) > 0 then 1 else 0 end as match_position_prefix_slash 
					,end_item_base
					,end_item_base_column
					,case when CHARINDEX('/',end_item_base) > 0 then 1 else 0 end as match_position_base_slash   
					,end_item_suffix	
					,end_item_suffix_column				    
					,case when CHARINDEX('/',end_item_suffix ) > 0 then 1 else 0 end  as match_position_suffix_slash        
					,part_index  
                  ,row_number() over (partition by s59.Processing_ID, S59.part_index, end_item_prefix,end_item_base,end_item_suffix   Order by s59.part_index) as rownum
                FROM PARWS59_PBOM_PARTS S59
                WHERE Processing_ID = @GUID					
        ) S59
 
       unpivot (error_value for error_col in (
                                              match_position_prefix_slash 
                                              ,match_position_base_slash 
                                              ,match_position_suffix_slash
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;


-- validation for decimal 
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       Err.Source_c                                 as [ARWE03_SOURCE_C],
	       staging_data_error_value                     as [ARWE03_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE03_ERROR_X],
	       Err.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       Err.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       Err.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       Err.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE03_ROW_IDX],
		   Err.part_index                               as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value,
		   error_column_cell                            as ARWE03_COLUMN
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS59_PBOM_PARTS
              ,Source_c
			  ,sub_assembly_name
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then end_item_prefix
				    when error_col = 'match_position_base_decimal'    then end_item_base 
				    when error_col = 'match_position_suffix_decimal'  then end_item_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then 'End Item Prefix contains a decimal point'
				    when error_col = 'match_position_base_decimal'    then 'End Item Base contains a decimal point'
				    when error_col = 'match_position_suffix_decimal'  then 'End Item Suffix contains a decimal point'
			   END as error_msg
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then end_item_prefix_column
				    when error_col = 'match_position_base_decimal'    then end_item_base_column
				    when error_col = 'match_position_suffix_decimal'  then end_item_suffix_column	
			   END as error_column_cell
			  ,part_index
			 from 
             (SELECT 
 			         Processing_ID
				    ,file_name
				    ,ARWS59_PBOM_PARTS
                    ,Source_c
					,sub_assembly_name
					,row_idx
					,end_item_prefix
					,end_item_prefix_column
					,Case when CHARINDEX('.',end_item_prefix) > 0 then 1 else 0 end as match_position_prefix_decimal 
					,end_item_base
					,end_item_base_column
					,case when CHARINDEX('.',end_item_base) > 0 then 1 else 0 end as match_position_base_decimal    
					,end_item_suffix	
					,end_item_suffix_column	               							    
					,case when CHARINDEX('.',end_item_suffix ) > 0 then 1 else 0 end  as match_position_suffix_decimal  
                 	,part_index    
                 ,row_number() over (partition by s59.Processing_ID, S59.part_index, end_item_prefix,end_item_base,end_item_suffix   Order by s59.part_index) as rownum
                FROM PARWS59_PBOM_PARTS S59
               WHERE Processing_ID = @GUID					
        ) S59
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_decimal 
                                              ,match_position_base_decimal 
                                              ,match_position_suffix_decimal  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;

--Get the BoB key - @CCTSS_K
EXEC [dbo].[PARWP_GET_CCTSS_KEY]    @GUID, @CCTSS_K OUTPUT, @FILE_TYPE = 'PBOM'

--****************************************
--End item validation for 
--****************************************
Drop table if exists #FORD_END_ITEM;
CREATE TABLE #FORD_END_ITEM
(
 ARWU04_CCTSS_VRNT_K           INT
,ARWU04_BNCHMK_F               BIT
,ARWA54_TYGRA_FILE_TYPE_N      VARCHAR(MAX)
,ARWA47_FEDEBOM_PLN_END_ITM_K  INT
,ARWA47_FORD_END_ITM_PREF_N    VARCHAR(MAX)
,ARWA47_FORD_END_ITM_BSE_N     VARCHAR(MAX)
,ARWA47_FORD_END_ITM_SFX_N     VARCHAR(MAX)
,ARWUB3_STRTG_PT_PART_X        VARCHAR(MAX)
,HAS_BOM_PART                  VARCHAR(MAX)
);

INSERT INTO #FORD_END_ITEM Execute PARWP_UI_CCTSS_VRNT_END_ITM @CCTSS_K; 
--Select * from #FORD_END_ITEM_STARTING_POINT;

--Error when the end item doesn't match a Tygra end item. When the Tygra file is mapped, all PBOM parts must have an end item.
INSERT INTO PARWE03_BATCH_PBOM_ERRORS
  Select 
		 Source_c
		,Case When end_item_prefix = '' and end_item_base = '' and end_item_suffix = ''
		      Then ''
			  Else end_item_prefix + '-' + end_item_base + '-' + end_item_suffix
		 End
		, 'End Item does not match a Tygra End Item. Please verify the following in ARROW Tygra Mapping: ' +
		  '1. The Starting Point Prefix/Base/Suffix is marked as In Scope, ' +
		  '2. Has a Job1 Target Cost, ' +
		  '3. Is mapped to a Benchmark Variant'
		,@GUID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,end_item_suffix_column                as ARWE03_COLUMN
  From
      (SELECT 
               Processing_ID
              ,sub_assembly_name
              ,part_index
              ,Source_c
              ,file_name
              ,row_idx
      		  ,end_item_prefix
      		  ,end_item_base
      		  ,end_item_suffix
              ,end_item_suffix_column
              ,ARWS59_PBOM_PARTS
              ,User_Selected_CTSP_N
      		  ,row_number() over (partition by S59.Processing_ID, S59.part_index   Order by s59.part_index) as rownum
         From PARWS59_PBOM_PARTS S59 
        Where Processing_ID    = @GUID
         and exists (Select 'X'
      	              From PARWUB6_CCTSS_TYGRA_FILE UB6
      				  Join PARWA54_TYGRA_FILE_TYPE  A54 ON A54.ARWA54_TYGRA_FILE_TYPE_K = UB6.ARWA54_TYGRA_FILE_TYPE_K
      				 Where UB6.ARWU01_CCTSS_K           = @CCTSS_K
      				   and A54.ARWA54_TYGRA_FILE_TYPE_N = 'Scope'
      			   )
		and not exists (
		select 'X' from
				(
				select U04.[ARWU01_CCTSS_K],U04.[ARWU04_VRNT_N],U04.ARWU04_BNCHMK_F,A09.ARWA05_ENRG_PGM_C, ARWA08_CCM_C, 
				COUNT(ARWA08_CCM_C) OVER (PARTITION BY U04.[ARWU01_CCTSS_K]) as cm_count
				from PARWU05_CCTSS_VRNT_CCM U05
				JOIN PARWU04_CCTSS_VRNT_FLAT U04 ON U04.[ARWU04_CCTSS_VRNT_K] = U05.[ARWU04_CCTSS_VRNT_K]
				JOIN PARWA09_PGM_CCM_FLAT A09 on A09.[ARWA09_PGM_CCM_K]=U05.[ARWA09_PGM_CCM_K]
				where [ARWU04_BNCHMK_F]=1
				and U04.[ARWU01_CCTSS_K]=@CCTSS_K
				) X
				where cm_count=1 and ARWA08_CCM_C = 'Non CM'
					)
      	and not exists (select 'X'
                          From #FORD_END_ITEM EI 
                         Where EI.ARWA47_FORD_END_ITM_PREF_N = S59.end_item_prefix
                           And EI.ARWA47_FORD_END_ITM_BSE_N  = S59.end_item_base
                           And EI.ARWA47_FORD_END_ITM_SFX_N  = S59.end_item_suffix
      					   And EI.ARWA54_TYGRA_FILE_TYPE_N   = 'Scope'
      					   and EI.ARWU04_BNCHMK_F            = 1
      	               )

      ) Stg
      Where rownum = 1
;

Drop table if exists #FORD_END_ITEM;

END TRY

BEGIN CATCH
Drop table if exists #FORD_END_ITEM;
INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE
             ,''                               -- Column
END CATCH





GO
