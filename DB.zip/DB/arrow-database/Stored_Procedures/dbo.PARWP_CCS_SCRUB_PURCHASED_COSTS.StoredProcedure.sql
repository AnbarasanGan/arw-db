DROP PROCEDURE [dbo].[PARWP_CCS_SCRUB_PURCHASED_COSTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 04/15/2019
-- Description:	Set Warning message that a purchased part also has raw materials or processing costs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asolosky   07/16/2019  Changed 'SubAssemly' to 'Sub Assembly' in the insert to error table
--                        Changed the queries to an exist and the joins by the actual keys on the table.  The original query took a long time.
-- Ashaik12   01/10/2020  Added TimeStamp parameter
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_CCS_SCRUB_PURCHASED_COSTS] 
-- Input Parameter
 @GUID   varchar(5000) 
,@CDSID  varchar(30)
,@TIME_STAMP DATETIME

AS

	SET NOCOUNT ON;
------------------------------------------------------------
-- Purchased cost has a raw material cost
------------------------------------------------------------
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select  
		 Err.[Source_c]
        ,Err.[ARWU18_BOM_PART_IX_N]
		,'Purchased Cost has a Raw Material Cost' --as Error_Msg
        ,Err.[Processing_ID]
        ,Err.[Filename]
		,object_name(@@PROCID) --AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
 		,@TIME_STAMP 
		,@CDSID
        ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
		,'Purchased Parts and Raw Materials'
		--identity key place holder		
		,'WARNING'
		,'Sub Assembly' + ' - ' + Err.[ARWU17_BOM_SUB_ASSY_N]
		,0 AS ARWE02_ROW_IDX
		,ARWU18_BOM_PART_IX_N
		,''
    FROM
    (	
	  SELECT v11.ARWU31_CTSP_N
             ,v11.[ARWA06_RGN_C] 
	         ,v11.[ARWA03_ENRG_SUB_CMMDTY_X]
	         ,v11.[ARWU17_BOM_SUB_ASSY_N]
	         ,v11.[ARWU18_BOM_PART_IX_N]
	         ,v11.[ARWA34_VEH_MDL_N]
	         ,v11.[ARWA17_SUPL_N]
             ,s22.[Source_c]
	         ,s22.[Processing_ID]
	         ,s22.[filename]
	         ,s22.[ARWS22_CCS_COVER_PAGE_INFO_K]
       FROM [dbo].[PARWV11_CCS_PURCHASED_PARTS_FLAT] v11
       JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
         ON v11.ARWU31_CTSP_N                = s22.[User_Selected_CTSP_N]
        and v11.[ARWA06_RGN_C]               = s22.[User_Selected_CTSP_Region_C]
        and v11.[ARWA03_ENRG_SUB_CMMDTY_X]   = s22.[User_Selected_ENRG_SUB_CMMDTY_X]
	    AND v11.ARWU01_BNCHMK_VRNT_N         = s22.[User_Selected_BNCMK_VRNT_N]
        and v11.[ARWA34_VEH_MDL_N]           = s22.[User_Selected_VEH_MDL_N]
        and v11.[ARWA35_DSGN_VEH_MDL_YR_C]   = s22.[User_Selected_VEH_MDL_YR_C]
        and v11.[ARWA35_DSGN_VEH_MDL_VRNT_X] = s22.[User_Selected_VEH_MDL_VRNT_X]
        and v11.[ARWA17_SUPL_N]              = s22.[User_Selected_SUPL_N]
	    AND v11.ARWA28_CNTRY_N               = s22.[User_Selected_SUPL_CNTRY_N]
	    AND v11.ARWA17_SUPL_C			     = s22.[User_Selected_SUPL_C]
	  WHERE S22.Processing_ID                  = @GUID
	  AND exists
	(Select 'X'
	   from [dbo].[PARWV10_CCS_RAW_MATERIALS_FLAT] v10
      WHERE v11.ARWU08_CCTSS_DSGN_SUPL_K = v10.ARWU08_CCTSS_DSGN_SUPL_K
        and v11.ARWU17_BOM_SUB_ASSY_K = v10.ARWU17_BOM_SUB_ASSY_K
        and v11.[ARWU18_BOM_PART_IX_N] = v10.[ARWU18_BOM_PART_IX_N]
    )
	
   ) Err
;

------------------------------------------------------------
-- Purchased cost has a processing cost
------------------------------------------------------------
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select  
		 Err.[Source_c]
        ,Err.[ARWU18_BOM_PART_IX_N]
		,'Purchased Cost has a Processing Cost' as Error_Msg
        ,Err.[Processing_ID]
        ,Err.[Filename]
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
 		,@TIME_STAMP 
		,@CDSID
        ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
		,'Purchased Parts and Processing'
		--identity key place holder		
		,'WARNING'
		,'Sub Assembly' + ' - ' + Err.[ARWU17_BOM_SUB_ASSY_N]
		,0 AS ARWE02_ROW_IDX
		,ARWU18_BOM_PART_IX_N
		,''
    FROM
    (	
	  SELECT v11.ARWU31_CTSP_N
             ,v11.[ARWA06_RGN_C] 
	         ,v11.[ARWA03_ENRG_SUB_CMMDTY_X]
	         ,v11.[ARWU17_BOM_SUB_ASSY_N]
	         ,v11.[ARWU18_BOM_PART_IX_N]
	         ,v11.[ARWA34_VEH_MDL_N]
	         ,v11.[ARWA17_SUPL_N]
             ,s22.[Source_c]
	         ,s22.[Processing_ID]
	         ,s22.[filename]
	         ,s22.[ARWS22_CCS_COVER_PAGE_INFO_K]
       FROM [dbo].[PARWV11_CCS_PURCHASED_PARTS_FLAT] v11
       JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
         ON v11.ARWU31_CTSP_N                = s22.[User_Selected_CTSP_N]
        and v11.[ARWA06_RGN_C]               = s22.[User_Selected_CTSP_Region_C]
        and v11.[ARWA03_ENRG_SUB_CMMDTY_X]   = s22.[User_Selected_ENRG_SUB_CMMDTY_X]
	    AND v11.ARWU01_BNCHMK_VRNT_N         = s22.[User_Selected_BNCMK_VRNT_N]
	    and v11.[ARWA34_VEH_MDL_N]           = s22.[User_Selected_VEH_MDL_N]
        and v11.[ARWA35_DSGN_VEH_MDL_YR_C]   = s22.[User_Selected_VEH_MDL_YR_C]
        and v11.[ARWA35_DSGN_VEH_MDL_VRNT_X] = s22.[User_Selected_VEH_MDL_VRNT_X]
        and v11.[ARWA17_SUPL_N]              = s22.[User_Selected_SUPL_N]
	    AND v11.ARWA28_CNTRY_N               = s22.[User_Selected_SUPL_CNTRY_N]
	    AND v11.ARWA17_SUPL_C			     = s22.[User_Selected_SUPL_C]
	  WHERE S22.Processing_ID                = @GUID
	    AND exists
	       (Select 'X'
              From [dbo].[PARWV12_CCS_PROCESSING_COSTS_FLAT] v12
             WHERE v11.ARWU08_CCTSS_DSGN_SUPL_K = v12.ARWU08_CCTSS_DSGN_SUPL_K
               and v11.ARWU17_BOM_SUB_ASSY_K    = v12.ARWU17_BOM_SUB_ASSY_K
               and v11.[ARWU18_BOM_PART_IX_N]   = v12.[ARWU18_BOM_PART_IX_N]
           )
 	) Err
	;

GO
