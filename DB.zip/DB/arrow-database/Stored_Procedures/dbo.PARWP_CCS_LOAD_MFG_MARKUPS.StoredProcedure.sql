DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_MFG_MARKUPS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ashaik12
-- Create date: 04/02/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 06/13/2019  ASHAIK12  N/A      Make all join conditions from cover page columns to user selected columns. And Remove the join for Engineering Commodity.
-- 06/17/2019  asolosky  N/A      Change the delete from design_supplier/sub-assembly/Markup_Type to just design_supplier
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 08/13/2019  ashaik12           Removed Delete Statement
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_MFG_MARKUPS] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

----------------- Insert into U28
INSERT INTO [dbo].[PARWU28_MFG_MRKP]
SELECT
   SUPL_QUTE.ARWU08_CCTSS_DSGN_SUPL_K as [ARWU08_CCTSS_DSGN_SUPL_K]
  ,SUPL_QUTE.[ARWU17_BOM_SUB_ASSY_K] as [ARWU17_BOM_SUB_ASSY_K]
  ,A38.ARWA38_MFG_MRKP_TYP_K as [ARWA38_MFG_MRKP_TYP_K]
  ,isNULL(mfg_markup.manufacturing_markup_value,0) as [ARWU28_MFG_MRKP_P]
  --,CASE WHEN mfg_markup.manufacturing_markup_value IS NULL THEN '0' ELSE mfg_markup.manufacturing_markup_value*100 END AS [ARWU28_MFG_MRKP_P]
  ,isNULL(mfg_markup.comments,'') as [ARWU28_MFG_MRKP_ASSMP_CMT_X]
  ,@TIME_STAMP as [ARWU28_CREATE_S]
  ,@CDSID
  ,@TIME_STAMP
  ,@CDSID
 from [dbo].[PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO] mfg_markup
 JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] cover_page_stage
 ON cover_page_stage.Processing_ID=mfg_markup.Processing_ID
 AND cover_page_stage.filename=mfg_markup.filename

-- SUPPLIER QUOTE MFG MARKUPS VIEW
JOIN [dbo].[PARWV09_CCS_BOM_SUB_ASSEMBLY] SUPL_QUTE
--ON cover_page_stage.Eng_commodity_name=SUPL_QUTE.ARWA02_ENRG_CMMDTY_X
ON cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]=SUPL_QUTE.[ARWA03_ENRG_SUB_CMMDTY_X]
AND cover_page_stage.[User_Selected_CTSP_N]=SUPL_QUTE.ARWU31_CTSP_N
AND cover_page_stage.[User_Selected_CTSP_Region_C]=SUPL_QUTE.[ARWA06_RGN_C]
AND cover_page_stage.[User_Selected_VEH_MAKE_N]=SUPL_QUTE.[ARWA14_VEH_MAKE_N]
AND cover_page_stage.[User_Selected_VEH_MDL_N]=SUPL_QUTE.[ARWA34_VEH_MDL_N]
AND cover_page_stage.[User_Selected_VEH_MDL_YR_C]=SUPL_QUTE.ARWA35_DSGN_VEH_MDL_YR_C
AND cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]=SUPL_QUTE.ARWA35_DSGN_VEH_MDL_VRNT_X
AND cover_page_stage.[User_Selected_BNCMK_VRNT_N]=SUPL_QUTE.[ARWU01_BNCHMK_VRNT_N]
AND cover_page_stage.[User_Selected_SUPL_N]=SUPL_QUTE.ARWA17_SUPL_N
AND cover_page_stage.[User_Selected_SUPL_CNTRY_N]=SUPL_QUTE.ARWA28_CNTRY_N
AND cover_page_stage.[User_Selected_SUPL_C]=SUPL_QUTE.ARWA17_SUPL_C
AND mfg_markup.sub_assembly_name= SUPL_QUTE.[ARWU17_BOM_SUB_ASSY_N]
--AND mfg_markup.supplier_name=SUPL_QUTE.[ARWA17_SUPL_N]
-- Get A38 Key
JOIN [dbo].[PARWA38_MFG_MRKP_TYP] A38
ON mfg_markup.manufacturing_markup_desc=A38.[ARWA38_MFG_MRKP_TYP_X]
where cover_page_stage.Processing_ID               = @Processing_ID
  AND cover_page_stage.Skip_loading_due_to_error_f = 0
--  AND mfg_markup.manufacturing_markup_value       !=0
 
 ;








-- Insert into Final assembly markups table
INSERT INTO [dbo].[PARWU30_FNL_ASSY_MRKP]
Select V04.ARWU08_CCTSS_DSGN_SUPL_K
      ,Staging.ARWA38_MFG_MRKP_TYP_K
      ,isNULL(Staging.manufacturing_markup_value,0) as ARWU30_FNL_ASSY_MRKP_P
      ,isNULL(Staging.comments,'')                  as ARWU30_FNLASSYMRKP_ASSMP_CMT_X
      ,@TIME_STAMP                                 as ARWU30_CREATE_S
      ,@CDSID                                       as ARWU30_CREATE_USER_C
      ,@TIME_STAMP                                 as ARWU30_LAST_UPDT_S
	  ,@CDSID                                       as ARWU30_LAST_UPDT_USER_C
  From PARWV04_DSGN_SUPL V04
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
			 ,S18.manufacturing_markup_value
			 ,S18.comments
             ,A38.ARWA38_MFG_MRKP_TYP_K 
			 ,A38.ARWA38_MFG_MRKP_TYP_C
			 ,A38.ARWA38_MFG_MRKP_TYP_X
       from [dbo].[PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO] S18
       JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO]                           cover_page_stage
         ON cover_page_stage.Processing_ID       = S18.Processing_ID
        AND cover_page_stage.filename            = S18.filename
	   JOIN [dbo].[PARWA38_MFG_MRKP_TYP] A38
         ON S18.manufacturing_markup_desc        = A38.[ARWA38_MFG_MRKP_TYP_X]
      where cover_page_stage.Processing_ID               = @Processing_ID
        AND cover_page_stage.Skip_loading_due_to_error_f = 0
        AND S18.sub_assembly_name                        = 'Final assembly'
      ) Staging
    ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X] = V04.[ENG_SUB_CMMDTY_DESC]
   AND Staging.[User_Selected_CTSP_N]               = V04.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]                = V04.[CTSP_REGION_CODE]
   AND Staging.[User_Selected_VEH_MAKE_N]          = V04.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]          = V04.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]     = V04.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]            = V04.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]     = V04.[VARIANT]
   AND Staging.[User_Selected_SUPL_N]         = V04.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]      = V04.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]         = V04.ARWA17_SUPL_C
--   AND Staging.manufacturing_markup_value!=0
 ;

GO
