SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Ashaik12
-- Create date: 2021-12-06
-- Description:	
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
--
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_DELETE_D14_TRADEOFF_SUMMARY]
@ARWU01_CCTSS_K        int
AS
--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

DELETE FROM [dbo].PARWD14_TRADEOFF_SUMMARY 
WHERE ARWU01_CCTSS_K = @ARWU01_CCTSS_K;

--  Select OBJECT_NAME(@@PROCID) as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
