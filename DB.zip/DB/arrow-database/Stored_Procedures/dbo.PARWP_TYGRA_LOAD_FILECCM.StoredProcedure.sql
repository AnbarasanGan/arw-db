DROP PROCEDURE [dbo].[PARWP_TYGRA_LOAD_FILECCM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/23/2020
-- Description:	Load the data in UB1 from S61 on TYGRA Load
-- =============================================

-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   03-19-2021  Added case for nick name match and region match
-- rwesley2   03-22-2021  cast s61 and a07 model year as decimal 6,2
-- ashaik12   03-30-2021  Added logic to use S63 mapping table for region conversions
-- ashaik12   04-06-2021  Added Model year to S63 join
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- Ashaik12   04-28-2021  Add Vehicle name to the join to S63   
-- Ashaik12   04-29-2021  Change query to merge so that it does not fail on inserting duplicates when loading data for multiple BoB's
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- rwesley2   05-21-2021  DEFECT US2555418 add @load_to_pgm_name to UB2 SP 
-- rwesley2   06-09-2021  US2604963 Add tygra file version number to join with UB1
-- rwesley    09-30-2021  US2879211 - load Current files. Change CM_NICKNAME to CCM in join
--                        replaced SUBSTRING with CASE 
-- ashaik12   02-15-2022  US3305905 Add CM10 to CM25
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_TYGRA_LOAD_FILECCM] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(MAX) 
	,@CDSID varchar(MAX)
	,@load_to_pgm_name varchar(MAX) 
    ,@version  int
	,@TIME_STAMP DATETIME

--	,@program_name varchar(MAX)
AS

SET NOCOUNT ON;

MERGE INTO [dbo].[PARWUB2_TYGRA_FILE_CCM] UB2
USING
(
select  
UB1.ARWUB1_TYGRA_FILE_K
, A09.ARWA09_PGM_CCM_K
from [dbo].[PARWS61_TYGRA_TITLE_PAGE] S61 
JOIN PARWUB1_TYGRA_FILE UB1 
ON S61.file_name = UB1.ARWUB1_TYGRA_FILE_N
and ub1.ARWUB1_TYGRA_FILE_REV_R = @version 
JOIN PARWA09_PGM_CCM_FLAT A09 	
--on s61.CM_NICKNAME = A09.ARWA08_CCM_C	
--on substring(s61.CCM,2, datalength(s61.CCM)) = A09.ARWA08_CCM_C
on CASE WHEN s61.CCM='CCM1' THEN 'CM1'
        WHEN s61.CCM='CCM2' THEN 'CM2'
        WHEN s61.CCM='CCM3' THEN 'CM3'
        WHEN s61.CCM='CCM4' THEN 'CM4'
        WHEN s61.CCM='CCM5' THEN 'CM5'
        WHEN s61.CCM='CCM6' THEN 'CM6'
        WHEN s61.CCM='CCM7' THEN 'CM7'
        WHEN s61.CCM='CCM8' THEN 'CM8'
        WHEN s61.CCM='CCM9' THEN 'CM9'
        WHEN s61.CCM='CCM10' THEN 'CM10'
        WHEN s61.CCM='CCM11' THEN 'CM11'
        WHEN s61.CCM='CCM12' THEN 'CM12'
        WHEN s61.CCM='CCM13' THEN 'CM13'
        WHEN s61.CCM='CCM14' THEN 'CM14'
        WHEN s61.CCM='CCM15' THEN 'CM15' 
	WHEN s61.CCM='CCM16' THEN 'CM16' 
	WHEN s61.CCM='CCM17' THEN 'CM17' 
	WHEN s61.CCM='CCM18' THEN 'CM18' 
	WHEN s61.CCM='CCM19' THEN 'CM19' 
	WHEN s61.CCM='CCM20' THEN 'CM20' 
	WHEN s61.CCM='CCM21' THEN 'CM21' 
	WHEN s61.CCM='CCM22' THEN 'CM22' 
	WHEN s61.CCM='CCM23' THEN 'CM23' 
	WHEN s61.CCM='CCM24' THEN 'CM24' 
	WHEN s61.CCM='CCM25' THEN 'CM25' 
		END = A09.ARWA08_CCM_C
AND S61.[CM_PROGRAM] = A09.ARWA05_ENRG_PGM_C
JOIN PARWS63_TYGRA_CM_MAPPING S63
ON S63.[ARROW_CM] = A09.ARWA08_CCM_C
AND S63.[ARROW_REGION] = A09.ARWA06_RGN_C
AND S63.[PROGRAM] = A09.ARWA05_ENRG_PGM_C
AND S63.ARROW_MDL_YR = A09.ARWA07_MDL_YR_C
AND S63.VEHICLE_NAME = @load_to_pgm_name 
where S61.Processing_ID=@GUID
) SRC
ON (SRC.ARWUB1_TYGRA_FILE_K = UB2.ARWUB1_TYGRA_FILE_K
AND SRC.ARWA09_PGM_CCM_K = UB2.ARWA09_PGM_CCM_K)
WHEN NOT MATCHED THEN INSERT
VALUES
(
  SRC.[ARWA09_PGM_CCM_K]
, @TIME_STAMP
, @CDSID
, @TIME_STAMP
, @CDSID
, SRC.[ARWUB1_TYGRA_FILE_K]
)

;

GO
