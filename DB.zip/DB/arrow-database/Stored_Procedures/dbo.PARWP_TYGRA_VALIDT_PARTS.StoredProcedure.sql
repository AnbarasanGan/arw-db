SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		rwesley2
-- Create date: 05/28/2020
-- Description:	Validate Tygra parts
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2021  US2456423 add non_cms to check for part assigned to CM
-- rwesley2   04-20-2021  US2453456 use MAX length when declaring a variable 
-- rwesley2   07-26-2021  US2567598 new validation: same part, same engineering commodity, different description then WARNING
-- rwesley2   07-26-2021  US2567597 new validation: same eng commodity/CM pairing with the same part multiple times then WARNING
-- rwesley2   04-04-2022  US3482265 changed 2 validations and a temp table to include all 25 CMs	
-- rwesley2   05-12-2022  US3617161 increase CMX varchar(5) to to varchar(max) on #TYGRA_SUMMARY
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_PARTS] 
-- Input Parameter
 @GUID varchar(MAX)
,@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

-- validate surrogate parts must be assigned to a CM
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,err.[Surrogate_Part_Prefix] + '-' + err.[Surrogate_Part_Base] + '-' + err.[Surrogate_Part_Suffix]
		,'Surrogate part part not assigned to a Control Model'   as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.[ARWS62_TYGRA_SUMMARY]
		,'PARWS62_TYGRA_SUMMARY'  
        ,'WARNING'                       
		,'Tygra Parts'  as sheet_name
		,Err.row_idx
		,Err.engineering_commodity
		,Err.[Vehicle_name]

    FROM
    (	
	  SELECT S62.*
	        ,row_number() OVER (PARTITION BY s62.vehicle_name, s62.engineering_commodity
			,s62.vehicle_name, s62.Surrogate_Part_Prefix, s62.Surrogate_Part_Base, s62.[Surrogate_Part_Suffix]
			order by s62.vehicle_name, s62.Surrogate_Part_Prefix, s62.Surrogate_Part_Base, s62.[Surrogate_Part_Suffix]) as rownum
	    FROM [dbo].[PARWS62_TYGRA_SUMMARY]  S62
	   WHERE s62.Processing_ID = @GUID
  	   and (s62.cm1 = 0 or s62.cm1 is NULL) and 
	   (s62.cm2 = 0 or s62.cm2 is NULL) and 
	   (s62.cm3 = 0 or s62.cm3 is NULL) and 
	   (s62.cm4 = 0 or s62.cm4 is NULL) and 
	   (s62.cm5 = 0 or s62.cm5 is NULL) and 
	   (s62.cm6 = 0 or s62.cm6 is NULL) and 
	   (s62.cm7 = 0 or s62.cm7 is NULL) and 
	   (s62.cm8 = 0 or s62.cm8 is NULL) and 
	   (s62.cm9 = 0 or s62.cm9 is NULL) and
	   (s62.cm10 = 0 or s62.cm10 is NULL) and
   	   (s62.cm11 = 0 or s62.cm11 is NULL) and
	   (s62.cm12 = 0 or s62.cm12 is NULL) and
   	   (s62.cm13 = 0 or s62.cm13 is NULL) and
	   (s62.cm14 = 0 or s62.cm14 is NULL) and
   	   (s62.cm15 = 0 or s62.cm15 is NULL) and
	   (s62.cm16 = 0 or s62.cm16 is NULL) and
   	   (s62.cm17 = 0 or s62.cm17 is NULL) and
	   (s62.cm18 = 0 or s62.cm18 is NULL) and
   	   (s62.cm19 = 0 or s62.cm19 is NULL) and
	   (s62.cm20 = 0 or s62.cm20 is NULL) and
   	   (s62.cm21 = 0 or s62.cm21 is NULL) and
	   (s62.cm22 = 0 or s62.cm22 is NULL) and
   	   (s62.cm23 = 0 or s62.cm23 is NULL) and
	   (s62.cm24 = 0 or s62.cm24 is NULL) and
   	   (s62.cm25 = 0 or s62.cm25 is NULL) and
	   (s62.non_cm1 =0 or s62.non_cm1 is NULL) and  
	   (s62.non_cm2 =0 or s62.non_cm2 is NULL) and  
	   (s62.non_cm3 =0 or s62.non_cm3 is NULL) and  
	   (s62.non_cm4 =0 or s62.non_cm4 is NULL) and  
	   (s62.non_cm5 =0 or s62.non_cm5 is NULL) and  
	   (s62.non_cm6 =0 or s62.non_cm6 is NULL) and  
	   (s62.non_cm7 =0 or s62.non_cm7 is NULL) and  
	   (s62.non_cm8 =0 or s62.non_cm8 is NULL) and
	   (s62.non_cm9 =0 or s62.non_cm9 is NULL) 
	   and (s62.[Surrogate_Part_Base] <> '' or s62.[Surrogate_Part_Base] is not NULL) 
	   )Err
	Where rownum = 1
	;
-- validate start point parts must be assigned to a CM
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,err. [Start_Point_Part_Prefix]+ '-' + err.[Start_Point_Part_Base] + '-' + err.[Start_Point_Part_Suffix]
		,'Start point part not assigned to a Control Model'   as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.[ARWS62_TYGRA_SUMMARY]
		,'PARWS62_TYGRA_SUMMARY'  
        ,'WARNING'                       
		,'Tygra Parts'  as sheet_name
		,Err.row_idx
		,Err.engineering_commodity
		,Err.[Vehicle_name]

    FROM
    (	
	  SELECT S62.*
	        ,row_number() OVER (PARTITION BY s62.vehicle_name, s62.engineering_commodity
			,s62.vehicle_name, s62.Start_Point_Part_Prefix, s62.Start_Point_Part_Base, s62.Start_Point_Part_Suffix
			order by s62.vehicle_name, s62.Start_Point_Part_Prefix, s62.Start_Point_Part_Base, s62.Start_Point_Part_Suffix) as rownum
	    FROM [dbo].[PARWS62_TYGRA_SUMMARY]  S62
	   WHERE s62.Processing_ID = @GUID
    	   and (s62.cm1 = 0 or s62.cm1 is NULL) and 
	   (s62.cm2 = 0 or s62.cm2 is NULL) and 
	   (s62.cm3 = 0 or s62.cm3 is NULL) and 
	   (s62.cm4 = 0 or s62.cm4 is NULL) and 
	   (s62.cm5 = 0 or s62.cm5 is NULL) and 
	   (s62.cm6 = 0 or s62.cm6 is NULL) and 
	   (s62.cm7 = 0 or s62.cm7 is NULL) and 
	   (s62.cm8 = 0 or s62.cm8 is NULL) and 
	   (s62.cm9 = 0 or s62.cm9 is NULL) and
	   (s62.cm10 = 0 or s62.cm10 is NULL) and
   	   (s62.cm11 = 0 or s62.cm11 is NULL) and
	   (s62.cm12 = 0 or s62.cm12 is NULL) and
   	   (s62.cm13 = 0 or s62.cm13 is NULL) and
	   (s62.cm14 = 0 or s62.cm14 is NULL) and
   	   (s62.cm15 = 0 or s62.cm15 is NULL) and
	   (s62.cm16 = 0 or s62.cm16 is NULL) and
   	   (s62.cm17 = 0 or s62.cm17 is NULL) and
	   (s62.cm18 = 0 or s62.cm18 is NULL) and
   	   (s62.cm19 = 0 or s62.cm19 is NULL) and
	   (s62.cm20 = 0 or s62.cm20 is NULL) and
   	   (s62.cm21 = 0 or s62.cm21 is NULL) and
	   (s62.cm22 = 0 or s62.cm22 is NULL) and
   	   (s62.cm23 = 0 or s62.cm23 is NULL) and
	   (s62.cm24 = 0 or s62.cm24 is NULL) and
   	   (s62.cm25 = 0 or s62.cm25 is NULL) and
	   (s62.non_cm1 =0 or s62.non_cm1 is NULL) and  
	   (s62.non_cm2 =0 or s62.non_cm2 is NULL) and  
	   (s62.non_cm3 =0 or s62.non_cm3 is NULL) and  
	   (s62.non_cm4 =0 or s62.non_cm4 is NULL) and  
	   (s62.non_cm5 =0 or s62.non_cm5 is NULL) and  
	   (s62.non_cm6 =0 or s62.non_cm6 is NULL) and  
	   (s62.non_cm7 =0 or s62.non_cm7 is NULL) and  
	   (s62.non_cm8 =0 or s62.non_cm8 is NULL) and
	   (s62.non_cm9 =0 or s62.non_cm9 is NULL) 
	   and (s62.[Start_Point_Part_Base] <> '' or s62.[Start_Point_Part_Base] is not NULL)   
	) Err
	Where rownum = 1
	;

--validation for same part, same engineering commodity, different description
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
   Select 
    'TYGRA'
	,err.start_pt_part
	,'The same part has different descriptions for the same engineering commodity'   as Error_Msg
    ,err.Processing_ID 
	,Err.file_name
	,object_name(@@PROCID) AS Procedure_x
	,@TIME_STAMP 
	,@CDSID
	,@TIME_STAMP 
	,@CDSID
    ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
    ,'PARWS62_TYGRA_SUMMARY'    as [ARWE02_STAGING_TABLE_X]
    ,'WARNING'                 as [ARWE02_ERROR_TYPE_X]
    ,''                        as [ARWE02_EXCEL_TAB_X]
    ,''                        as [ARWE02_ROW_IDX]
    ,err.[Start_Point_Part_Desc]                  as [ARWE02_Part_Index]
    ,err.engineering_commodity   as [ARWE02_ARROW_Value]

    FROM
    (	
select s62.[Vehicle_name]
,s62.[Engineering_Commodity]
,s62.[Start_Point_Part_Prefix] + '-' + s62.[Start_Point_Part_Base] + '-' + s62.[Start_Point_Part_Suffix] as start_pt_part
,s62.[Start_Point_Part_Desc]
,s62.processing_id
,s62.file_name
from PARWS62_TYGRA_SUMMARY s62
join PARWS62_TYGRA_SUMMARY s62d
on s62.[Start_Point_Part_Prefix] + '-' + s62.[Start_Point_Part_Base] + '-' + s62.[Start_Point_Part_Suffix] =  
           s62d.[Start_Point_Part_Prefix] + '-' + s62d.[Start_Point_Part_Base] + '-' + s62d.[Start_Point_Part_Suffix]
and s62.Engineering_Commodity = s62d.Engineering_Commodity
and s62.Processing_ID = s62d.processing_id
and s62.Start_Point_Part_Desc <> s62d.Start_Point_Part_Desc
where s62.[Start_Point_Part_Prefix] + '-' + s62.[Start_Point_Part_Base] + '-' + s62.[Start_Point_Part_Suffix] is not null
and s62.Start_Point_Part_Desc is not null
and s62.Processing_ID = @GUID
group by s62.[Vehicle_name],s62.[Engineering_Commodity]
,s62.[Start_Point_Part_Prefix] + '-' + s62.[Start_Point_Part_Base] + '-' + s62.[Start_Point_Part_Suffix]
,s62.[Start_Point_Part_Desc],s62.processing_id,s62.file_name
	   )Err

	;


-- validation for same eng commodity/CM pairing with the same part multiple times 
-- need to unpivot S62 so that CMs are rows not columns.

DROP TABLE IF EXISTS #TYGRA_SUMMARY

CREATE TABLE #TYGRA_SUMMARY (
	[TYGRA_SUMMARY] int,
	[Processing_ID] varchar(max),
	[Source_c] varchar(max),
	[Vehicle_name] varchar(max),
	[Engineering_Commodity] varchar(max),
	[Start_Point_Part_Prefix] varchar(max),
	[Start_Point_Part_Base]  varchar(max),
	[Start_Point_Part_Suffix] varchar(max),
	[Start_Point_Part_Desc] varchar(max),
    [FEDEBOM_Planned_Prefix] varchar(max),
    [FEDEBOM_Planned_Base] varchar(max),
    [FEDEBOM_Planned_Suffix] varchar(max),
	[file_name] varchar(max),
	[row_idx] int ,
	[CREATE_S] datetime ,
	[CREATE_USER_C] varchar(max),
	[LAST_UPDT_S] datetime ,
	[LAST_UPDT_USER_C] varchar(max),
	include_f char(1),  -- will hold the value of th CM column, 1 or 0
	cmx varchar(max)   -- will hold column name from unpivot, ie CM1
	)
;

-- have to list all columns because UNPIVOT will not unpivot a column if it is NULL
INSERT INTO #TYGRA_SUMMARY
SELECT unpvt.*  
from 
   (SELECT ARWS62_TYGRA_SUMMARY,Processing_ID,Source_c,Vehicle_name--,PMT
           ,ISNULL(cm1,0) as CM1   
          ,ISNULL(cm2,0) as CM2
          ,ISNULL(cm3,0) as CM3
          ,ISNULL(cm4,0) as CM4
		  ,ISNULL(cm5,0) as CM5
          ,ISNULL(cm6,0) as CM6
          ,ISNULL(cm7,0) as CM7
          ,ISNULL(cm8,0) as CM8
          ,ISNULL(cm9,0) as CM9
		  ,ISNULL(cm10,0) as cm10
		  ,ISNULL(cm11,0) as cm11
		  ,ISNULL(cm12,0) as cm12
		  ,ISNULL(cm13,0) as cm13
		  ,ISNULL(cm14,0) as cm14
		  ,ISNULL(cm15,0) as cm15
		  ,ISNULL(cm16,0) as cm16
		  ,ISNULL(cm17,0) as cm17
		  ,ISNULL(cm18,0) as cm18
		  ,ISNULL(cm19,0) as cm19
		  ,ISNULL(cm20,0) as cm20
		  ,ISNULL(cm21,0) as cm21
		  ,ISNULL(cm22,0) as cm22
		  ,ISNULL(cm23,0) as cm23
		  ,ISNULL(cm24,0) as cm24
		  ,ISNULL(cm25,0) as cm25
          ,ISNULL(non_cm1,0) as non_cm1
          ,ISNULL(non_cm2,0) as non_cm2
          ,ISNULL(non_cm3,0) as non_cm3
          ,ISNULL(non_cm4,0) as non_cm4
		  ,ISNULL(non_cm5,0) as non_cm5
          ,ISNULL(non_cm6,0) as non_cm6
          ,ISNULL(non_cm7,0) as non_cm7
		  ,ISNULL(non_cm8,0) as non_cm8
          ,ISNULL(non_cm9,0) as non_cm9
		  ,Engineering_Commodity
          ,ISNULL(start_point_part_Prefix,' ') as start_point_part_Prefix
	  ,ISNULL(start_point_part_Base,' ' ) as start_point_part_Base
	  ,ISNULL(start_point_part_Suffix,'') as start_point_part_Suffix
	  ,ISNULL(start_point_part_Desc,' ') as start_point_part_Desc
	  ,ISNULL(FEDEBOM_Planned_Prefix,' ') as FEDEBOM_Planned_Prefix
	  ,ISNULL(FEDEBOM_Planned_Base,' ') as FEDEBOM_Planned_Base
	  ,ISNULL(FEDEBOM_Planned_Suffix,' ') as FEDEBOM_Planned_Suffix
          ,file_name,row_idx
          ,CREATE_S,CREATE_USER_C,LAST_UPDT_S,LAST_UPDT_USER_C
    from  [dbo].[PARWS62_TYGRA_SUMMARY]) s
UNPIVOT 
       (control_model for cmx in
	    (cm1, cm2, cm3, cm4, cm5, cm6, cm7, cm8, cm9 , cm10, cm11, cm12, cm13, cm14, cm15, cm16, cm17, cm18, cm19, cm20, cm21, cm22, cm23, cm24, cm25, 
		 non_cm1, non_cm2, non_cm3, non_cm4, non_cm5, non_cm6, non_cm7, non_cm8, non_cm9)
		) as unpvt
	where unpvt.Processing_ID = @GUID
;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 'TYGRA'
		,err.start_pt_part
		,'The same start point part occurs multiple times for the same engineering commodity/CM pair'   as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
       ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS62_TYGRA_SUMMARY'    as [ARWE02_STAGING_TABLE_X]
	   ,'WARNING'                 as [ARWE02_ERROR_TYPE_X]
	   ,''                        as [ARWE02_EXCEL_TAB_X]
	   ,''                        as [ARWE02_ROW_IDX]
	   ,err.cmx                 as [ARWE02_Part_Index]
	   ,err.engineering_commodity   as [ARWE02_ARROW_Value]

    FROM
    (	

select processing_id
,cmx
,Engineering_Commodity
,[Start_Point_Part_Prefix] + '-' + [Start_Point_Part_Base] + '-' + [Start_Point_Part_Suffix] as start_pt_part
,file_name
,count(*)  as cnt
from #TYGRA_SUMMARY
where include_f = 1
and Processing_ID = @GUID 
and ([Start_Point_Part_Prefix] <> ''
    and [Start_Point_Part_Base] <> ''
	and [Start_Point_Part_Suffix] <> ''
	)
group by processing_id
,cmx
,Engineering_Commodity
,[Start_Point_Part_Prefix] + '-' + [Start_Point_Part_Base] + '-' + [Start_Point_Part_Suffix]
,file_name
having count(*) > 1

) err
;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 'TYGRA'
		,err.FEDEBOM_part
		,'The same FEDEBOM planned part occurs multiple times for the same engineering commodity/CM pair'   as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
       ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS62_TYGRA_SUMMARY'    as [ARWE02_STAGING_TABLE_X]
	   ,'WARNING'                 as [ARWE02_ERROR_TYPE_X]
	   ,''                        as [ARWE02_EXCEL_TAB_X]
	   ,''                        as [ARWE02_ROW_IDX]
	   ,err.cmx                 as [ARWE02_Part_Index]
	   ,err.engineering_commodity   as [ARWE02_ARROW_Value]

    FROM
    (	

select processing_id
,cmx
,Engineering_Commodity
,[FEDEBOM_Planned_Prefix] + '-' + [FEDEBOM_Planned_Base] + '-' + [FEDEBOM_Planned_Suffix] as FEDEBOM_part
,file_name
,count(*)  as cnt
from #TYGRA_SUMMARY
where include_f = 1
and Processing_ID = @GUID
and ([FEDEBOM_Planned_Prefix] <> ''
    and [FEDEBOM_Planned_Base] <> ''
	and [FEDEBOM_Planned_Suffix] <> ''
	)
group by processing_id
,cmx
,Engineering_Commodity
,[FEDEBOM_Planned_Prefix] + '-' + [FEDEBOM_Planned_Base] + '-' + [FEDEBOM_Planned_Suffix]
,file_name
having count(*) > 1

) err
;



-- parts tab does not have a corresponding title page in the file
--	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
--     Select 
--		 Err.Source_c
--		,Err.file_name
--		,'File does not have a title page' as Error_Msg
--        ,err.Processing_ID 
--		,Err.file_name
--        ,'RJW_PARWP_TYGRA_VALIDT_TITLE_PARTS' as procedure_x
-- 		,@TIME_STAMP 
-- 		,@CDSID
--		,@TIME_STAMP 
--		,@CDSID
--	    ,err.ARWS62_TYGRA_SUMMARY
--		,'PARWP_TYGRA_VALIDT_PARTS'  
--        ,'WARNING'                       
--		,'Tygra Title Page'  as sheet_name
--		,Err.row_idx
--		,' '
--		,' '
--    FROM
--    (	
--      select s62.*
--        ,row_number() OVER (PARTITION BY s62.processing_id, s62.file_name
--			order by s62.processing_id, s62.file_name) as rownum
--     from PARWS62_TYGRA_SUMMARY s62
--     left join PARWS61_TYGRA_TITLE_PAGE s61
--     on s61.[Processing_ID] = s62.[Processing_ID]
--     where s61.Processing_ID IS NULL
--	 and s62.[Processing_ID] = @GUID
--  ) Err
--	 where rownum = 1
--
--	;

-- commented out until table is fixed or is rewritten
---- CM has no parts assigned(joining to ##variant_tbl to only validate against the correct number of CMs. don't want to validate against CM1 - CM9 where ther are only CM1 - CM4)
--	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
--    Select 
--		 z.Source_c
--		,z.pmtx
--		,'CM not assigned to any parts' as Error_Msg
--        ,z.Processing_ID 
--		,z.file_name
--        ,'RJW_PARWP_TYGRA_VALIDT_TITLE_PARTS' as procedure_x
-- 		,@TIME_STAMP 
-- 		,@CDSID
--		,@TIME_STAMP 
--		,@CDSID
--	    ,1
--		,'PARWP_TYGRA_VALIDT_PARTS'  
--        ,'WARNING'                       
--		,'Tygra Title Page'  as sheet_name
--		,0
--		,' '
--		,' '
--    FROM
--    (	
--      select * from (
--                     select * 
--                        from (
--                              select source_c 
--                                    ,ts.processing_id
--                                    ,file_name
--                                    ,pmtx
--                                    ,sum(cast (include_f as integer)) as cm_sum
--                              from ##TYGRA_SUMMARY  ts
--	                          join ##variant_tbl vt
--	                            on ts.processing_id = vt.processing_id
--                               and ts.pmtx = 'cm' + cast(vt.rownum as char(2))
--                               group by source_c, ts.processing_id,file_name,pmtx 
--                              ) x
--                       where x.cm_sum = 0
--                       ) y
--     ) z
--;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS61_TYGRA_TITLE_PAGE'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	





GO
