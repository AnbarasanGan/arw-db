DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_ASSEMBLY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 04/03/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 05/20/2019  Asolosky  N/A      If source country isnot found in the A28 table, use the empty string country record.
--                                Also changed the insert to use the staging source country instead of the V08 view country
-- 06/13/2019  ASHAIK12  N/A      Make all join conditions from cover page columns to user selected columns. And Remove the join for Engineering Commodity.
-- 06/21/2019  ASOLOSKY  N/A      Changed the delete to use only the ARWU08_CCTSS_DSGN_SUPL_K.  I removed ARWU17_BOM_SUB_ASSY_K from the ON clause.
--                                Since sub-assembly was not needed, The join was changed from the V09 to V04
-- 06/25/2019  rwesley2  N/A      changed ROW_NUMBER function to order by stage table row_idx col
-- 06/26/2019  rwesley2  N/A      removed ROW_NUMBER function and replaced with row_idx col on U27 and U29 INSERT
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 07/16/2019  asolosky			  Removed the ISNULL functions.  All staging columns that were Varchar but the database had the types as
--                                numeric were change to use a case statement
--                                NOTE: The UI writes empty strings to the staging tables instead of NULLs.
-- 07/31/2019  asolosky           added substring,1,256 in the U27 and U29 inserts.  Will fix the database later to handle a larger column
-- 08/13/2019  ashaik12           Removed Delete Statement
-- 10/29/2019  asolosky		      Removed the Sustring(1,256) for ARWU27_PART_IX_OPER_IX_X in Assembly and Final Assembly
-- 12/26/2019  ashaik12           Refactor to use flat view
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- 08/27/2020  Ashaik12           Added Total Labor Minutes
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_ASSEMBLY] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;



----------------------------------------------------------------------------------------------------- 
INSERT INTO PARWU27_ASSY_COST
SELECT --ARWU27_ASSY_COST_K is an identity 
       V09.ARWU08_CCTSS_DSGN_SUPL_K                          AS ARWU08_CCTSS_DSGN_SUPL_K
	  ,V09.ARWU17_BOM_SUB_ASSY_K                             AS ARWU17_BOM_SUB_ASSY_K
      ,ASSEMBLY_STAGE.[row_idx]                              AS ARWU27_ASSY_COST_DSPLY_SEQ_R
      ,ISNULL(ASSEMBLY_STAGE.part_index,'')                  AS ARWU27_PART_IX_OPER_IX_X
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')             AS ARWU27_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')              AS ARWU27_ASSY_OPER_X
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_SRC_CNTRY_K
	  ,CRCY.ARWA29_CRCY_K                        AS ARWA29_CRCY_K 

	  ,ASSEMBLY_STAGE.machine_make_model         AS ARWU27_MACH_MAKE_MDL_X
	  ,ASSEMBLY_STAGE.capital_exp_for_machine AS ARWU27_CPTL_EXPNDTR_FOR_MACH_A
	  ,ASSEMBLY_STAGE.machine_size  AS ARWU27_MACH_SIZE_IN_MET_TN_Q

	  ,ASSEMBLY_STAGE.assembly_secs_operation          AS ARWU27_ASSY_SEC_PER_OPER_Q
	  ,ASSEMBLY_STAGE.machinehourly_operation_overhead AS ARWU27_MACH_OPER_OVRHD_HRLY_A
	  ,ASSEMBLY_STAGE.direct_headcount                 AS ARWU27_DIR_HDCNT_Q
	  ,ASSEMBLY_STAGE.direct_hourly_labor_headcount    AS ARWU27_DIR_HRLY_LBR_HDCNT_A
	  ,ASSEMBLY_STAGE.indirect_labor_costs             AS ARWU27_INDIR_LBR_PER_DIR_P
	  ,ASSEMBLY_STAGE.fringes                          AS ARWU27_FRNG_PER_DIR_LBR_P
	  ,ASSEMBLY_STAGE.packaging_costs                  AS ARWU27_PKNG_COST_PER_PCE_A
	  ,ASSEMBLY_STAGE.logistics_cost                   AS ARWU27_LGSTCS_COST_PER_PCE_A
	  ,ASSEMBLY_STAGE.tax_duty_per_operation           AS ARWU27_TAX_AND_DUTY_PER_PCE_A
      ,ASSEMBLY_STAGE.comments                         AS ARWU27_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                     AS ARWU27_CREATE_S
	  ,@CDSID                                          AS ARWU27_CREATE_USER_C
	  ,@TIME_STAMP                                     AS ARWU27_LAST_UPDT_S
	  ,@CDSID                                          AS ARWU27_LAST_UPDT_USER_C
      ,ASSEMBLY_STAGE.total_labor_minutes              AS ARWU27_TOT_LBR_MIN_Q
  From PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN dbo.PARWS22_CCS_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename

 -- Join with Supplier Quote View
  JOIN PARWV09_CCS_BOM_SUB_ASSEMBLY   V09
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V09.ARWA03_ENRG_SUB_CMMDTY_X
    --  AND COVER_PAGE_STAGE.[User_Selected_ENRG_CMMDTY_X]      = V09.ARWA02_ENRG_CMMDTY_X
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V09.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V09.ARWA06_RGN_C
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V09.ARWU01_BNCHMK_VRNT_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V09.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V09.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V09.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V09.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V09.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V09.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V09.ARWA28_CNTRY_N
      AND ASSEMBLY_STAGE.sub_assembly_name                    = V09.ARWU17_BOM_SUB_ASSY_N

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency=CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''

  Where cover_page_stage.Processing_ID               = @GUIDIN 
    And cover_page_stage.Skip_loading_due_to_error_f = 0
;
----------------------------------------------------------------------------------------------------- 
--Final Assembly
-----------------------------------------------------------------------------------------------------

----------------------------------------------------------------------------------------------------- 
INSERT INTO PARWU29_FNL_ASSY_COST
SELECT --ARWU29_FNL_ASSY_COST_K is an identity 
       U08.ARWU08_CCTSS_DSGN_SUPL_K                              AS ARWU08_CCTSS_DSGN_SUPL_K
      ,ASSEMBLY_STAGE.[row_idx]                                  AS ARWU29_FNLASSYCOST_DSPLY_SEQ_R
      ,ISNULL(ASSEMBLY_STAGE.part_index,'')                      AS ARWU29_PART_SUB_ASSY_OPER_IX_X
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')                 AS ARWU29_FNL_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')                  AS ARWU29_FNL_ASSY_OPER_X
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_SRC_CNTRY_K
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_CRCY_K 
	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU29_MACH_MAKE_MDL_X
	  ,ISNULL(ASSEMBLY_STAGE.capital_exp_for_machine,0)          AS ARWU29_CPTL_EXPNDTR_FOR_MACH_A
	  ,ISNULL(ASSEMBLY_STAGE.machine_size,0)                     AS ARWU29_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU29_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU29_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU29_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU29_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU29_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU29_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU29_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU29_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU29_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU29_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                               AS ARWU29_CREATE_S
	  ,@CDSID                                                    AS ARWU29_CREATE_USER_C
	  ,@TIME_STAMP                                               AS ARWU29_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU29_LAST_UPDT_USER_C
	  ,ASSEMBLY_STAGE.total_labor_minutes                        AS ARWU29_TOT_LBR_MIN_Q
  From PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN dbo.PARWS22_CCS_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename

 -- Join with Supplier Quote View
   JOIN  [dbo].PARWU08_CCTSS_DSGN_SUPL_FLAT  U08
      ON  COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U08.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = U08.[ARWA03_ENRG_SUB_CMMDTY_X]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U08.[ARWA06_RGN_C]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U08.[ARWU01_BNCHMK_VRNT_N]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = U08.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = U08.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = U08.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = U08.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U08.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U08.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U08.ARWA28_CNTRY_N

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency = CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''
  Where cover_page_stage.Processing_ID               = @GUIDIN 
    And cover_page_stage.Skip_loading_due_to_error_f = 0
	And ASSEMBLY_STAGE.sub_assembly_name             = 'Final assembly'
;


GO
