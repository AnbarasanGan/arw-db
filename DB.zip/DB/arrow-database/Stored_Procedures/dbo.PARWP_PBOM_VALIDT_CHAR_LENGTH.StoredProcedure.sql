DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_CHAR_LENGTH]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 08/24/2020
-- Description:	Validate the PARWS59_PBOM_PARTS staging table's character field's length and make sure they don't exceed the maximum.
-- =============================================
-- Changes
-- =============================================
-- Author   Date       User Story Description
-- ------   -----      ---------- ----------
-- rwesley2 09-11-2020 US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky 10-20-2020 US1996362  Switch from E02 to E03 and include Excel column
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_PBOM_VALIDT_CHAR_LENGTH] 
-- Input Parameter
 @Processing_ID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP    datetime

AS
BEGIN TRY
SET NOCOUNT ON;

--Error for material spec over 1024 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,material_spec
		,'Material Specs can''t be more than 1024 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value  --no arrow value
		,material_spec_column                  as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @Processing_ID
    and DATALENGTH(material_spec)  > 1024;

--Error for cmmdty_spec1 over 1024 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,cmmdty_spec1
		,'Commodity Specific 1 can''t be more than 1024 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,cmmdty_spec1_column                   as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @Processing_ID
    and DATALENGTH(cmmdty_spec1)  > 1024;

--Error for cmmdty_spec2 over 1024 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,cmmdty_spec2
		,'Commodity Specific 2 can''t be more than 1024 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value  --no arrow value
		,cmmdty_spec2_column                   as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @Processing_ID
    and DATALENGTH(cmmdty_spec2)  > 1024;

--Error for cmmdty_spec3 over 1024 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,cmmdty_spec3
		,'Commodity Specific 3 can''t be more than 1024 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,cmmdty_spec3_column                   as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @Processing_ID
    and DATALENGTH(cmmdty_spec3)  > 1024;

--Error for comments over 1024 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,comments
		,'Comments can''t be more than 1024 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index                            as ARWE03_Part_Index
		,''                                    as ARWE03_Arrow_value
		,comments_column                       as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS 
  Where Processing_ID    = @Processing_ID
    and DATALENGTH(comments)  > 1024;
END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''                                --ARWE03_BATCH_ERRORS_REF_K
		,'PARWS59_PBOM_PARTS'              --ARWE03_STAGING_TABLE_X
		--ARWE03_BATCH_ERRORS_K Identity key
		,'ERROR'                           --ARWE03_ERROR_TYPE_X
        ,'SYSTEM'                          --ARWE03_EXCEL_TAB_X
		,0                                 --row_idx
        ,''                               -- part_index 
		,''                               -- ARROW_VALUE
		,''                               --column
;
END CATCH;	

GO
