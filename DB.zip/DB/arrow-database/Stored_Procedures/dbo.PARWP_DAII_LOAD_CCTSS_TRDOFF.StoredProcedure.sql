DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_CCTSS_TRDOFF]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ashaik12
-- Create date: 11/07/2019
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 12/23/2019  ASHAIK12            Remove PROCESSING filter
-- 01/03/2020  ASHAIK12            Refactored the Joins to get U06 key when joining on U37 and U46 tables.
-- 01/14/2020  Ashaik12            Added Time_Stamp parameter 
-- 11/30/2020  Asolosky  US2064099 DAW Import fails with a Duplicate trade off when there are groupings with [UNASSIGNED] and blank - for Supplier Ideas
--                                 Moved the case statement to the inner selects
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_CCTSS_TRDOFF] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--**********************************
-- Insert into U85
--********************************** 

INSERT INTO [PARWU85_CCTSS_TRDOFF]
select ARWU01_CCTSS_K
      ,1                               AS ARWU85_BNCHMK_F
      ,ARWU85_CCTSS_TRDOFF_X           AS [ARWU85_CCTSS_TRDOFF_X]
	  ,''                              AS [ARWU85_CCTSS_TRDOFF_RTNLE_X]
	  ,''                              AS [ARWU85_CCTSS_TRDOFF_DATA_SRC_X]
	  ,1                               AS [ARWU85_CCTSS_TRDOFF_INCLD_F]
	  ,[ARWA31_CONFID_LVL_K]           AS [ARWA31_CONFID_LVL_K]
	  ,0                               AS [ARWU85_TRDOFF_AGRMT_BFR_MP_F]
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]   AS [ARWA43_TRDOFF_AGRMT_FORUM_K]
	  ,@TIME_STAMP                     AS [ARWU85_CREATE_S]
      ,@CDSID                          AS [ARWU85_CREATE_USER_C]
      ,@TIME_STAMP                     AS [ARWU85_LAST_UPDT_S]
      ,@CDSID                          AS [ARWU85_LAST_UPDT_USER_C]
from 
(
SELECT  
       U01.ARWU01_CCTSS_K              AS [ARWU01_CCTSS_K]
  	  ,CASE WHEN S35.tough_choice_grouping = '' 
  	        THEN 'UNASSIGNED' 
  		    ELSE S35.tough_choice_grouping  
  	   END                             AS [ARWU85_CCTSS_TRDOFF_X]
	  ,A31.ARWA31_CONFID_LVL_K         AS [ARWA31_CONFID_LVL_K]
	  ,A43.ARWA43_TRDOFF_AGRMT_FORUM_K AS [ARWA43_TRDOFF_AGRMT_FORUM_K]
  FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
  JOIN PARWS34_DAII_COVER_PAGE_INFO           S34
    ON S34.Processing_ID       = S35.Processing_ID
   AND S34.filename            = S35.filename
  JOIN PARWU01_CCTSS_FLAT         U01
    ON U01.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND U01.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
   AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND U01.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N
  JOIN PARWA31_CONFID_LVL         A31
    ON A31.ARWA31_CONFID_LVL_X ='High'
  JOIN PARWA43_TRDOFF_AGRMT_FORUM A43
    ON A43.ARWA43_TRDOFF_AGRMT_FORUM_N='To be determined'
 Where S34.Processing_ID               = @GUIDIN 
   And S34.Skip_loading_due_to_error_f = 0
   And not exists --Can't add a tough group if it already exists
       (Select 'X'
          From PARWU85_CCTSS_TRDOFF U85_Check
	     Where U85_Check.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
		   AND ARWU85_BNCHMK_F = 1
		   And U85_Check.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S35.tough_choice_grouping='' THEN 'UNASSIGNED' ELSE S35.tough_choice_grouping END   
       )
UNION
   SELECT  
       U01.ARWU01_CCTSS_K              AS [ARWU01_CCTSS_K]
   	  ,CASE WHEN S44.improvement_idea_grouping = '' 
   	        THEN 'UNASSIGNED' 
   		    ELSE S44.improvement_idea_grouping  
   	   END                             AS [ARWU85_CCTSS_TRDOFF_X]
	  ,A31.ARWA31_CONFID_LVL_K         AS [ARWA31_CONFID_LVL_K]
	  ,A43.ARWA43_TRDOFF_AGRMT_FORUM_K AS [ARWA43_TRDOFF_AGRMT_FORUM_K]
  FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
  JOIN PARWS34_DAII_COVER_PAGE_INFO              S34
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename
  JOIN PARWU01_CCTSS_FLAT        U01
    ON U01.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND U01.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
   AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND U01.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N  
  JOIN PARWA31_CONFID_LVL         A31
    ON A31.ARWA31_CONFID_LVL_X ='High'
  JOIN PARWA43_TRDOFF_AGRMT_FORUM A43
    ON A43.ARWA43_TRDOFF_AGRMT_FORUM_N='To be determined'
 Where S34.Processing_ID               = @GUIDIN
   And S34.Skip_loading_due_to_error_f = 0
   And not exists --Can't add a tough group if it already exists
       (Select 'X'
          From PARWU85_CCTSS_TRDOFF U85_Check
	     Where U85_Check.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
		   AND ARWU85_BNCHMK_F = 1
		   And U85_Check.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S44.improvement_idea_grouping='' THEN 'UNASSIGNED' ELSE S44.improvement_idea_grouping END   
       )
) X
Group by --Get distinct data to write into the table
       ARWU01_CCTSS_K          
	  ,ARWU85_CCTSS_TRDOFF_X
	  ,ARWA31_CONFID_LVL_K
	  ,[ARWA43_TRDOFF_AGRMT_FORUM_K]
	 ;

--**********************************
-- Insert into U86
--********************************** 

INSERT INTO [dbo].[PARWU86_DSGN_ADJ_TRDOFF]
SELECT U37.ARWU37_CCTSS_DSGN_ADJ_K     AS ARWU37_CCTSS_DSGN_ADJ_K
      ,U85.ARWU85_CCTSS_TRDOFF_K       AS ARWU85_CCTSS_TRDOFF_K
	  ,@TIME_STAMP                    AS ARWU86_CREATE_S
      ,@CDSID                          AS ARWU86_CREATE_USER_C
      ,@TIME_STAMP                    AS ARWU86_LAST_UPDT_S
      ,@CDSID                          AS ARWU86_LAST_UPDT_USER_C
FROM [dbo].PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
  JOIN PARWS34_DAII_COVER_PAGE_INFO           S34
    ON S34.Processing_ID       = S35.Processing_ID
   AND S34.filename            = S35.filename

   JOIN [dbo].[PARWU06_CCTSS_DSGN_FLAT] U06       
	     on S34.[User_Selected_CTSP_N]            = U06.[ARWU31_CTSP_N]
		and S34.[User_Selected_CTSP_Region_C]     = U06.[ARWA06_RGN_C]
		and S34.[User_Selected_BNCMK_VRNT_N]      = U06.[ARWU01_BNCHMK_VRNT_N]
		and S34.[User_Selected_ENRG_SUB_CMMDTY_X] = U06.ARWA03_ENRG_SUB_CMMDTY_X
		and S34.[User_Selected_VEH_MAKE_N]        = U06.ARWA14_VEH_MAKE_N
		and S34.[User_Selected_VEH_MDL_N]         = U06.ARWA34_VEH_MDL_N
		and S34.[User_Selected_VEH_MDL_YR_C]      = U06.ARWA35_DSGN_VEH_MDL_YR_C
		and S34.[User_Selected_VEH_MDL_VRNT_X]    = U06.ARWA35_DSGN_VEH_MDL_VRNT_X

   JOIN PARWU37_CCTSS_DSGN_ADJ U37
   ON  U37.ARWU06_CCTSS_DSGN_K = U06.ARWU06_CCTSS_DSGN_K
   AND U37.ARWU37_CCTSS_DSGN_ADJ_ID_N = S35.change_id

   JOIN PARWU85_CCTSS_TRDOFF U85
   ON U85.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S35.tough_choice_grouping='' THEN 'UNASSIGNED' ELSE S35.tough_choice_grouping END
   AND U06.ARWU01_CCTSS_K       = U85.ARWU01_CCTSS_K
   AND U85.ARWU85_BNCHMK_F=1

    Where S34.Processing_ID               = @GUIDIN 
    And S34.Skip_loading_due_to_error_f = 0
    AND not exists --Can't add if it already exists
       (
	     Select 'X'
          From PARWU86_DSGN_ADJ_TRDOFF U86_check
	     Where U86_check.ARWU37_CCTSS_DSGN_ADJ_K = U37.ARWU37_CCTSS_DSGN_ADJ_K 
       )
	GROUP BY U37.ARWU37_CCTSS_DSGN_ADJ_K,U85.ARWU85_CCTSS_TRDOFF_K

;


--**********************************
-- Insert into U87
--********************************** 

INSERT INTO [dbo].PARWU87_DSGN_IMPRV_TRDOFF
SELECT U46.ARWU46_CCTSS_DSGN_IMPRV_K   AS ARWU46_CCTSS_DSGN_IMPRV_K
      ,U85.ARWU85_CCTSS_TRDOFF_K       AS ARWU85_CCTSS_TRDOFF_K
	  ,@TIME_STAMP                    AS ARWU86_CREATE_S
      ,@CDSID                          AS ARWU86_CREATE_USER_C
      ,@TIME_STAMP                    AS ARWU86_LAST_UPDT_S
      ,@CDSID                          AS ARWU86_LAST_UPDT_USER_C
FROM [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
  JOIN PARWS34_DAII_COVER_PAGE_INFO           S34
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename

 -- Join with Design/Supplier Flat View
  JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT   U08
    ON U08.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
   AND U08.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
   AND U08.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
   AND U08.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N
   AND U08.ARWA14_VEH_MAKE_N          = S34.[User_Selected_VEH_MAKE_N]
   AND U08.ARWA34_VEH_MDL_N           = S34.[User_Selected_VEH_MDL_N]   
   AND U08.ARWA35_DSGN_VEH_MDL_YR_C	  = S34.[User_Selected_VEH_MDL_YR_C]
   AND U08.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.[User_Selected_VEH_MDL_VRNT_X]
   AND U08.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
   AND U08.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
   AND U08.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N

   JOIN PARWU46_CCTSS_DSGN_IMPRV U46
   ON U46.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
   AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  s44.improvement_id + '#' + CONVERT(VARCHAR,U08.[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  s44.improvement_id  + '#' + 'Ford'	              
        END)

   JOIN PARWU85_CCTSS_TRDOFF U85
   ON  U85.ARWU01_CCTSS_K = U08.ARWU01_CCTSS_K
   AND U85.ARWU85_BNCHMK_F=1
   AND U85.ARWU85_CCTSS_TRDOFF_X = CASE WHEN S44.improvement_idea_grouping='' THEN 'UNASSIGNED' ELSE S44.improvement_idea_grouping END


    Where S34.Processing_ID               = @GUIDIN 
    And S34.Skip_loading_due_to_error_f = 0
    AND not exists --Can't add if it already exists
       (
	     Select 'X'
          From PARWU87_DSGN_IMPRV_TRDOFF U87_check
	     Where U87_check.ARWU46_CCTSS_DSGN_IMPRV_K = U46.ARWU46_CCTSS_DSGN_IMPRV_K 
       )
	GROUP BY U46.ARWU46_CCTSS_DSGN_IMPRV_K,U85.ARWU85_CCTSS_TRDOFF_K

	;




GO
