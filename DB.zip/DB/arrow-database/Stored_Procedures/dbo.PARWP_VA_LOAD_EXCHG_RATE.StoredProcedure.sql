DROP PROCEDURE [dbo].[PARWP_VA_LOAD_EXCHG_RATE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 10/11/2019
-- Description:	Load  U22 Currency table if new currency shows up VA import  
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 10/15/2019  rwesley            added DISTINCT to U22 load to eliminate dup insert error
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_VA_LOAD_EXCHG_RATE] 
-- Input Parameter
@Processing_ID varchar(500),
@CDSID Varchar(8),
@TIME_STAMP DATETIME

AS

--BEGIN TRY
SET NOCOUNT ON;

------------- LOAD into [PARWU22_SUPL_CRCY_EXCHG_RATE] for new exchange rates added in Purchased parts
MERGE INTO PARWU22_SUPL_CRCY_EXCHG_RATE U22_Target
USING
(
Select DISTINCT(Supplier.ARWU07_CCTSS_SUPL_K)    as ARWU07_CCTSS_SUPL_K
	  ,A29.ARWA29_CRCY_K                         as ARWA29_CRCY_K
	  ,isNULL(s50.[exchange_rate] ,0)            as ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,@TIME_STAMP                              as ARWU21_CREATE_S
	  ,@CDSID                                    as ARWU21_CREATE_USER_C
	  ,@TIME_STAMP                              as ARWU21_LAST_UPDT_S
	  ,@CDSID                                    as ARWU21_LAST_UPDT_USER_C 
  From [dbo].[PARWS50_VA_PURCHASED_PARTS_INFO] s50
  Join
(
 SELECT S45.Processing_ID
	   ,S45.Processing_Status_x
	   ,S45.filename
	   ,V04.ARWU07_CCTSS_SUPL_K 
	   ,row_number () over (partition by processing_id, ARWU07_CCTSS_SUPL_K order by filename, ARWU07_CCTSS_SUPL_K) as rownum
  FROM [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
--Design and Supplier
  Join PARWV04_DSGN_SUPL  V04
    ON S45.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
   AND S45.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
   AND S45.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
   AND S45.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
   AND S45.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
   AND S45.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
   AND S45.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
	  where S45.[Processing_ID]       = @Processing_ID
		AND S45.Skip_loading_due_to_error_f  = 0
) Supplier

    On s50.Processing_ID       = Supplier.Processing_ID
   AND s50.filename            = Supplier.filename
--Currrency
  JOIN PARWA29_CRCY A29	ON A29.ARWA29_CRCY_C = s50.[local_currency]
Where rownum = 1
) as U22_SOURCE
ON(U22_Target.ARWU07_CCTSS_SUPL_K = U22_Source.ARWU07_CCTSS_SUPL_K)
   AND U22_Target.ARWA29_CRCY_K = U22_Source.ARWA29_CRCY_K
When NOT Matched then
 Insert Values (
 		ARWU07_CCTSS_SUPL_K
		,ARWA29_CRCY_K
		,ARWU22_CRCY_PER_SUPL_CRCY_R
		,@TIME_STAMP               
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		) 
;
 
------------- LOAD into [PARWU22_SUPL_CRCY_EXCHG_RATE] for new exchange rates added in Raw materials
MERGE INTO PARWU22_SUPL_CRCY_EXCHG_RATE U22_Target
USING
(
Select DISTINCT(Supplier.ARWU07_CCTSS_SUPL_K)    as ARWU07_CCTSS_SUPL_K
	  ,A29.ARWA29_CRCY_K                         as ARWA29_CRCY_K
	  ,isNULL(s51.[exchange_rate] ,0)            as ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,@TIME_STAMP                              as ARWU21_CREATE_S
	  ,@CDSID                                    as ARWU21_CREATE_USER_C
	  ,@TIME_STAMP                              as ARWU21_LAST_UPDT_S
	  ,@CDSID                                    as ARWU21_LAST_UPDT_USER_C 
  From [dbo].[PARWS51_VA_RAW_MATERIALS_INFO]  s51
  Join
(
 SELECT S45.Processing_ID
	   ,S45.Processing_Status_x
	   ,S45.filename
	   ,V04.ARWU07_CCTSS_SUPL_K 
	   ,row_number () over (partition by processing_id, ARWU07_CCTSS_SUPL_K order by filename, ARWU07_CCTSS_SUPL_K) as rownum
  FROM [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
--Design and Supplier
  Join PARWV04_DSGN_SUPL  V04
    ON S45.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
   AND S45.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
   AND S45.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
   AND S45.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
   AND S45.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
   AND S45.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
   AND S45.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
	  where S45.[Processing_ID]       = @Processing_ID
		AND S45.Skip_loading_due_to_error_f  = 0
) Supplier

    On s51.Processing_ID       = Supplier.Processing_ID
   AND s51.filename            = Supplier.filename
--Currrency
  JOIN PARWA29_CRCY A29	ON A29.ARWA29_CRCY_C = s51.[local_currency]
Where rownum = 1
) as U22_SOURCE
ON(U22_Target.ARWU07_CCTSS_SUPL_K = U22_Source.ARWU07_CCTSS_SUPL_K)
   AND U22_Target.ARWA29_CRCY_K = U22_Source.ARWA29_CRCY_K
When NOT Matched then
 Insert Values (
 		ARWU07_CCTSS_SUPL_K
		,ARWA29_CRCY_K
		,ARWU22_CRCY_PER_SUPL_CRCY_R
		,@TIME_STAMP               
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		) 
;

------------- LOAD into [PARWU22_SUPL_CRCY_EXCHG_RATE] for new exchange rates added in processing costs
MERGE INTO PARWU22_SUPL_CRCY_EXCHG_RATE U22_Target
USING
(
Select DISTINCT(Supplier.ARWU07_CCTSS_SUPL_K)    as ARWU07_CCTSS_SUPL_K
	  ,A29.ARWA29_CRCY_K                         as ARWA29_CRCY_K
	  ,isNULL(s52.[exchange_rate] ,0)            as ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,@TIME_STAMP                              as ARWU21_CREATE_S
	  ,@CDSID                                    as ARWU21_CREATE_USER_C
	  ,@TIME_STAMP                              as ARWU21_LAST_UPDT_S
	  ,@CDSID                                    as ARWU21_LAST_UPDT_USER_C 
  From [dbo].[PARWS52_VA_PROCESSING_PARTS_INFO] s52
  Join
(
 SELECT s45.Processing_ID
	   ,s45.Processing_Status_x
	   ,s45.filename
	   ,V04.ARWU07_CCTSS_SUPL_K 
	   ,row_number () over (partition by processing_id, ARWU07_CCTSS_SUPL_K order by filename, ARWU07_CCTSS_SUPL_K) as rownum
  FROM [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
--Design and Supplier
  Join PARWV04_DSGN_SUPL  V04
    ON s45.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
   AND s45.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
   AND s45.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
   AND s45.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
   AND s45.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
   AND s45.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
   AND s45.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
	  where s45.[Processing_ID]       = @Processing_ID
		AND s45.Skip_loading_due_to_error_f  = 0
) Supplier

    On s52.Processing_ID       = Supplier.Processing_ID
   AND s52.filename            = Supplier.filename
--Currrency
  JOIN PARWA29_CRCY A29	ON A29.ARWA29_CRCY_C = s52.[local_currency]
Where rownum = 1
) as U22_SOURCE
ON(U22_Target.ARWU07_CCTSS_SUPL_K = U22_Source.ARWU07_CCTSS_SUPL_K)
   AND U22_Target.ARWA29_CRCY_K = U22_Source.ARWA29_CRCY_K
When NOT Matched then
 Insert Values (
 		ARWU07_CCTSS_SUPL_K
		,ARWA29_CRCY_K
		,ARWU22_CRCY_PER_SUPL_CRCY_R
		,@TIME_STAMP               
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		) 
;

------------- LOAD into [PARWU22_SUPL_CRCY_EXCHG_RATE] for new exchange rates added in assembly
MERGE INTO PARWU22_SUPL_CRCY_EXCHG_RATE U22_Target
USING
(
Select DISTINCT(Supplier.ARWU07_CCTSS_SUPL_K)    as ARWU07_CCTSS_SUPL_K
	  ,A29.ARWA29_CRCY_K                         as ARWA29_CRCY_K
	  ,isNULL(s52.[exchange_rate] ,0)            as ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,@TIME_STAMP                              as ARWU21_CREATE_S
	  ,@CDSID                                    as ARWU21_CREATE_USER_C
	  ,@TIME_STAMP                              as ARWU21_LAST_UPDT_S
	  ,@CDSID                                    as ARWU21_LAST_UPDT_USER_C 
  From [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO]  s52
  Join
(
 SELECT s45.Processing_ID
	   ,s45.Processing_Status_x
	   ,s45.filename
	   ,V04.ARWU07_CCTSS_SUPL_K 
	   ,row_number () over (partition by processing_id, ARWU07_CCTSS_SUPL_K order by filename, ARWU07_CCTSS_SUPL_K) as rownum
  FROM [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
--Design and Supplier
  Join PARWV04_DSGN_SUPL  V04
    ON s45.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
   AND s45.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
   AND s45.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
   AND s45.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
   AND s45.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
   AND s45.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
   AND s45.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N

	  where s45.[Processing_ID]       = @Processing_ID
		AND s45.Skip_loading_due_to_error_f  = 0
) Supplier

    On s52.Processing_ID       = Supplier.Processing_ID
   AND s52.filename            = Supplier.filename
--Currrency
  JOIN PARWA29_CRCY A29	ON A29.ARWA29_CRCY_C = s52.[local_currency]
Where rownum = 1
) as U22_SOURCE
ON(U22_Target.ARWU07_CCTSS_SUPL_K = U22_Source.ARWU07_CCTSS_SUPL_K)
   AND U22_Target.ARWA29_CRCY_K = U22_Source.ARWA29_CRCY_K
When NOT Matched then
 Insert Values (
 		ARWU07_CCTSS_SUPL_K
		,ARWA29_CRCY_K
		,ARWU22_CRCY_PER_SUPL_CRCY_R
		,@TIME_STAMP               
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		) 
;


GO
