DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_ENGCOMMDTY_SUBCOMMDTY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Asolosky
-- Create date: 03/15/2019
-- Description:	Stored Procedure to Validate BOB Details
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   07/19/2019  Changed the validation to display the commodity/sub-commodity in the error.
-- Asolosky   09/10/2019  Added row_idx
-- Ashaik12   12/25/2019  Updated Error Description for Sub commodity to say Commodity Scope
-- Ashaik12   01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_ENGCOMMDTY_SUBCOMMDTY]
	-- Add the parameters for the stored procedure here
	   @GUID  varchar(500) -- Comes from Master
	  ,@CDSID varchar(30)
	  ,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO PARWE02_BATCH_ERRORS
      SELECT
	         Validate.[Source_c]                        as [ARWE02_SOURCE_C],
	         Validate.[Eng_commodity_name]              as [ARWE02_ERROR_VALUE],
	         'Engineer commodity name on the cover page does not match the selected Engineer Commodity Name set up for the Program' as ARWE02_ERROR_VALUE,
	         Validate.[Processing_ID]                   as [ARWE02_PROCESSING_ID],
	         Validate.[filename]                        as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                      as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                                as [ARWE02_CREATE_S],
	         @CDSID                                     as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                                as [ARWE02_LAST_UPDT_S],
	         @CDSID                                     as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS22_CCS_COVER_PAGE_INFO_K]    as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS22_CCS_COVER_PAGE_INFO'              as [ARWE02_STAGING_TABLE_X],
	         'ERROR'                                    as [ARWE02_ERROR_TYPE_X],
	         'Cover'                                    as [ARWE02_EXCEL_TAB_X],
			 0                                          as ARWE02_ROW_IDX,
	         ''                                         as ARWE02_Part_Index,
		     User_Selected_ENRG_CMMDTY_X                as ARWE02_ARROW_Value
       FROM 
       (
        SELECT Processing_ID,
		       Model_Year,
		       Program,
		       Region,
               Eng_commodity_name,
			   User_Selected_ENRG_CMMDTY_X,
		       Eng_SubCommodity_name,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO S22
         WHERE Processing_ID                = @GUID 
		   And User_Selected_ENRG_CMMDTY_X != Eng_commodity_name                    
       ) Validate
    ;

	    -- Insert statements for procedure here
	INSERT INTO PARWE02_BATCH_ERRORS
      SELECT
	         Validate.[Source_c]                            as [ARWE02_SOURCE_C],
	         Validate.Eng_SubCommodity_name                 as [ARWE02_ERROR_VALUE],
	         'Commodity Scope on the cover page does not match the selected Commodity Scope' as [ARWE02_ERROR_VALUE],
	         Validate.[Processing_ID]                       as [ARWE02_PROCESSING_ID],
	         Validate.[filename]                            as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                          as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                                    as [ARWE02_CREATE_S],
	         @CDSID                                         as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                                    as [ARWE02_LAST_UPDT_S],
	         @CDSID                                         as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS22_CCS_COVER_PAGE_INFO_K]        as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS22_CCS_COVER_PAGE_INFO'                  as [ARWE02_STAGING_TABLE_X],
	         'ERROR'                                        as [ARWE02_ERROR_TYPE_X],
	         'Cover'                                        as [ARWE02_EXCEL_TAB_X],
			 0                                              as ARWE02_ROW_IDX,
	         ''                                             as ARWE02_Part_Index,
		     User_Selected_ENRG_SUB_CMMDTY_X                as ARWE02_ARROW_Value

       FROM 
       (
        SELECT Processing_ID,
		       Model_Year,
		       Program,
		       Region,
               Eng_commodity_name,
		       Eng_SubCommodity_name,
			   User_Selected_ENRG_SUB_CMMDTY_X,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS22_CCS_COVER_PAGE_INFO_K
          FROM PARWS22_CCS_COVER_PAGE_INFO S22
         WHERE Processing_ID                    = @GUID 
		   And User_Selected_ENRG_SUB_CMMDTY_X != Eng_SubCommodity_name                    
       ) Validate
    ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                       --source_c
             ,'Catch Error'                  --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                          --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()              --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS22_CCS_COVER_PAGE_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;

GO
