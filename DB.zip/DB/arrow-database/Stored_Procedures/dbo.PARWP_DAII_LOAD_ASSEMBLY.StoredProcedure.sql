DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_ASSEMBLY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asamriya
-- Create date: 06/27/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/01/2019  ASHAIK12           Added join condition on improvement_id
-- 07/12/2019  asolosky		      Moved the deletes to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 05/28/2020  Ashaik12           DE169686 fix - change filter
-- 07/29/2020  Ashaik12           US1802362 - Including sub assy name !='Adjustment Final Assembly' so final assembly data is not considered
--                                when loading the data into Assembly table
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_ASSEMBLY] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO PARWU41_ASSY_DSGN_ADJ
SELECT
       V04.ARWU08_CCTSS_DSGN_SUPL_K                          AS ARWU08_CCTSS_DSGN_SUPL_K
	  ,ASSEMBLY_STAGE.row_idx                                AS ARWU41_ASSY_COST_DSPLY_SEQ_R
	  ,U37.ARWU37_CCTSS_DSGN_ADJ_K                           AS ARWU37_CCTSS_DSGN_ADJ_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')             AS ARWU41_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')              AS ARWU41_ASSY_OPER_X
	  
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_SRC_CNTRY_K
	   
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_CRCY_K 

	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU41_MACH_MAKE_MDL_X
	  ,ISNULL(ASSEMBLY_STAGE.capital_exp_for_machine,0)          AS ARWU41_CPTL_EXPNDTR_FOR_MACH_A
	  ,ISNULL(ASSEMBLY_STAGE.machine_size,0)                     AS ARWU41_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU41_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU41_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU41_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU41_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU41_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU41_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU41_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU41_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU41_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU41_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWU41_CREATE_S
	  ,@CDSID                                                    AS ARWU41_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWU41_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU41_LAST_UPDT_USER_C

       From PARWS42_DAII_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
        JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename

  JOIN PARWV04_DSGN_SUPL   V04
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.VARIANT
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	     AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N

  JOIN [dbo].[PARWU37_CCTSS_DSGN_ADJ] U37
       ON V04.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
	   AND ASSEMBLY_STAGE.change_improvement_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
  

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency=CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''

  Where cover_page_stage.Processing_ID               = @GUIDIN
	AND ASSEMBLY_STAGE.cost_type ='Adjustment Costs'
	AND ASSEMBLY_STAGE.sub_assembly_name != 'Adjustment Final Assembly'
    And cover_page_stage.Skip_loading_due_to_error_f = 0
;
----------------------------------------------------------------------------------------------------- 
--Final Assembly
-----------------------------------------------------------------------------------------------------

INSERT INTO PARWU43_FNL_ASSY_DSGN_ADJ
SELECT  
       V04.ARWU08_CCTSS_DSGN_SUPL_K                              AS ARWU08_CCTSS_DSGN_SUPL_K
      ,ASSEMBLY_STAGE.row_idx                                    AS ARWU43_FNLASSYCOST_DSPLY_SEQ_R
	  ,U37.ARWU37_CCTSS_DSGN_ADJ_K                               AS ARWU37_CCTSS_DSGN_ADJ_K
	  ,ISNULL(ASSEMBLY_STAGE.operation_index,'')                 AS ARWU43_FNL_ASSY_OPER_IX_C
	  ,ISNULL(ASSEMBLY_STAGE.operation_desc,'')                  AS ARWU43_FNL_ASSY_OPER_X
	  ,Case When LOC.ARWA28_CNTRY_K is Null then 
		         a28_EmptyStr.ARWA28_CNTRY_K 
			Else LOC.ARWA28_CNTRY_K 
	   End as ARWA28_SRC_CNTRY_K
	  ,CRCY.ARWA29_CRCY_K                                        AS ARWA29_CRCY_K 
	  ,ISNULL(ASSEMBLY_STAGE.machine_make_model,'')              AS ARWU43_MACH_MAKE_MDL_X
	  ,ISNULL(ASSEMBLY_STAGE.capital_exp_for_machine,0)          AS ARWU43_CPTL_EXPNDTR_FOR_MACH_A
	  ,ISNULL(ASSEMBLY_STAGE.machine_size,0)                     AS ARWU43_MACH_SIZE_IN_MET_TN_Q
	  ,ISNULL(ASSEMBLY_STAGE.assembly_secs_operation,0)          AS ARWU43_ASSY_SEC_PER_OPER_Q
	  ,ISNULL(ASSEMBLY_STAGE.machinehourly_operation_overhead,0) AS ARWU43_MACH_OPER_OVRHD_HRLY_A
	  ,ISNULL(ASSEMBLY_STAGE.direct_headcount,0)                 AS ARWU43_DIR_HDCNT_Q
	  ,ISNULL(ASSEMBLY_STAGE.direct_hourly_labor_headcount,0)    AS ARWU43_DIR_HRLY_LBR_HDCNT_A
	  ,ISNULL(ASSEMBLY_STAGE.indirect_labor_costs,0)             AS ARWU43_INDIR_LBR_PER_DIR_P
	  ,ISNULL(ASSEMBLY_STAGE.fringes,0)                          AS ARWU43_FRNG_PER_DIR_LBR_P
	  ,ISNULL(ASSEMBLY_STAGE.packaging_costs,0)                  AS ARWU43_PKNG_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.logistics_cost,0)                   AS ARWU43_LGSTCS_COST_PER_PCE_A
	  ,ISNULL(ASSEMBLY_STAGE.tax_duty_per_operation,0)           AS ARWU43_TAX_AND_DUTY_PER_PCE_A
      ,ISNULL(ASSEMBLY_STAGE.comments,0)                         AS ARWU43_FNL_ASSY_ASSMP_CMT_X
	  ,@TIME_STAMP                                              AS ARWU43_CREATE_S
	  ,@CDSID                                                    AS ARWU43_CREATE_USER_C
	  ,@TIME_STAMP                                              AS ARWU43_LAST_UPDT_S
	  ,@CDSID                                                    AS ARWU43_LAST_UPDT_USER_C
  From PARWS42_DAII_ASSEMBLY_PARTS_INFO   ASSEMBLY_STAGE
  JOIN dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
    ON COVER_PAGE_STAGE.Processing_ID       = ASSEMBLY_STAGE.Processing_ID
   AND COVER_PAGE_STAGE.filename            = ASSEMBLY_STAGE.filename


   JOIN  [dbo].[PARWV04_DSGN_SUPL]  V04
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V04.[ENG_SUB_CMMDTY_DESC]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.[CTSP_REGION_CODE]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N

	   JOIN [dbo].[PARWU37_CCTSS_DSGN_ADJ] U37 
	   ON U37.ARWU06_CCTSS_DSGN_K = V04.ARWU06_CCTSS_DSGN_K
	   AND U37.ARWU37_CCTSS_DSGN_ADJ_ID_N = ASSEMBLY_STAGE.change_improvement_id

 --Currency
     JOIN PARWA29_CRCY   CRCY
       ON ASSEMBLY_STAGE.local_currency = CRCY.ARWA29_CRCY_C
 --Operation Location-Country
Left JOIN PARWA28_CNTRY  LOC
       ON LOC.ARWA28_CNTRY_N = ASSEMBLY_STAGE.operation_location
     JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
       ON a28_EmptyStr.ARWA28_ISO3_CNTRY_C        = ''
  Where cover_page_stage.Processing_ID               = @GUIDIN
    And cover_page_stage.Skip_loading_due_to_error_f = 0
	And ASSEMBLY_STAGE.sub_assembly_name             = 'Adjustment Final Assembly'
	AND ASSEMBLY_STAGE.cost_type = 'Adjustment Costs'
;

GO
