DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_BOM_PART]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 01/07/2020
-- Description:	Validate the PARWS59_PBOM_PARTS staging table
--              Verify the PARWU182 unique key (ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N).  There can't be duplicate part indexes per file and processing_id.
--              Note: Copied from the PARWP_CCS_VALIDT_BOM_PART procedure and modified.
-- =============================================
-- Changes
-- =============================================
-- Author   Date       User Story Description
-- ------   -----      ---------- ----------
-- asolosky 06/15/2020 US1689875  Part Index can't be empty and must start with A-F or DP
-- asolosky 06/15/2020 US1726944  PBOM import - Part Indexes must have either letters [a-z], numbers [0-9] or periods. Plus directed parts must start with DP
-- rwesley2	07/10/2020 U1715516   PBOM Import error when part already exists from DA manage adjustments ADD
--                                PBOM Import error when part already exists from VA manage adjustments ADD
-- asolosky 07/16/2020 US1771016  Added error message for carriage return and line feed.
-- asolosky 08/24/2020 US1804570  Added error message for part index over 64 char.
-- rwesley2 09-11-2020 US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- asolosky 10/06/2020 US1963446  Changed VA Dup error from Error to Warning
-- Asolosky 10/20/2020 US1996362  Switch from E02 to E03 and include Excel column
-- Asolosky 12/11/2020 US2145462  Error 'PBOM part was already added in ARROW manage Design adjustments and is a duplicate', doesn't always display.
--                                The fix was to remove the S59 in-line table and join all the tables in one select.
-- Asolosky 05/19/2021 US2145462  PBOM template change to 6.00 which increases the sub-assemblies from [A-F] to [A-Y] and DP
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_PBOM_VALIDT_BOM_PART] 
-- Input Parameter
 @Processing_ID Varchar(5000)
,@CDSID         Varchar(30)
,@TIME_STAMP    datetime

AS
Declare @Found_error Varchar(1) = 'N';

BEGIN TRY
	SET NOCOUNT ON;

	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,part_index 
		,'Duplicate Part index found in file' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
		,part_index 
		,''       -- no arrow value 
	    ,part_index_column                     as ARWE03_COLUMN

    FROM
	    (
          Select dups.*
                ,COUNT(part_index) OVER (PARTITION BY part_index) part_index_count 
            From
                 (	
	               SELECT
                          S59.*
                         ,row_number()      OVER (PARTITION BY S59.part_index, row_idx order by row_idx) as rownum
	                 FROM PARWS59_PBOM_PARTS  S59
	                Where S59.Processing_ID       = @Processing_ID 
	                 
	             ) DUPS
	       Where rownum = 1
	    ) CNT
   Where part_index_count > 1
;
-- part index naming standards
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(replace(part_index,char(10),'<LF>'),char(10),'<CR>')          as [ARWE03_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   S59.part_index                               as [ARWE03_Part_Index],
		   '',                                          -- no arrow value 
	       part_index_column                            as ARWE03_COLUMN
      FROM 
	       (Select Source_c, part_index, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx, part_index_column,
		           Case When part_index = ''
				             Then 'The Part index is empty and must be entered.'
		                When substring(part_index,1,1) Not in ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y') and
						     Substring(part_index,1,2) != 'DP'
				             Then 'The Part index does not follow proper naming standards. The first position must be a character [A-Y] or DP followed by a number. Part Examples A1.1, DP1.1'  
		                When substring(part_index,1,1) in ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y') and
						     Substring(part_index,1,2) != 'DP' and IsNumeric(substring(part_index,2,1)) = 0 --non-numeric will be a zero.
				             Then 'The Part index does not follow proper naming standards. The first position must be a character [A-Y] followed by a number. Part Example A1.1'  
                        When substring(part_index,1,2) = 'DP' and IsNumeric(substring(part_index,3,1)) = 0 
				             Then 'The Directed Part index does not follow proper naming standards. A Directed part index starts with DP and must be followed by a number. Part Example DP1.1' 
                        When sub_assembly_idx_c = 'DP' and substring(part_index,1,2) != 'DP' 
				             Then 'The Directed Part index does not follow proper naming standards. A Directed part index must start with DP' 
                        When sub_assembly_idx_c != 'DP' and substring(part_index,1,2) = 'DP' 
				             Then 'The Part index does not follow proper naming standards. A non Directed Part sub assembly cannot have a part index that starts with DP' 
                        When part_index like '%[^A-Za-z0-9.]%'
						     Then 'The Part index does not follow proper naming standards. A part can only have letters, numbers and periods' 
                        Else ''
                   End as ERROR_MSG,
		           row_number() over (partition by file_name, part_index order by row_idx) as rownum
		      From PARWS59_PBOM_PARTS  
             Where Processing_ID         = @Processing_ID
		   ) S59
     WHERE rownum     = 1  --A part can show up multiple times due to different designs in the PBOM file. We only want to display the error 1 time.
       and ERROR_MSG != ''
    ;

--DA Dup error
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 x.Source_c
		,x.part_index 
		,'PBOM part was already added in ARROW manage Design adjustments and is a duplicate for design: ' + ARWU14_CCTSS_DSGN_DSPLY_N
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,x.ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,x.sub_assembly_name   
	    ,x.row_idx                               as ARWE03_ROW_IDX
		,x.part_index                            as ARWE03_Part_Index
		,x.ARWU18_BOM_PART_IX_N                  as ARWE03_Arrow_value
	    ,x.part_index_column                     as ARWE03_COLUMN

    FROM
    (
     Select S59.source_c, S59.part_index, S59.file_name, S59.ARWS59_PBOM_PARTS
	       ,S59.sub_assembly_name, S59.row_idx, S59.part_index_column
           ,u06.ARWU14_CCTSS_DSGN_DSPLY_N
		   ,ARWU18_BOM_PART_IX_N
       From PARWS59_PBOM_PARTS      S59
       join PARWU06_CCTSS_DSGN_FLAT U06
         ON U06.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
        and u06.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
        and u06.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
        and u06.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
        and u06.ARWU14_CCTSS_DSGN_DSPLY_N = s59.design_name
       Join PARWU18_BOM_PART        U18
         ON U18.ARWU01_CCTSS_K            = U06.ARWU01_CCTSS_K
        and U18.ARWU18_BOM_PART_IX_N      = S59.part_index
        and Exists (Select 'X'
                      from PARWU37_CCTSS_DSGN_ADJ        U37
     				 Join PARWA40_DSGN_ADJ_PART_CHG_TYP A40 
     				 ON A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = U37.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
     				Where U37.ARWU06_CCTSS_DSGN_K = U06.ARWU06_CCTSS_DSGN_K
     				  and U37.ARWU18_BOM_PART_K   = U18.ARWU18_BOM_PART_K
     				  and A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'A'  --ADD
     			  )
       Where S59.Processing_ID = @Processing_ID
	) x
  ;

-- VA Dupe error
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 x.Source_c
		,x.part_index 
		,'PBOM part was already added in ARROW manage Variant adjustments and is a duplicate'
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,x.ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'WARNING'
		,x.sub_assembly_name   
	    ,x.row_idx                               as ARWE03_ROW_IDX
		,x.part_index                            as ARWE03_Part_Index
		,x.ARWU18_BOM_PART_IX_N                  as ARWE03_Arrow_value
	    ,x.part_index_column                     as ARWE03_COLUMN
    FROM (
  Select S59.*, u04.ARWU04_VRNT_N, ARWU18_BOM_PART_IX_N
  from ( 
         Select Source_c, part_index, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx, part_index_column,
		        User_Selected_CTSP_N, User_Selected_ENRG_SUB_CMMDTY_X, User_Selected_CTSP_Region_C, User_Selected_BNCMK_VRNT_N,
		        design_name,
		        row_number() over (partition by file_name, part_index order by row_idx) as rownum
		   From PARWS59_PBOM_PARTS  
          Where Processing_ID         = @Processing_ID
	   ) s59
  join PARWU04_CCTSS_VRNT_FLAT U04
    ON U04.ARWU31_CTSP_N             = s59.User_Selected_CTSP_N
   and U04.ARWA03_ENRG_SUB_CMMDTY_X  = s59.User_Selected_ENRG_SUB_CMMDTY_X
   and U04.ARWA06_RGN_C              = s59.User_Selected_CTSP_Region_C
   and U04.ARWU01_BNCHMK_VRNT_N      = s59.User_Selected_BNCMK_VRNT_N
  Join PARWU18_BOM_PART        U18
    ON U18.ARWU01_CCTSS_K            = U04.ARWU01_CCTSS_K
   and U18.ARWU18_BOM_PART_IX_N      = S59.part_index
   and Exists (Select 'X'
                 from PARWU65_CCTSS_VRNT_ADJ        U65
				 Join PARWA40_DSGN_ADJ_PART_CHG_TYP A40 ON A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = U65.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
				Where U65.ARWU04_CCTSS_VRNT_K = u04.ARWU04_CCTSS_VRNT_K
				  and U65.ARWU18_BOM_PART_K   = U18.ARWU18_BOM_PART_K
				  and A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'A'  --ADD
			  )
  Where rownum = 1
  )x
  ;

-- Line Feed validation
DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(part_index,char(10),'<LF>')          as [ARWE03_ERROR_VALUE],  --replace line feed with <LF>
	       'A part index can''t have an imbedded line feed <LF>'       as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   s59.part_index                               as [ARWE03_PART_INDEX], 
		   ''                                           as [ARWE03_ARROW_VALUE],
	       part_index_column                            as ARWE03_COLUMN
      FROM 
	       (Select Source_c, part_index, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx, part_index_column,
		           row_number() over (partition by file_name, part_index order by row_idx) as rownum
		      From PARWS59_PBOM_PARTS  
             Where Processing_ID         = @Processing_ID
		   ) S59
     WHERE rownum     = 1  --A part can show up multiple times due to different designs in the PBOM file. We only want to display the error 1 time.
       and NullIf(PATINDEX(@pat10,S59.part_index),0) > 0  --Looking for carriage 
    ;

-- Carriage Return validation
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(part_index,char(13),'<CR>')          as [ARWE03_ERROR_VALUE],  --replace carriage return with <CR>
	       'A part index can''t have an imbedded carriage return <CR>' as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   s59.part_index                               as [ARWE03_PART_INDEX], 
		   ''                                         as [ARWE03_ARROW_VALUE],
	       part_index_column                            as ARWE03_COLUMN
      FROM 
	       (Select Source_c, part_index, Processing_ID, file_name, ARWS59_PBOM_PARTS, sub_assembly_name, row_idx, part_index_column,
		           row_number() over (partition by file_name, part_index order by row_idx) as rownum
		      From PARWS59_PBOM_PARTS  
             Where Processing_ID         = @Processing_ID
		   ) S59
     WHERE rownum     = 1  --A part can show up multiple times due to different designs in the PBOM file. We only want to display the error 1 time.
       and NullIf(PATINDEX(@pat13,S59.part_index),0) > 0  --Looking for carriage 
    ;

--Error for part index over 64 char
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
    Select 
		 Source_c
		,part_index 
		,'Part index can''t be more than 64 characters.' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,ARWS59_PBOM_PARTS
		,'PARWS59_PBOM_PARTS'
		,'ERROR'
		,sub_assembly_name   
	    ,row_idx                               as ARWE03_ROW_IDX
	    ,part_index                            as [ARWE03_PART_INDEX] 
		,''                                    as [ARWE03_ARROW_VALUE]
		,part_index_column                     as ARWE03_COLUMN
   From PARWS59_PBOM_PARTS  
  Where Processing_ID    = @Processing_ID
    and Datalength(part_index)  > 64;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE03_BATCH_PBOM_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,NULL                              --ARWE03_BATCH_ERRORS_REF_K
		,'PARWS59_PBOM_PARTS'              --ARWE03_STAGING_TABLE_X
		--ARWE03_BATCH_ERRORS_K Identity key
		,'ERROR'                           --ARWE03_ERROR_TYPE_X
		,'SYSTEM'                          --ARWE03_EXCEL_TAB_X
		,0                                 --row_idx
		,''                               -- part_index 
		,''                               -- ARROW_VALUE
    	,''                               --column
;
END CATCH;		

EOJ:
GO
