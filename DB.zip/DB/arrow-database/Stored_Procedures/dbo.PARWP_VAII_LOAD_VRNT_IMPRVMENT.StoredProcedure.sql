SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ashaik12
-- Create date: 06/30/2022
-- Description:	Load data for Variant Imporvement Ideas into UD2 table 
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/27/22    ASHAIK12  DE260318  Appending supplier key to fix pink screen
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VAII_LOAD_VRNT_IMPRVMENT] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--=============================================
--=============================================
--  U18 INSERT 
-- TABLE variables to hold new Part Index
 DECLARE @new_part_index TABLE (
         NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
        ,NEW_CHANGE_ID VARCHAR (64) NOT NULL
        ,NEW_PART_NAME VARCHAR (256) NOT NULL
		,NEW_CCTSS INT NOT NULL
	    ,row_idx INT
		                        )
 	;
-- get new part index from s67 that is not on u18. since improvement ideas don't have a type of change any part on the improvement ideas
-- tab that's not on the u18 is assummed to be a part ADD    
-- when skip loading flag is not 0, nothing is loaded to the temp table, so nothing is inserted to u18.
INSERT INTO @new_part_index
   select * from (
       SELECT distinct(s67.part_index )as not_matched_PI
  	         ,s67.improvement_id
	         ,s67.part_name
			 ,u04_view.[ARWU01_CCTSS_K]
 	         ,row_number() OVER (PARTITION BY s67.part_index, s67.part_name,u04_view.[ARWU01_CCTSS_K]
			   order by s67.part_index, s67.part_name,u04_view.[ARWU01_CCTSS_K]) as rownum
       FROM [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO S67
	   LEFT JOIN   [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45
         on S45.Processing_ID       = S67.Processing_ID
        and S45.filename            = S67.filename
  	   LEFT join [dbo].[PARWU04_CCTSS_VRNT_FLAT] u04_view       
	     on S45.[User_Selected_CTSP_N]            = u04_view.[ARWU31_CTSP_N]
		and S45.[User_Selected_CTSP_Region_C]     = u04_view.[ARWA06_RGN_C]
		and S45.[User_Selected_ENRG_CMMDTY_X]     = u04_view.[ARWA02_ENRG_CMMDTY_X]
		and S45.[User_Selected_ENRG_SUB_CMMDTY_X] = u04_view.ARWA03_ENRG_SUB_CMMDTY_X
		and S45.[User_Selected_BNCMK_VRNT_N]      = u04_view.ARWU01_BNCHMK_VRNT_N
		and S45.[User_selected_WALK_VRNT_X]       = u04_view.ARWU04_VRNT_N

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	      on u04_view.ARWU01_CCTSS_K = u18.ARWU01_CCTSS_K
	     and S67.[part_index] = U18.ARWU18_BOM_PART_IX_N
       WHERE s67.Processing_ID       =  @GUIDIN 
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S45.Skip_loading_due_to_error_f = 0
		 ) x
		 Where x.rownum = 1
		 ;
 
-- check for part index match using first 2 characters 
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID       as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) = substring(npi.NEW_CHANGE_ID,1,2)
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;
-- deleting and reloading the temp table to make sure any parts inserted from the 2 character match above don't get inserted again fromn the 1 character match
-- anything inserted to the u18 from the 2 character match will not be on the temp table
DELETE from @new_part_index
INSERT INTO @new_part_index
   select * from (
       SELECT distinct(s67.part_index )as not_matched_PI
  	         ,s67.improvement_id
	         ,s67.part_name
			 ,u04_view.[ARWU01_CCTSS_K]
 	         ,row_number() OVER (PARTITION BY s67.part_index, s67.part_name,u04_view.[ARWU01_CCTSS_K]
			   order by s67.part_index, s67.part_name,u04_view.[ARWU01_CCTSS_K]) as rownum
       FROM [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO  S67
	   LEFT JOIN dbo.PARWS45_VA_COVER_PAGE_INFO      S45
         on S45.Processing_ID       = S67.Processing_ID
        and S45.filename            = S67.filename
  	   LEFT join [dbo].[PARWU04_CCTSS_VRNT_FLAT] u04_view       
	     on S45.[User_Selected_CTSP_N]            = u04_view.[ARWU31_CTSP_N]
		and S45.[User_Selected_CTSP_Region_C]     = u04_view.[ARWA06_RGN_C]
		and S45.[User_Selected_ENRG_CMMDTY_X]     = u04_view.[ARWA02_ENRG_CMMDTY_X]
		and S45.[User_Selected_ENRG_SUB_CMMDTY_X] = u04_view.ARWA03_ENRG_SUB_CMMDTY_X
		and S45.[User_Selected_BNCMK_VRNT_N]      = u04_view.ARWU01_BNCHMK_VRNT_N
		and S45.[User_selected_WALK_VRNT_X]       = u04_view.ARWU04_VRNT_N

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	      on u04_view.ARWU01_CCTSS_K = u18.ARWU01_CCTSS_K
	     and S67.[part_index] = U18.ARWU18_BOM_PART_IX_N
       WHERE s67.Processing_ID       =  @GUIDIN 
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S45.Skip_loading_due_to_error_f = 0
		 ) x
		 Where x.rownum = 1
		 ;
-- doing not DP because if only using first character from a directed part may get wrong sub-assy
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID      as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_CHANGE_ID,1,1)
	   and substring(npi.NEW_CHANGE_ID,1,2) <> 'DP'
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;
--=============================================
--=============================================

INSERT INTO  PARWUD2_CCTSS_VRNT_IMPRV
select
        ARWU04_CCTSS_VRNT_K
	   ,ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	   ,ARWU18_BOM_PART_K
	   ,[ARWUD2_CCTSS_VRNT_IMPRV_IDEA_X]
	   ,[ARWUD2_CCTSS_VRNT_IMPRV_ORIG_X]
       ,@TIME_STAMP                      AS ARWUD2_CREATE_S
       ,@CDSID                           AS ARWUD2_CREATE_USER_C
       ,@TIME_STAMP                      AS ARWUD2_LAST_UPDT_S
       ,@CDSID                           AS ARWUD2_LAST_UPDT_USER_C
	   ,[ARWUD2_SPEC_SDS_NUM_X]
	   ,''								AS ARWUD2_CIA_ID_NUM_X
	   ,[ARWU07_CCTSS_SUPL_K]
	  from
	  (
SELECT  u04_view.ARWU04_CCTSS_VRNT_K 
       ,(CASE 
	      WHEN S67.originator = 'Supplier'
		      THEN  s67.improvement_id + '#' + CONVERT(VARCHAR,U07.[ARWU07_CCTSS_SUPL_K])
			  ELSE s67.improvement_id
        END) as ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	   ,U18.ARWU18_BOM_PART_K             AS [ARWU18_BOM_PART_K]
	   ,S67.idea_description              AS [ARWUD2_CCTSS_VRNT_IMPRV_IDEA_X]
	   ,S67.originator                    AS [ARWUD2_CCTSS_VRNT_IMPRV_ORIG_X]
	   ,S67.Ford_Spec_SDS_Num             AS [ARWUD2_SPEC_SDS_NUM_X]
	   ,U07.[ARWU07_CCTSS_SUPL_K]         AS [ARWU07_CCTSS_SUPL_K]
        From PARWS45_VA_COVER_PAGE_INFO     S45 
        JOIN PARWS67_VA_IMPROVEMENT_IDEAS_INFO  S67
    ON S45.Processing_ID       = S67.Processing_ID
   AND S45.filename            = S67.filename
   AND S67.originator ='Supplier'
  JOIN [dbo].[PARWU04_CCTSS_VRNT_FLAT] u04_view       
	     on S45.[User_Selected_CTSP_N]            = u04_view.[ARWU31_CTSP_N]
		and S45.[User_Selected_CTSP_Region_C]     = u04_view.[ARWA06_RGN_C]
		and S45.[User_Selected_ENRG_CMMDTY_X]     = u04_view.[ARWA02_ENRG_CMMDTY_X]
		and S45.[User_Selected_ENRG_SUB_CMMDTY_X] = u04_view.ARWA03_ENRG_SUB_CMMDTY_X
		and S45.[User_Selected_BNCMK_VRNT_N]      = u04_view.ARWU01_BNCHMK_VRNT_N
		and S45.[User_selected_WALK_VRNT_X]       = u04_view.ARWU04_VRNT_N
    
   JOIN [dbo].[PARWU18_BOM_PART] U18
   ON  u04_view.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K
   AND U18.ARWU18_BOM_PART_IX_N       = S67.part_index  

   JOIN PARWU07_CCTSS_SUPL_FLAT U07
   ON u04_view.ARWU01_CCTSS_K = U07.ARWU01_CCTSS_K
   AND S45.[User_Selected_SUPL_N] = U07.ARWA17_SUPL_N
   AND S45.[User_Selected_SUPL_C] = U07.[ARWA17_SUPL_C]

 Where S45.Processing_ID               = @GUIDIN
   AND S45.Skip_loading_due_to_error_f = 0
   And NOT exists --Insert if it doesn't already exist
      (Select 'X'
        From PARWUD2_CCTSS_VRNT_IMPRV UD2_check
	   Where UD2_check.ARWU04_CCTSS_VRNT_K        = u04_view.ARWU04_CCTSS_VRNT_K 
	       and (CASE WHEN S67.originator = 'Supplier'
		      THEN  s67.improvement_id + '#' + CONVERT(VARCHAR,U07.[ARWU07_CCTSS_SUPL_K])
			  ELSE s67.improvement_id
        END)  = ARWUD2_CCTSS_VRNT_IMPRV_ID_N 
      )
	  ) X
group by ARWU04_CCTSS_VRNT_K
	    ,ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	    ,ARWU18_BOM_PART_K
	    ,[ARWUD2_CCTSS_VRNT_IMPRV_IDEA_X]
	    ,[ARWUD2_CCTSS_VRNT_IMPRV_ORIG_X]
	    ,[ARWUD2_SPEC_SDS_NUM_X]
		,[ARWU07_CCTSS_SUPL_K]
;










GO
