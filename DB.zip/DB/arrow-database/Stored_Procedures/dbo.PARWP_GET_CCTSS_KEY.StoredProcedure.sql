DROP PROCEDURE [dbo].[PARWP_GET_CCTSS_KEY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 05/28/2019
-- Description:	Procedure to return an CCTSS Key which will be passed as parameter to CCT Load Procedures
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   09/05       Added Variant 'VA' to the If-then-Else logic. Changed to use the U01 view.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_GET_CCTSS_KEY]
@GUIDIN VARCHAR(500),
@CCTSS_K INT OUTPUT,
@FILE_TYPE Varchar(50)
AS
	SET NOCOUNT ON;

--There can be multiple files uploaded for the same Program but different suppliers so a Distinct is needed in each query
IF @FILE_TYPE = 'CCS'
   SELECT @CCTSS_K =
   (select Distinct ARWU01_CCTSS_K
      FROM PARWS22_CCS_COVER_PAGE_INFO S22  
      Join PARWU01_CCTSS_FLAT U01
        ON U01.ARWU31_CTSP_N            = S22.User_Selected_CTSP_N
       AND U01.ARWA06_RGN_C             = S22.User_Selected_CTSP_Region_C
       AND U01.ARWA03_ENRG_SUB_CMMDTY_X = S22.User_Selected_ENRG_SUB_CMMDTY_X
       AND U01.ARWU01_BNCHMK_VRNT_N     = S22.User_Selected_BNCMK_VRNT_N
     Where S22.Processing_ID=@GUIDIN
   );

ELSE IF @FILE_TYPE = 'DAII'

   SELECT @CCTSS_K =
   (select Distinct ARWU01_CCTSS_K
      FROM PARWS34_DAII_COVER_PAGE_INFO S34  
      Join PARWU01_CCTSS_FLAT U01
        ON U01.ARWU31_CTSP_N            = S34.User_Selected_CTSP_N
       AND U01.ARWA06_RGN_C             = S34.User_Selected_CTSP_Region_C
       AND U01.ARWA03_ENRG_SUB_CMMDTY_X = S34.User_Selected_ENRG_SUB_CMMDTY_X
       AND U01.ARWU01_BNCHMK_VRNT_N     = S34.User_Selected_BNCMK_VRNT_N
     Where S34.Processing_ID=@GUIDIN
   );

ELSE IF @FILE_TYPE = 'PBOM'

   SELECT @CCTSS_K =
   (select Distinct ARWU01_CCTSS_K
      FROM PARWS59_PBOM_PARTS S59  
      Join PARWU01_CCTSS_FLAT U01
        ON U01.ARWU31_CTSP_N            = S59.User_Selected_CTSP_N
       AND U01.ARWA06_RGN_C             = S59.User_Selected_CTSP_Region_C
       AND U01.ARWA03_ENRG_SUB_CMMDTY_X = S59.User_Selected_ENRG_SUB_CMMDTY_X
       AND U01.ARWU01_BNCHMK_VRNT_N     = S59.User_Selected_BNCMK_VRNT_N
     Where S59.Processing_ID            = @GUIDIN
   );
ELSE --'VA'

   SELECT @CCTSS_K = 
   (select Distinct ARWU01_CCTSS_K
      FROM PARWS45_VA_COVER_PAGE_INFO S45  
      Join PARWU01_CCTSS_FLAT U01
        ON U01.ARWU31_CTSP_N            = S45.User_Selected_CTSP_N
       AND U01.ARWA06_RGN_C             = S45.User_Selected_CTSP_Region_C
       AND U01.ARWA03_ENRG_SUB_CMMDTY_X = S45.User_Selected_ENRG_SUB_CMMDTY_X
       AND U01.ARWU01_BNCHMK_VRNT_N     = S45.User_Selected_BNCMK_VRNT_N
     Where S45.Processing_ID=@GUIDIN
   );

RETURN @CCTSS_K
;


GO
