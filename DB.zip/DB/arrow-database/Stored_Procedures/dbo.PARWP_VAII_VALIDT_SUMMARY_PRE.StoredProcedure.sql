SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 07/06/2022
-- Description:	Consolidated PARWP_VA_VALIDT_ASM_SUMMARY, PARWP_VA_VALIDT_FNL_ASM_SUMMARY, 
--              PARWP_VA_VALIDT_ASM_SUMMARY, PARWP_VA_VALIDT_ASM_SUMMARY, PARWP_VA_VALIDT_ASM_SUMMARY into this procedure
--              Added Markups to the validation verification
--              Markups are a componded total per business rules.  The compounded Markup total matches the Excel file formulas from the Cost sheets
--              Removed Skip_loading_due_to_error_f = 0 from the where clauses. This was present in the original procedures.
-- =============================================
-- Changes
-- =============================================
--                     User
-- Author   Date       Story     Description
-- ------   -----      --------  -----------
-- ASHAIK12 07/12/2022 DE259220  Add Sub Assembly to ON Condition in the merge query
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VAII_VALIDT_SUMMARY_PRE] 
@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS
BEGIN TRY

SET NOCOUNT ON
--For DeBugging
--Declare @GUID varchar(5000)           = '31C3E4BF-57FF-4EB1-9AD5-32C328485965';
--Declare @CDSID varchar(30)            = 'Asolosky';
--Declare @TIME_STAMP DATETIME          = GETUTCDATE();
--Declare @V_Threshold_A DECIMAL(38,18) = .01;

DROP TABLE IF EXISTS #PRE_VA_VALIDATION;
CREATE TABLE #PRE_VA_VALIDATION (
 TEMPLATE_SECTION      VARCHAR(MAX)
,STAGING_COST          Decimal(38,19)
,ARROW_CALC_COST       Decimal(38,19) 
,SOURCE_C              VARCHAR(MAX)
,PROCESSING_ID         VARCHAR(MAX)
,FILENAME              VARCHAR(MAX)
,BATCH_ERROR_REF_K     INT
,STAGING_TABLE         VARCHAR(MAX)
,SUB_ASSEMBLY          VARCHAR(MAX)
);

DROP TABLE IF EXISTS #PARWS54_VA_MARKUPS_FLAT;
CREATE TABLE #PARWS54_VA_MARKUPS_FLAT (
 FILENAME                 VARCHAR(MAX)
,Processing_id            VARCHAR(MAX)
,SUB_ASSEMBLY             VARCHAR(MAX)
,Scrap_Markup             Decimal(38,19)
,Scrap_Markup_Tot_amt     Decimal(38,19)
,SGA_TOTAL_Markup         Decimal(38,19)
,SGA_Markup_Tot_amt       Decimal(38,19)
,PROFIT_Markup            Decimal(38,19)
,PROFIT_Tot_amt           Decimal(38,19)
);

--*****************
--Purchased parts
--*****************
INSERT INTO #PRE_VA_VALIDATION 
Select 'Purchased parts'                      AS TEMPLATE_SECTION 
      ,S67_purchased_part                     AS STAGING_COST 
	  ,S50.S50_unit_cost_usd                  AS ARROW_CALC_COST
      ,S67.Source_c 
	  ,S67.Processing_ID
	  ,S67.filename
	  ,S67.ARWS45_VA_COVER_PAGE_INFO_K
      ,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'   AS STAGING_TABLE
      ,S50.sub_assembly_name                  AS SUB_ASSEMBLY
 From
     (
       select SUM(purchased_part) as S67_purchased_part
	         ,S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
			-- , S46.sheet_name 
	        -- ,Case When S46.sheet_name like 'ADJ-%'
		    --       Then ltrim(Rtrim(substring(S46.sheet_name,5,500)))
			--	   When S46.sheet_name = 'Adjustment Details'
			--	   Then 'Adjustment Costs'  --Need to replace so the join would work
			--       Else S46.sheet_name
		    --  End as S46_substr_sub_assembly_name
         from PARWS67_VA_IMPROVEMENT_IDEAS_INFO S67
         JOIN dbo.PARWS45_VA_COVER_PAGE_INFO     S45 ON S45.Processing_ID = S67.Processing_ID
                                                    AND S45.filename      = S67.filename
        where S45.Processing_ID               = @GUID
        group by S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K--, S46.sheet_name
     ) S67

Join (
        select SUM(CASE WHEN sub_assembly_name!='Costs-Directed Parts' 
		                THEN (no_of_pieces)
						      * (purchased_price_per_piece + inbound_packaging_costs + inbound_logistics_costs + tax_duty)
							  * (1 + purchased_parts_markup_cost)
							  * exchange_rate 
					    ELSE (((no_of_pieces)
						      * (inbound_packaging_costs + inbound_logistics_costs + tax_duty))
							  + ((purchased_price_per_piece + inbound_packaging_costs + inbound_logistics_costs + tax_duty)*purchased_parts_markup_cost*no_of_pieces))
							  * exchange_rate  
					END) as S50_unit_cost_usd  --as COST_PER_PEICE_LoCur
              , S45.filename
              , S45.Processing_ID
              , S50.sub_assembly_name
          FROM PARWS50_VA_PURCHASED_PARTS_INFO  S50
          JOIN PARWS45_VA_COVER_PAGE_INFO       S45 ON S45.Processing_ID     = S50.Processing_ID
                                                   and S45.filename          = S50.filename
          where S45.Processing_ID               = @GUID
            and S50.sub_assembly_name          = 'Improvement Costs'
     	 group by S45.filename, S45.Processing_ID, S50.sub_assembly_name
     ) S50
   On S67.filename                     = S50.filename 
  AND S67.Processing_ID                = S50.Processing_ID

;

--*****************
--Raw materials
--*****************
INSERT INTO #PRE_VA_VALIDATION
Select 'Raw Materials'               AS TEMPLATE_SECTION
      ,S67_raw_material              AS STAGING_COST 
	  ,S40_unit_cost_usd             AS ARROW_CALC_COST
      ,S67.Source_c 
	  ,S67.Processing_ID
	  ,S67.filename
	  ,S67.ARWS45_VA_COVER_PAGE_INFO_K
      ,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
      ,S51.sub_assembly_name         AS SUB_ASSEMBLY
 From
     (
       select SUM(raw_material) as S67_raw_material , S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
         from PARWS67_VA_IMPROVEMENT_IDEAS_INFO S67
         JOIN PARWS45_VA_COVER_PAGE_INFO         S45 ON S45.Processing_ID = S67.Processing_ID
                                                    AND S45.filename      = S67.filename
        where S45.Processing_ID  = @GUID
        group by S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
     ) S67

 Join
     (
        select SUM((no_of_pieces
		             * gross_usage_per_piece
                     * (material_price + inbound_packaging_costs + inbound_logistics_costs + tax_duty_per_uom)
                     - (no_of_pieces * ((gross_usage_per_piece) * reclamation_pcntg * scrap_price))
                   ) * exchange_rate
				  ) as S40_unit_cost_usd  --as Matrl_cost_usd  
              , S45.filename
              , S45.Processing_ID
              , S51.sub_assembly_name
          FROM PARWS45_VA_COVER_PAGE_INFO       S45
     	  Join PARWS51_VA_RAW_MATERIALS_INFO    S51 ON S51.Processing_ID     = S45.Processing_ID
                                                   and S51.filename          = S45.filename
          where S45.Processing_ID               = @GUID
            and S51.sub_assembly_name            = 'Improvement Costs'
				
     	  group by S45.filename, S45.Processing_ID, S51.sub_assembly_name
     ) S51
   On S67.filename                 = S51.filename 
  AND S67.Processing_ID            = S51.Processing_ID

;

--*****************
--Processing
--*****************
INSERT INTO #PRE_VA_VALIDATION 
Select 'Processing'                  AS TEMPLATE_SECTION   
      ,S67_processing              AS STAGING_COST 
	  ,S52_unit_cost_usd             AS ARROW_CALC_COST
      ,S67.Source_c 
	  ,S67.Processing_ID
	  ,S67.filename
	  ,S67.ARWS45_VA_COVER_PAGE_INFO_K
      ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
      ,S52.sub_assembly_name         AS SUB_ASSEMBLY
 From
     (
       select SUM(processing) as S67_processing
	         ,S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K 
         from PARWS67_VA_IMPROVEMENT_IDEAS_INFO S67
         JOIN PARWS45_VA_COVER_PAGE_INFO         S45 ON S45.Processing_ID = S67.Processing_ID
                                                    AND S45.filename      = S67.filename
        where S45.Processing_ID  = @GUID
        group by S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
     ) S67
 Join
     (
        select SUM(CASE WHEN no_of_pieces_per_cycle=0 
		                THEN no_of_pieces_per_subassy*(packaging_costs  + logistics_cost  +  tax_duty_per_piece  + licensing_costs)*exchange_rate
	                    ELSE ( no_of_pieces_per_subassy *
                               (
                                ((cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle) 
                            	+ 
                            	(((cycle_time_sec*(direct_hourly_labor_headcount/3600)*direct_headcount)/no_of_pieces_per_cycle )*(1+indirect_labor_costs)*(1+fringes))
                            	+  packaging_costs + logistics_cost  +  tax_duty_per_piece  + licensing_costs 
                               )
                              ) * exchange_rate
				   END) as S52_unit_cost_usd  --as Processing_Cost_locur  
              , S45.filename
              , S45.Processing_ID
              , S52.sub_assembly_name
          FROM PARWS52_VA_PROCESSING_PARTS_INFO S52
          JOIN PARWS45_VA_COVER_PAGE_INFO       S45 ON S45.Processing_ID     = S52.Processing_ID
                                                   and S45.filename          = S52.filename
          where S45.Processing_ID  = @GUID
            and S52.sub_assembly_name          = 'Improvement Costs'
                
     	 group by S45.filename, S45.Processing_ID,S52.sub_assembly_name
     ) S52
   On S67.filename                 = S52.filename 
  AND S67.Processing_ID            = S52.Processing_ID

;

--*****************
--Assembly
--*****************
INSERT INTO #PRE_VA_VALIDATION 
Select 'Assembly'                   AS TEMPLATE_SECTION   --'Purchased parts' 
      ,assembly_cost                AS STAGING_COST 
	  ,S53_unit_cost_usd            AS ARROW_CALC_COST
      ,S67.Source_c 
	  ,S67.Processing_ID
	  ,S67.filename
	  ,S67.ARWS45_VA_COVER_PAGE_INFO_K
      ,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
      ,S53.sub_assembly_name        AS SUB_ASSEMBLY
 From
     (
       select SUM(assembly) as assembly_cost
             ,S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
         from PARWS67_VA_IMPROVEMENT_IDEAS_INFO S67
         JOIN PARWS45_VA_COVER_PAGE_INFO         S45 ON S45.Processing_ID = S67.Processing_ID
                                                    AND S45.filename      = S67.filename
        where S45.Processing_ID  = @GUID
        group by S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
     ) S67
 Join
     (
        select SUM(IsNUll((assembly_secs_operation
                            * (machinehourly_operation_overhead/3600)
     				       + ((assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount)*(1+indirect_labor_costs)*(1+fringes))
     				       + packaging_costs+logistics_cost+tax_duty_per_operation
     					 ) * exchange_rate,0)
     			 ) as S53_unit_cost_usd  --ASM_COST_CALCULATED
              , S45.filename
              , S45.Processing_ID
              , S53.sub_assembly_name
          FROM PARWS53_VA_ASSEMBLY_PARTS_INFO   S53
          JOIN PARWS45_VA_COVER_PAGE_INFO       S45 ON S45.Processing_ID     = S53.Processing_ID
                                                   and S45.filename          = S53.filename
          where S45.Processing_ID  = @GUID
            and S53.sub_assembly_name          = 'Improvement Costs'
                
     	 group by S45.filename, S45.Processing_ID,S53.sub_assembly_name
     ) S53
    On S67.filename                 = S53.filename 
   AND S67.Processing_ID            = S53.Processing_ID	
;

--*****************
--Final assembly
--*****************
INSERT INTO #PRE_VA_VALIDATION
Select 'Improvement Final Assembly' AS TEMPLATE_SECTION   --'Purchased parts' 
      ,final_assembly_cost         AS STAGING_COST 
	  ,S53_unit_cost_usd           AS ARROW_CALC_COST
      ,S67.Source_c 
	  ,S67.Processing_ID
	  ,S67.filename
	  ,S67.ARWS45_VA_COVER_PAGE_INFO_K
      ,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
      ,S53.sub_assembly_name        AS SUB_ASSEMBLY
 From
     (
       select SUM(final_assembly) as final_assembly_cost 
             ,S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
         from PARWS67_VA_IMPROVEMENT_IDEAS_INFO S67
         JOIN PARWS45_VA_COVER_PAGE_INFO         S45 ON S45.Processing_ID = S67.Processing_ID
                                                    AND S45.filename      = S67.filename
        where S45.Processing_ID  = @GUID
        group by S45.filename, S45.Processing_ID, S45.Source_c, S45.ARWS45_VA_COVER_PAGE_INFO_K
     ) S67
Join
     (
        select SUM(IsNUll((assembly_secs_operation
                           * (machinehourly_operation_overhead/3600)
     				      + ((assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount)*(1+indirect_labor_costs)*(1+fringes))
     				      + packaging_costs+logistics_cost+tax_duty_per_operation
     					 )* exchange_rate,0)
     			  ) as S53_unit_cost_usd --ASM_COST_CALCULATED     
              ,S45.filename
              ,S45.Processing_ID
              ,S53.sub_assembly_name
          FROM PARWS53_VA_ASSEMBLY_PARTS_INFO   S53
          JOIN PARWS45_VA_COVER_PAGE_INFO       S45 ON S45.Processing_ID     = S53.Processing_ID
                                                   and S45.filename          = S53.filename
          where S45.Processing_ID  = @GUID
            and S53.sub_assembly_name ='Improvement Final Assembly'
     	 group by S45.filename, S45.Processing_ID, S53.sub_assembly_name
     ) S53
 On S67.filename      = S53.filename 
AND S67.Processing_ID = S53.Processing_ID
;

--select * from #PRE_VA_VALIDATION;

--*****************
--Setup up the markups From the S54 Staging table so the Scrap, SG&A, Profit and amounts are on one line
--*****************
INSERT INTO #PARWS54_VA_MARKUPS_FLAT
Select FILENAME
      ,Processing_ID
      ,sub_assembly_name                                as SUB_ASSEMBLY
      ,Sum(Scrap_Markup)                                as Scrap_Markup
      ,Sum(Scrap_Markup_Tot_amt)                        as Scrap_Markup_Tot_amt
      ,Sum(SGA_TOTAL_Markup)                            as SGA_TOTAL_Markup
      ,Sum(SGA_Markup_Tot_amt)                          as SGA_Markup_Tot_amt
      ,Sum(PROFIT_Markup)                               as PROFIT_Markup
      ,Sum(PROFIT_Tot_amt)                              as PROFIT_Tot_amt
  From
      (
       Select FILENAME
	         ,Processing_ID
             ,sub_assembly_name
             ,Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value  ELSE 0 END AS Scrap_Markup 
             ,Case When manufacturing_markup_desc = 'Scrap'        Then unit_cost_usd               ELSE 0 END AS Scrap_Markup_Tot_amt 
             ,Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value  ELSE 0 END AS SGA_TOTAL_Markup 
             ,Case When manufacturing_markup_desc = 'SG&A - Total' Then unit_cost_usd               ELSE 0 END AS SGA_Markup_Tot_amt  
             ,Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value  ELSE 0 END AS PROFIT_Markup 
             ,Case When manufacturing_markup_desc = 'Profit'       Then unit_cost_usd               ELSE 0 END AS PROFIT_Tot_amt
         From PARWS54_VA_MANUFACTURING_MARKUPS_INFO S54
        Where Processing_ID = @GUID
		 and manufacturing_markup_desc in ('Scrap','SG&A - Total','Profit')
		 and sub_assembly_name in ('Improvement Costs','Improvement Final Assembly')
      ) MRKUP
group by FILENAME, processing_id, sub_assembly_name;

--select * from #PARWS54_VA_MARKUPS_FLAT

/*****************/
--Staging Table Markups without the ARROW calculated formula cost. ARROW_CALC_COST is set to 0
--Using the markups from the Excel Costs sheets instead of from the Adj sheets
/*****************/
INSERT INTO #PRE_VA_VALIDATION
select 'Manufacturing Markups'                                       AS TEMPLATE_SECTION   
      ,Scrap_Markup_Tot_amt +  SGA_Markup_Tot_amt + PROFIT_Tot_amt   AS STAGING_COST
      ,0                                                             AS ARROW_CALC_COST    --Will update this amount below
      ,S45.Source_c
	  ,S45.Processing_ID
	  ,S45.filename
	  ,S45.ARWS45_VA_COVER_PAGE_INFO_K
      ,'PARWS45_VA_COVER_PAGE_INFO'
      ,S54.SUB_ASSEMBLY
  FROM PARWS45_VA_COVER_PAGE_INFO  S45
  JOIN #PARWS54_VA_MARKUPS_FLAT    S54 ON S54.Processing_ID = S45.Processing_ID
                                      AND S54.filename      = S45.filename
 where S45.Processing_ID = @GUID
;
--select * from #PRE_VA_VALIDATION

--*****************
--Update ARROW manufacturing markup amount in Pre_Val_Target
--*****************
MERGE INTO #PRE_VA_VALIDATION   Pre_Val_Target
USING
(--Pre_Val_Source
Select TOT.FILENAME
      ,TOT.SUB_ASSEMBLY  
      ,'Manufacturing Markups' AS Template_Section  

	  ,SCRAP_MARKUP_TOT    --For testing purpose only
	  ,SGA_MARKUP_TOT      --For testing purpose only
	  ,PROFIT_MARKUP_TOT   --For testing purpose only
	  ,(SCRAP_MARKUP_TOT + SGA_MARKUP_TOT + PROFIT_MARKUP_TOT) As Grand_Total_Markup --This must match the markup subtotal in the Excel file.
  From
(--TOT
Select Split.FILENAME
      ,Split.SUB_ASSEMBLY
	  ,ARROW_Purchased_COST
	  ,ARROW_Raw_COST
	  ,ARROW_Processing_COST
	  ,ARROW_Assembly_COST
	  ,ASM_Process_Raw_A
	  ,Scrap_Markup     * (ASM_Process_Raw_A)                                      as SCRAP_MARKUP_TOT --Markup for Scrap
	  ,SGA_TOTAL_Markup * (ASM_Process_Raw_A + (Scrap_Markup * ASM_Process_Raw_A)) as SGA_MARKUP_TOT   --Markup for SGA is a componded calculation per William Brown
	  ,PROFIT_Markup    * (ASM_Process_Raw_A
	                               + (Scrap_Markup     * (ASM_Process_Raw_A)) --SCRAP_MARKUP
	                               + (SGA_TOTAL_Markup * (ASM_Process_Raw_A + (Scrap_Markup * ASM_Process_Raw_A))) 
								  ) as PROFIT_MARKUP_TOT                                                 --Markup for Profit is a componded calculation per William Brown
  From
(--Split
  Select FILENAME
        ,SUB_ASSEMBLY
        ,Sum(ARROW_Purchased_COST)          as ARROW_Purchased_COST
        ,Sum(ARROW_Raw_COST)                as ARROW_Raw_COST
        ,Sum(ARROW_Processing_COST)         as ARROW_Processing_COST
        ,Sum(ARROW_Assembly_COST)           as ARROW_Assembly_COST
        ,Sum(ARROW_Final_Assembly_COST)     as ARROW_Final_Assembly_COST
		,Case When SUB_ASSEMBLY = 'Improvement Final assembly'                                      --Adjusment Final Assembly doesn't have Raw, Processing, Assembly
		      Then Sum(ARROW_Final_Assembly_COST)                                                  --Amount used for markup calc
			  Else Sum(ARROW_Assembly_COST)   + Sum(ARROW_Processing_COST)   + Sum(ARROW_Raw_COST) --Amount used for markup calc
		 End  ASM_Process_Raw_a
  From
      (--PRE
       --Need to get all the totals already inserted into the temp #PRE_VALIDATION table which will be used to calculate the markups.
       Select FILENAME
             ,SUB_ASSEMBLY
             ,Case When Template_Section = 'Purchased parts'            Then ARROW_CALC_COST ELSE 0 END AS ARROW_Purchased_COST 
             ,Case When Template_Section = 'Raw materials'              Then ARROW_CALC_COST ELSE 0 END AS ARROW_Raw_COST
             ,Case When Template_Section = 'Processing'                 Then ARROW_CALC_COST ELSE 0 END AS ARROW_Processing_COST
             ,Case When Template_Section = 'Assembly'                   Then ARROW_CALC_COST ELSE 0 END AS ARROW_Assembly_COST
             ,Case When Template_Section = 'Improvement Final Assembly'  Then ARROW_CALC_COST ELSE 0 END AS ARROW_Final_Assembly_COST
       
        From #PRE_VA_VALIDATION
	   Where Sub_Assembly in ('Improvement Final Assembly','Improvement Costs')  --Not using Purchased parts for markups but still bringing along for debugging purpose  
      ) PRE
  group by FILENAME, SUB_ASSEMBLY 
) SPLIT
Join #PARWS54_VA_MARKUPS_FLAT S54_FLAT on S54_FLAT.filename     = Split.filename 
                                      and S54_FLAT.SUB_ASSEMBLY = Split.SUB_ASSEMBLY
) TOT
)  Pre_Val_Source

ON (Pre_Val_Target.FILENAME             = Pre_Val_Source.FILENAME  AND  
	Pre_Val_Target.Template_Section     = Pre_Val_Source.Template_Section
	AND	Pre_Val_Target.SUB_ASSEMBLY = Pre_Val_Source.SUB_ASSEMBLY
   )
when MATCHED THEN
UPDATE SET          
 	Pre_Val_Target.ARROW_CALC_COST = Pre_Val_Source.Grand_Total_Markup
;

--Select * From #PRE_VA_VALIDATION;
--Select * from #PARWS54_VA_MARKUPS_FLAT;



/*****************/
--ERRORS
/*****************/
INSERT INTO dbo.PARWE02_BATCH_ERRORS
select 
       Source_c
      ,CAST(STAGING_COST as Varchar(50)) as ARWE02_ERROR_VALUE
--	  ,TEMPLATE_SECTION
      ,Case When TEMPLATE_SECTION = 'Purchased parts' Then
      	         'Purchased Parts total in Supplier Quote Summary does not match calculated Purchased Parts total. Please verify that the formulas have not been changed in column L of the Improvement Ideas sheet and/or column Z/AB of the Improvement Cost-Purchased Part section. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Raw materials' Then
			     'Raw Materials total in Supplier Quote Summary does not match calculated Raw Materials total. Please verify that the formulas have not changed in column M of the Improvement Ideas sheet and/or column Z/AB of the Improvement Cost-Raw Materials section. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Processing' Then
                 'Processing total in Supplier Quote Summary does not match calculated Processing total. Please verify that the formulas have not changed in column N of the Improvement Ideas sheet and/or column Z/AB of the Improvement Cost-Processing section. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Assembly' Then
                 'Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not changed in column O of the Improvement Ideas sheet and/or column Z/AB of the Improvement Cost-Assembly section. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Improvement Final assembly' Then
                 'Final Assembly total in Supplier Quote Summary does not match calculated Final Assembly total. Please verify that the formulas have not changed in column Q of the Improvement Ideas sheet and/or column X/Z of the Improvement Cost-Final Assembly section. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.' 
			When TEMPLATE_SECTION = 'Manufacturing markups' AND SUB_ASSEMBLY = 'Improvement Costs' Then
                 'Manufacturing markup total in Improvement Costs does not match calculated Manufacturing markup total. Please verify that the formulas have not been changed in column AB of the Total Markup per Piece section. Also remove any blank rows between markups. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Manufacturing markups' AND SUB_ASSEMBLY = 'Improvement Final Assembly' Then
                 'Manufacturing markup total in Improvement Final Assembly does not match the calculated Final Assembly Manufacturing markup total. Please verify that the formulas have not been changed in column Z of the Total Markup section. Also remove any blank rows between markups. The system will stop reading the data when it finds 2 blank rows.'
            Else TEMPLATE_SECTION + ' Unknown Template Section. Contact ARROW Support'
       End as ARWE02_ERROR_X

      ,Processing_ID
      ,filename
      ,OBJECT_NAME(@@PROCID)  as ARWE02_PROCEDURE_X
      ,@TIME_STAMP  as ARWE02_CREATE_S
      ,@CDSID       as ARWE02_CREATE_USER_C
      ,@TIME_STAMP  as ARWE02_LAST_UPDT_S
      ,@CDSID       as ARWE02_LAST_UPDT_USER_C
      ,BATCH_ERROR_REF_K
      ,STAGING_TABLE
      ,'ERROR'
      ,SUB_ASSEMBLY
      ,0                               as ARWE02_ROW_IDX
      ,''       --Part_index
      ,CAST(ARROW_CALC_COST as varchar(50)) as ARWE02_ARROW_Value
 FROM #PRE_VA_VALIDATION
Where 
  (
      ABS(ARROW_CALC_COST) <  ABS(STAGING_COST) - @V_Threshold_A
	  or 
	  ABS(ARROW_CALC_COST) >  ABS(STAGING_COST) + @V_Threshold_A
   )
;
--select * from PARWE02_BATCH_ERRORS where ARWE02_PROCESSING_ID = '31C3E4BF-57FF-4EB1-9AD5-32C328485965';--@GUID;
DROP TABLE IF EXISTS #PRE_VA_VALIDATION;
DROP TABLE IF EXISTS #PARWS54_VA_MARKUPS_FLAT;

END TRY

BEGIN CATCH

DROP TABLE IF EXISTS #PRE_VA_VALIDATION;
DROP TABLE IF EXISTS #PARWS54_VA_MARKUPS_FLAT;

INSERT INTO dbo.PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;

GO
