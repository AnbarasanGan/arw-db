SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 04/28/2021
-- Description:	Procedure to call Program exchange rate update from the UI.
--              This takes the summary procedures from the CCS/GCS, DAII and VA import and
--              consolidates them so the UI can make one call for an update.
--            
-- How to Run Manually
--    DECLARE @RC int
--    Declare @U31_K int = 1
--    DECLARE @CDSID   varchar(8) = 'ASOLOSKY'
--    DECLARE @result  int
--    
--    EXECUTE @RC = [dbo].[PARWP_UI_PRGM_EXCHG_RATE_UPD]
--      ,@U31_K
--      ,@CDSID
--      ,@result OUTPUT
--    ;
-- =============================================
-- Changes
-- =============================================
-- Author     Date      User Story  Description
-- ------     -----     ----------  -----------
-- btemkow    2022-01-24 US3259290  Added call to PARWP_CALC_MASTER_LOAD_PRIMARY
-- btemkow    2022-04-06 US3501484  updated status names
-- Asolosky   2022-06-03 US3690513  Change DA Consolidation to use PARWP_DAIICT_SUMMARY
-- Ashaik12  07/27/2022 US3876656   Add VA II summary table delete SP and load SP
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_UI_PRGM_EXCHG_RATE_UPD] 
@U31_K int, 
@CDSID   varchar(8),
@err_msg varchar(max) Output

AS
Begin
 SET NOCOUNT ON;
 DECLARE @TIME_STAMP DATETIME = GETUTCDATE();
 DECLARE @ARWA11_k   INT;
 DECLARE @Comment    VARCHAR(1024) = 'Program Exchange Rate Update';

 DECLARE @CCTSS_K INTEGER;
 DECLARE @Primary_output_error  VARCHAR(5000);
 DECLARE @u01_Study             Varchar(100);

 Set @err_msg = 'SUCCESS';
 
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));

 BEGIN TRY
 
 Select @ARWA11_k = ARWA11_CCTSS_STAT_K
   From PARWA11_CCTSS_STAT
  Where ARWA11_CCTSS_STAT_N = 'To be Reconciled'
   
 BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master
 
  	DECLARE BoB_cur CURSOR FOR Select ARWU01_CCTSS_K from PARWU01_CCTSS_FLAT where ARWU31_CTSP_K = @U31_K;
	OPEN BoB_cur;
	FETCH NEXT FROM BoB_cur INTO @CCTSS_K;
	WHILE @@FETCH_STATUS = 0 and @err_msg = 'SUCCESS'
	BEGIN

	Set @u01_Study = (Select U01.ARWU31_CTSP_N    + ' ' +
                          U01.ARWA06_RGN_C     + ' ' +
                   	      substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	      substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                     from PARWU01_CCTSS_FLAT  U01
                    where U01.ARWU01_CCTSS_K = @CCTSS_K
 				  );

	-- CCS/GCS Consolidation
    EXEC [dbo].[PARWP_CST_CONSL_DELETE_SUM_TBLS]    @CCTSS_K;

	EXEC [dbo].[PARWP_CCT_LOAD_PURCHPART]           @CCTSS_K, @CDSID, @TIME_STAMP; --U55
	EXEC [dbo].[PARWP_CCT_LOAD_U56_SUPL_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP; --U56
	EXEC [dbo].[PARWP_CCT_UPD_U06_DSGN_FNLASSY]     @CCTSS_K, @CDSID, @TIME_STAMP; --U06
	EXEC [dbo].[PARWP_CCT_LOAD_U08_FINAL_ASSY]      @CCTSS_K, @CDSID, @TIME_STAMP; --U08
	EXEC [dbo].[PARWP_CCT_UPD_U08_SUPL_QTE_A]       @CCTSS_K, @CDSID, @TIME_STAMP; --U08
	EXEC [dbo].[PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP; --U57

	-- DAII Consolidation	
   EXEC [dbo].[PARWP_DAIICT_SUMMARY]               @CCTSS_K, @CDSID, @TIME_STAMP;	      

	-- Variant Consolidation
    EXEC [dbo].[PARWP_VA_CONSL_DELETE_SUM_TBLS]        @CCTSS_K;

	EXEC [dbo].[PARWP_VACT_LOAD_U81_SUPL_VRNT_ADJ]     @CCTSS_K, @CDSID, @TIME_STAMP; --U81

	-- VA II 
	EXEC [dbo].[PARWP_VAII_CONSL_DELETE_SUM_TBLS]  @CCTSS_K;
	EXEC [dbo].[PARWP_VAIICT_LOAD_UD9_SUPL_DSGN_IMPRV] @CCTSS_K, @CDSID, @TIME_STAMP; -- UD9

	-- Set BoB status to Invalid
    EXEC  [dbo].[PARWP_CCTSS_INSERT_BOB_STATUS]        @CCTSS_K, @CDSID, @TIME_STAMP, @ARWA11_k, @Comment;

	-- (Re)load the Primary Calc tables
    EXEC [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
         @U01_k                = @CCTSS_K
       , @U06_k                = -1
       , @U04_k                = -1
       , @CDSID                = @CDSID
       , @TRIGGER              = 'PROGRAM EXCHANGE CHANGE'
       , @Primary_output_error = @Primary_output_error OUTPUT
    ;   

    If @Primary_output_error = ''
       Begin
		 FETCH NEXT FROM BoB_cur INTO @CCTSS_K;
       End
    Else
       Begin
         Set @err_msg = 'Master Load Primary Error: ' + @Primary_output_error;
       End
	END;
	CLOSE BoB_cur;
	DEALLOCATE BoB_cur;

   If @err_msg = 'SUCCESS'
	   Begin
         COMMIT TRANSACTION
	   End
   Else
	   Begin
         Rollback
       End

 END TRY

 --CATCH
 BEGIN CATCH

 	CLOSE BoB_cur;
	DEALLOCATE BoB_cur;

    Rollback;

     Set @err_msg = 'PROGRAM EXCHANGE RATE CHANGE SYSTEM ERROR: ' +              
	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

  END CATCH;	
End;
GO
