DROP PROCEDURE [dbo].[PARWP_PBOM_SCRUB_SPCL_CHARS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 10/31/2019
-- Description:	scub procedure to remove special characters from PBOM
-- =============================================
-- CHANGES                  User
-- Date			CDSID		Story	  Description
-- ----------   --------    -------   -----------
-- 02-04-2020   rwesley2	US1359101 Add scrub to remove leading space from part index		
-- 02-10-2020   rwesley2	US1359101 Add scrub to replace '-' with 0 (zero) for length, width, depth, usage, and thickness
-- 02-14-2020	asolosky    US1359101 Removed the scrub for Design Display Name.  The scrub removed 2 spaces when we didn't want it removed
-- 02-27-2020	asolosky    US1456108 Changed the '-' scrub to select only columns = '-' and update to 0
-- 07-16-2020	asolosky    US1771016 removed the scrub for part_index and name. A new error was added to check for CR/LF. Also added scrub for diameter
-- 09-11-2020   rwesley2    US1910880 Add part index and Arrow value to error. Write error to new E02 error table
-- 10-15-2020   asolosky    US2002682 Remove update of '-' to zero.  All '-' must not produce an error.
-- 10-20-2020   asolosky    US1996362 Switch from E02 to E03 and include Excel column.
-- 09-02-2021   asolosky    US2831635 Added design_name to trim spaces.
-- 09-16-2021   asolosky    US2831635 Added sub_assembly_name and sub_assembly_idx_c to trim spaces.
-- =============================================	
CREATE PROCEDURE [dbo].[PARWP_PBOM_SCRUB_SPCL_CHARS]
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

UPDATE [dbo].[PARWS59_PBOM_PARTS]
   SET part_index          = LTRIM(RTRIM(s59.part_index)),
       part_name           = LTRIM(RTRIM(s59.part_name)),
	   design_name         = LTRIM(RTRIM(s59.design_name)),
	   sub_assembly_name   = LTRIM(RTRIM(s59.sub_assembly_name)),
	   sub_assembly_idx_c  = LTRIM(RTRIM(s59.sub_assembly_idx_c))
  FROM [dbo].[PARWS59_PBOM_PARTS]   s59
 WHERE s59.Processing_ID   = @GUID
;

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE
			 ,''                               -- Column
END CATCH





GO
