DROP PROCEDURE [dbo].[PARWP_DA_VALIDT_PRO_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 11/21/2019
-- Description:	Validate if sum of Purchased unit cost is equal to the cost in Summary table. 
--              This helps to identify if any part indexes errored out in validation from the Purchased Parts table
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   12/18/2019  Converted from using the views for validation to the staging tables.  An error won't let the data load to ARROW
-- Ashaik12   03/10/2020  Fix Tab Name
-- rwesley2   05/04/2020  US1575405 removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s35.sheet_name. 
--                        Only applies to DA not II
-- rwesley2   06/03/2020  US1667506 added logic to handle single tab template versions
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12   14/12/2020  Use calculated unit cost instead of the staging value (the final value could be hardcoded)
-- Asolosky   01/19/2021  US2164194 Changed the threshold from a dynamic number which used the UpperBound and LowerBound function, to a static number.
--                        The static threshold number is passed in from the master procedure and is based on the PARWT01_THRESHOLD table.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DA_VALIDT_PRO_SUMMARY] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS

-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.
SET NOCOUNT ON;

BEGIN TRY
--++++++++++++++++++++++++++++++++++++
    -- processing totals validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
 X.ARWE02_SOURCE_C
,X.s35_cost             --'Processing total in Supplier Quote Summary: '+ CAST(S35_processing as varchar(50))
,X.ARWE02_ERROR_X
,X.ARWE02_PROCESSING_ID
,X.ARWE02_FILENAME
,X.ARWE02_PROCEDURE_X
,X.[ARWE02_CREATE_S]
,X.[ARWE02_CREATE_USER_C]
,X.ARWE02_LAST_UPDT_S
,X.[ARWE02_LAST_UPDT_USER_C]
,X.ARWE02_BATCH_ERRORS_REF_K
,X.ARWE02_STAGING_TABLE_X
,'ERROR'
,X.ARWE02_EXCEL_TAB_X + ' - Supplier Quote Summary'
,0                               as ARWE02_ROW_IDX
,''                -- No Part Index
,S41_unit_cost_usd -- ' does not match Processing total in Arrow: ' + CAST(S41_unit_cost_usd as varchar(50))
FROM
(
select 
       S35.Source_c                            AS [ARWE02_SOURCE_C],
       S41_unit_cost_usd,
       CASE WHEN S35_processing = S41_unit_cost_usd 
	        THEN '' 
			ELSE 'Processing total in Supplier Quote Summary does not match calculated Processing total. Please verify that the formulas have not changed in column P of the Adj sheet and/or column Z/AB of Processing section in the Costs sheet'
			END AS ARWE02_ERROR_X  
       ,S35.Processing_ID                      AS ARWE02_PROCESSING_ID
       ,S35.filename                           AS ARWE02_FILENAME 
       ,OBJECT_NAME(@@PROCID)                  AS [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP                           AS [ARWE02_CREATE_S]
       ,@CDSID                                 AS [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP                           AS [ARWE02_LAST_UPDT_S]
       ,@CDSID                                 AS [ARWE02_LAST_UPDT_USER_C]
       ,S35.ARWS34_DAII_COVER_PAGE_INFO_K      AS [ARWE02_BATCH_ERRORS_REF_K]
       ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO' AS [ARWE02_STAGING_TABLE_X]
       ,S41_unit_cost_usd                      AS S41_summed_cost
       ,S35_processing                         AS s35_cost
	   ,S41.sub_assembly_name                  AS ARWE02_EXCEL_TAB_X
from 
(
  select SUM(processing) as S35_processing , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K,S35.sheet_name 
    from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
    JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                 AND S34.filename      = S35.filename
   where S34.Processing_ID               = @GUID
     and S34.Skip_loading_due_to_error_f = 0
   group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
) S35
Join
(
   select SUM(CASE WHEN [no_of_pieces_per_cycle]=0 THEN [no_of_pieces_per_subassy]*([packaging_costs]  + [logistics_cost]  +  [tax_duty_per_piece]  + [licensing_costs])*exchange_rate
	ELSE ( [no_of_pieces_per_subassy]*
   (
    (([cycle_time_sec]*([machinehourly_operation_overhead]/3600))/[no_of_pieces_per_cycle]) 
	+ 
	((([cycle_time_sec]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])/[no_of_pieces_per_cycle] )*(1+[indirect_labor_costs])*(1+[fringes]))
	+  [packaging_costs] + [logistics_cost]  +  [tax_duty_per_piece]  + [licensing_costs] 
   )
  ) *[exchange_rate]  END) as S41_unit_cost_usd
  , S34.filename
  , S34.Processing_ID
  , S41.sub_assembly_name
     FROM PARWS34_DAII_COVER_PAGE_INFO       S34
	 Join PARWS41_DAII_PROCESSING_PARTS_INFO S41 ON S41.Processing_ID     = S34.Processing_ID
                                                and S41.filename          = S34.filename
     where S34.Processing_ID               = @GUID
	   and S34.Skip_loading_due_to_error_f = 0
       and S41.sub_assembly_name            like 'Costs%'
	 group by S34.filename, S34.Processing_ID,S41.sub_assembly_name
) S41
 On S35.filename = S41.filename AND S35.Processing_ID = S41.Processing_ID
	and ltrim(Rtrim(substring(s35.sheet_name,5,500))) = ltrim(rtrim(substring(s41.sub_assembly_name,7,500)))
	and s35.sheet_name like 'ADJ-%'    
) X
where X.ARWE02_ERROR_X!=''
  and 
	(
	  ABS(S41_summed_cost) <  ABS(s35_cost) - @V_Threshold_A
	  or 
	  ABS(S41_summed_cost) >  ABS(s35_cost) + @V_Threshold_A
	)

UNION

select 
 X.ARWE02_SOURCE_C
,X.s35_cost              --ARWE02_ERROR_VALUE
,X.ARWE02_ERROR_X
,X.ARWE02_PROCESSING_ID
,X.ARWE02_FILENAME
,X.ARWE02_PROCEDURE_X
,X.[ARWE02_CREATE_S]
,X.[ARWE02_CREATE_USER_C]
,X.ARWE02_LAST_UPDT_S
,X.[ARWE02_LAST_UPDT_USER_C]
,X.ARWE02_BATCH_ERRORS_REF_K
,X.ARWE02_STAGING_TABLE_X
,'ERROR'
,X.ARWE02_EXCEL_TAB_X + ' - Supplier Quote Summary'
,0                               as ARWE02_ROW_IDX
,''
,S41_unit_cost_usd
FROM
(
select 
       S35.Source_c                            AS [ARWE02_SOURCE_C],
       S41_unit_cost_usd,
       CASE WHEN S35_processing = S41_unit_cost_usd 
	        THEN '' 
			ELSE 'Processing total in Supplier Quote Summary does not match calculated Processing total. Please verify that the formulas have not changed in column P of the Adj sheet and/or column Z/AB of Processing section in the Costs sheet'
			END AS ARWE02_ERROR_X  
       ,S35.Processing_ID                      AS ARWE02_PROCESSING_ID
       ,S35.filename                           AS ARWE02_FILENAME 
       ,OBJECT_NAME(@@PROCID)                  AS [ARWE02_PROCEDURE_X]
       ,@TIME_STAMP                           AS [ARWE02_CREATE_S]
       ,@CDSID                                 AS [ARWE02_CREATE_USER_C]
       ,@TIME_STAMP                           AS [ARWE02_LAST_UPDT_S]
       ,@CDSID                                 AS [ARWE02_LAST_UPDT_USER_C]
       ,S35.ARWS34_DAII_COVER_PAGE_INFO_K      AS [ARWE02_BATCH_ERRORS_REF_K]
       ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO' AS [ARWE02_STAGING_TABLE_X]
       ,S41_unit_cost_usd                      AS S41_summed_cost
       ,S35_processing                         AS s35_cost
	   ,s35.sheet_name                         AS ARWE02_EXCEL_TAB_X
from 
(
  select SUM(processing) as S35_processing , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K,S35.sheet_name 
    from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
    JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                 AND S34.filename      = S35.filename
   where S34.Processing_ID               = @GUID
     and S34.Skip_loading_due_to_error_f = 0
   group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
) S35
Join
(
   select SUM(CASE WHEN [no_of_pieces_per_cycle]=0 THEN [no_of_pieces_per_subassy]*([packaging_costs]  + [logistics_cost]  +  [tax_duty_per_piece]  + [licensing_costs])*exchange_rate
	ELSE ( [no_of_pieces_per_subassy]*
   (
    (([cycle_time_sec]*([machinehourly_operation_overhead]/3600))/[no_of_pieces_per_cycle]) 
	+ 
	((([cycle_time_sec]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])/[no_of_pieces_per_cycle] )*(1+[indirect_labor_costs])*(1+[fringes]))
	+  [packaging_costs] + [logistics_cost]  +  [tax_duty_per_piece]  + [licensing_costs] 
   )
  ) *[exchange_rate]  END) as S41_unit_cost_usd
  , S34.filename
  , S34.Processing_ID
  , S41.sub_assembly_name
     FROM PARWS34_DAII_COVER_PAGE_INFO       S34
	 Join PARWS41_DAII_PROCESSING_PARTS_INFO S41 ON S41.Processing_ID     = S34.Processing_ID
                                                and S41.filename          = S34.filename
     where S34.Processing_ID               = @GUID
	   and S34.Skip_loading_due_to_error_f = 0
       and  S41.sub_assembly_name                   like 'Adjustment Costs'
		 group by S34.filename, S34.Processing_ID,S41.sub_assembly_name
) S41
 On S35.filename = S41.filename AND S35.Processing_ID = S41.Processing_ID
	and  s35.sheet_name = 'Adjustment details'
		  
) X
where X.ARWE02_ERROR_X!=''
  and 
	(
	  ABS(S41_summed_cost) <  ABS(s35_cost) - @V_Threshold_A
	  or 
	  ABS(S41_summed_cost) >  ABS(s35_cost) + @V_Threshold_A
	)

;
END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;    


GO
