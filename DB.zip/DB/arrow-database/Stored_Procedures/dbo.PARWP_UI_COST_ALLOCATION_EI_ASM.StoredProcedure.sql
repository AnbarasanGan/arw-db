DROP PROCEDURE IF EXISTS [dbo].[PARWP_UI_COST_ALLOCATION_EI_ASM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =========================================================================================
-- Author:		KVIJAYAB
-- Create date: MAR/25/2021
-- Description:	This SP should be called after running [PARWP_UI_COST_ALLOCATION_EI] SP
--				For given U04 key, this SP gives the already allocated 
--				end-item cost per subassembly. And the total sub assembly cost.
--				Called from Cost Allocation screen. 
-- Input Parameter: 
--		@ARWU04_CCTSS_VRNT_K = the variant key for which the data is required, 
--		@LWST_IDC_DSGN_KEY	 = the lowest IDC design key, 
--		@PROCESSING_ID		 = the processing id that the PARWP_UI_COST_ALLOCATION_EI SP returned
-- Output: Returns the values from a select statement
-- How to Run:  Execute [PARWP_UI_COST_ALLOCATION_EI_ASM] @ARWU04_CCTSS_VRNT_K = 1, @LWST_IDC_DSGN_KEY = 55, @PROCESSING_ID = '9A447857-2946-475A-A719-69E0C668659B'
-- Changes
-- =========================================================================================
-- Author     Date         Description
-- ------     -----        -----------
-- kvijayab	  MAR/25/2021  initial version
-- =========================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_COST_ALLOCATION_EI_ASM] 
@ARWU04_CCTSS_VRNT_K INTEGER,
@LWST_IDC_DSGN_KEY   INTEGER,
@PROCESSING_ID   UNIQUEIDENTIFIER

AS

SET NOCOUNT ON;
Declare @Start_Time DATETIME = GETUTCDATE();

IF ((SELECT ARWA11_FRZN_DATA_F FROM PARWU04_CCTSS_VRNT_FLAT WHERE ARWU04_CCTSS_VRNT_K = @ARWU04_CCTSS_VRNT_K) = 1)
BEGIN
	SELECT DATATYPE, ARWA47_FORD_END_ITM_K, ARWU17_BOM_SUB_ASSY_K, ASM_QUOTE FROM PARWD18_COST_ALLOCATION_EI_ASM
	WHERE ARWU04_CCTSS_VRNT_K = @ARWU04_CCTSS_VRNT_K
END
ELSE BEGIN TRY

	-- gather qte, da, ii data starts

	--DECLARE @ARWU04_CCTSS_VRNT_K INTEGER = 2;
	--DECLARE @LWST_IDC_DSGN_KEY	 INTEGER = 55;
	--DECLARE @PROCESSING_ID   UNIQUEIDENTIFIER = '9A447857-2946-475A-A719-69E0C668659B';


	-- row wise allocation per assembly
	SELECT --@ARWU04_CCTSS_VRNT_K as ARWU04_CCTSS_VRNT_K,
	CONCAT('ROW_', ARWA47_FORD_END_ITM_K, '_', ARWU17_BOM_SUB_ASSY_K) AS DATATYPE, ARWA47_FORD_END_ITM_K, ARWU17_BOM_SUB_ASSY_K, ARWUB0_SUB_ASSY_ALLOC_A AS ASM_QUOTE
	FROM PARWUA9_VRNT_END_ITM UA9
	JOIN PARWUB0_VRNT_END_ITM_SUB_ASSY UB0 ON UB0.ARWUA9_VRNT_END_ITM_K = UA9.ARWUA9_VRNT_END_ITM_K
	WHERE ARWU04_CCTSS_VRNT_K = @ARWU04_CCTSS_VRNT_K

	UNION
	
	--total quote per assembly
	SELECT --@ARWU04_CCTSS_VRNT_K as ARWU04_CCTSS_VRNT_K, 
	CONCAT('TOTAL_', ARWU17_BOM_SUB_ASSY_K) AS DATATYPE, NULL AS ARWA47_FORD_END_ITM_K, ARWU17_BOM_SUB_ASSY_K, ADJ_BOB AS ASM_QUOTE
	FROM --PARWP01_BOB_DAII_ASSY_SUMM 
		PARWD02_BOB_DAII_ASM_SUMMARY
	WHERE --Processing_ID = @PROCESSING_ID AND 
		ARWU06_CCTSS_DSGN_K = @LWST_IDC_DSGN_KEY
	GROUP BY ARWU17_BOM_SUB_ASSY_K, ADJ_BOB

	--DELETE FROM [dbo].PARWP01_BOB_DAII_ASSY_SUMM WHERE Processing_ID = @PROCESSING_ID;

--	Select OBJECT_NAME(@@PROCID) as Procedure_Name 
--      ,@@Rowcount                                 as Records_Returned
--      ,convert(time, GETUTCDATE() - @Start_Time ) as run_time;

END TRY

BEGIN CATCH

END CATCH

GO
