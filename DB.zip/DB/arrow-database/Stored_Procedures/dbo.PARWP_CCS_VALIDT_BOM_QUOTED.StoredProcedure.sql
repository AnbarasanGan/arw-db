DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_QUOTED]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 06/06/2019
-- Description:	Validate that all parts on the BOM have been quoted. 
-- =============================================
-- =============================================
-- Changes
-- Date        CDSID    Feature   Description
-- ----------  -------- -------   -----------
-- 06/28/2019  asolosky N/A       Changed to select only data from the S13 where quoted='No' 
--                                The No records must be marked as an error.  Commented out the old code for now. 
-- 09/10/2019  Asolosky           Added row_idx
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- 09/11/2020  Asolosky US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- 12/07/2020  Asolosky US2129929 Display an error when BOM Quoted column is not Yes or No
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_BOM_QUOTED] 
-- Input Parameter
 @GUID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
	SET NOCOUNT ON;
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Err.Source_c
		,Err.[part_index]
		,'BOM Part Index not quoted' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.[ARWS13_CCS_FORD_BOM_PARTS_INFO_K]  
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'  
        ,'WARNING'                       
		,'BoM'+' - '+ Err.[part_sub_assembly_name]
	    ,row_idx                               as ARWE02_ROW_IDX
		,[part_index]
		,''  --No ARROW Value
    FROM
    (	
	  SELECT S13.*
	    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
	   WHERE S13.processing_ID        =@GUID
		 and s13.[quoted]            = 'No'	  
	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,quoted
		,'Quoted column must be Yes or No. The template has a formula in this column which was manually overridden. Please copy the formula from a valid "Quoted" cell and paste it into the cell with the error. This will automatically populate a Yes or No.' as Error_Msg
        ,Processing_ID 
		,file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,ARWS13_CCS_FORD_BOM_PARTS_INFO_K 
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'  
        ,'ERROR'                       
		,'BoM'+' - '+ part_sub_assembly_name
	    ,row_idx                               as ARWE02_ROW_IDX
		,part_index
		,''  --No ARROW Value
    FROM PARWS13_CCS_FORD_BOM_PARTS_INFO S13
    WHERE S13.processing_ID          = @GUID
	  and IsNull(s13.quoted,'#!~&$') Not in ('Yes', 'No')	  
	;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                  --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0   --row_idx
		,''  --Part_index
		,''  --Arrow value
    ;

END CATCH;	



GO
