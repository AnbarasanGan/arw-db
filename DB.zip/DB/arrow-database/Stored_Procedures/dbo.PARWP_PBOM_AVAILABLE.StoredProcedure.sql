DROP PROCEDURE [dbo].[PARWP_PBOM_AVAILABLE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2019
-- Description:	Determines if a BoB has PBOM or (Cost Sheets/DAII/Variant) files already loaded
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- IN parameter:  @CCTSS_K  = U01_K (BoB key)
-- Out paramenter:@PBOM     = 'Y' if PBOM file is loaded
-- How to Execute:
--     Declare @PBOM Varchar(1);
--     execute PARWP_PBOM_AVAILABLE 130, @PBOM OUTPUT;
--     select @PBOM as PBOM;
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_PBOM_AVAILABLE] 
-- Input Parameter
 @CCTSS_K                    Int
,@PBOM_AVAILABLE_OUT         Varchar(1) = 'N' OUTPUT
AS


SET NOCOUNT ON;

--Check if PBOM file is available
Select @PBOM_AVAILABLE_OUT  = 'Y'
  From PARWU01_CCTSS_FLAT
 Where ARWU01_CCTSS_K = @CCTSS_K
   and IsNull(ARWU01_PBOM_LAST_IMPT_FILE_N,'') != ''
;

--If PBOM is NUll, set to N
If IsNull(@PBOM_AVAILABLE_OUT,'N') = 'N' 
   Set @PBOM_AVAILABLE_OUT = 'N'
;
GO
