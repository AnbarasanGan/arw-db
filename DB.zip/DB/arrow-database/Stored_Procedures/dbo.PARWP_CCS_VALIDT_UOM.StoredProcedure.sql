DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_UOM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 03/22/2019
-- Description:	Stored Procedure to validate UOM
-- =============================================
-- Changes
-- =============================================
-- Author    Date        Description
-- ------    -----       -----------
-- Asolosky  09/10/2019  Added row_idx
-- Ashaik12  01/10/2020  Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky  09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_UOM] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Validate.[Source_c] as [ARWE02_SOURCE_C],
	  Validate.[uom] as [ARWE02_ERROR_VALUE],
	  'Unit of Measure Not found in Arrow Database' as [ARWE02_ERROR_X],
	  Validate.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Validate.[file_name] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Validate.[ARWS13_CCS_FORD_BOM_PARTS_INFO_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS13_CCS_FORD_BOM_PARTS_INFO' as  [ARWE02_STAGING_TABLE_X],
	  'ERROR',
	  'BoM'+' - ' + VALIDATE.[part_sub_assembly_name],
	  row_idx                               as ARWE02_ROW_IDX,
	  part_index,
	  ''  --No ARROW Value
       FROM (
	   --Find all staging records where the Program is not in the Arrow A05 table
        SELECT 
              Processing_ID,
		      uom,
			  part_index,
		      Processing_Status_x,
		      Source_c,
		      file_name,
              [ARWS13_CCS_FORD_BOM_PARTS_INFO_K],
			  [part_sub_assembly_name],
			  row_idx
         FROM [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO] S13
        WHERE Processing_ID= @GUID
	      and Not Exists
		      (Select 'X'
			     from  [dbo].[PARWA27_UOM] UOM
                where S13.uom=UOM.[ARWA27_UOM_C]
              )

   ) Validate;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH




GO
