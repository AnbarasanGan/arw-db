DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_MTRL_USG]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Ashaik12
-- Create date: 01/22/2020
-- Description:	Validate the Material Usage for Part Index matches the Material Usage already loaded into Arrow.
-- =============================================
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 09/11/2020  Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_BOM_MTRL_USG] 
-- Input Parameter
 @GUID       varchar(5000)
,@CDSID      varchar(30)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
	SET NOCOUNT ON;
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 S13.Source_c
		,S13.material_usage
		,'Material Usage does not match Material Usage already loaded into ARROW for Design: ' + U06.ARWA34_VEH_MDL_N + '. Please verify if the value matches across CCS files'  as Error_Msg
        ,S13.Processing_ID 
		,S13.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S13.[ARWS13_CCS_FORD_BOM_PARTS_INFO_K]  
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'  
        ,'ERROR'                       
		,'BoM'+' - '+ S13.[part_sub_assembly_name]
	    ,S13.row_idx       as ARWE02_ROW_IDX
		,S13.part_index
		,U19.ARWU19_DSGN_PART_MTRL_USG_Q  --ARROW Value
from 
PARWS22_CCS_COVER_PAGE_INFO S22
JOIN [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO] S13
ON S22.Processing_ID = S13.Processing_ID
AND S22.filename = S13.file_name

JOIN PARWU06_CCTSS_DSGN_FLAT U06
ON S22.[User_Selected_CTSP_N] = U06.ARWU31_CTSP_N
AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U06.ARWA03_ENRG_SUB_CMMDTY_X
AND S22.User_Selected_CTSP_Region_C = U06.ARWA06_RGN_C
AND S22.User_Selected_BNCMK_VRNT_N = U06.ARWU01_BNCHMK_VRNT_N
AND S22.User_Selected_VEH_MAKE_N = U06.ARWA14_VEH_MAKE_N
AND S22.User_Selected_VEH_MDL_N = U06.ARWA34_VEH_MDL_N
AND S22.User_Selected_VEH_MDL_YR_C = U06.ARWA35_DSGN_VEH_MDL_YR_C
AND S22.User_Selected_VEH_MDL_VRNT_X = U06.ARWA35_DSGN_VEH_MDL_VRNT_X

JOIN PARWU18_BOM_PART U18
ON U18.ARWU01_CCTSS_K = U06.ARWU01_CCTSS_K
AND U18.ARWU18_BOM_PART_IX_N = S13.part_index

JOIN PARWU19_DSGN_PART U19
ON U19.ARWU06_CCTSS_DSGN_K = U06.ARWU06_CCTSS_DSGN_K
AND U18.ARWU18_BOM_PART_K = U19.ARWU18_BOM_PART_K

where round(S13.material_usage,9) != U19.ARWU19_DSGN_PART_MTRL_USG_Q
and S22.Processing_ID = @GUID

;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''                                --part_index
		,''                                --arrow_value
    ;

END CATCH;

GO
