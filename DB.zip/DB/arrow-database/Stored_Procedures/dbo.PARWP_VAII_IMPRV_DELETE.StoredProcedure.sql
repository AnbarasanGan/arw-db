SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 06/30/2022
-- Description:	Delete base table data before loading the file
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------

-- =============================================

CREATE OR ALTER  PROCEDURE [dbo].[PARWP_VAII_IMPRV_DELETE]
-- Input Parameter
@GUIDIN   Varchar(5000),
@CDSID	  Varchar(30),
@CCTSS_K  INT

AS

SET NOCOUNT ON;

-- UD9
MERGE INTO [dbo].[PARWUD9_SUPL_VRNT_IMPRV]  UD9_Target
Using
(
Select UD9.ARWU09_CCTSS_VRNT_SUPL_K
  From  [dbo].[PARWUD9_SUPL_VRNT_IMPRV] UD9
  Join PARWU09_CCTSS_VRNT_SUPL_FLAT U09 On UD9.ARWU09_CCTSS_VRNT_SUPL_K = u09.ARWU09_CCTSS_VRNT_SUPL_K
 Where U09.ARWU01_CCTSS_K = @CCTSS_K
) as UD9_Source

ON (UD9_Target.ARWU09_CCTSS_VRNT_SUPL_K = UD9_Source.ARWU09_CCTSS_VRNT_SUPL_K)
WHEN MATCHED THEN DELETE;

MERGE INTO  [dbo].[PARWUD4_PURC_PART_VRNT_IMPRV]  UD4_Target
Using
	 (Select U09.[ARWU09_CCTSS_VRNT_SUPL_K]
        From    [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45

      -- Join with Supplier Quote View
         JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09
          ON S45.User_Selected_CTSP_N         = U09.ARWU31_CTSP_N
         AND S45.User_Selected_CTSP_Region_C  = U09.[ARWA06_RGN_C]
		 AND S45.[User_Selected_ENRG_CMMDTY_X] = U09.[ARWA02_ENRG_CMMDTY_X]
		 AND S45.Eng_SubCommodity_name        = U09.[ARWA03_ENRG_SUB_CMMDTY_X]         
         AND S45.User_Selected_BNCMK_VRNT_N   = U09.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
		 AND S45.[User_selected_WALK_VRNT_X] = U09.[ARWU04_VRNT_N]
         AND S45.User_Selected_SUPL_N         = U09.ARWA17_SUPL_N
         AND S45.User_Selected_SUPL_CNTRY_N   = U09.ARWA28_CNTRY_N
         AND S45.User_Selected_SUPL_C         = U09.ARWA17_SUPL_C

       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f         = 0
      ) as UD4_Source
 ON ( UD4_Target.[ARWU09_CCTSS_VRNT_SUPL_K]          = UD4_Source.[ARWU09_CCTSS_VRNT_SUPL_K] )
WHEN MATCHED THEN DELETE;

MERGE INTO  [dbo].PARWUD5_RAW_MTRL_VRNT_IMPRV  UD5_Target
Using
	 (Select U09.[ARWU09_CCTSS_VRNT_SUPL_K]
        From    [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45

      -- Join with Supplier Quote View
         JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09
          ON S45.User_Selected_CTSP_N         = U09.ARWU31_CTSP_N
         AND S45.User_Selected_CTSP_Region_C  = U09.[ARWA06_RGN_C]
		 AND S45.[User_Selected_ENRG_CMMDTY_X] = U09.[ARWA02_ENRG_CMMDTY_X]
		 AND S45.Eng_SubCommodity_name        = U09.[ARWA03_ENRG_SUB_CMMDTY_X]         
         AND S45.User_Selected_BNCMK_VRNT_N   = U09.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
		 AND S45.[User_selected_WALK_VRNT_X] = U09.[ARWU04_VRNT_N]
         AND S45.User_Selected_SUPL_N         = U09.ARWA17_SUPL_N
         AND S45.User_Selected_SUPL_CNTRY_N   = U09.ARWA28_CNTRY_N
         AND S45.User_Selected_SUPL_C         = U09.ARWA17_SUPL_C

       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f         = 0
      ) as UD5_Source
 ON (UD5_Target.[ARWU09_CCTSS_VRNT_SUPL_K] = UD5_Source.[ARWU09_CCTSS_VRNT_SUPL_K])
WHEN MATCHED THEN DELETE;

MERGE INTO PARWUD6_PROCG_VRNT_IMPRV UD6_target
USING
  (Select U09.[ARWU09_CCTSS_VRNT_SUPL_K]
        From    [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45

      -- Join with Supplier Quote View
         JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09
          ON S45.User_Selected_CTSP_N         = U09.ARWU31_CTSP_N
         AND S45.User_Selected_CTSP_Region_C  = U09.[ARWA06_RGN_C]
		 AND S45.[User_Selected_ENRG_CMMDTY_X] = U09.[ARWA02_ENRG_CMMDTY_X]
		 AND S45.Eng_SubCommodity_name        = U09.[ARWA03_ENRG_SUB_CMMDTY_X]         
         AND S45.User_Selected_BNCMK_VRNT_N   = U09.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
		 AND S45.[User_selected_WALK_VRNT_X] = U09.[ARWU04_VRNT_N]
         AND S45.User_Selected_SUPL_N         = U09.ARWA17_SUPL_N
         AND S45.User_Selected_SUPL_CNTRY_N   = U09.ARWA28_CNTRY_N
         AND S45.User_Selected_SUPL_C         = U09.ARWA17_SUPL_C

       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f         = 0
      ) as uD6_source

ON (uD6_target.[ARWU09_CCTSS_VRNT_SUPL_K] = uD6_source.[ARWU09_CCTSS_VRNT_SUPL_K])
when MATCHED THEN DELETE
;

MERGE INTO  [dbo].PARWUD7_ASSY_VRNT_IMPRV  UD7_Target
Using
	 (Select U09.[ARWU09_CCTSS_VRNT_SUPL_K]
        From    [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45

      -- Join with Supplier Quote View
         JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09
          ON S45.User_Selected_CTSP_N         = U09.ARWU31_CTSP_N
         AND S45.User_Selected_CTSP_Region_C  = U09.[ARWA06_RGN_C]
		 AND S45.[User_Selected_ENRG_CMMDTY_X] = U09.[ARWA02_ENRG_CMMDTY_X]
		 AND S45.Eng_SubCommodity_name        = U09.[ARWA03_ENRG_SUB_CMMDTY_X]         
         AND S45.User_Selected_BNCMK_VRNT_N   = U09.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
		 AND S45.[User_selected_WALK_VRNT_X] = U09.[ARWU04_VRNT_N]
         AND S45.User_Selected_SUPL_N         = U09.ARWA17_SUPL_N
         AND S45.User_Selected_SUPL_CNTRY_N   = U09.ARWA28_CNTRY_N
         AND S45.User_Selected_SUPL_C         = U09.ARWA17_SUPL_C

       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f         = 0
      ) as UD7_Source

 ON (UD7_Target.[ARWU09_CCTSS_VRNT_SUPL_K] = UD7_Source.[ARWU09_CCTSS_VRNT_SUPL_K])
WHEN MATCHED THEN DELETE;

MERGE INTO PARWUD8_FNL_ASSY_VRNT_IMPRV   UD8_Target
Using
	 ( Select U09.[ARWU09_CCTSS_VRNT_SUPL_K]
        From    [dbo].[PARWS45_VA_COVER_PAGE_INFO]    S45

      -- Join with Supplier Quote View
         JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] U09
          ON S45.User_Selected_CTSP_N         = U09.ARWU31_CTSP_N
         AND S45.User_Selected_CTSP_Region_C  = U09.[ARWA06_RGN_C]
		 AND S45.[User_Selected_ENRG_CMMDTY_X] = U09.[ARWA02_ENRG_CMMDTY_X]
		 AND S45.Eng_SubCommodity_name        = U09.[ARWA03_ENRG_SUB_CMMDTY_X]         
         AND S45.User_Selected_BNCMK_VRNT_N   = U09.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
		 AND S45.[User_selected_WALK_VRNT_X] = U09.[ARWU04_VRNT_N]
         AND S45.User_Selected_SUPL_N         = U09.ARWA17_SUPL_N
         AND S45.User_Selected_SUPL_CNTRY_N   = U09.ARWA28_CNTRY_N
         AND S45.User_Selected_SUPL_C         = U09.ARWA17_SUPL_C

       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f         = 0
      ) as UD8_Source

 ON ( UD8_Target.[ARWU09_CCTSS_VRNT_SUPL_K] = UD8_Source.[ARWU09_CCTSS_VRNT_SUPL_K])
WHEN MATCHED THEN DELETE;


GO
