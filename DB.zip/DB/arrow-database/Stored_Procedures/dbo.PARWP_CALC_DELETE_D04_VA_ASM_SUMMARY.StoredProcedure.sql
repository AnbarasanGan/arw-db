DROP PROCEDURE If Exists [dbo].[PARWP_CALC_DELETE_D04_VA_ASM_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 10/22/2021
-- Description:	Procedure to Delete the PARWD04_VA_ASM_SUMMARY table based on the design passed in
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CALC_DELETE_D04_VA_ASM_SUMMARY]
@T04_CCTSS_VRNT [dbo].[PARWT04_CCTSS_VRNT] READONLY
AS

--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

--  Select * FROM @T06_CCTSS_DSGN;

  Delete PARWD04_VA_ASM_SUMMARY
   Where [ARWU04_CCTSS_VRNT_K] IN (select ARWU04_CCTSS_VRNT_K from @T04_CCTSS_VRNT  )
  ;
--  Select OBJECT_NAME(@@PROCID)                      as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
