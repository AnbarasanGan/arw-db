DROP PROCEDURE [dbo].[PARWP_UI_CCTSS_VRNT_END_ITM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- ===========================================================================================
-- Author:		btemkow
-- Create date: 2021-02-26
-- Description:	This SP returns the Starting Point Ford End Items from the Tygra Records
--              mapped to the BoB, for each Variant / Tygra File Type (Scope, Current)
-- Input Parameter: @ARWU01_CCTSS_K
-- Output: Returns the values from a select statement
-- How to Run:  Execute [PARWP_UI_CCTSS_VRNT_END_ITM] @ARWU01_CCTSS_K = 72
-- Changes
-- =========================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow	  2021-02-26  initial version
-- btemkow    2021-03-08  added ARWU01_BNCHMK_F to the result set
-- btemkow    2021-04-07  Update to handle multiple Non CM values (Non CM1, Non CM2, etc.)
-- btemkow    2021-04-27  Replace ARWA47_STRTG_PT_END_ITM_K with ARWA47_FEDEBOM_PLN_END_ITM_K
-- btemkow    2021-05-10  Refactored to replace old UB1 (CTSP_TYGRA_FILE) with new UB1 (TYGRA_FILE)
-- btemkow    2021-06-10  Added HAS_BOM_PART {yes,no} to show if Variant/FileType/End Item appears in U63
-- =========================================================================================
--DROP PROCEDURE [dbo].[PARWP_UI_CCTSS_VRNT_END_ITM]

CREATE PROCEDURE [dbo].[PARWP_UI_CCTSS_VRNT_END_ITM] 
@ARWU01_CCTSS_K        INTEGER

AS

SET NOCOUNT ON;


--get the BoB's mapped, in-scope Tygra records
--from valid Tygra File Revisions (join to UB6)
--that are "starting point" records (ARWUB3_JOB1_TRGT_A <> 0)
declare @mapped_strt_pt_tygra_rec table (
 ARWUB3_TYGRA_FILE_REC_K int
,valid_for_cctss varchar(3)
)

insert into @mapped_strt_pt_tygra_rec
select
 UB3.ARWUB3_TYGRA_FILE_REC_K
,''
from PARWUB5_CCTSS_TYGRA_FILE_REC as UB5
join PARWUB3_TYGRA_FILE_REC as UB3
	on UB5.ARWUB3_TYGRA_FILE_REC_K = UB3.ARWUB3_TYGRA_FILE_REC_K
join PARWUB1_TYGRA_FILE as UB1
	on UB3.ARWUB1_TYGRA_FILE_K = UB1.ARWUB1_TYGRA_FILE_K
join PARWUB6_CCTSS_TYGRA_FILE as UB6
	on UB5.ARWU01_CCTSS_K = UB6.ARWU01_CCTSS_K
	and UB1.ARWUB1_TYGRA_FILE_K = UB6.ARWUB1_TYGRA_FILE_K
	and UB1.ARWA54_TYGRA_FILE_TYPE_K = UB6.ARWA54_TYGRA_FILE_TYPE_K
where UB5.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
and UB3.ARWUB3_JOB1_TRGT_A <> 0
and ARWUB5_IN_SCOPE_F = 1;


--get the BoB's Multi-CM Variants (ex. VRNT X: CM1/CM3)
declare @multi_vrnt_ccm table (
ARWU04_CCTSS_VRNT_K int
,ARWA09_PGM_CCM_K int
)

insert into @multi_vrnt_ccm
select
 U04.ARWU04_CCTSS_VRNT_K
,A09.ARWA09_PGM_CCM_K
from PARWU04_CCTSS_VRNT as U04
join PARWU05_CCTSS_VRNT_CCM as U05
	on U04.ARWU04_CCTSS_VRNT_K = U05.ARWU04_CCTSS_VRNT_K
join PARWA09_PGM_CCM_FLAT as A09
	on U05.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
	and A09.ARWA08_CCM_C not like '%Non%'  --exclude all Non CMs
join (
	select ARWU04_CCTSS_VRNT_K
	from PARWU05_CCTSS_VRNT_CCM as U05
	join PARWA09_PGM_CCM_FLAT as A09
		on U05.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
		and A09.ARWA08_CCM_C not like '%Non%'  --exclude all Non CMs
	group by ARWU04_CCTSS_VRNT_K
	having count(*) > 1 --multi
) multi_vrnt
	on U04.ARWU04_CCTSS_VRNT_K = multi_vrnt.ARWU04_CCTSS_VRNT_K
where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

--mark INVALID all Tygra Records that have mappings to some, but NOT ALL of a Multi-CM Variant's CMs 
--(ex. tygra rec has only CM1 but VRNT X: CM1/CM3 )
update @mapped_strt_pt_tygra_rec
set valid_for_cctss = 'no'
where ARWUB3_TYGRA_FILE_REC_K in (
select
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
from @multi_vrnt_ccm as MVC
join (
	select 
	 ARWUB1_TYGRA_FILE_K
	,ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
	from PARWUB4_TYGRA_FILE_REC_CCM as UB4
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join  @multi_vrnt_ccm as MVC
		on UB2.ARWA09_PGM_CCM_K = MVC.ARWA09_PGM_CCM_K
	group by
	 ARWUB1_TYGRA_FILE_K
	,ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
) rec_vrnt_at_least_1
	on MVC.ARWU04_CCTSS_VRNT_K = rec_vrnt_at_least_1.ARWU04_CCTSS_VRNT_K
join @mapped_strt_pt_tygra_rec as MSPTR
	on rec_vrnt_at_least_1.ARWUB3_TYGRA_FILE_REC_K = MSPTR.ARWUB3_TYGRA_FILE_REC_K
join PARWUB2_TYGRA_FILE_CCM as UB2
	on MVC.ARWA09_PGM_CCM_K = UB2.ARWA09_PGM_CCM_K
	and rec_vrnt_at_least_1.ARWUB1_TYGRA_FILE_K = UB2.ARWUB1_TYGRA_FILE_K
left join PARWUB4_TYGRA_FILE_REC_CCM as UB4
	on UB2.ARWUB2_TYGRA_FILE_CCM_K = UB4.ARWUB2_TYGRA_FILE_CCM_K
	and MSPTR.ARWUB3_TYGRA_FILE_REC_K = UB4.ARWUB3_TYGRA_FILE_REC_K
where UB4.ARWUB2_TYGRA_FILE_CCM_K is null
group by MSPTR.ARWUB3_TYGRA_FILE_REC_K
)

--add Tygra Record -> Incomplete Multi Variant mappings
declare @incmplt_mult_vrnt table (
 ARWUB3_TYGRA_FILE_REC_K int
,ARWU04_CCTSS_VRNT_K int
)

insert into @incmplt_mult_vrnt
select
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
,rec_vrnt_at_least_1.ARWU04_CCTSS_VRNT_K
from @multi_vrnt_ccm as MVC
join (
	select 
	 ARWUB1_TYGRA_FILE_K
	,ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
	from PARWUB4_TYGRA_FILE_REC_CCM as UB4
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join  @multi_vrnt_ccm as MVC
		on UB2.ARWA09_PGM_CCM_K = MVC.ARWA09_PGM_CCM_K
	group by
	 ARWUB1_TYGRA_FILE_K
	,ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
) rec_vrnt_at_least_1
	on MVC.ARWU04_CCTSS_VRNT_K = rec_vrnt_at_least_1.ARWU04_CCTSS_VRNT_K
join @mapped_strt_pt_tygra_rec as MSPTR
	on rec_vrnt_at_least_1.ARWUB3_TYGRA_FILE_REC_K = MSPTR.ARWUB3_TYGRA_FILE_REC_K
join PARWUB2_TYGRA_FILE_CCM as UB2
	on MVC.ARWA09_PGM_CCM_K = UB2.ARWA09_PGM_CCM_K
	and rec_vrnt_at_least_1.ARWUB1_TYGRA_FILE_K = UB2.ARWUB1_TYGRA_FILE_K
left join PARWUB4_TYGRA_FILE_REC_CCM as UB4
	on UB2.ARWUB2_TYGRA_FILE_CCM_K = UB4.ARWUB2_TYGRA_FILE_CCM_K
	and MSPTR.ARWUB3_TYGRA_FILE_REC_K = UB4.ARWUB3_TYGRA_FILE_REC_K
where UB4.ARWUB2_TYGRA_FILE_CCM_K is null
group by
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
,rec_vrnt_at_least_1.ARWU04_CCTSS_VRNT_K

--mark VALID all Tygra Records (NOT already marked INVALID) that have mappings to ALL of a Multi-CM Variant's CM
--(ex. tygra rec: CM1/CM2/CM3, VRNT X: CM1/CM3)
update @mapped_strt_pt_tygra_rec
set valid_for_cctss = 'yes'
where ARWUB3_TYGRA_FILE_REC_K in (
select
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
from @mapped_strt_pt_tygra_rec as MSPTR
join (
	select 
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
	from PARWUB4_TYGRA_FILE_REC_CCM as UB4
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join  @multi_vrnt_ccm as MVC
		on UB2.ARWA09_PGM_CCM_K = MVC.ARWA09_PGM_CCM_K
	group by
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
) rec_vrnt_at_least_1
	on MSPTR.ARWUB3_TYGRA_FILE_REC_K = rec_vrnt_at_least_1.ARWUB3_TYGRA_FILE_REC_K
where MSPTR.valid_for_cctss <> 'no'
)

--add Complete Multi-VRNTs to "Valid Record Variants" 
declare @rec_vrnt table (
 ARWUB3_TYGRA_FILE_REC_K int
,ARWU04_CCTSS_VRNT_K int
)

insert into @rec_vrnt
select
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
,rec_vrnt_at_least_1.ARWU04_CCTSS_VRNT_K
from @mapped_strt_pt_tygra_rec as MSPTR
join (
	select 
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
	from PARWUB4_TYGRA_FILE_REC_CCM as UB4
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join  @multi_vrnt_ccm as MVC
		on UB2.ARWA09_PGM_CCM_K = MVC.ARWA09_PGM_CCM_K
	group by
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
) rec_vrnt_at_least_1
	on MSPTR.ARWUB3_TYGRA_FILE_REC_K = rec_vrnt_at_least_1.ARWUB3_TYGRA_FILE_REC_K
left join @incmplt_mult_vrnt as IMV
	on MSPTR.ARWUB3_TYGRA_FILE_REC_K = IMV.ARWUB3_TYGRA_FILE_REC_K
	and rec_vrnt_at_least_1.ARWU04_CCTSS_VRNT_K = IMV.ARWU04_CCTSS_VRNT_K
where IMV.ARWUB3_TYGRA_FILE_REC_K is null

--get the BoB's Single-CM Variants (ex. VRNT Y: CM2)
declare @single_vrnt_ccm table (
ARWU04_CCTSS_VRNT_K int
,ARWA09_PGM_CCM_K int
)

insert into @single_vrnt_ccm
select
 U04.ARWU04_CCTSS_VRNT_K
,A09.ARWA09_PGM_CCM_K
from PARWU04_CCTSS_VRNT as U04
join PARWU05_CCTSS_VRNT_CCM as U05
	on U04.ARWU04_CCTSS_VRNT_K = U05.ARWU04_CCTSS_VRNT_K
join PARWA09_PGM_CCM_FLAT as A09
	on U05.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
	and A09.ARWA08_CCM_C not like '%Non%'  --exclude all Non CMs
join (
	select ARWU04_CCTSS_VRNT_K
	from PARWU05_CCTSS_VRNT_CCM as U05
	join PARWA09_PGM_CCM_FLAT as A09
		on U05.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
		and A09.ARWA08_CCM_C not like '%Non%'  --exclude all Non CMs
	group by ARWU04_CCTSS_VRNT_K
	having count(*) = 1 --single
) single_vrnt
	on U04.ARWU04_CCTSS_VRNT_K = single_vrnt.ARWU04_CCTSS_VRNT_K
where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

--mark VALID all Tygra Records (NOT already marked INVALID) that have mappings to a Single-CM Variant's CM
--(ex. tygra rec: CM1/CM2, VRNT Y: CM2)
update @mapped_strt_pt_tygra_rec
set valid_for_cctss = 'yes'
where ARWUB3_TYGRA_FILE_REC_K in (
select
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
from @mapped_strt_pt_tygra_rec as MSPTR
join (
	select 
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
	from PARWUB4_TYGRA_FILE_REC_CCM as UB4
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join  @single_vrnt_ccm as SVC
		on UB2.ARWA09_PGM_CCM_K = SVC.ARWA09_PGM_CCM_K
	group by
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
) rec_vrnt
	on MSPTR.ARWUB3_TYGRA_FILE_REC_K = rec_vrnt.ARWUB3_TYGRA_FILE_REC_K
where MSPTR.valid_for_cctss <> 'no'
)

--add mapped single-VRNTs to "Valid Record Variants"
insert into @rec_vrnt
select
 MSPTR.ARWUB3_TYGRA_FILE_REC_K
,ARWU04_CCTSS_VRNT_K
from @mapped_strt_pt_tygra_rec as MSPTR
join (
	select 
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
	from PARWUB4_TYGRA_FILE_REC_CCM as UB4
	join PARWUB2_TYGRA_FILE_CCM as UB2
		on UB4.ARWUB2_TYGRA_FILE_CCM_K = UB2.ARWUB2_TYGRA_FILE_CCM_K
	join  @single_vrnt_ccm as SVC
		on UB2.ARWA09_PGM_CCM_K = SVC.ARWA09_PGM_CCM_K
	group by
	 ARWUB3_TYGRA_FILE_REC_K
	,ARWU04_CCTSS_VRNT_K
) rec_vrnt
	on MSPTR.ARWUB3_TYGRA_FILE_REC_K = rec_vrnt.ARWUB3_TYGRA_FILE_REC_K

--mark INVALID all Tygra Records not already marked VALID or INVALID (records with no CM to Variant mappings)
update @mapped_strt_pt_tygra_rec
set valid_for_cctss = 'no'
where valid_for_cctss = '';

--return all Starting Point Ford End Items from mapped tygra records for each valid Variant / File Type
select 
 U04.ARWU04_CCTSS_VRNT_K
,ARWU04_BNCHMK_F
,ARWA54_TYGRA_FILE_TYPE_N
,UB3.ARWA47_FEDEBOM_PLN_END_ITM_K
,ARWA47_FORD_END_ITM_PREF_N
,ARWA47_FORD_END_ITM_BSE_N
,ARWA47_FORD_END_ITM_SFX_N
,ARWUB3_STRTG_PT_PART_X
,case when has_bom_part.ARWU04_CCTSS_VRNT_K is null then 'no' else 'yes' end as HAS_BOM_PART
from @rec_vrnt as RV
join PARWU04_CCTSS_VRNT as U04
	on RV.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
join PARWUB3_TYGRA_FILE_REC as UB3
	on RV.ARWUB3_TYGRA_FILE_REC_K = UB3.ARWUB3_TYGRA_FILE_REC_K
join PARWUB1_TYGRA_FILE as UB1
	on UB3.ARWUB1_TYGRA_FILE_K = UB1.ARWUB1_TYGRA_FILE_K
join PARWA54_TYGRA_FILE_TYPE as A54
	on UB1.ARWA54_TYGRA_FILE_TYPE_K = A54.ARWA54_TYGRA_FILE_TYPE_K
join PARWA47_FORD_END_ITM as A47
	on UB3.ARWA47_FEDEBOM_PLN_END_ITM_K = A47.ARWA47_FORD_END_ITM_K
left join (
	select
	 ARWU04_CCTSS_VRNT_K
	,ARWA57_END_ITM_MAP_TYPE_X
	,ARWA47_FORD_END_ITM_K
	from PARWU63_VRNT_BOM_PART_END_ITM as U63
	join PARWA57_END_ITM_MAP_TYPE as A57
		on U63.ARWA57_END_ITM_MAP_TYPE_K = A57.ARWA57_END_ITM_MAP_TYPE_K
	group by
	 ARWU04_CCTSS_VRNT_K
	,ARWA57_END_ITM_MAP_TYPE_X
	,ARWA47_FORD_END_ITM_K
) as has_bom_part
	on U04.ARWU04_CCTSS_VRNT_K = has_bom_part.ARWU04_CCTSS_VRNT_K
	and A54.ARWA54_TYGRA_FILE_TYPE_N = has_bom_part.ARWA57_END_ITM_MAP_TYPE_X
	and A47.ARWA47_FORD_END_ITM_K = has_bom_part.ARWA47_FORD_END_ITM_K
group by 
 U04.ARWU04_CCTSS_VRNT_K
,ARWU04_BNCHMK_F
,ARWA54_TYGRA_FILE_TYPE_N
,UB3.ARWA47_FEDEBOM_PLN_END_ITM_K
,ARWA47_FORD_END_ITM_PREF_N
,ARWA47_FORD_END_ITM_BSE_N
,ARWA47_FORD_END_ITM_SFX_N
,ARWUB3_STRTG_PT_PART_X
,has_bom_part.ARWU04_CCTSS_VRNT_K
GO


