DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_EXCHG_RATE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ashaik12
-- Create date: 03/27/2019
-- Description:	Load Data into the U21 , U22 Currency tables   
--              First currency in Wins. No updates     
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 06/13/2019  ASHAIK12  N/A      Make all join conditions from cover page columns to user selected columns. And Remove the join for Engineering Commodity.
-- 06/17/2019  asolosky  N/A      Change the delete on PARWU22_SUPL_CRCY_EXCHG_RATE from design_supplier/Currency_k to just design_supplier
-- 06/19/2019  asolosky  N/A      Data base change to move the U21 and U22 tables to connect to the U07 instead of the U08 table. Changed the procedure based on the DB changes
-- 06/21/2019  asolosky  N/A      Changed the U22 insert statement to get the unique suppliers from design and suppliers.  
--                                If the suppliers aren't unique, the import has a chance to get a unique key constraint against the exchange rate table
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 10/11/2019  rwesley2           added currency code to U22 insert to load exchange rates imported after initial load
-- 10/15/2019  rwesley            added DISTINCT to U22 load to eliminate dup insert error
-- 12/26/2019  ashaik12           Refactor to use flat views
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_EXCHG_RATE] 
-- Input Parameter
@Processing_ID varchar(500),
@CDSID Varchar(8),
@TIME_STAMP DATETIME

AS

--BEGIN TRY
SET NOCOUNT ON;


------------- LOAD into PARWU21_CCTSS_DSGN_SUPL_CRCY
MERGE INTO [dbo].[PARWU21_CCTSS_SUPL_CRCY] U21_Target
USING
(
SELECT 
		 X.ARWU07_CCTSS_SUPL_K as ARWU07_CCTSS_SUPL_K
		,A29.ARWA29_CRCY_K as [ARWA29_CRCY_K]
		,@TIME_STAMP                  as ARWU21_CREATE_S
		,@CDSID as ARWU21_CREATE_USER_C
		,@TIME_STAMP                  as ARWU21_LAST_UPDT_S
		,@CDSID as ARWU21_LAST_UPDT_USER_C 
FROM
(
select Distinct
     U07.ARWU07_CCTSS_SUPL_K 
	 ,S27_EXCH.supplier_picked_crcy_c
FROM
      [dbo].[PARWS27_CCS_EXCHANGE_RATE_TAB] S27_EXCH
	  JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] S22
	  ON S22.filename=S27_EXCH.filename
	  AND S22.Processing_ID=S27_EXCH.Processing_ID
	  JOIN [dbo].PARWU07_CCTSS_SUPL_FLAT U07
	  ON S22.[User_Selected_CTSP_N]                              = U07.ARWU31_CTSP_N
	   AND S22.[User_Selected_CTSP_Region_C]                     = U07.[ARWA06_RGN_C]
	   AND S22.[User_Selected_ENRG_SUB_CMMDTY_X]                 = U07.[ARWA03_ENRG_SUB_CMMDTY_X]
	   AND S22.[User_Selected_BNCMK_VRNT_N]                      = U07.[ARWU01_BNCHMK_VRNT_N]
	   AND S22.[User_Selected_SUPL_N]                            = U07.ARWA17_SUPL_N
	   AND S22.[User_Selected_SUPL_C]                            = U07.ARWA17_SUPL_C
	   AND S22.[User_Selected_SUPL_CNTRY_N]                      = U07.ARWA28_CNTRY_N
	--   AND S22.[User_Selected_VEH_MAKE_N]                        = U08.ARWA14_VEH_MAKE_N
	--   AND S22.[User_Selected_VEH_MDL_N]                         = U08.ARWA34_VEH_MDL_N
	--   AND S22.[User_Selected_VEH_MDL_YR_C]                      = U08.ARWA35_DSGN_VEH_MDL_YR_C
	--   AND s22.[User_Selected_VEH_MDL_VRNT_X]                    = U08.ARWA35_DSGN_VEH_MDL_VRNT_X
	  where S27_EXCH.[Processing_ID]=@Processing_ID
	    AND S22.Skip_loading_due_to_error_f    = 0
) X
JOIN [dbo].[PARWA29_CRCY] A29
  ON X.supplier_picked_crcy_c = A29.ARWA29_CRCY_C
) as U21_SOURCE
ON(U21_Target.ARWU07_CCTSS_SUPL_K = U21_Source.ARWU07_CCTSS_SUPL_K)
When NOT Matched then
 Insert Values (
 		ARWU07_CCTSS_SUPL_K
		,[ARWA29_CRCY_K]
		,@TIME_STAMP               
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		) 
;


------------- LOAD into [PARWU22_SUPL_CRCY_EXCHG_RATE]
MERGE INTO PARWU22_SUPL_CRCY_EXCHG_RATE U22_Target
USING
(
Select DISTINCT(Supplier.ARWU07_CCTSS_SUPL_K)    as ARWU07_CCTSS_SUPL_K
	  ,A29.ARWA29_CRCY_K                         as ARWA29_CRCY_K
	  ,isNULL(S27_EXCH.usd_per_local_currency,0) as ARWU22_CRCY_PER_SUPL_CRCY_R
	  ,@TIME_STAMP                              as ARWU21_CREATE_S
	  ,@CDSID                                    as ARWU21_CREATE_USER_C
	  ,@TIME_STAMP                              as ARWU21_LAST_UPDT_S
	  ,@CDSID                                    as ARWU21_LAST_UPDT_USER_C 
  From PARWS27_CCS_EXCHANGE_RATE_TAB S27_EXCH
  Join
(
 SELECT S22.Processing_ID
	   ,S22.Processing_Status_x
	   ,S22.filename
	   ,U07.ARWU07_CCTSS_SUPL_K 
	   ,row_number () over (partition by processing_id, ARWU07_CCTSS_SUPL_K order by filename, ARWU07_CCTSS_SUPL_K) as rownum
  FROM PARWS22_CCS_COVER_PAGE_INFO   S22
--Design and Supplier
  JOIN [dbo].PARWU07_CCTSS_SUPL_FLAT U07
	  ON S22.[User_Selected_CTSP_N]                              = U07.ARWU31_CTSP_N
	   AND S22.[User_Selected_CTSP_Region_C]                     = U07.[ARWA06_RGN_C]
	   AND S22.[User_Selected_ENRG_SUB_CMMDTY_X]                 = U07.[ARWA03_ENRG_SUB_CMMDTY_X]
	   AND S22.[User_Selected_BNCMK_VRNT_N]                      = U07.[ARWU01_BNCHMK_VRNT_N]
	   AND S22.[User_Selected_SUPL_N]                            = U07.ARWA17_SUPL_N
	   AND S22.[User_Selected_SUPL_C]                            = U07.ARWA17_SUPL_C
	   AND S22.[User_Selected_SUPL_CNTRY_N]                      = U07.ARWA28_CNTRY_N
	--   AND S22.[User_Selected_VEH_MAKE_N]                        = U08.ARWA14_VEH_MAKE_N
	--   AND S22.[User_Selected_VEH_MDL_N]                         = U08.ARWA34_VEH_MDL_N
	--   AND S22.[User_Selected_VEH_MDL_YR_C]                      = U08.ARWA35_DSGN_VEH_MDL_YR_C
	--   AND s22.[User_Selected_VEH_MDL_VRNT_X]                    = U08.ARWA35_DSGN_VEH_MDL_VRNT_X
	  where S22.[Processing_ID]       = @Processing_ID
	    AND S22.Skip_loading_due_to_error_f  = 0
) Supplier

    On S27_EXCH.Processing_ID       = Supplier.Processing_ID
   AND S27_EXCH.filename            = Supplier.filename
--Currrency
  JOIN PARWA29_CRCY A29	ON A29.ARWA29_CRCY_C = S27_EXCH.currency_code
Where rownum = 1
) as U22_SOURCE
ON(U22_Target.ARWU07_CCTSS_SUPL_K = U22_Source.ARWU07_CCTSS_SUPL_K)
   AND U22_Target.ARWA29_CRCY_K = U22_Source.ARWA29_CRCY_K
When NOT Matched then
 Insert Values (
 		ARWU07_CCTSS_SUPL_K
		,ARWA29_CRCY_K
		,ARWU22_CRCY_PER_SUPL_CRCY_R
		,@TIME_STAMP               
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		) 
;



GO
