DROP PROCEDURE IF EXISTS [dbo].[PARWP_TYGRA_VALIDT_PARTS_SPCL_CHARS_UI] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		RWESLEY2
-- Create date: 10/28/2020
-- Description:	Stored Procedure to validate TYGRA columns for special characters. SP used in UI
-- User story:  US2034427
-- =============================================
-- Changes
-- =============================================
-- Author     Date     User Story  Description
-- ------     -----    ----------  -----------
-- Ashaik12   04/19/2021            Add validation for BOB PIA EI
-- rwesley2   04-20-2021  US2453456 use MAX length when declaring a variable 
-- Ashaik12   04/2/2021   US2478016 Add validation for FEDEBOM PLANNED BOB PIA EI
-- rwesley2	  04-28-2021  US2492277 remove validation that requires both base and suffix be present for a part to be valid
--                                  for both surrogate and starting point parts
-- rwesley    09-30-2021  US2879211 - load Current files
-- rwesley2   10-22-2021  US2995475 remove P05 join
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_VALIDT_PARTS_SPCL_CHARS_UI] 
	-- Add the parameters for the stored procedure here
	 @processing_id  varchar(MAX)
	,@CDSID varchar(MAX)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

-- validation for surrogate parts
-- validation for slash
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	       Err.Source_c                                 as [ARWE02_SOURCE_C],
	       staging_data_error_value                     as [ARWE02_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE02_ERROR_X],
	       Err.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       Err.file_name                                as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       Err.ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS62_TYGRA_SUMMARY'                      as [ARWE02_STAGING_TABLE_X],
	       'WARNING'                                    as [ARWE02_ERROR_TYPE_X],
	       'Tygra parts'                                as [ARWE02_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE02_ROW_IDX],
		   ''                                           as ARWE02_Part_Index,
		   ''                                           as ARWE02_Arrow_value
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS62_TYGRA_SUMMARY  
              ,Source_c
			  ,Vehicle_name
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then surrogate_part_prefix
				    when error_col = 'match_position_base_slash'    then surrogate_part_base 
				    when error_col = 'match_position_suffix_slash'  then surrogate_part_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then 'Surrogate part Prefix contains a slash'
				    when error_col = 'match_position_base_slash'    then 'Surrogate part Base contains a slash'
				    when error_col = 'match_position_suffix_slash'  then 'Surrogate part Suffix contains a slash'
			   END as error_msg
			 from 
             (SELECT 
 			         s62.Processing_ID
				    ,file_name
				    ,ARWS62_TYGRA_SUMMARY
                    ,Source_c
					,vehicle_name
					,row_idx
					,surrogate_part_prefix
					,Case when CHARINDEX('/',surrogate_part_prefix) > 0 then 1 else 0 end as match_position_prefix_slash 
					,surrogate_part_base
					,case when CHARINDEX('/',surrogate_part_base) > 0 then 1 else 0 end as match_position_base_slash   
					,surrogate_part_suffix	
					,case when CHARINDEX('/',surrogate_part_suffix ) > 0 then 1 else 0 end  as match_position_suffix_slash  
                    ,row_number() over (partition by s62.Processing_ID, s62.vehicle_name, surrogate_part_prefix,surrogate_part_base,surrogate_part_suffix   Order by s62.vehicle_name) as rownum
                FROM PARWS62_TYGRA_SUMMARY s62
               WHERE s62.Processing_ID = @processing_id
				
        ) s62
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_slash
                                              ,match_position_base_slash 
                                              ,match_position_suffix_slash  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;

-- validation for decimal 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	       Err.Source_c                                 as [ARWE02_SOURCE_C],
	       staging_data_error_value                     as [ARWE02_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE02_ERROR_X],
	       Err.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       Err.file_name                                as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       Err.ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS62_TYGRA_SUMMARY'                      as [ARWE02_STAGING_TABLE_X],
	       'WARNING'                                    as [ARWE02_ERROR_TYPE_X],
	       'Tygra parts'                                as [ARWE02_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE02_ROW_IDX],
		   ''                                           as ARWE02_Part_Index,
		   ''                                           as ARWE02_Arrow_value
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS62_TYGRA_SUMMARY  
              ,Source_c
			  ,Vehicle_name
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then surrogate_part_prefix
				    when error_col = 'match_position_base_decimal'    then surrogate_part_base 
				    when error_col = 'match_position_suffix_decimal'  then surrogate_part_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then 'Surrogate part Prefix contains a decimal point'
				    when error_col = 'match_position_base_decimal'    then 'Surrogate part Base contains a decimal point'
				    when error_col = 'match_position_suffix_decimal'  then 'Surrogate part Suffix contains a decimal point'
			   END as error_msg
			 from 
             (SELECT 
 			         s62.Processing_ID
				    ,file_name
				    ,ARWS62_TYGRA_SUMMARY
                    ,Source_c
					,vehicle_name
					,row_idx
					,surrogate_part_prefix
					,Case when CHARINDEX('.',surrogate_part_prefix) > 0 then 1 else 0 end as match_position_prefix_decimal 
					,surrogate_part_base
					,case when CHARINDEX('.',surrogate_part_base) > 0 then 1 else 0 end as match_position_base_decimal    
					,surrogate_part_suffix	
					,case when CHARINDEX('.',surrogate_part_suffix ) > 0 then 1 else 0 end  as match_position_suffix_decimal  
                    ,row_number() over (partition by s62.Processing_ID, s62.vehicle_name, surrogate_part_prefix,surrogate_part_base,surrogate_part_suffix   Order by s62.vehicle_name) as rownum
                FROM PARWS62_TYGRA_SUMMARY s62
               WHERE s62.Processing_ID = @processing_id 
				
        ) s62
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_decimal 
                                              ,match_position_base_decimal 
                                              ,match_position_suffix_decimal  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;
 
   
--Error for end_item_prefix over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,surrogate_part_prefix
		,'Surrogate part Prefix can''t be more than 32 characters.' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY               as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'            as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                          as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                      as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                            as [ARWE02_ROW_IDX]
	    ,''                                 as ARWE02_Part_Index
	    ,''                                 as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62
  Where s62.Processing_ID    = @processing_id
    and DATALENGTH(surrogate_part_prefix)  > 32;

--Error for end_item_base over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,surrogate_part_base
		,'Surrogate part Base can''t be more than 32 characters.' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62
    Where s62.Processing_ID    = @processing_id
    and DATALENGTH(surrogate_part_base)  > 32;
	
--Error for end_item_suffix over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,surrogate_part_suffix
		,'Surrogate part Suffix can''t be more than 32 characters.' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62
  Where s62.Processing_ID    = @processing_id
    and DATALENGTH(surrogate_part_suffix)  > 32;
 
 -- validate start point parts
 -- validation for slash
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	       Err.Source_c                                 as [ARWE02_SOURCE_C],
	       staging_data_error_value                     as [ARWE02_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE02_ERROR_X],
	       Err.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       Err.file_name                                as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       Err.ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS62_TYGRA_SUMMARY'                      as [ARWE02_STAGING_TABLE_X],
	       'WARNING'                                    as [ARWE02_ERROR_TYPE_X],
	       'Tygra parts'                                as [ARWE02_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE02_ROW_IDX],
		   ''                                           as ARWE02_Part_Index,
		   ''                                           as ARWE02_Arrow_value
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS62_TYGRA_SUMMARY  
              ,Source_c
			  ,Vehicle_name
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then Start_Point_part_prefix
				    when error_col = 'match_position_base_slash'    then Start_Point_part_base 
				    when error_col = 'match_position_suffix_slash'  then Start_Point_part_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_slash'  then 'Start Point part Prefix contains a slash'
				    when error_col = 'match_position_base_slash'    then 'Start Point part Base contains a slash'
				    when error_col = 'match_position_suffix_slash'  then 'Start Point part Suffix contains a slash'
			   END as error_msg
			 from 
             (SELECT 
 			         s62.Processing_ID
				    ,file_name
				    ,ARWS62_TYGRA_SUMMARY
                    ,Source_c
					,vehicle_name
					,row_idx
					,Start_Point_part_prefix
					,Case when CHARINDEX('/',Start_Point_part_prefix) > 0 then 1 else 0 end as match_position_prefix_slash 
					,Start_Point_part_base
					,case when CHARINDEX('/',Start_Point_part_base) > 0 then 1 else 0 end as match_position_base_slash   
					,Start_Point_part_suffix	
					,case when CHARINDEX('/',Start_Point_part_suffix ) > 0 then 1 else 0 end  as match_position_suffix_slash  
                    ,row_number() over (partition by s62.Processing_ID, s62.vehicle_name, Start_Point_part_prefix,Start_Point_part_base,Start_Point_part_suffix   Order by s62.vehicle_name) as rownum
               From PARWS62_TYGRA_SUMMARY s62
               WHERE s62.Processing_ID = @processing_id 
				
        ) s62
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_slash
                                              ,match_position_base_slash 
                                              ,match_position_suffix_slash  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;

-- validation for decimal 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	       Err.Source_c                                 as [ARWE02_SOURCE_C],
	       staging_data_error_value                     as [ARWE02_ERROR_VALUE],
	       ERROR_MSG                                    as [ARWE02_ERROR_X],
	       Err.Processing_ID                            as [ARWE02_PROCESSING_ID],
	       Err.file_name                                as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       Err.ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS62_TYGRA_SUMMARY'                      as [ARWE02_STAGING_TABLE_X],
	       'WARNING'                                    as [ARWE02_ERROR_TYPE_X],
	       'Tygra parts'                                as [ARWE02_EXCEL_TAB_X],
	       Err.row_idx                                  as [ARWE02_ROW_IDX],
		   ''                                           as ARWE02_Part_Index,
		   ''                                           as ARWE02_Arrow_value
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS62_TYGRA_SUMMARY  
              ,Source_c
			  ,Vehicle_name
			  ,row_idx
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then Start_Point_part_prefix
				    when error_col = 'match_position_base_decimal'    then Start_Point_part_base 
				    when error_col = 'match_position_suffix_decimal'  then Start_Point_part_suffix 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'match_position_prefix_decimal'  then 'Start Point part Prefix contains a decimal point'
				    when error_col = 'match_position_base_decimal'    then 'Start Point part Base contains a decimal point'
				    when error_col = 'match_position_suffix_decimal'  then 'Start Point part Suffix contains a decimal point'
			   END as error_msg
			 from 
             (SELECT 
 			         s62.Processing_ID
				    ,file_name
				    ,ARWS62_TYGRA_SUMMARY
                    ,Source_c
					,vehicle_name
					,row_idx
					,Start_Point_part_prefix
					,Case when CHARINDEX('.',Start_Point_part_prefix) > 0 then 1 else 0 end as match_position_prefix_decimal 
					,Start_Point_part_base
					,case when CHARINDEX('.',Start_Point_part_base) > 0 then 1 else 0 end as match_position_base_decimal    
					,Start_Point_part_suffix	
					,case when CHARINDEX('.',Start_Point_part_suffix ) > 0 then 1 else 0 end  as match_position_suffix_decimal  
                    ,row_number() over (partition by s62.Processing_ID, s62.vehicle_name, Start_Point_part_prefix,Start_Point_part_base,Start_Point_part_suffix   Order by s62.vehicle_name) as rownum
               From PARWS62_TYGRA_SUMMARY s62
               WHERE s62.Processing_ID = @processing_id
				
        ) s62
 
       unpivot (error_value for error_col in (
                                               match_position_prefix_decimal 
                                              ,match_position_base_decimal 
                                              ,match_position_suffix_decimal  
											  )
               ) unpvt
        Where error_value = 1
		  and rownum = 1
      ) Err
;
 
 
--Error for end_item_prefix over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Start_Point_part_prefix
		,'Start Point part Prefix can''t be more than 32 characters.' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY               as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'            as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                          as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                      as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                            as [ARWE02_ROW_IDX]
	    ,''                                 as ARWE02_Part_Index
	    ,''                                 as ARWE02_Arrow_value
   From PARWS62_TYGRA_SUMMARY s62
  Where s62.Processing_ID    = @processing_id
    and DATALENGTH(Start_Point_part_prefix)  > 32;

--Error for end_item_base over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Start_Point_part_base
		,'Start Point part Base can''t be more than 32 characters.' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
    From PARWS62_TYGRA_SUMMARY s62
  Where s62.Processing_ID    = @processing_id
    and DATALENGTH(Start_Point_part_base)  > 32;
	
--Error for end_item_suffix over 32 char
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Start_Point_part_suffix
		,'Start Point part Suffix can''t be more than 32 characters.' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
    From PARWS62_TYGRA_SUMMARY s62
  Where s62.Processing_ID    = @processing_id
    and DATALENGTH(Start_Point_part_suffix)  > 32;
 --

 -- VALIDATE BOB PIA EI, first split BOB PIA EI into Prefix, Base and Suffix and check against Start Point Prefix, Start Point Base and Start Point Suffix

	-- Check if BOB_PIA_EI has all three Prefix Base and Suffix 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 'TYGRA'
		,Prefix+'-'+Base+'-'+Suffix
		,'BOB PIA EI should have all Prefix-Base-Suffix values' 
		,@processing_id
		,''
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,0                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,0                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   From 
   (
   SELECT 
			  dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 1, '-') AS Prefix,
			  dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 2, '-') AS Base,
			  dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 3, '-') AS Suffix
	From PARWS62_TYGRA_SUMMARY s62
		where s62.Processing_Id=@processing_id
   ) X
   where Prefix='' or Base='' or Suffix=''
   ;
	-- Check if the BOB_PIA_EI prefix base and suffix are Start Point prefix base and suffix
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'BOB PIA EI should be an existing Start Point Prefix-Base-Suffix' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   
   From 
   (Select Source_c,[Start_Point_Part_Prefix],[Start_Point_Part_Base],[Start_Point_Part_Suffix]
   ,[Processing_ID],file_name,ARWS62_TYGRA_SUMMARY,row_idx,
   dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 1, '-') AS Prefix,
   dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 2, '-') AS Base,
   dbo.PARWF_SEPARATES_COLUMNS([BoB_PIA_End_Item], 3, '-') AS Suffix
   From PARWS62_TYGRA_SUMMARY  
  Where Processing_ID    = @processing_id ) S62
 WHERE (Start_Point_Part_Prefix != Prefix    
AND [Start_Point_Part_Base] != Base
AND [Start_Point_Part_Suffix] != Suffix)
AND (Prefix !='' AND Base !='' AND Suffix !='')
AND (Prefix is NOT NULL AND Base is NOT NULL AND Suffix is NOT NULL)
;


	-- Check if FEDEBOM BOB_PIA_EI has all three Prefix Base and Suffix 
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'FEDEBOM PLANNED BOB PIA EI should have all Prefix-Base-Suffix values' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,0                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   From 
   (
   SELECT 
			  dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 1, '-') AS Prefix,
			  dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 2, '-') AS Base,
			  dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 3, '-') AS Suffix,
			  file_name, row_idx , Source_c
		From PARWS62_TYGRA_SUMMARY s62
		where s62.Processing_Id=@processing_id
   ) X
   where Prefix='' or Base='' or Suffix=''
   ;
	-- Check if the FEDEBOM BOB_PIA_EI prefix base and suffix are FEDEBOM PLANNED Point prefix base and suffix
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,Prefix+'-'+Base+'-'+Suffix
		,'FEDEBOM PLANNED BOB PIA EI should be an existing FEDEBOM PLANNED Point Prefix-Base-Suffix' 
		,@processing_id
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
	    ,ARWS62_TYGRA_SUMMARY                     as [ARWE02_BATCH_ERRORS_REF_K]
	    ,'PARWS62_TYGRA_SUMMARY'                  as [ARWE02_STAGING_TABLE_X]
	    ,'WARNING'                                as [ARWE02_ERROR_TYPE_X]
	    ,'Tygra parts'                            as [ARWE02_EXCEL_TAB_X]
	    ,row_idx                                  as [ARWE02_ROW_IDX]
	    ,''                                       as ARWE02_Part_Index
	    ,''                                       as ARWE02_Arrow_value
   
   From 
   (Select Source_c,[FEDEBOM_Planned_Prefix],[FEDEBOM_Planned_Base],[FEDEBOM_Planned_Suffix]
   ,[Processing_ID],file_name,ARWS62_TYGRA_SUMMARY,row_idx,
   dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 1, '-') AS Prefix,
   dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 2, '-') AS Base,
   dbo.PARWF_SEPARATES_COLUMNS([FEDEBOM_bob_pia_ei], 3, '-') AS Suffix
   From PARWS62_TYGRA_SUMMARY 
  Where Processing_ID    = @processing_id) S62
 WHERE (FEDEBOM_Planned_Prefix != Prefix    
AND [FEDEBOM_Planned_Base] != Base
AND [FEDEBOM_Planned_Suffix] != Suffix)
AND (Prefix !='' AND Base !='' AND Suffix !='')
AND (Prefix is NOT NULL AND Base is NOT NULL AND Suffix is NOT NULL)
;



END TRY
BEGIN CATCH

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@processing_id							--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 --ARWE02_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE
END CATCH





GO


