SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 07/26/2022
-- Description:	US3870129 - checks that engineering commodity picked in the UI is found on the Tygra file that the user wants to load
--              
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_ENG_COMM_UI] 
-- Input Parameter
 @processing_id varchar(max)
,@CDSID         varchar(max)
,@file_source   varchar(max)
,@load_to_pgm_name varchar(max)
,@Tygra_file_name varchar(max)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
  Select 
		 @file_source                as [ARWE02_SOURCE_C]
		,(select ARWA02_ENRG_CMMDTY_X from PARWU01_CCTSS_FLAT u01
                                   where err.ARWU01_CCTSS_K = u01.ARWU01_CCTSS_K)  as [ARWE02_ERROR_VALUE]   -- 
		,'Engineering commodity selected is not on the file you are trying to load.' as [ARWE02_ERROR_x]
        ,@processing_id               as [ARWE02_PROCESSING_ID]
		,@Tygra_file_name          as [ARWE02_FILENAME]
		,object_name(@@PROCID)       as [ARWE02_PROCEDURE_X]
	    ,@TIME_STAMP                 as [ARWE02_CREATE_S]
   	    ,@CDSID                      as [ARWE02_CREATE_USER_C]
	    ,@TIME_STAMP                 as [ARWE02_LAST_UPDT_S]
	    ,@CDSID                      as [ARWE02_LAST_UPDT_USER_C]
	    ,1                           as [ARWE02_BATCH_ERRORS_REF_K]
		,'PARWS62_TYGRA_SUMMARY'  as [ARWE02_STAGING_TABLE_X]
        ,'ERROR'                     as [ARWE02_ERROR_TYPE_X] 
		,'Tygra detalis Page'          as [ARWE02_EXCEL_TAB_X]
	    ,''                          as [ARWE02_ROW_IDX]
	    ,''                          as [ARWE02_Part_Index]
		,'Arrow program:  ' +  @load_to_pgm_name as [ARWE02_ARROW_Value]
    FROM
	(

 select * from (
 select Processing_ID
       ,ARWU01_CCTSS_K
	     from PARWS66_TYGRA_BOB  
		 where processing_id = @processing_id  
		 and LAST_UPDT_S = (select max(LAST_UPDT_S) from PARWS66_TYGRA_BOB where processing_id = @processing_id )
		 ) s66
 where NOT EXISTS 
      (select 'X'
	     from PARWS62_TYGRA_SUMMARY s62
  where s66.processing_id = s62.processing_id
  and s62.engineering_commodity = (select [ARWA02_ENRG_CMMDTY_X] from PARWU01_CCTSS_FLAT u01
                                   where s66.ARWU01_CCTSS_K = u01.ARWU01_CCTSS_K
                                     )

      ) 
   ) err

;
END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@processing_id                            --Processing_id
		,@Tygra_file_name                          --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS62_TYGRA_SUMMARY'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	


