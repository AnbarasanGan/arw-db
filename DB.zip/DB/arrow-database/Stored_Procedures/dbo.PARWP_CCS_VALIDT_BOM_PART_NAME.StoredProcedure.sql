DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_PART_NAME]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ashaik12
-- Create date: 03/20/2019
-- Description:	Validate the PARWS13_CCS_FORD_BOM_PARTS_INFO staging table
--              Display a warning message if the part name is duplicated within a sub-assembly
--              Note: there shouldn't be a file with a different processing_id but to be safe it checks for both (See partition by code below)
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- rwesley2  07/03/2019   Changed to a WARNING 
-- Asolosky  09/10/2019   Added row_idx
-- Ashaik12  01/10/2020   Added TimeStamp parameter and removed filter on Processing Status
-- asolosky  07/27/2020   US1771016  Added error message for carriage return and line feed.
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_BOM_PART_NAME] 
-- Input Parameter
 @Processing_ID varchar(5000)
,@CDSID         varchar(30)
,@TIME_STAMP DATETIME

AS
BEGIN TRY
	SET NOCOUNT ON;
	INSERT INTO PARWE02_BATCH_ERRORS
    Select 
		 STAGING.Source_c
		,STAGING.part_sub_assembly_name  + '-' + STAGING.part_name 
		,'Duplicate part name found in file for a specific sub assembly' 
		,@Processing_ID
		,file_name
		,object_name(@@PROCID) AS Procedure_x
		,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP 
		,@CDSID
		,STAGING.ARWS13_CCS_FORD_BOM_PARTS_INFO_K  as ARWE02_BATCH_ERRORS_REF_K
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'         as ARWE02_STAGING_TABLE_X
		,'WARNING'
        ,'BoM'+' - '+STAGING.[part_sub_assembly_name]
	    ,row_idx                                   as ARWE02_ROW_IDX
		,part_index
		,''  --No ARROW Value
    FROM
    (	
	  SELECT
             S13.*
	        ,COUNT(part_name) OVER (PARTITION BY S13.file_name, S13.part_sub_assembly_name, S13.processing_ID, S13.part_name) part_name_count
	    FROM [dbo].PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
	    JOIN [dbo].PARWS22_CCS_COVER_PAGE_INFO      S22
	      ON S22.Processing_ID       = S13.Processing_ID
         AND S22.filename            = S13.file_name
	   Where S13.Processing_ID       = @Processing_ID  
	    
	) STAGING
	Where part_name_count > 1 

-- Line Feed validation
DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(part_name,char(10),'<LF>')           as [ARWE02_ERROR_VALUE],  --replace line feed with <LF>
	       'A part name can''t have an imbedded line feed <LF>'       as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       file_name                                    as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K             as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'            as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       part_sub_assembly_name                       as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   part_index                                   as [ARWE02_Part_Index],
		   ''                                           as [ARWE02_ARROW_Value]	
      FROM PARWS13_CCS_FORD_BOM_PARTS_INFO
     WHERE Processing_ID         = @Processing_ID
       and NullIf(PATINDEX(@pat10,part_name),0) > 0  --Looking for Line Feed 
    ;

-- Carriage Return validation
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(part_name,char(13),'<CR>')           as [ARWE02_ERROR_VALUE],  --replace carriage return with <CR>
	       'A part name can''t have an imbedded carriage return <CR>' as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       file_name                                    as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS13_CCS_FORD_BOM_PARTS_INFO_K             as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS13_CCS_FORD_BOM_PARTS_INFO'            as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       part_sub_assembly_name                       as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   part_index                                   as [ARWE02_Part_Index],
		   ''                                           as [ARWE02_ARROW_Value]	
      FROM PARWS13_CCS_FORD_BOM_PARTS_INFO
     WHERE Processing_ID         = @Processing_ID
       and NullIf(PATINDEX(@pat13,part_name),0) > 0  --Looking for Carriage Return 
    ;


END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
        ,'SYSTEM'
		,0                                 --row_idx
		,''  --Part_index
		,''  --Arrow value	
;
END CATCH;	
	


GO
