DROP PROCEDURE [dbo].[PARWP_VA_UPDATE_S45_COVER_ERROR_FLAG]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2019
-- Description:	Select the DAII COVER PAGE staging records and join to the error table in order to find errors
--              If the error_type_x is 'ERROR' or 'SYSTEM', set the skip_load_f to 1 (YES)
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
--              Copied from PARWP_DAII_UPDATE_S34_COVER_ERROR_FLAG
-- =============================================
-- Changes
-- CDSID        DATE     Feature  Description
-- ----------  --------  -------  -----------
-- Ashaik12  09/30/2020 US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_VA_UPDATE_S45_COVER_ERROR_FLAG] 
-- Input Parameter
@GUIDIN Varchar(5000)

AS

SET NOCOUNT ON;

     --	Merge on Cover page to stop processing a file if there's an error 
     MERGE INTO [dbo].[PARWS45_VA_COVER_PAGE_INFO] S45_TARGET
     USING
     (Select * From
         (Select 
                 S45.Processing_ID
               , S45.filename
               , row_number() over (partition by S45.Processing_ID, S45.filename Order by E01.ARWE02_ERROR_TYPE_X) as rownum
               , ARWE02_ERROR_TYPE_X
               , CASE WHEN ARWE02_ERROR_TYPE_X in ('ERROR','SYSTEM') Then 1 Else 0  END Skip_loading_f
            From [dbo].[PARWS45_VA_COVER_PAGE_INFO] S45
       LEFT JOIN PARWE02_BATCH_ERRORS         E01
              ON S45.Processing_ID = E01.ARWE02_PROCESSING_ID  
             AND S45.filename      = E01.ARWE02_FILENAME       
           WHERE S45.PROCESSING_ID        = @GUIDIN
          ) Stg_Err
        Where rownum = 1
      ) S45_SOURCE

      on (S45_TARGET.Processing_ID = S45_SOURCE.Processing_ID AND
          S45_TARGET.FILENAME      = S45_SOURCE.FILENAME
         )
    when MATCHED THEN
         UPDATE SET          
     	    S45_TARGET.Skip_loading_due_to_error_f = IsNull(Skip_loading_f,0)
;


GO
