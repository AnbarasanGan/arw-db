DROP PROCEDURE IF EXISTS [dbo].[PARWP_TYGRA_LOAD_FILE_REC_CCM_UI] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 12/23/2020
-- Description:	Load the data in UB3 from S62 on TYGRA Load. SP is used in the UI
-- =============================================

-- Changes
-- =============================================
-- Ashaik12  03/30/2021  One query to handle all loads, now we have to use S63 table for all programs.
-- Ashaik12  04/06/2021  Added joins from S63 for Region and model year
-- rwesley2  4-20-2021   U2453456 use MAX length when declaring a variable
-- Ashaik12  04-28-2021  Add Vehicle name to the join to S63
-- Ashaik12  04-29-2021  Change to Merge
-- rwesley2  05-10-2021  US2522370    Remove reference to U31 key and replace with new UB1 table and UB1 key
-- ASHAIK12  06-16-2021  Fix join on vehicle name
-- rwesley2  09-17-2021  US2891597 add branching logic for initial load and BoB refresh. For BoB refresh pass in U01 key.  
-- rwesle2   09-30-2021  US2879211 - load Current files
-- rwesley2  10-22-2021  UB2995475 removed P05 join.  
--                                 Added S66 join. 
--                                 Removed branching logic and Created 1 MERGE to handle INSERT for initial load and BoB refresh 
-- ashaik12   02-15-2022  US3305905 Add CM10 to CM25
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_LOAD_FILE_REC_CCM_UI] 
	-- Add the parameters for the stored procedure here
     @processing_id  varchar(MAX) 
	,@CDSID varchar(MAx)
	,@TIME_STAMP DATETIME
	,@load_to_pgm_name varchar(MAX)
AS

SET NOCOUNT ON;

--******************************************************
-- it loads the table for all Engineering Commodities.
 --******************************************************
MERGE INTO [dbo].[PARWUB4_TYGRA_FILE_REC_CCM] UB4
USING
(
select 
  UB3.ARWUB3_TYGRA_FILE_REC_K          AS ARWUB3_TYGRA_FILE_REC_K
, [ARWUB2_TYGRA_FILE_CCM_K]            AS [ARWUB2_TYGRA_FILE_CCM_K]       
from PARWUB2_TYGRA_FILE_CCM UB2
JOIN PARWUB1_TYGRA_FILE UB1 on UB1.[ARWUB1_TYGRA_FILE_K]=UB2.ARWUB1_TYGRA_FILE_K
JOIN PARWA09_PGM_CCM_FLAT A09 ON UB2.ARWA09_PGM_CCM_K = A09.ARWA09_PGM_CCM_K
JOIN
(
SELECT unpvt.*  
from 
   (SELECT file_name,s62.Processing_ID,Source_c,Vehicle_name,PMT
          ,ISNULL(cm1,0) as cm1
          ,ISNULL(cm2,0) as cm2
          ,ISNULL(cm3,0) as cm3
          ,ISNULL(cm4,0) as cm4
		  ,ISNULL(cm5,0) as cm5
          ,ISNULL(cm6,0) as cm6
          ,ISNULL(cm7,0) as cm7
          ,ISNULL(cm8,0) as cm8
          ,ISNULL(cm9,0) as cm9
		  ,ISNULL(cm10,0) as cm10
		  ,ISNULL(cm11,0) as cm11
		  ,ISNULL(cm12,0) as cm12
		  ,ISNULL(cm13,0) as cm13
		  ,ISNULL(cm14,0) as cm14
		  ,ISNULL(cm15,0) as cm15
		  ,ISNULL(cm16,0) as cm16
		  ,ISNULL(cm17,0) as cm17
		  ,ISNULL(cm18,0) as cm18
		  ,ISNULL(cm19,0) as cm19
		  ,ISNULL(cm20,0) as cm20
		  ,ISNULL(cm21,0) as cm21
		  ,ISNULL(cm22,0) as cm22
		  ,ISNULL(cm23,0) as cm23
		  ,ISNULL(cm24,0) as cm24
		  ,ISNULL(cm25,0) as cm25
          ,ISNULL(non_cm1,0) as non_cm1
          ,ISNULL(non_cm2,0) as non_cm2
          ,ISNULL(non_cm3,0) as non_cm3
          ,ISNULL(non_cm4,0) as non_cm4
		  ,ISNULL(non_cm5,0) as non_cm5
          ,ISNULL(non_cm6,0) as non_cm6
          ,ISNULL(non_cm7,0) as non_cm7
		  ,ISNULL(non_cm8,0) as non_cm8
          ,ISNULL(non_cm9,0) as non_cm9
		 ,[ARWS62_TYGRA_SUMMARY]--row_idx
		 ,Surrogate_Part_Prefix,Surrogate_Part_Base,Surrogate_Part_Suffix , Start_Point_Part_Prefix,Start_Point_Part_Base,Start_Point_Part_Suffix
    from  [dbo].[PARWS62_TYGRA_SUMMARY]  s62     
where s62.Processing_ID = @processing_id  )s
UNPIVOT 
       (control_model for cm in
	    (cm1, cm2, cm3, cm4, cm5, cm6, cm7, cm8, cm9 , cm10, cm11, cm12, cm13, cm14, cm15, cm16, cm17, cm18, cm19, cm20, cm21, cm22, cm23, cm24, cm25, non_cm1, non_cm2, non_cm3, non_cm4, non_cm5, non_cm6, non_cm7, non_cm8, non_cm9)
				) as unpvt

) Tygra_file_rec
ON UB1.ARWUB1_TYGRA_FILE_N = Tygra_file_rec.file_name
JOIN PARWS63_TYGRA_CM_MAPPING S63
ON S63.STAGING_CM = cm
AND S63.ARROW_CM=A09.ARWA08_CCM_C
AND S63.PROGRAM=A09.ARWA05_ENRG_PGM_C 
AND S63.ARROW_REGION = A09.ARWA06_RGN_C
AND S63.ARROW_MDL_YR = A09.ARWA07_MDL_YR_C
AND Tygra_file_rec.Vehicle_name = UB1.[ARWUB1_TYGRA_FILE_PGM_N]
AND S63.VEHICLE_NAME=@load_to_pgm_name
and control_model!=0
JOIN PARWUB3_TYGRA_FILE_REC UB3 
ON UB3.[ARWUB1_TYGRA_FILE_K] = UB1.[ARWUB1_TYGRA_FILE_K]
AND UB3.[ARWUB3_TYGRA_FILE_REC_SEQ_R] = [ARWS62_TYGRA_SUMMARY]--row_idx
Where ub3.ARWA02_ENRG_CMMDTY_k in (select ARWA02_ENRG_CMMDTY_k FROM PARWU01_CCTSS_FLAT u01
                                                              join PARWS66_TYGRA_BOB s66
	                                                           on  Tygra_file_rec.processing_id = s66.processing_id
	                                                           and u01.ARWU01_CCTSS_K = s66.ARWU01_CCTSS_K
															   group by ARWA02_ENRG_CMMDTY_k  )

) SRC
ON (SRC.ARWUB3_TYGRA_FILE_REC_K = UB4.ARWUB3_TYGRA_FILE_REC_K
AND SRC.[ARWUB2_TYGRA_FILE_CCM_K] = UB4.[ARWUB2_TYGRA_FILE_CCM_K])
WHEN NOT MATCHED THEN INSERT
VALUES
(
 ARWUB3_TYGRA_FILE_REC_K
,[ARWUB2_TYGRA_FILE_CCM_K]
, @TIME_STAMP
, @CDSID     
, @TIME_STAMP
, @CDSID 
)
;






GO


