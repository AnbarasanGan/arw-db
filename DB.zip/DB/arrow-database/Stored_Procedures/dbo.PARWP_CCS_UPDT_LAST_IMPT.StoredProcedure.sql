DROP PROCEDURE [dbo].[PARWP_CCS_UPDT_LAST_IMPT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asamriya
-- Create date: 08/19/2019
-- Description:	load ARROW U08 Design Supplier table
-- =============================================
-- Changes
-- Author    Date       User Story  Description
-- ------    --------   ----------  -----------
-- ASOLOSKY  07/18/2020 US1694181   Added Template version to the update
-- ASOLOSKY  10/26/2020 US1950592   Changed update of Template version to only happen when there's no error.
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_UPDT_LAST_IMPT] 
-- Input Parameter
@GUIDIN                 Varchar(5000),
@CDSID	                Varchar(30),
@PROCESSING_STATUS      Varchar(50)

AS

SET NOCOUNT ON;

MERGE INTO [dbo].[PARWU08_CCTSS_DSGN_SUPL]  U08_Target
   USING

   (
   select   
            v04.[ARWU08_CCTSS_DSGN_SUPL_K]   
		   ,A24.[ARWA24_DSGN_SUPL_QTE_STAT_K] 
		   ,A24.[ARWA24_DSGN_SUPL_QTE_STAT_N]
		   ,S22.filename						
           ,S22.LAST_UPDT_S                      
           ,@CDSID                            AS [ARWU08_CCS_LAST_IMPT_USER_C]
		   ,case when @PROCESSING_STATUS = 'Processing_Error' then 'Error'			
			when @PROCESSING_STATUS = 'Regular' and S22.Skip_loading_due_to_error_f = 0 then 'No Error'
			else 'Error' end               AS PROCESSING_STATUS
			,U08.ARWA24_DSGN_SUPL_QTE_STAT_K  as Current_Status
			,U08.[ARWU08_CCS_LAST_IMPT_USER_C] as Current_Imp_User
			,U08.[ARWU08_CCS_LAST_IMPT_S]      as Current_Imp_Timestamp
			,U08.[ARWU08_CCS_LAST_IMPT_FILE_N] as Current_Imp_filename
			,U08.[ARWA50_CCS_FILE_VER_K]       as U08_ARWA50_CCS_FILE_VER_K
			,A50.[ARWA50_CCS_FILE_VER_K]       as A50_ARWA50_CCS_FILE_VER_K
			,ROW_NUMBER()                   OVER (PARTITION BY v04.[ARWU08_CCTSS_DSGN_SUPL_K] ORDER BY S22.filename) AS rownum    


          from [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22

		              
           JOIN [dbo].[PARWV04_DSGN_SUPL] v04
              on s22.[User_Selected_ENRG_SUB_CMMDTY_X] = v04.[ENG_SUB_CMMDTY_DESC]
            and s22.[User_Selected_CTSP_N]            = v04.ARWU31_CTSP_N
            and s22.[User_Selected_CTSP_Region_C]     = v04.[CTSP_REGION_CODE]
            and s22.[User_Selected_BNCMK_VRNT_N]      = v04.[VARIANT]      --BoB variant
            and s22.[User_Selected_VEH_MAKE_N]        = v04.ARWA14_VEH_MAKE_N
            and s22.[User_Selected_VEH_MDL_N]         = v04.ARWA34_VEH_MDL_N
            and s22.[User_Selected_VEH_MDL_VRNT_X]    = v04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
			AND S22.[User_Selected_VEH_MDL_YR_C]      = v04.[ARWA35_DSGN_VEH_MDL_YR_C]
            AND s22.[User_Selected_SUPL_N]            = v04.ARWA17_SUPL_N
            AND S22.[User_Selected_SUPL_C]            = v04.ARWA17_SUPL_C
            AND S22.[User_Selected_SUPL_CNTRY_N]      = v04.ARWA28_CNTRY_N

			JOIN [dbo].[PARWU08_CCTSS_DSGN_SUPL] U08

			on v04.ARWU08_CCTSS_DSGN_SUPL_K = U08.[ARWU08_CCTSS_DSGN_SUPL_K]

			JOIN [PARWA24_DSGN_SUPL_QTE_STAT] A24
			
			ON A24.ARWA24_DSGN_SUPL_QTE_STAT_N = case when @PROCESSING_STATUS = 'Processing_Error'  
			                                               and U08.ARWA24_DSGN_SUPL_QTE_STAT_K = (select ARWA24_DSGN_SUPL_QTE_STAT_K 
														                                            from [dbo].[PARWA24_DSGN_SUPL_QTE_STAT] 
																								   where [ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Not Imported')
			                                          then 'Not Imported'
			                                          when @PROCESSING_STATUS = 'Regular' and S22.Skip_loading_due_to_error_f = 0 
													  then 'Imported'
			                                          else 'Import Error'
												  end
			
			Join PARWA50_CCS_FILE_VER A50 on a50.ARWA50_CCS_FILE_VER_N  = S22.TEMPLATE_VERSION
		where s22.[Processing_ID]             =   @GUIDIN 

		) U08_Source
			
		

			      ON  U08_Target.ARWU08_CCTSS_DSGN_SUPL_K  =  U08_Source.ARWU08_CCTSS_DSGN_SUPL_K

			  and U08_Source.rownum = 1	
				  

		 WHEN MATCHED THEN
       UPDATE SET         	
	   
	     U08_Target.ARWU08_CCS_LAST_IMPT_FILE_N       = case when PROCESSING_STATUS = 'No Error' then U08_Source.filename else U08_Source.Current_Imp_filename end
		,U08_Target.ARWU08_CCS_LAST_IMPT_S            = case when PROCESSING_STATUS = 'No Error' then U08_Source.LAST_UPDT_S else U08_Source.Current_Imp_Timestamp end
	    ,U08_Target.ARWU08_CCS_LAST_IMPT_USER_C       = case when PROCESSING_STATUS = 'No Error' then U08_Source.ARWU08_CCS_LAST_IMPT_USER_C else U08_Source.Current_Imp_User end
		,U08_Target.ARWA24_DSGN_SUPL_QTE_STAT_K		  = case when U08_Source.[ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Not Imported' and PROCESSING_STATUS = 'Error' then (select ARWA24_DSGN_SUPL_QTE_STAT_K from [dbo].[PARWA24_DSGN_SUPL_QTE_STAT] where [ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Not Imported')
														when U08_Source.[ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Imported' and PROCESSING_STATUS = 'Error' then (select ARWA24_DSGN_SUPL_QTE_STAT_K from [dbo].[PARWA24_DSGN_SUPL_QTE_STAT] where [ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Import Error')
														when U08_Source.[ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Import Error' and PROCESSING_STATUS = 'Error' then (select ARWA24_DSGN_SUPL_QTE_STAT_K from [dbo].[PARWA24_DSGN_SUPL_QTE_STAT] where [ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Import Error')
														else (select ARWA24_DSGN_SUPL_QTE_STAT_K from [dbo].[PARWA24_DSGN_SUPL_QTE_STAT] where [ARWA24_DSGN_SUPL_QTE_STAT_N] = 'Imported') end
		,U08_Target.ARWU08_LAST_UPDT_S				  = U08_Source.LAST_UPDT_S
		,U08_Target.ARWU08_LAST_UPDT_USER_C           = U08_Source.ARWU08_CCS_LAST_IMPT_USER_C
		,U08_Target.ARWA50_CCS_FILE_VER_K             = case when PROCESSING_STATUS = 'No Error' then U08_Source.A50_ARWA50_CCS_FILE_VER_K else U08_Source.U08_ARWA50_CCS_FILE_VER_K  end
;

GO
