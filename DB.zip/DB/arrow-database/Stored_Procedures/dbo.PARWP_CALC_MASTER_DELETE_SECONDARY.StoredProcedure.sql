SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASOLOSKY
-- Create date: 04/04/2022
-- Description: Procedure that deletes all secondary tables
-- Input Parameters
-- @U01_k - ARWU01_CCTSS_K and it must always be passed in 
--          A zero indicates that a developer is testing for a SYSTEM ERROR.  
--          It was done this way so the code didn't have to be changed and recompiled every time and messing with others testing.
-- @DC_Study_F - 'Y' indicates the study is DC, 'N' indicates its not a DC study
-- @CDSID - The person who is triggering the procedure
-- Output Parameter(s)
-- @Primary_output_error - Will return the error message on an exception. No error returns an empty string ('')
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_MASTER_DELETE_SECONDARY]
 @U01_k                  INT     --Study Key must always be passed in.  A zero indicates that a developer is testing for a SYSTEM ERROR
,@DC_Study_F             varchar(1)
,@CDSID                  varchar(8)
,@Secondary_delete_error varchar(5000) OUTPUT

AS

SET NOCOUNT ON;

BEGIN
 BEGIN TRY

    Declare @TMP INT = @U01_k/@U01_k;  -- A zero indicates that a developer is testing for a SYSTEM ERROR
    
    Set @Secondary_delete_error = ''
    
    IF @DC_Study_F = 'N'
    Begin  
      Execute [dbo].[PARWP_CALC_DELETE_D05_DSGN_DA_TRADEOFF_PART_DETAIL]      @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D07_DSGN_INTENT_ADJ]                   @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D08_DSGN_II_TRADEOFF_PART_DETAIL]      @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D09_VA_DA_TRADEOFF_PART_DETAIL]        @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D10_VARIANT_COST_OVRVW]                @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D12_DSGN_INTENT_ADJ_L2]                @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D13_COST_ALLOCATION_EI]                @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D14_TRADEOFF_SUMMARY]                  @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D15_VA_TRADEOFF_LIST_SLIDE]            @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D16_RISKS_AND_OPPS]                    @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D17_AVG_VEH_COST]                      @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D18_COST_ALLOCATION_EI_ASM]            @U01_k;
	 End;
	 Else --Its a DC study
	 Begin
      Execute [dbo].[PARWP_CALC_DELETE_D19_DC_COST_ALLOCATION_EI]             @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D20_DC_COST_ALLOCATION_EI_ASM]         @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D21_DC_CT_VRNT_COST]                   @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D22_DC_DSGN_II_TRADEOFF_PART_DETAIL]   @U01_k;
      Execute [dbo].[PARWP_CALC_DELETE_D23_DC_VRNT_SUP_COST]                  @U01_k;
	 END;
  --select 1/0;

 -- COMMIT will be done by the calling process
 END TRY

 BEGIN CATCH
--  Rollback will be done by the calling process
    Declare @u01_Study Varchar(100);
    Set @u01_Study = (Select U01.ARWU31_CTSP_N            + ' ' +
                             U01.ARWA06_RGN_C             + ' ' +
                      	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                      	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                        from PARWU01_CCTSS_FLAT U01
                       where U01.ARWU01_CCTSS_K = @U01_k
                     );

    Set @Secondary_delete_error = 'Study Key: '       + cast(@U01_k as varchar(20)) + 
	                               ' |Study: '         + ISNULL(@u01_Study, '') +
	                               ' |GMT Date/Time: ' + CONVERT(varchar, GETUTCDATE(), 120) +
	                               ' |CDS: '           + @CDSID +
	                               ' |Procedure: '     + ERROR_PROCEDURE() + 
								          ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
								          ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
 END CATCH;	

END;
GO
