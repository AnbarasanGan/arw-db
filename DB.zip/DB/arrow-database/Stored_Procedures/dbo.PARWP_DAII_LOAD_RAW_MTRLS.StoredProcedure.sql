DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_RAW_MTRLS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 06/21/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 06/27/2019  Ashaik12            Changed the join from U19_K to U18_K
-- 07/12/2019  Asolosky		       Moved the deletes to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure
-- 08/28/2019  Asolosky  US1154597 Changed UoM from a _K column to a description column to handle text. 
--                                 Removed join on the PARWA27_UOM table.
-- 01/14/2020  Ashaik12            Added Time_Stamp parameter and removed filter on Processing Status
-- ==============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_RAW_MTRLS] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--DELETE: moved to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS

INSERT INTO PARWU39_RAW_MTRL_DSGN_ADJ
SELECT --ARWU39_RAW_MTRL_DSGN_ADJ_K is an identity 
       V04.ARWU08_CCTSS_DSGN_SUPL_K                      AS ARWU08_CCTSS_DSGN_SUPL_K
	  ,S40.row_idx AS ARWU39_RAW_MTRL_DSPLY_SEQ_R
      ,U37.ARWU37_CCTSS_DSGN_ADJ_K           AS ARWU37_CCTSS_DSGN_ADJ_K
	  ,S40.material_specification            AS ARWU39_RAW_MTRL_SPEC_X
	  ,S40.source_supplier                   AS ARWU39_SRC_SUPL_N

	  ,Case When A28.ARWA28_CNTRY_K is Null then A28_EmptyStr.ARWA28_CNTRY_K Else A28.ARWA28_CNTRY_K  End AS ARWA28_SRC_CNTRY_K

	  ,A29.ARWA29_CRCY_K                     AS ARWA29_LCL_CRCY_K
	  ,S40.no_of_pieces                      AS ARWU39_PCE_PER_SUB_ASSY_Q
	  ,S40.uom                               AS ARWU39_RAW_MTRL_UOM_X
	  ,S40.gross_usage_per_piece             AS ARWU39_GRS_USG_PER_PCE_Q
	  ,IsNULL(S40.[material_price],0)        AS ARWU39_MTRL_PEL_RATE_PER_UOM_A  
      ,IsNULL(S40.inbound_packaging_costs,0) AS ARWU39_INBND_PKNG_COST_UOM_A
      ,IsNULL(S40.inbound_logistics_costs,0) AS ARWU39_INBND_LGSTCS_COST_UOM_A
      ,IsNULL(S40.tax_duty_per_uom,0)        AS ARWU39_TAX_AND_DUTY_PER_UOM_A
      ,IsNULL(S40.reclamation_pcntg,0)       AS ARWU39_RCLMTN_P
      ,IsNULL(S40.scrap_price,0)             AS ARWU39_SCRAP_PRCE_PER_UOM_A
      ,IsNULL(S40.comments,0)                AS ARWU39_RAW_MTRL_ASSMP_CMT_X
	  ,@TIME_STAMP                          AS ARWU38_CREATE_S
	  ,@CDSID                                AS ARWU38_CREATE_USER_C
	  ,@TIME_STAMP                          AS ARWU38_LAST_UPDT_S
	  ,@CDSID                                AS ARWU38_LAST_UPDT_USER_C

  From PARWS34_DAII_COVER_PAGE_INFO     S34 
  JOIN PARWS40_DAII_RAW_MATERIALS_INFO  S40
    ON S40.Processing_ID       = S34.Processing_ID
   AND S40.filename            = S34.filename

 -- Join with Supplier Quote View
    JOIN dbo.PARWV04_DSGN_SUPL V04
    ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

--Design Adjustment Part
  Join PARWU37_CCTSS_DSGN_ADJ  U37 
    ON U37.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
   And U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  = S40.change_improvement_id  
 --Currency
  JOIN PARWA29_CRCY      A29           ON S40.local_currency   = A29.ARWA29_CRCY_C
 --Source-Country
 Left JOIN PARWA28_CNTRY A28           ON S40.source_country   = A28.ARWA28_CNTRY_N
  JOIN PARWA28_CNTRY     A28_EmptyStr  ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

  Where S34.Processing_ID               = @GUIDIN
	AND S34.Skip_loading_due_to_error_f = 0
	And S40.cost_type                   = 'Adjustment Costs'

;

GO
