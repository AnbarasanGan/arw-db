
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 05/25/2022
-- Description:	based on whether the file is new or previously loaded to Tygra, determine where to get processing ID from. 
-- US3657704 - initial user story 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------

-- =============================================
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_INPUT_PARAMETERS]
	-- Add the parameters for the stored procedure here

-- Input Parameter
@CDSID varchar(MAX)
,@file_name varchar(max)
,@time_stamp datetime
--,@previously_loaded varchar(max)  -- N = new file from ACT, Y means previoulsy loaded to ARROW
,@file_source varchar(max)
,@GUID varchar(MAX) OUTPUT



AS

Begin Try

SET NOCOUNT ON;


--*******************************************************************************************************
-- If file from ACT is being loaded to ARROW for the first time get a new processing ID - Pass back to UI
--*******************************************************************************************************
If @file_source = 'ACT'
Begin
   DECLARE @Processing_id uniqueidentifier = NEWID();
   set @guid = @processing_id
End


--*******************************************************************************************************
--If BoB load, get processing Id from previously loaded file by file name and max last update date 
--*******************************************************************************************************
If @file_source = 'ARROW'
Begin
   set @guid = (
   select processing_id from PARWS61_TYGRA_TITLE_PAGE
   where [file_name] = @file_name
   and [LAST_UPDT_S]  = (select max([LAST_UPDT_S]) from PARWS61_TYGRA_TITLE_PAGE
                       where [file_name] = @file_name)
   group by Processing_ID)
END



 END TRY

 --CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@processing_id                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWP_TYGRA_UI_LOAD_UB1_UI'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	




GO


