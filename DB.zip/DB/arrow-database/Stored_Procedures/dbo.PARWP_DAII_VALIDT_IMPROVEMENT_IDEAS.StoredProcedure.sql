DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_IMPROVEMENT_IDEAS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 07/02/2019
-- Description:	validate Improvement Ideas Part Index, PArt Name against PBOM 
--              and check that idea has been quoted
-- =============================================
-- CHANGES
-- Date			CDSID	  Feature Description
-- ----------   --------  ------- -----------
-- 07/12/2019	rwesley2	na		added validation that part index belongs to the design
-- 07/19/2019	rwesley2	na		added validation for improvement idea grouping
-- 08/01        ASHAIK12            Changed from ERROR to WARNING for BOM Qouted validation
-- 09/10/2019   asamriya            Added row_idx
-- 09/12/2019   rwesley2            added validation for Improvement Idea Originator 
-- 10/04/2019   ashaik12            Changed WARNING to ERROR on the Originator field validation
-- 10/29/2019   ashaik12            Add new validation to check if Added part index is of one character
-- 11/01/2019   asolosky            Change the U19 table join to a left join in the @design_part_index TABLE
-- 11/05/2019   rwesley2            new validation to check if added part has a sub-assembly 
-- 11/07/2019   rwesley2            added REPLACE to remove special characters for U18 bom part name
-- 11/08/2019   asolosky            Comment out the validate Improvement Idea Grouping select statement (@design_part_index TABLE).
--                                  This validation will stop any part add for Improvement Idea so it had to be removed.
-- 11/18/2019   rwesley             comment out validate Improvement Idea Grouping
-- 11/21/2019  rwesley2             new business rule:  the first character of a part index defines the sub-assy  
-- 11/23/2019  ashaik12             Commented out the first validation as a new part index might not exist in U18 table, we need to add it to U18 in the load.
-- 11/26/2019  ashaik12             Moved last validation that checks if a new part index has a sub-assy to ADDED_PARTS based on review 
--                                  And Fixed second procedure to validate part description to a left join instead of NOT EXISTS
-- 01/14/2020  Ashaik12             Added Time_Stamp parameter and removed filter on Processing Status
-- 07/14/2020  Asolosky  US1701019  Changed error to include the Arrow part name: 'Improvement Idea Name: '+ Err.[part_name] + ', doesn''t match PBOM Part name: ' +  ARWU18_BOM_PART_X
-- 07/24/2020  Asolosky  US1771016  used the replace function for part_name to display a line feed
-- 07/29/2020  Asolosky  US1782182  New part index adds in Improvement ideas must have an unique part name. A part can be in the excel file more than once with different change_ids but the part names must be the same.
--                                  Added the validation: verify the improvement idea part index has 1 unique part name.  If it has more, reject. This was a defect
-- 09/11/2020  Asolosky  US1910882  Switched from E01 error table to E02 to include part_index and arrow_Value
-- 12/07/2020  Asolosky  US2129929  Display an error when BOM Quoted column is not Yes or No
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_IMPROVEMENT_IDEAS] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
/*
-- validate Improvement Idea Part index
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  Err.[part_index] as [ARWE02_ERROR_VALUE],
	  'Improvement Idea Part Index does not match a CCS PBOM part index:  ' + Err.[part_index] as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  'Improvement Ideas' as [ARWE02_EXCEL_TAB_X],
	  Err.row_idx
       FROM 
       (
        SELECT 
          Processing_ID,
		  part_index,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS44_DAII_IMPROVEMENT_IDEA_K],
		  row_idx
        FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO]     S44
        WHERE Processing_Status_x = 'PROCESSING'
		and Processing_ID=@GUID
	    and Not Exists
		      (Select 'X'
			     from [dbo].[PARWU18_BOM_PART] U18
                where S44.[part_index]=U18.ARWU18_BOM_PART_IX_N
)
                    
       ) Err

    ;
*/
-- validate Improvement Idea Part description
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>') as [ARWE02_ERROR_VALUE],
	  'Improvement Idea Name doesn''t match PBOM Part name in ARROW.' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  'Improvement Ideas' as [ARWE02_EXCEL_TAB_X],
	  Err.row_idx,
	  improvement_id,
	  ARWU18_BOM_PART_X  -- ARROW Value
       FROM 
       (
        SELECT 
          S44.Processing_ID,
		  S44.part_name,
		  S44.part_index,
		  S44.improvement_id,
		  ARWU18_BOM_PART_X,
		  S44.Source_c,
		  S44.filename,
          ARWS44_DAII_IMPROVEMENT_IDEA_K,
		  S44.row_idx
        FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO   S44
        JOIN PARWS34_DAII_COVER_PAGE_INFO          S34
          ON S34.Processing_ID       = S44.Processing_ID
         AND S34.filename            = S44.filename
	    JOIN PARWU01_CCTSS_FLAT   U01
          ON U01.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
         AND U01.ARWA06_RGN_C               = S34.User_Selected_CTSP_Region_C
         AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S34.User_Selected_ENRG_SUB_CMMDTY_X 
         AND U01.ARWU01_BNCHMK_VRNT_N       = S34.User_Selected_BNCMK_VRNT_N
		JOIN PARWU18_BOM_PART     U18
		  ON U01.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K 
		 and S44.[part_index]   = u18.[ARWU18_BOM_PART_IX_N]
       WHERE S44.Processing_ID  = @GUID
	     and s44.[part_name]   != U18.[ARWU18_BOM_PART_X]
                    
       ) Err

    ;
-- validate Improvement Idea is Quoted
 INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]

    Select 
		 Err.Source_c
		,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>')
		,'Improvement ID not quoted'  as Error_Msg
        ,err.Processing_ID 
		,Err.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K]
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'  
        ,'WARNING'                       
		,'Improvement Ideas'
		,Err.row_idx
	    ,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>')
	    ,''  -- ARROW Value
    FROM
    (	
	  SELECT S44.*
	    FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO] S44
	   WHERE S44.processing_ID       = @GUID
		 and s44.[quoted]            = 'No'	  
	) Err
	;

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 Source_c
		,quoted
		,'Quoted column must be Yes or No. The template has a formula in this column which was manually overridden. Please copy the formula from a valid "Quoted" cell and paste it into the cell with the error. This will automatically populate a Yes or No.' as Error_Msg
        ,Processing_ID 
		,filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'  
        ,'ERROR'                       
		,'Improvement Ideas'
	    ,row_idx                               as ARWE02_ROW_IDX
		,replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>')
		,''  --No ARROW Value
    FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO
    WHERE processing_ID          = @GUID
	  and IsNull(quoted,'#!~&$') Not in ('Yes', 'No')	  
;
-- validate Improvement Idea Part Index belongs to Design (removed 11/8/2019)
--DECLARE @design_part_index TABLE (
--         design_make VARCHAR(32) NOT NULL
--        ,design_model VARCHAR (32) NOT NULL
--        ,design_MY VARCHAR (7) NOT NULL
--	    ,design_part_index VARCHAR (64) NOT NULL
--		                                 )
--	;
--
--INSERT INTO @design_part_index
--SELECT U06.[ARWA14_VEH_MAKE_N]
--	  ,U06.[ARWA34_VEH_MDL_N]
--	  ,U06.[ARWA35_DSGN_VEH_MDL_YR_C]
--      ,U18.[ARWU18_BOM_PART_IX_N]
--  FROM PARWU06_CCTSS_DSGN_FLAT  U06
--  join PARWU18_BOM_PART         U18     On U18.ARWU01_CCTSS_K        = U06.ARWU01_CCTSS_K
--  join PARWU17_BOM_SUB_ASSY     U17     On U17.ARWU17_BOM_SUB_ASSY_K = U18.ARWU17_BOM_SUB_ASSY_K
--  join PARWS34_DAII_COVER_PAGE_INFO S34 On S34.User_Selected_CTSP_N  = U06.ARWU31_CTSP_N  --added join to cover page to reduce the amount of data to a BoB
--   and S34.User_Selected_CTSP_Region_C     = U06.ARWA06_RGN_C
--   and S34.User_Selected_ENRG_SUB_CMMDTY_X = U06.ARWA03_ENRG_SUB_CMMDTY_X
--   and S34.User_Selected_BNCMK_VRNT_N      = U06.ARWU01_BNCHMK_VRNT_N
-- Where S34.Processing_ID = @GUID
-- Group by U06.[ARWA14_VEH_MAKE_N]   --There's dups because the Processing_id could have multiple files. The group by will remove them
--	     ,U06.[ARWA34_VEH_MDL_N]
--	     ,U06.[ARWA35_DSGN_VEH_MDL_YR_C]
--         ,U18.[ARWU18_BOM_PART_IX_N]
--;
--
--INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
--      SELECT
--	   Err.[Source_c] 
--	  ,Err.part_index
--      ,'Improvement Ideas - Part Index does not belong to this Design:  ' + Err.part_index  AS ARWE02_ERROR_X 
--	  ,Err.[Processing_ID] 
--	  ,Err.[filename] 
--	  ,OBJECT_NAME(@@PROCID) 
--	  ,@TIME_STAMP 
--	  ,@CDSID   
--	  ,@TIME_STAMP   
--	  ,@CDSID  
--	  ,Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K]
--	  ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'     
--	  ,'ERROR'
--	  ,'Improvememt Ideas' 
--	  ,Err.row_idx
--   FROM 
--       (
--select s44.[Processing_ID]
--		,s44.[part_index]
--		,s44.[Processing_Status_x]
--        ,s44.[Source_c]
--		,s44.filename
--		,s44.[ARWS44_DAII_IMPROVEMENT_IDEA_K]
--		,s44.row_idx
--from [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO] s44
--join [dbo].[PARWS34_DAII_COVER_PAGE_INFO]        s34
--on s44.[Processing_ID] = s34.[Processing_ID]
--and s44.[filename] = s34.[filename]
--where s44.[Processing_ID]              = @GUID
--and s44.[Processing_Status_x]        = 'PROCESSING'
--and s34.[User_Selected_VEH_MAKE_N] + s34.[User_Selected_VEH_MDL_N] + s34.[User_Selected_VEH_MDL_YR_C] + s44.[part_index]  
--NOT IN (
--        SELECT dpi.design_make + dpi.design_model + dpi.design_MY + dpi.design_part_index
--		from  @design_part_index dpi
--		)
--) ERR
--;		 

-- validate Improvement Idea Grouping (removed 11/18/2019)
--	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
--      SELECT
--	  Err.[Source_c] as [ARWE02_SOURCE_C],
--	  Err.[part_index] as [ARWE02_ERROR_VALUE],
--	  'Part Index Not Assigned to an Trade-off Grouping:  ' +  Err.[part_index] as [ARWE02_ERROR_X],
--	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
--	  Err.[filename] as [ARWE02_FILENAME],
--	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
--	  @TIME_STAMP as [ARWE02_CREATE_S],
--	  @CDSID as [ARWE02_CREATE_USER_C],
--	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
--	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
--	  Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K] as [ARWE02_BATCH_ERRORS_REF_K],
--	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X],
--	  'WARNING' as [ARWE02_ERROR_TYPE_X],
--	  'Improvement Ideas' as [ARWE02_EXCEL_TAB_X],
--	  Err.row_idx
--       FROM 
--       (
--        SELECT 
--          Processing_ID,
--		  part_index,
--		  Processing_Status_x,
--		  Source_c,
--		  filename,
--          [ARWS44_DAII_IMPROVEMENT_IDEA_K],
--		  row_idx
--        FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO]     S44
--        WHERE Processing_Status_x = 'PROCESSING'
--		and Processing_ID =  @GUID
--	    and improvement_idea_grouping = ' '
--                    
--       ) Err
--
--    ;

-- validate Improvement Idea Originator
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  CASE WHEN Err.[originator] = '' THEN '<Blank>'
		   ELSE Err.[originator]
	  END as [ARWE02_ERROR_VALUE],
	  'Improvement Idea Originator is not Ford or Supplier.' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
	  @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  'Improvement Ideas' as [ARWE02_EXCEL_TAB_X],
	  Err.row_idx,
      replace(replace(improvement_id,char(10),'<LF>'),char(13),'<CR>'),
	  ''  -- ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
		  originator,
		  improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS44_DAII_IMPROVEMENT_IDEA_K],
		  row_idx
        FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO]     S44
        WHERE Processing_ID = @GUID
	    and originator not in ('Ford','Supplier')
                    
       ) Err

    ;

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  S44.[Source_c]                         as [ARWE02_SOURCE_C],
	  S44.[part_index]                       as [ARWE02_ERROR_VALUE],
	  'Part Index is Less than 2 Characters' as  [ARWE02_ERROR_X],
	  S44.[Processing_ID]                    as [ARWE02_PROCESSING_ID],
	  S44.[filename]                         as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID)                  as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP                            as [ARWE02_CREATE_S],
      @CDSID                                 as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP                            as [ARWE02_LAST_UPDT_S],
	  @CDSID                                 as [ARWE02_LAST_UPDT_USER_C],
	  S44.[ARWS44_DAII_IMPROVEMENT_IDEA_K]   as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'  as [ARWE02_STAGING_TABLE_X],
	  'ERROR'                                as [ARWE02_ERROR_TYPE_X],
	  'Improvement Ideas'                    as [ARWE02_EXCEL_TAB_X],
	  S44.row_idx                            as [ARWE02_ROW_IDX],
	  S44.improvement_id,
	  ''  -- ARROW Value
       FROM 
         [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO S44
        WHERE Processing_ID         = @GUID
	--	and S46.type_of_change    ='ADD'
		and len(S44.part_index) <= 1


    ;

-- verify the improvement idea part index has 1 unique name.  If it has more, reject
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
 SELECT
	    Err.[Source_c]                        as [ARWE02_SOURCE_C]
	   ,replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>')                                           as [ARWE02_ERROR_VALUE]
	   ,'The new part index has 2 different part names. Please correct this so the part names are the same.'  as [ARWE02_ERROR_X]
	   ,Err.[Processing_ID]                   as [ARWE02_PROCESSING_ID]
	   ,Err.[filename]                        as [ARWE02_FILENAME]
	   ,OBJECT_NAME(@@PROCID)                 as [ARWE02_PROCEDURE_X]
	   ,@TIME_STAMP                           as [ARWE02_CREATE_S]
	   ,@CDSID                                as [ARWE02_CREATE_USER_C]
	   ,@TIME_STAMP                           as [ARWE02_LAST_UPDT_S]
	   ,@CDSID                                as [ARWE02_LAST_UPDT_USER_C]
	   ,Err.[ARWS44_DAII_IMPROVEMENT_IDEA_K]  as [ARWE02_BATCH_ERRORS_REF_K]
	   ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO' as [ARWE02_STAGING_TABLE_X]
	   ,'ERROR'                               as [ARWE02_ERROR_TYPE_X]
	   ,'Improvement Ideas'                   as [ARWE02_EXCEL_TAB_X]
	   ,Err.row_idx
	   ,improvement_id
	   ,''
   FROM 
       (--find part_index that has more than one unique name
	    Select *
	          ,Count(*) over (partition by filename, part_index) cnt  
	      from  
               (--get unique part_index and part_name
                SELECT Source_c,
                       Processing_ID,
		               part_index,
					   improvement_id,
		         	   part_name,
		               Processing_Status_x,
		               filename,
                      [ARWS44_DAII_IMPROVEMENT_IDEA_K],
		               row_idx,
		         	  ROW_NUMBER() over (partition by filename, part_index, part_name Order by row_idx) rownum
                 FROM [dbo].[PARWS44_DAII_IMPROVEMENT_IDEAS_INFO]     S44
                WHERE Processing_ID       = @GUID
	              and Not Exists
		               (Select 'X'
		         	     from [dbo].[PARWU18_BOM_PART] U18
                        where S44.[part_index]=U18.ARWU18_BOM_PART_IX_N
                       )                    
               ) uniq
         Where rownum = 1
	   ) ERR
	   Where cnt > 1

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;






GO
