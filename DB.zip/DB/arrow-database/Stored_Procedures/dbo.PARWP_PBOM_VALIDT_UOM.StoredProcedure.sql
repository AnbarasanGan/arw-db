DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_UOM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Asolosky
-- Create date: 01/08/2020
-- Description:	Stored Procedure to validate UOM
--        Note: Copied from the PARWP_CCS_VALIDT_UOM procedure and modified.
-- =============================================
-- Changes
-- =============================================
-- Author    Date        Description
-- ------    -----       -----------
-- rwesley2  09-11-2020  US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky  10-20-2020  US1996362 Switch from E02 to E03 and include Excel column
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDT_UOM] 
 @GUID       varchar(5000) 
,@CDSID      varchar(30)
,@TIME_STAMP datetime

AS

BEGIN TRY

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
      SELECT
	  Validate.[Source_c]                           as [ARWE03_SOURCE_C],
	  Validate.[uom]                                as [ARWE03_ERROR_VALUE],
	  'Unit of Measure Not found in Arrow Database' as [ARWE03_ERROR_X],
	  Validate.[Processing_ID]                      as [ARWE03_PROCESSING_ID],
	  Validate.[file_name]                          as [ARWE03_FILENAME],
	  OBJECT_NAME(@@PROCID)                         as [ARWE03_PROCEDURE_X],
	  @TIME_STAMP                                   as [ARWE03_CREATE_S],
	  @CDSID                                        as [ARWE03_CREATE_USER_C],
	  @TIME_STAMP                                   as [ARWE03_LAST_UPDT_S],
	  @CDSID                                        as [ARWE03_LAST_UPDT_USER_C],
	  Validate.ARWS59_PBOM_PARTS                    as [ARWE03_BATCH_ERRORS_REF_K],
	  'PARWS59_PBOM_PARTS'                          as [ARWE03_STAGING_TABLE_X],
	  'ERROR',
	  VALIDATE.sub_assembly_name,
	  row_idx                                       as ARWE03_ROW_IDX,
	  part_index                                    as ARWE03_Part_Index,
	  ''                                            as ARWE03_Arrow_value,
	  uom_column                                    as ARWE03_COLUMN
       FROM (
	   --Find all staging records where the Unit of Measure is not in the Arrow A27 table
        SELECT 
              Processing_ID,
		      uom,
			  uom_column,
		      Source_c,
			  part_index,
		      file_name,
              ARWS59_PBOM_PARTS,
			  sub_assembly_name,
			  row_idx
         FROM PARWS59_PBOM_PARTS  S59
        WHERE Processing_ID = @GUID
	      and Not Exists
		      (Select 'X'
			     from PARWA27_UOM A27
                where S59.uom = A27.ARWA27_UOM_C
              )

   ) Validate;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS'             --ARWE03_STAGING_TABLE_X
			 --ARWE03_BATCH_ERRORS_K Identity key
			 ,'ERROR'                          --ARWE03_ERROR_TYPE_X
			 ,'SYSTEM'                         --ARWE03_EXCEL_TAB_X
			 ,0                                --row_idx
	         ,''                               --part_index 
	         ,''                               --ARROW_VALUE
			 ,''                               --Column
END CATCH
GO
