SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 6/21/2019
-- Description:	validate DAII Adjustment Costs: processing costs
-- Notes: not validating OP index or Op desc.  These are free-form enties and not required on CCS
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12  07/30        Added Validations to check Improvement Id against Improevement Ideas table
-- rwesley2  07/31/19     Added calculated field validations
-- asamriya  09/10/2019   Added row_idx
-- rwesley2  09/13/2019   added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- asolosky  09/30/2019   Insert for error: "The Calculated field Machine /operation overhead costs" had change_id instead of ARWS41_DAII_PROCESSING_PARTS_K.  Changed back to the _k column 
-- asolosky  09/30/2019   Changed error messages to more descriptive
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky  07/24/2020   US1771016 used the replace function for change_id and part_name to display a line feed
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  04/12/2021   US2430169 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021   US2815039 Added a case statement in the first change id validation. Had to create the case by template version.
--                        When change id does not belong the BOM Sub Assembly display an error. This happens if the user does a copy paste from another sheet.
-- Asolosky  06/01/2022   US3664508 Added new error to reject a file if the supplier quoted a change id with a type of DELETE 
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_DAII_VALIDT_PROCESSING_COSTS] 

@GUID varchar(5000), 
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--++++++++++++++++++++++++++++++++++++
-- Change improvement ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,replace(replace(change_improvement_id,char(10),'<LF>'),char(13),'<CR>') 
	  ,Error_x 
	  ,Processing_ID 
	  ,filename
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,ARWS41_DAII_PROCESSING_PARTS_K
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'   
	  ,'ERROR'
	  ,sub_assembly_name
	  ,row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
  FROM 
       (
        SELECT 
		       S41.Processing_ID,
               S41.change_improvement_id,
		       S41.Processing_Status_x,
		       S41.Source_c,
		       S41.filename,
               S41.ARWS41_DAII_PROCESSING_PARTS_K,
		       S41.sub_assembly_name,
		       S41.row_idx,
		       Case When S34.TEMPLATE_VERSION < 'V2.6' --For old templates not broken out by sub-assembly
			        Then Case When coalesce(S35.change_id,'~')    != S41.change_improvement_id  
			                  Then 'Adjustment Costs for Processing - Invalid Change ID.'					 
					          Else ''
						  End
				    Else -- Version >= 'V2.6'
			             Case When Substring(S35.sheet_name,5,DATALENGTH(S35.sheet_name)) != Substring(S41.sub_assembly_name,7,DATALENGTH(S41.sub_assembly_name)) 
		                      Then 'Processing: Change Id was found on a different ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  When S35.sheet_name               is Null
			                  Then 'Processing: Change Id was not found on any ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  Else ''
						 End
		       End Error_x
          FROM PARWS41_DAII_PROCESSING_PARTS_INFO   S41
          Join PARWS34_DAII_COVER_PAGE_INFO         S34
		    ON S34.Processing_ID = S41.Processing_ID
		   and S34.filename      = S41.filename
     Left Join PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
            ON S35.change_id     = S41.change_improvement_id
		   and S35.filename      = S41.filename
		   and S35.Processing_ID = S41.Processing_ID
         WHERE S41.Processing_ID = @GUID
		   and S41.cost_type     = 'Adjustment Costs'
       ) Err
 Where Error_x != ''
;

--++++++++++++++++++++++++++++++++++++
-- Change improvement ID Part Description validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>') 
	  ,'Adjustment Costs for Processing - Part Description does not match Adjustment Details Part Name.'
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID)  
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS41_DAII_PROCESSING_PARTS_K
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx   
      ,change_improvement_id
      ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  change_improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS41_DAII_PROCESSING_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
		  and S41.cost_type='Adjustment Costs'
	      and Not Exists
		      (Select 'X'
               from  [dbo].PARWS35_DAII_ADJUSTMENT_DETAILS_INFO s35
               where s41.[change_improvement_id] = s35.[change_id]
			     and s41.part_description=s35.part_name
				 and s41.[filename] = s35.[filename]
				 and s41.Processing_ID=s35.Processing_ID
              )
       ) Err

    ;

	--++++++++++++++++++++++++++++++++++++
-- Change improvement ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_improvement_id,char(10),'<LF>'),char(13),'<CR>') 
	  ,'Improvement Costs for Processing - Improvement ID was not found on the Improvement Ideas Sheet. Please do not copy/paste. Use the drop down to select the Improvement Id.' 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS41_DAII_PROCESSING_PARTS_K
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'   
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx
      ,change_improvement_id
      ,''  --No ARROW Value
        FROM 
       (
        SELECT 
		  Processing_ID,
          [change_improvement_id],
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS41_DAII_PROCESSING_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
		  and S41.cost_type='Improvement Costs'
	      and Not Exists
		      (Select 'X'
               from  [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO s44
               where s41.[change_improvement_id] = s44.improvement_id
				 and s41.[filename] = s44.[filename]
				 and s41.Processing_ID = s44.Processing_ID
              )
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
-- Change improvement ID Part Description validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>') 
	  ,'Improvement Costs for Processing -  Part Description does not match Part Name on Improvement Ideas tab' 
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID)  
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS41_DAII_PROCESSING_PARTS_K
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,ERR.row_idx  
      ,change_improvement_id
      ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  change_improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS41_DAII_PROCESSING_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
		  and S41.cost_type='Improvement Costs'
	      and Not Exists
		      (Select 'X'
               from  [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO s44
               where s41.[change_improvement_id] = s44.improvement_id
			     and s41.part_description=s44.part_name
				 and s41.[filename] = s44.[filename]
				 and s41.Processing_ID=s44.Processing_ID
)
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Currency Code validation
-- note: not validating the code is associated with correct country
--++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,ISNULL(Err.[local_currency],0)  
	  ,'Processing - Invalid Currency Code'
	  ,Err.[Processing_ID] 
	  ,Err.[filename]  
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP    
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS41_DAII_PROCESSING_PARTS_K  
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO' 
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx
      ,change_improvement_id
      ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          [local_currency],
		  change_improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS41_DAII_PROCESSING_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
			and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s41.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;

-----------------------------------------------------------------------------
--  START calculated field validations
-----------------------------------------------------------------------------
--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Machine /operation overhead costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.machine_op_overhead_costs
	  ,'Processing - Machine/operation overhead costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS41_DAII_PROCESSING_PARTS_K]
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx
      ,change_improvement_id
      ,'Calculated:' + CAST(Err.Calculated_value as Varchar(50))--ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS41_DAII_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  [change_improvement_id],
		  machine_op_overhead_costs,
		  case when no_of_pieces_per_cycle=0 then 0 else ((cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle)  end  as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
		  and case when no_of_pieces_per_cycle=0 then 0 
			       else ABS(((cycle_time_sec*(machinehourly_operation_overhead/3600))/no_of_pieces_per_cycle)  - (machine_op_overhead_costs)) end > @threshold 
       ) Err
    ;
--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Direct labor cost per piece [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.direct_hourly_labor_cost
	  ,'Processing - Direct labor cost per piece, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS41_DAII_PROCESSING_PARTS_K]
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx
      ,change_improvement_id
      ,'Calculated:' + CAST(Err.Calculated_value as Varchar(50))--ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS41_DAII_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  [change_improvement_id],
		  direct_hourly_labor_cost,
		  case when no_of_pieces_per_cycle=0 then 0 else ((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle) end as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
			and case when no_of_pieces_per_cycle=0 then 0 
			else ABS(((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle) - ([direct_hourly_labor_cost])) end > @threshold
       ) Err
    ;
--++++++++++++++++++++++++++++++++++++
-- Calculated Field Valdation Check for Total labor costs [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.total_labor_costs
	  ,'Processing - Total labor costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS41_DAII_PROCESSING_PARTS_K]
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'  
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,ERR.row_idx
      ,change_improvement_id
      ,'Calculated:' + CAST(Err.Calculated_value as Varchar(50))--ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          manufacturing_location,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS41_DAII_PROCESSING_PARTS_K],
		  sub_assembly_name,
		  [change_improvement_id],
		  total_labor_costs,
		  case when no_of_pieces_per_cycle=0 then 0 else ((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)*(1+indirect_labor_costs)*(1+fringes) end as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS41_DAII_PROCESSING_PARTS_INFO] s41
        WHERE Processing_ID= @GUID
			and case when no_of_pieces_per_cycle=0 then 0 
			else ABS((((cycle_time_sec*(direct_hourly_labor_headcount/3600))*direct_headcount/no_of_pieces_per_cycle)*(1+indirect_labor_costs)*(1+fringes)) - (total_labor_costs)) end > @threshold 
		  ) Err
    ;
-----------------------------------------------------------------------------
--  END calculated field validations
-----------------------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Processing: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS41_DAII_PROCESSING_PARTS_K
	  ,'PARWS41_DAII_PROCESSING_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.change_improvement_id 
	  ,'' 
  FROM 
      (
        SELECT 
               S41.Processing_ID
              ,s41.exchange_rate
  		      ,s41.Source_c
  		      ,s41.filename
              ,s41.ARWS41_DAII_PROCESSING_PARTS_K
  		      ,s41.sub_assembly_name
  		      ,s41.change_improvement_id
			  ,s41.row_idx
			  ,S55.usd_per_local_currency
			  ,S55.supplier_picked_crcy_c
          FROM PARWS41_DAII_PROCESSING_PARTS_INFO S41 
		  Join PARWS55_DAII_EXCHANGE_RATE_TAB     S55
		    On S55.Processing_ID  = S41.Processing_ID
		   And S55.filename       = S41.filename
		   And S55.currency_code  = S41.local_currency
         WHERE S41.Processing_ID  = @GUID
		   and S41.exchange_rate != S55.usd_per_local_currency
      ) Err
;
--++++++++++++++++++++++++++++++++++++
-- DA type DELETE validation
--+++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
       S41.Source_c
      ,S41.change_improvement_id 
      ,'This Part Index is being deleted. Remove it from Processing. Please quote only the Assembly and Final Assembly adjustment for the DELETE.' AS ARWE02_ERROR_X 
      ,S41.Processing_ID
      ,S41.filename
      ,OBJECT_NAME(@@PROCID) 
      ,@TIME_STAMP 
      ,@CDSID   
      ,@TIME_STAMP   
      ,@CDSID  
      ,S41.ARWS41_DAII_PROCESSING_PARTS_K 
      ,'PARWS41_DAII_PROCESSING_PARTS_INFO'     
      ,'ERROR'
      ,S41.sub_assembly_name 
      ,S41.row_idx
      ,S41.change_improvement_id
      ,''  --No ARROW Value
  FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
  Join PARWS41_DAII_PROCESSING_PARTS_INFO   S41  ON S41.Processing_ID         = S35.Processing_ID
                                                AND S41.filename              = S35.filename
	 								                     AND S41.change_improvement_id = S35.change_id
 WHERE S35.Processing_ID  = @GUID          
   AND S35.type_of_change = 'DELETE'
   AND S41.cost_type      = 'Adjustment Costs'              
;
END TRY
BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
	         ,@CDSID  
             ,@TIME_STAMP
	         ,@CDSID  
			 ,''
			 ,'PARWS41_DAII_PROCESSING_PARTS_INFO' ,
			 --ARWE02_BATCH_ERRORS_K Identity key
			 'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value		
END CATCH;

GO
