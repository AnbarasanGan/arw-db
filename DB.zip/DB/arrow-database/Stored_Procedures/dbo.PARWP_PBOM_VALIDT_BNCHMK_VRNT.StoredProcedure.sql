DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_BNCHMK_VRNT]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASOLOSKY
-- Create date: 07/21/2020
-- Description:	Stored Procedure to validate Benchmark Variant for PBOM Imports. 
-- User Story: US1573358 PBOM Template V5.71 with Benchmark Variant and 8 designs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        User Story Description
-- ------     -----       ---------- ----------
-- rwesley2   09-11-2020  US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10-20-2020  US1996362 switch from E02 to E03 and include Excel column
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDT_BNCHMK_VRNT] 
	 @GUID       varchar(500)
	,@CDSID      varchar(30)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	SET NOCOUNT ON;

/* --In the TI it was determined we shouldn't have to do this validation. Leaving the code here in case it needs to be implemented in the future
--******************************************************
--Multiple Benchmark Variants in the staging table
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      Benchmark_Var_N                            as [ARWE03_ERROR_VALUE], 
	      'ARROW is detecting more than one benchmark variant which should not happen. This is likely an IT issue.  Please contact ARROW support: ' + @GUID  as ARWE03_ERROR_VALUE,
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  'BoB Teardown Template'                      as [ARWE03_EXCEL_TAB_X],
		  8                                            as ARWE03_ROW_IDX 
		  ,''                                          as [ARWE03_Part_Index]  
		  ,''                                          as [ARWE03_ARROW_Value]
		  ,''                                          as ARWE03_COLUMN
      FROM (select *
	              ,Count(*) over (partition by file_name) as cnt
	          From (
    	            select S59.Benchmark_Var_N
		                  ,S59.User_Selected_BNCMK_VRNT_N
    		         	  ,S59.file_name
			         	  ,ARWS59_PBOM_PARTS
			         	  ,row_idx
			         	  ,row_number() over (partition by S59.file_name, Benchmark_Var_N Order by S59.row_idx) as rownum
                     FROM PARWS59_PBOM_PARTS  S59
                    Where S59.Processing_ID              = @GUID
				   ) Unq
              Where rownum = 1
    	  ) S59
      Where cnt > 1
;
*/

--******************************************************
--The Benchmark Variant in the file does not match the selected Benchmark Variant
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      Benchmark_Var_N                              as [ARWE03_ERROR_VALUE], -- file value
	      'The Benchmark Variant in the file does not match the User selected Benchmark Variant' as ARWE03_ERROR_VALUE,
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'WARNING'                                    as [ARWE03_ERROR_TYPE_X],
		  ''                                           as [ARWE03_EXCEL_TAB_X],
		  8                                            as ARWE03_ROW_IDX, 
		  ''                                           as ARWE03_Part_Index,
		  S59.User_Selected_BNCMK_VRNT_N               as ARWE03_ARROW_Value,
		  'B'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.Benchmark_Var_N
		          ,S59.User_Selected_BNCMK_VRNT_N
    			  ,S59.file_name
				  ,s59.part_index
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,row_number() over (partition by S59.file_name Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID              = @GUID
            	) S59
      Where rownum = 1
	    and User_Selected_BNCMK_VRNT_N != Benchmark_Var_N
;


END TRY
BEGIN CATCH

INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
	         ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --No ARROW Value
			 ,''  --column
END CATCH


GO
