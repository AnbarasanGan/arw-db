DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_MFG_MARKUP]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIK12
-- Create date: 07/12/2019
-- Description:	Manufacturing Markup data Validation
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   07/22/2019  Changed 2nd validation message to use a case statement
-- Asolosky   08/06/2019  Changed all Markup errors to warnings since the data is not being used.  The CCS markup will be used in
--                        consolidation so this data isn't critical.  Also removed directed parts from case statements. 
--                        Directed parts aren't a Sub-Assembly in DAII.
-- Asolosky   08/08/2019  Changed back to ERROR from WARNING.  Removed this filter: manufacturing_markup_desc <> 'SG&A - Total' on Markup Type validation (1st validation)
--                        Replaced the manufacturing markup validation with a new query (2nd validation).  Had to bring all the data into 1 row
--                        in order to do the validation logic. Markup is only needed when raw, processing, assembly data is available (one of the 3)
--                        Only 1 validation message will be shown at a time because the data had to be brought into 1 record.
-- asamriya  09/10/2019   Added row_idx
-- Ashaik12   12/25/2019  Remove Case when statements in Error Descriptions.
-- Ashaik12   01/14/2020  Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky   05/11/2020  US1600585 DAII MFG markup doesn't match CCS/GCS, display an error
--                        Change error 'Final Assembly Markups do not match CCS' from warning to error.
--                        Change all filters from 'Final Assembly' to 'Adjustment Final Assembly' 
-- asolosky   08/19/2020  Changed Manufacturing Markup cast from 9,4 to 12,9. Also removed Format; Was cast(FORMAT(STG.Staging_SCRP_MRKP_P,'P') as varchar(50)) to cast(STG.Staging_SCRP_MRKP_P as varchar(50)) 
--                        Added IsNull to all Final Assembly and Assembly Manufacturing Markup Case statements; like -> STG.Staging_PROFIT_MRKP_P != IsNull(V20.PROFIT_MRKP_P,0).  Added because there isn't always a CCS/GCS markup
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky   03/24/2021  US2402891 changed validation for DAW markups not matching CCS. Changed join to U17 so its now a left join.
--                        Changed the Case so IsNull is using -999999 instead of zero.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_MFG_MARKUP] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Description validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                              as ARWE02_SOURCE_C
	  ,ERR.manufacturing_markup_desc             as ARWE02_ERROR_VALUE
	  ,'Manufacturing Markups: Manufacturing Markup Type is Invalid.' AS ARWE02_ERROR_X
	  ,ERR.Processing_ID                         as ARWE02_PROCESSING_ID
	  ,ERR.filename                              as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                     as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                               as ARWE02_CREATE_S
	  ,@CDSID                                    as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                               as ARWE02_LAST_UPDT_S
	  ,@CDSID                                    as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS43_DAII_MFG_MARKUP_K              as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS43_DAII_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,0                                         as ARWE02_ROW_IDX
	  ,''  --No part index
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
               [manufacturing_markup_desc],
		       Processing_Status_x,
			   sub_assembly_name,
		       Source_c,
		       filename,
               ARWS43_DAII_MFG_MARKUP_K,
			   row_idx
         FROM [dbo].[PARWS43_DAII_MANUFACTURING_MARKUPS_INFO] S43
        WHERE Processing_ID= @GUID
	      and Not Exists
		      (Select 'X'
               from  [dbo].[PARWA38_MFG_MRKP_TYP] A38
               where A38.[ARWA38_MFG_MRKP_TYP_X] = S43.manufacturing_markup_desc 
			  )              
        ) ERR
;
--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Value data check for Scrap, SG&A and Profit
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
Select 
       Source_c                 as ARWE02_SOURCE_C
      ,Error_Value_R            as ARWE02_ERROR_VALUE
      ,Error_Message_x          as ARWE02_ERROR_X     
  	  ,Processing_ID            as ARWE02_PROCESSING_ID
	  ,filename                 as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)    as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP              as ARWE02_CREATE_S
	  ,@CDSID                   as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP              as ARWE02_LAST_UPDT_S
	  ,@CDSID                   as ARWE02_LAST_UPDT_USER_C
	  ,ARWS43_DAII_MFG_MARKUP_K as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS43_DAII_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  --ARWE02_BATCH_ERRORS_K Identity number
	  ,Error_Type_x             as ARWE02_ERROR_TYPE_X
	  ,sub_assembly_name        as ARWE02_EXCEL_TAB_X
	  ,row_idx				    as ARWE02_ROW_IDX
	  ,''  --No part index
	  ,''  --No ARROW Value	 
From
(
Select Sum_to_Combine_data.* 
      ,Case When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Profit_manufacturing_markup_value = 0
	        Then 'Manufacturing Markup: Supplier Quote for Profit is zero' 
			When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Scrap_manufacturing_markup_value = 0
			Then 'Manufacturing Markup: Supplier Quote for Scrap is zero' 
			When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and SGA_total_manufacturing_markup_value = 0
			Then 'Manufacturing Markup: Supplier Quote for SG&A-Total is zero' 
	   End as Error_Message_x
      ,Case When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Profit_manufacturing_markup_value = 0
	        Then 'WARNING' --Profit is a warning for Design Ajustment.  CCS must have Profit.
			When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Scrap_manufacturing_markup_value = 0 
			Then 'WARNING' 
			When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and SGA_total_manufacturing_markup_value = 0
			Then 'WARNING' 
	   End as Error_Type_x
      ,Case When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Profit_manufacturing_markup_value = 0
	        Then Profit_manufacturing_markup_value
			When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Scrap_manufacturing_markup_value = 0
			Then Scrap_manufacturing_markup_value 
			When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and SGA_total_manufacturing_markup_value = 0
			Then SGA_total_manufacturing_markup_value
	   End as Error_Value_R
      ,Case When (Raw_F >= 1 or Process_F >= 1 or Assembly_F >= 1) and Profit_manufacturing_markup_value = 0
	        Then Profit_ARWS43_DAII_MFG_MARKUP_K 
			When (Raw_F >= 1 or Process_F = 1 or Assembly_F = 1) and Scrap_manufacturing_markup_value = 0
			Then Scrap_ARWS43_DAII_MFG_MARKUP_K
			When (Raw_F = 1 or Process_F >= 1 or Assembly_F >= 1) and SGA_total_manufacturing_markup_value = 0
			Then Total_ARWS43_DAII_MFG_MARKUP_K
	   End as ARWS43_DAII_MFG_MARKUP_K
  From
(
--Bring all the data together.  The SUM is bringing the records together on the same line. The SUM is not used to sum the data.
Select 
	  Processing_ID  
	  ,filename
	  ,sub_assembly_name
	  ,Source_c
	  ,row_idx
	  ,Sum(Purch_F)                              OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Purch_F
	  ,Sum(Raw_F)                                OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Raw_F
	  ,Sum(Process_F)                            OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Process_F
	  ,Sum(Assembly_F)                           OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Assembly_F
	  ,Sum(Scrap_manufacturing_markup_value)     OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Scrap_manufacturing_markup_value
      ,Sum(SGA_total_manufacturing_markup_value) OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as SGA_total_manufacturing_markup_value
      ,Sum(profit_manufacturing_markup_value)    OVER (PARTITION BY Processing_ID, filename,sub_assembly_name) as Profit_manufacturing_markup_value	
      ,SUM(Scrap_ARWS43_DAII_MFG_MARKUP_K)       OVER (PARTITION BY Processing_ID, sub_assembly_name,filename) as Scrap_ARWS43_DAII_MFG_MARKUP_K
	  ,SUM(Total_ARWS43_DAII_MFG_MARKUP_K)       OVER (PARTITION BY Processing_ID, sub_assembly_name,filename) as Total_ARWS43_DAII_MFG_MARKUP_K
	  ,SUM(Profit_ARWS43_DAII_MFG_MARKUP_K)      OVER (PARTITION BY Processing_ID, sub_assembly_name,filename) as Profit_ARWS43_DAII_MFG_MARKUP_K
      ,ROW_NUMBER()                              OVER (PARTITION BY Processing_ID, filename,sub_assembly_name
	                                                       ORDER BY filename) as row_num
  From
(--Purchased Parts
      SELECT distinct 
	         Case When S39.Processing_ID is NULL then 0 else 1 end as Purch_F
			,0 as Raw_F
			,0 as Process_F
			,0 as Assembly_F
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as profit_manufacturing_markup_value	
	        ,0 as Scrap_ARWS43_DAII_MFG_MARKUP_K	
	        ,0 as Total_ARWS43_DAII_MFG_MARKUP_K
	        ,0 as Profit_ARWS43_DAII_MFG_MARKUP_K	
			,S39.sub_assembly_name  
			,S39.Processing_ID  
			,S39.filename
			,S39.Source_c
			,S39.row_idx
        FROM PARWS39_DAII_PURCHASED_PARTS_INFO S39 
        WHERE S39.Processing_ID       = @GUID
		  and S39.sub_assembly_name  != 'Adjustment Final Assembly'
--Raw
Union
      SELECT distinct 
	         0 as Purch_F
			,Case When S40.Processing_ID is NULL then 0 else 1 end as Raw_F
			,0 as Process_F
			,0 as Assembly_F 
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as profit_manufacturing_markup_value
	        ,0 as Scrap_ARWS43_DAII_MFG_MARKUP_K	
	        ,0 as Total_ARWS43_DAII_MFG_MARKUP_K
	        ,0 as Profit_ARWS43_DAII_MFG_MARKUP_K					
			,S40.sub_assembly_name
			,S40.Processing_ID  
			,S40.filename
			,S40.Source_c
			,S40.row_idx
        FROM PARWS40_DAII_RAW_MATERIALS_INFO S40
        WHERE S40.Processing_ID       = @GUID
		  and S40.sub_assembly_name  != 'Adjustment Final Assembly'
--Processing
Union
      SELECT distinct 
	         0 as Purch_F
			,0 as Raw_F
	        ,Case When S41.Processing_ID is Null then 0 else 1 end as Process_F
			,0 as Assembly_F
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as profit_manufacturing_markup_value	
	        ,0 as Scrap_ARWS43_DAII_MFG_MARKUP_K	
	        ,0 as Total_ARWS43_DAII_MFG_MARKUP_K
	        ,0 as Profit_ARWS43_DAII_MFG_MARKUP_K	
			,S41.sub_assembly_name
			,S41.Processing_ID  
			,S41.filename
			,S41.Source_c
			,S41.row_idx
        FROM PARWS41_DAII_PROCESSING_PARTS_INFO S41 
        WHERE S41.Processing_ID       = @GUID
		  and S41.sub_assembly_name  != 'Adjustment Final Assembly'
--Assembly
Union
      SELECT distinct
	         0 as Purch_F
			,0 as Raw_F	   
			,0 as Process_F
	        ,Case When S42.Processing_ID is Null then 0 else 1 end as Assembly_F  
	        ,0 as Scrap_manufacturing_markup_value
            ,0 as SGA_total_manufacturing_markup_value
            ,0 as Profit_manufacturing_markup_value		
	        ,0 as Scrap_ARWS43_DAII_MFG_MARKUP_K	
	        ,0 as Total_ARWS43_DAII_MFG_MARKUP_K
	        ,0 as Profit_ARWS43_DAII_MFG_MARKUP_K				 
			,S42.sub_assembly_name 
			,S42.Processing_ID  
			,S42.filename
			,S42.Source_c
			,S42.row_idx
        FROM [dbo].[PARWS42_DAII_ASSEMBLY_PARTS_INFO] S42 
        WHERE S42.Processing_ID       = @GUID
		  and S42.sub_assembly_name  != 'Adjustment Final Assembly'
Union 

-- Markups
Select Purch_F
      ,Raw_F	   
      ,Process_F
      ,Assembly_F  
      ,Scrap_manufacturing_markup_value
      ,SGA_total_manufacturing_markup_value
      ,Profit_manufacturing_markup_value	
	  ,Scrap_ARWS43_DAII_MFG_MARKUP_K	
	  ,Total_ARWS43_DAII_MFG_MARKUP_K
	  ,Profit_ARWS43_DAII_MFG_MARKUP_K
      ,sub_assembly_name 
      ,Processing_ID  
      ,filename
	  ,Source_c
	  ,row_idx
  From
(
 Select 0 as Purch_F
       ,0 as Raw_F	   
	   ,0 as Process_F
	   ,0 as Assembly_F  
	   ,Sum(Scrap)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Scrap_manufacturing_markup_value
       ,Sum(Total)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as SGA_total_manufacturing_markup_value
       ,Sum(Profit)  OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as profit_manufacturing_markup_value

       ,SUM(Scrap_ARWS43_DAII_MFG_MARKUP_K)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Scrap_ARWS43_DAII_MFG_MARKUP_K
	   ,SUM(Total_ARWS43_DAII_MFG_MARKUP_K)   OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Total_ARWS43_DAII_MFG_MARKUP_K
	   ,SUM(Profit_ARWS43_DAII_MFG_MARKUP_K)  OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name) as Profit_ARWS43_DAII_MFG_MARKUP_K

       ,ROW_NUMBER() OVER (PARTITION BY Processing_ID, sub_assembly_name,filename, supplier_name
	                           ORDER BY supplier_name) as row_num
	   ,sub_assembly_name
	   ,Processing_ID 
	   ,filename
	   ,Source_c
	   ,row_idx
   from
 (
       SELECT 
             Processing_ID,
		     sub_assembly_name,
		     supplier_name,
		     manufacturing_markup_desc,
             manufacturing_markup_value,
		     case When [manufacturing_markup_desc] = 'SG&A - Total' then isNull([manufacturing_markup_value],0) else 0 end as Total,
		     case When [manufacturing_markup_desc] = 'Scrap'        then isNull([manufacturing_markup_value],0) else 0 end as Scrap,
		     case When [manufacturing_markup_desc] = 'Profit'       then isNull([manufacturing_markup_value],0) else 0 end as Profit,
		     Processing_Status_x,
		     Source_c,
		     filename,
		     case When [manufacturing_markup_desc] = 'SG&A - Total' then ARWS43_DAII_MFG_MARKUP_K end as Total_ARWS43_DAII_MFG_MARKUP_K,
		     case When [manufacturing_markup_desc] = 'Scrap'        then ARWS43_DAII_MFG_MARKUP_K end as Scrap_ARWS43_DAII_MFG_MARKUP_K,
		     case When [manufacturing_markup_desc] = 'Profit'       then ARWS43_DAII_MFG_MARKUP_K end as Profit_ARWS43_DAII_MFG_MARKUP_K,
             ARWS43_DAII_MFG_MARKUP_K,
			 row_idx 
        FROM PARWS43_DAII_MANUFACTURING_MARKUPS_INFO S43
       WHERE S43.Processing_ID              = @GUID and
			 S43.sub_assembly_name         != 'Adjustment Final Assembly' and
		     S43.manufacturing_markup_desc in ('SG&A - Total','Scrap','Profit')
 ) mrkup
) Final_mrkup
where row_num = 1

) All_Unions
 Where sub_assembly_name is not NULL
) Sum_to_Combine_data
Where row_num = 1
) Case_Determine_ERROR
Where Error_Type_x in ('ERROR','WARNING')
;

--++++++++++++++++++++++++++++++++++++
    -- Final Assembly Manufacturing Markup Value: data check on Scrap, SG&A and Profit should match CCS
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                              as ARWE02_SOURCE_C
	  ,ERR.Excel_Value                           as ARWE02_ERROR_VALUE
	  ,ERR.Markup_Error                          as ARWE02_ERROR_X
	  ,ERR.Processing_ID                         as ARWE02_PROCESSING_ID
	  ,ERR.filename                              as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                     as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                               as ARWE02_CREATE_S
	  ,@CDSID                                    as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                               as ARWE02_LAST_UPDT_S
	  ,@CDSID                                    as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS43_DAII_MFG_MARKUP_K              as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS43_DAII_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  --ARWE02_BATCH_ERRORS_K  identity key
	  ,'ERROR'                                   as ARWE02_ERROR_TYPE_X
	  ,ERR.sub_assembly_name                     as ARWE02_EXCEL_TAB_X
	  ,0                                         as ARWE02_ROW_IDX     --hard coded as 0 since there's multiple row_idx.
	  ,''               --No part index
	  ,ERR.Markup_Value --ARROW Value
       FROM 
       ( --ERR Data
 Select STG.*
       ,V21.SCRP_MRKP_P
	   ,V21.SGA_Total_MRKP_P
	   ,V21.PROFIT_MRKP_P
	   ,Case When STG.Staging_SCRP_MRKP_P      != IsNull(V21.SCRP_MRKP_P,-9999999) or 
	              STG.Staging_SGA_Total_MRKP_P != IsNull(V21.SGA_Total_MRKP_P,-9999999) or 
				  STG.Staging_PROFIT_MRKP_P    != IsNull(V21.PROFIT_MRKP_P,-9999999)
			--CCS data
	         Then Case When V21.SCRP_MRKP_P is Null or V21.SGA_Total_MRKP_P is Null or V21.PROFIT_MRKP_P is Null
			           Then cost_type + ' Final Assembly Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter final assembly markups that must match DAW markups (even if no costs are present) and re-import. Next re-import your DAW file'
					   When V21.SCRP_MRKP_P = 0 and V21.SGA_Total_MRKP_P = 0 and V21.PROFIT_MRKP_P = 0 --Same message as above.  Broke this out separate so the logic is easier to understand.
					   Then cost_type + ' Final Assembly Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter final assembly markups that must match DAW markups (even if no costs are present) and re-import. Next re-import your DAW file'
					   Else cost_type + ' Final Assembly Markups do not match GCS/CCS. Please open the DAW file, update the final assembly markups so they match the GCS/CCS file and re-import. If the DAW markups are correct, then the GCS/CCS file needs to be updated. Open the GCS/CCS files, update the markups and re-import. Next re-import your DAW file'
					   End
			 Else NULL
		End Markup_Error

		--Only using one of the ARWS43_DAII_MFG_MARKUP_K columns to use in the error record
	   ,Case When STG.Staging_PROFIT_MRKP_P    != V21.PROFIT_MRKP_P    Then PROFIT_ARWS43_DAII_MFG_MARKUP_K
	         When STG.Staging_SCRP_MRKP_P      != V21.SCRP_MRKP_P      Then SCRP_ARWS43_DAII_MFG_MARKUP_K
	         When STG.Staging_SGA_Total_MRKP_P != V21.SGA_Total_MRKP_P Then SGA_Total_ARWS43_DAII_MFG_MARKUP_K
			 ELSE Null
        End ARWS43_DAII_MFG_MARKUP_K

		--Markup_Value
		,    'GCS/CCS Scrap: '  + case When V21.SCRP_MRKP_P      is Null Then '<blank>' Else  cast(V21.SCRP_MRKP_P      as varchar(50)) End
		 + ', GCS/CCS Total: '  + case When V21.SGA_Total_MRKP_P is Null Then '<blank>' Else  cast(V21.SGA_Total_MRKP_P as varchar(50)) End
		 + ', GCS/CCS Profit: ' + case When V21.PROFIT_MRKP_P    is Null Then '<blank>' Else  cast(V21.PROFIT_MRKP_P    as varchar(50)) End 
		 as Markup_Value

		 --DA Staging data
		,    ' DA Scrap: '  + cast(STG.Staging_SCRP_MRKP_P      as varchar(50))  
		 +  ', DA Total: '  + cast(STG.Staging_SGA_Total_MRKP_P as varchar(50))  
		 + ', DA Profit: '  + cast(STG.Staging_PROFIT_MRKP_P    as varchar(50))
		 as Excel_Value

   From
       ( --Put the scrap,total and profit on the same record to make the validation easier
        Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        	  ,V04.ARWU06_CCTSS_DSGN_K AS ARWU06_CCTSS_DSGN_K
        	  ,V04.ARWU01_CCTSS_K
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_SCRP_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_SGA_Total_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_PROFIT_MRKP_P
        	  ,Sum(Case When manufacturing_markup_desc      = 'Scrap'        Then ARWS43_DAII_MFG_MARKUP_K   Else 0 End) AS SCRP_ARWS43_DAII_MFG_MARKUP_K
        	  ,Sum(Case When manufacturing_markup_desc      = 'SG&A - Total' Then ARWS43_DAII_MFG_MARKUP_K   Else 0 End) AS SGA_Total_ARWS43_DAII_MFG_MARKUP_K
        	  ,Sum(Case When manufacturing_markup_desc      = 'Profit'       Then ARWS43_DAII_MFG_MARKUP_K   Else 0 End) AS PROFIT_ARWS43_DAII_MFG_MARKUP_K
			  ,S34.Processing_ID  
			  ,S34.filename
			  ,S34.Source_c 
			  ,S43.sub_assembly_name 
			  ,S43.cost_type
--			  ,S43.row_idx
		 FROM PARWS34_DAII_COVER_PAGE_INFO             S34
		 Join PARWS43_DAII_MANUFACTURING_MARKUPS_INFO  S43
           ON S34.Processing_ID       = S43.Processing_ID
          AND S34.filename            = S43.filename

 -- Join with Program, Design, Supplier data and Sub-assembly
        JOIN PARWV04_DSGN_SUPL   V04
          ON S34.User_Selected_CTSP_N            = V04.ARWU31_CTSP_N
         AND S34.User_Selected_CTSP_Region_C     = V04.CTSP_REGION_CODE
         AND S34.User_Selected_ENRG_SUB_CMMDTY_X = V04.ENG_SUB_CMMDTY_DESC
         AND S34.User_Selected_BNCMK_VRNT_N      = V04.VARIANT      --BoB variant 
         AND S34.User_Selected_VEH_MAKE_N        = V04.ARWA14_VEH_MAKE_N
         AND S34.User_Selected_VEH_MDL_N         = V04.ARWA34_VEH_MDL_N
         AND S34.User_Selected_VEH_MDL_YR_C      = V04.ARWA35_DSGN_VEH_MDL_YR_C    
         AND S34.User_Selected_VEH_MDL_VRNT_X    = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
         AND S34.User_Selected_BNCMK_VRNT_N      = V04.VARIANT      --BoB variant
         AND S34.User_Selected_SUPL_N            = V04.ARWA17_SUPL_N
         AND S34.User_Selected_SUPL_CNTRY_N      = V04.ARWA28_CNTRY_N
         AND S34.User_Selected_SUPL_C            = V04.ARWA17_SUPL_C
       WHERE S34.Processing_ID              = @GUID
		 and S43.sub_assembly_name          = 'Adjustment Final Assembly'
		 and S43.manufacturing_markup_desc in ('Scrap','SG&A - Total','Profit' )
       Group by 
             V04.ARWU08_CCTSS_DSGN_SUPL_K
            ,V04.ARWU06_CCTSS_DSGN_K
            ,V04.ARWU01_CCTSS_K
		    ,S34.Processing_ID  
		    ,S34.filename
			,S34.Source_c 
	        ,S43.sub_assembly_name 
			,S43.cost_type
--			,S43.row_idx
      ) STG
    Left Join PARWV21_FINAL_ASSEMBLY_MFG_MRKP  V21
           ON V21.ARWU08_CCTSS_DSGN_SUPL_K = STG.ARWU08_CCTSS_DSGN_SUPL_K
    ) ERR
  Where Markup_Error is NOT NULL
;

--++++++++++++++++++++++++++++++++++++
    -- Manufacturing Markup Value: data check on Scrap, SG&A and Profit should match CCS
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                              as ARWE02_SOURCE_C
	  ,ERR.Excel_Value                           as ARWE02_ERROR_VALUE
	  ,ERR.Markup_Error                          as ARWE02_ERROR_X
	  ,ERR.Processing_ID                         as ARWE02_PROCESSING_ID
	  ,ERR.filename                              as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                     as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                               as ARWE02_CREATE_S
	  ,@CDSID                                    as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                               as ARWE02_LAST_UPDT_S
	  ,@CDSID                                    as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS43_DAII_MFG_MARKUP_K              as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS43_DAII_MANUFACTURING_MARKUPS_INFO' as ARWE02_STAGING_TABLE_X
	  --ARWE02_BATCH_ERRORS_K  identity key
	  ,'ERROR'                                   as ARWE02_ERROR_TYPE_X
	  ,ERR.sub_assembly_name                     as ARWE02_EXCEL_TAB_X
	  ,0                                         as ARWE02_ROW_IDX  --hard coded as 0 since there's multiple row_idx.
	  ,''                --No part index
	  ,ERR.Markup_Value  --ARROW Value
       FROM 
       ( --ERR Data
 Select STG.*
       ,V20.SCRP_MRKP_P
	   ,V20.SGA_Total_MRKP_P
	   ,V20.PROFIT_MRKP_P
	   ,Case When STG.Staging_SCRP_MRKP_P != IsNull(V20.SCRP_MRKP_P,-9999999) or STG.Staging_SGA_Total_MRKP_P != IsNull(V20.SGA_Total_MRKP_P,-9999999) or STG.Staging_PROFIT_MRKP_P != IsNull(V20.PROFIT_MRKP_P,-9999999)
			--CCS data
	         Then Case When V20.SCRP_MRKP_P is Null or V20.SGA_Total_MRKP_P is Null or V20.PROFIT_MRKP_P is Null
			           Then cost_type + ' Manufacturing Markups are missing in GCS/CCS or the sub assemblies don''t match. Please open the GCS/CCS file, enter Manufacturing markups that must match DAW markups (even if no costs are present) and re-import. Next re-import your DAW file'
					   When V20.SCRP_MRKP_P = 0 and V20.SGA_Total_MRKP_P = 0 and V20.PROFIT_MRKP_P = 0 --Same message as above.  Broke this out separate so the logic is easier to understand.
					   Then cost_type + ' Manufacturing Markups are missing in GCS/CCS. Please open the GCS/CCS file, enter Manufacturing markups that must match DAW markups (even if no costs are present) and re-import. Next re-import your DAW file'
					   Else cost_type + ' Manufacturing Markups do not match GCS/CCS. Please open the DAW file, update the Manufacturing markups so they match the GCS/CCS file and re-import. If the DAW markups are correct, then the GCS/CCS file needs to be updated. Open the GCS/CCS files, update the markups and re-import. Next re-import your DAW file'
					   End
			 Else NULL
		End Markup_Error

		--Only using one of the ARWS43_DAII_MFG_MARKUP_K columns to use in the error record
	   ,Case When STG.Staging_PROFIT_MRKP_P    != V20.PROFIT_MRKP_P    Then PROFIT_ARWS43_DAII_MFG_MARKUP_K
	         When STG.Staging_SCRP_MRKP_P      != V20.SCRP_MRKP_P      Then SCRP_ARWS43_DAII_MFG_MARKUP_K
	         When STG.Staging_SGA_Total_MRKP_P != V20.SGA_Total_MRKP_P Then SGA_Total_ARWS43_DAII_MFG_MARKUP_K
			 ELSE Null
        End ARWS43_DAII_MFG_MARKUP_K

		--Markup_Value
		,     'GCS/CCS Scrap: ' + case When V20.SCRP_MRKP_P      is Null Then '<blank>' Else  cast(V20.SCRP_MRKP_P      as varchar(50)) End
		 +  ', GCS/CCS Total: ' + case When V20.SGA_Total_MRKP_P is Null Then '<blank>' Else  cast(V20.SGA_Total_MRKP_P as varchar(50)) End
		 + ', GCS/CCS Profit: ' + case When V20.PROFIT_MRKP_P    is Null Then '<blank>' Else  cast(V20.PROFIT_MRKP_P    as varchar(50)) End 
         as Markup_Value

		--DA Staging data
		,+   ' DA Scrap: '  + cast(STG.Staging_SCRP_MRKP_P      as varchar(50))  
		 +  ', DA Total: '  + cast(STG.Staging_SGA_Total_MRKP_P as varchar(50))  
		 + ', DA Profit: '  + cast(STG.Staging_PROFIT_MRKP_P    as varchar(50)) 
        as Excel_Value

   From
       ( --Put the scrap,total and profit on the same record to make the validation easier

        Select U08.ARWU08_CCTSS_DSGN_SUPL_K
        	  ,U08.ARWU06_CCTSS_DSGN_K AS ARWU06_CCTSS_DSGN_K
        	  ,U08.ARWU01_CCTSS_K			  
			  ,U17.ARWU17_BOM_SUB_ASSY_K
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_SCRP_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_SGA_Total_MRKP_P
        	  ,Cast(Sum(Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value Else 0 End) as Decimal(12,9)) AS Staging_PROFIT_MRKP_P
        	  ,Sum(Case When manufacturing_markup_desc      = 'Scrap'        Then ARWS43_DAII_MFG_MARKUP_K   Else 0 End) AS SCRP_ARWS43_DAII_MFG_MARKUP_K
        	  ,Sum(Case When manufacturing_markup_desc      = 'SG&A - Total' Then ARWS43_DAII_MFG_MARKUP_K   Else 0 End) AS SGA_Total_ARWS43_DAII_MFG_MARKUP_K
        	  ,Sum(Case When manufacturing_markup_desc      = 'Profit'       Then ARWS43_DAII_MFG_MARKUP_K   Else 0 End) AS PROFIT_ARWS43_DAII_MFG_MARKUP_K
			  ,S34.Processing_ID  
			  ,S34.filename
			  ,S34.Source_c 
			  ,S43.sub_assembly_name 
			  ,S43.cost_type
--			  ,S43.row_idx
		 FROM PARWS34_DAII_COVER_PAGE_INFO             S34
		 Join PARWS43_DAII_MANUFACTURING_MARKUPS_INFO  S43
           ON S34.Processing_ID       = S43.Processing_ID
          AND S34.filename            = S43.filename

 -- Join with Program, Design, Supplier data and Sub-assembly
        JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT   U08
          ON S34.User_Selected_CTSP_N            = U08.ARWU31_CTSP_N
         AND S34.User_Selected_CTSP_Region_C     = U08.ARWA06_RGN_C
         AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U08.ARWA03_ENRG_SUB_CMMDTY_X
         AND S34.User_Selected_BNCMK_VRNT_N      = U08.ARWU01_BNCHMK_VRNT_N      --BoB variant
         AND S34.User_Selected_VEH_MAKE_N        = U08.ARWA14_VEH_MAKE_N
         AND S34.User_Selected_VEH_MDL_N         = U08.ARWA34_VEH_MDL_N
         AND S34.User_Selected_VEH_MDL_YR_C      = U08.ARWA35_DSGN_VEH_MDL_YR_C    
         AND S34.User_Selected_VEH_MDL_VRNT_X    = U08.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
         AND S34.User_Selected_SUPL_N            = U08.ARWA17_SUPL_N
         AND S34.User_Selected_SUPL_CNTRY_N      = U08.ARWA28_CNTRY_N
         AND S34.User_Selected_SUPL_C            = U08.ARWA17_SUPL_C
		Left Join PARWU17_BOM_SUB_ASSY U17 
		  On u17.ARWU01_CCTSS_K               = u08.ARWU01_CCTSS_K
		 And U17.ARWU17_BOM_SUB_ASSY_N        = STUFF(S43.sub_assembly_name,1,6,'')	--Remove the first 6 characters and replace with empty string
       WHERE S34.Processing_ID                = @GUID
		 and S43.sub_assembly_name          like 'Costs-%'
		 and S43.manufacturing_markup_desc in ('Scrap','SG&A - Total','Profit' )
       Group by 
             U08.ARWU08_CCTSS_DSGN_SUPL_K
            ,U08.ARWU06_CCTSS_DSGN_K
            ,U08.ARWU01_CCTSS_K
			,U17.ARWU17_BOM_SUB_ASSY_K
		    ,S34.Processing_ID  
		    ,S34.filename
			,S34.Source_c 
	        ,S43.sub_assembly_name 
			,S43.cost_type
--			,S43.row_idx
      ) STG
    Left Join PARWV20_MFG_MRKP  V20
           ON V20.ARWU08_CCTSS_DSGN_SUPL_K = STG.ARWU08_CCTSS_DSGN_SUPL_K
		  And V20.ARWU17_BOM_SUB_ASSY_K    = STG.ARWU17_BOM_SUB_ASSY_K
    ) ERR
  Where Markup_Error is NOT NULL
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS43_DAII_MANUFACTURING_MARKUPS_INFO'
		,'ERROR'
		,'SYSTEM'
		,0
		,''  --Part_index
		,''  --Arrow value	
;
END CATCH;	

GO
