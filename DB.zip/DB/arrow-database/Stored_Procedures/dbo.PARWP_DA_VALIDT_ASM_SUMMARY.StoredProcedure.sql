DROP PROCEDURE [dbo].[PARWP_DA_VALIDT_ASM_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 11/21/2019
-- Description:	Validate if sum of Purchased unit cost is equal to the cost in Summary table. 
--              This helps to identify if any part indexes errored out in validation from the Purchased Parts table
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Asolosky   12/18/2019  Converted from using the views for validation to the staging tables.  An error won't let the data load to ARROW
-- Ashaik12   03/10/2020  Fixed Filter column from cost_type to sub_assembly_name, fix tab name
-- rwesley2   05/04/2020  US1575405 removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s35.sheet_name. 
--                        Only applies to DA not II
-- rwesley2   06/03/2020  US1667506 added logic to handle single tab template versions
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12   14/12/2020  Use calculated unit cost instead of the staging value (the final value could be hardcoded)
-- Asolosky   01/19/2021  US2164194 Changed the threshold from a dynamic number which used the UpperBound and LowerBound function, to a static number.
--                        The static threshold number is passed in from the master procedure and is based on the PARWT01_THRESHOLD table.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DA_VALIDT_ASM_SUMMARY] 

@GUID varchar(5000),
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
BEGIN TRY
--++++++++++++++++++++++++++++++++++++
    -- Sub-Assembly Name validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
 X.ARWE02_SOURCE_C
,X.s35_cost     --'Assembly total in Supplier Quote Summary: '+ CAST(S35.assembly as varchar(50))
,X.ARWE02_ERROR_X
,X.ARWE02_PROCESSING_ID
,X.ARWE02_FILENAME
,X.ARWE02_PROCEDURE_X
,X.[ARWE02_CREATE_S]
,X.[ARWE02_CREATE_USER_C]
,X.ARWE02_LAST_UPDT_S
,X.[ARWE02_LAST_UPDT_USER_C]
,X.ARWE02_BATCH_ERRORS_REF_K
,X.ARWE02_STAGING_TABLE_X
,'ERROR'
,x.ARWE02_EXCEL_TAB_X + ' - Supplier Quote Summary'
,0                               as ARWE02_ROW_IDX
,''                 --Part index
,S42_unit_cost_usd --' does not match Assembly total in Arrow: ' + CAST(S42_unit_cost_usd as varchar(50))
FROM
(
select 
       S35.Source_c            AS [ARWE02_SOURCE_C]
      ,S42_unit_cost_usd 
      ,CASE WHEN S35.assembly = S42_unit_cost_usd 
	        THEN '' 
			ELSE 'Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not changed in column Q of the Adj sheet and/or column Z/AB of Assembly section in the Costs sheet'
			END  AS ARWE02_ERROR_X  
      ,S35.Processing_ID                      AS ARWE02_PROCESSING_ID
      ,S35.filename                           AS ARWE02_FILENAME 
      ,OBJECT_NAME(@@PROCID)                  AS [ARWE02_PROCEDURE_X]
      ,@TIME_STAMP                            AS [ARWE02_CREATE_S]
      ,@CDSID                                 AS [ARWE02_CREATE_USER_C]
      ,@TIME_STAMP                            AS [ARWE02_LAST_UPDT_S]
      ,@CDSID                                 AS [ARWE02_LAST_UPDT_USER_C]
      ,S35.ARWS34_DAII_COVER_PAGE_INFO_K      AS [ARWE02_BATCH_ERRORS_REF_K]
      ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'  AS [ARWE02_STAGING_TABLE_X]
      ,S42_unit_cost_usd                      AS S42_summed_cost
      ,S35.assembly                           AS s35_cost
	  ,s42.sub_assembly_name                  AS ARWE02_EXCEL_TAB_X
from 
(
  select SUM(assembly) as assembly , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name 
    from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
    JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                 AND S34.filename     = S35.filename
   where S34.Processing_ID               = @GUID
     and S34.Skip_loading_due_to_error_f = 0
   group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
) S35
Join
(
   select SUM(IsNUll(([assembly_secs_operation]*([machinehourly_operation_overhead]/3600)
				+(([assembly_secs_operation]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])*(1+[indirect_labor_costs])*(1+[fringes]))
				+[packaging_costs]+[logistics_cost]+[tax_duty_per_operation])*[exchange_rate],0)) as S42_unit_cost_usd
				, S34.filename
				, S34.Processing_ID
				, s42.sub_assembly_name
     FROM PARWS34_DAII_COVER_PAGE_INFO     S34
	 Join PARWS42_DAII_ASSEMBLY_PARTS_INFO S42 ON S42.Processing_ID     = S34.Processing_ID
                                              and S42.filename          = S34.filename
     where S34.Processing_ID               = @GUID
     and  S42.sub_assembly_name            like 'Costs%'
	       	   and S34.Skip_loading_due_to_error_f = 0
	 group by S34.filename, S34.Processing_ID, s42.sub_assembly_name
) S42
 On S35.filename = S42.filename AND S35.Processing_ID = S42.Processing_ID	
	and ltrim(Rtrim(substring(s35.sheet_name,5,500))) = ltrim(rtrim(substring(s42.sub_assembly_name,7,500)))
	and s35.sheet_name like 'ADJ-%'    
) X
	where X.ARWE02_ERROR_X!=''
	and 
	(
	  ABS(S42_summed_cost) <  ABS(s35_cost) - @V_Threshold_A
	  or 
	  ABS(S42_summed_cost) >  ABS(s35_cost) + @V_Threshold_A
	)

UNION

select 
 X.ARWE02_SOURCE_C
,X.s35_cost     --'Assembly total in Supplier Quote Summary: '+ CAST(S35.assembly as varchar(50))
,X.ARWE02_ERROR_X
,X.ARWE02_PROCESSING_ID
,X.ARWE02_FILENAME
,X.ARWE02_PROCEDURE_X
,X.[ARWE02_CREATE_S]
,X.[ARWE02_CREATE_USER_C]
,X.ARWE02_LAST_UPDT_S
,X.[ARWE02_LAST_UPDT_USER_C]
,X.ARWE02_BATCH_ERRORS_REF_K
,X.ARWE02_STAGING_TABLE_X
,'ERROR'
,x.ARWE02_EXCEL_TAB_X + ' - Supplier Quote Summary'
,0                               as ARWE02_ROW_IDX
,''                 --Part index
,S42_unit_cost_usd --' does not match Assembly total in Arrow: ' + CAST(S42_unit_cost_usd as varchar(50))
FROM
(
select 
       S35.Source_c            AS [ARWE02_SOURCE_C]
      ,S42_unit_cost_usd       
      ,CASE WHEN S35.assembly = S42_unit_cost_usd 
	        THEN '' 
			ELSE 'Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not changed in column Q of the Adj sheet and/or column Z/AB of Assembly section in the Costs sheet'
			END  AS ARWE02_ERROR_X  
      ,S35.Processing_ID                      AS ARWE02_PROCESSING_ID
      ,S35.filename                           AS ARWE02_FILENAME 
      ,OBJECT_NAME(@@PROCID)                  AS [ARWE02_PROCEDURE_X]
      ,@TIME_STAMP                            AS [ARWE02_CREATE_S]
      ,@CDSID                                 AS [ARWE02_CREATE_USER_C]
      ,@TIME_STAMP                            AS [ARWE02_LAST_UPDT_S]
      ,@CDSID                                 AS [ARWE02_LAST_UPDT_USER_C]
      ,S35.ARWS34_DAII_COVER_PAGE_INFO_K      AS [ARWE02_BATCH_ERRORS_REF_K]
      ,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'  AS [ARWE02_STAGING_TABLE_X]
      ,S42_unit_cost_usd                      AS S42_summed_cost
      ,S35.assembly                           AS s35_cost
	  ,s35.sheet_name                         AS ARWE02_EXCEL_TAB_X
from 
(
  select SUM(assembly) as assembly , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name 
    from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
    JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                 AND S34.filename     = S35.filename
   where S34.Processing_ID               = @GUID
     and S34.Skip_loading_due_to_error_f = 0
   group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
) S35
Join
(
   select SUM(IsNUll(([assembly_secs_operation]*([machinehourly_operation_overhead]/3600)
				+(([assembly_secs_operation]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])*(1+[indirect_labor_costs])*(1+[fringes]))
				+[packaging_costs]+[logistics_cost]+[tax_duty_per_operation])*[exchange_rate],0)) as S42_unit_cost_usd
				, S34.filename
				, S34.Processing_ID
				, s42.sub_assembly_name
     FROM PARWS34_DAII_COVER_PAGE_INFO     S34
	 Join PARWS42_DAII_ASSEMBLY_PARTS_INFO S42 ON S42.Processing_ID     = S34.Processing_ID
                                              and S42.filename          = S34.filename
     where S34.Processing_ID               = @GUID
     and  S42.sub_assembly_name                   like 'Adjustment Costs'
	 and S34.Skip_loading_due_to_error_f = 0
	 group by S34.filename, S34.Processing_ID, s42.sub_assembly_name
) S42
 On S35.filename = S42.filename AND S35.Processing_ID = S42.Processing_ID	
	and s35.sheet_name = 'Adjustment details'
	
) X
	where X.ARWE02_ERROR_X !=''
	and 
	(
	  ABS(S42_summed_cost) <  ABS(s35_cost) - @V_Threshold_A
	  or 
	  ABS(S42_summed_cost) >  ABS(s35_cost) + @V_Threshold_A
	)

;
END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value		
END CATCH;

GO
