
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ============================================================================================
-- Author:		rwesley2
-- Create date: 04-22-2022
-- Description:	This SP updates the Variant fields whose calculations are based on mapped Tygra records
-- SP is called from PARWP_TYGRA_UI_TYGRA_LOAD	  
-- This SP is a clone of PARWP_UI_CCTSS_VRNT_TYGRA_CALC and must be kept in synch with changes to that SP  
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2022  US3433185 initial version
-- rwesley2   06-08-2022  US3704897 remove Try/Catch. Any error will be caught in the master 
-- ============================================================================================


CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_UI_VRNT_CALC] 

@TYGRA_U04_VRNT_UPDATE  PARWT01_CCTSS READONLY
,@processing_id varchar(500)
,@CDSid varchar(8)
,@Time_Stamp datetime
,@RESULT VARCHAR(MAX) OUTPUT

AS

SET NOCOUNT ON;

	UPDATE U04
	SET
		 U04.ARWU04_FIN_SURGT_A = 0
		,U04.ARWU04_OOS_SURGT_CNTNT_A = 0
		,U04.ARWU04_FIN_STRT_PT_A = 0
		,U04.ARWU04_OOS_STRT_PT_A = 0
		,U04.ARWU04_JOB_LAST_COST_A = 0
		,U04.ARWU04_LEFT_ATTR_A = 0
		,U04.ARWU04_OOS_LEFT_ATTR_A = 0
		,U04.ARWU04_CMPTBL_EFIC_A = 0
		,U04.ARWU04_OOS_CMPTBL_EFIC_A = 0
		,U04.ARWU04_FIN_MEV_A = 0
		,U04.ARWU04_OOS_FIN_MEV_A = 0
		,U04.ARWU04_FIN_RIGHT_ATTRS_A = 0
		,U04.ARWU04_OOS_FIN_RIGHT_ATTRS_A = 0
		,U04.ARWU04_JOB1_ATTR_EFIC_A = 0
		,U04.ARWU04_OOS_JOB1_ATTR_EFIC_A = 0
		,U04.ARWU04_SCOPE_FIN_TRGT_ASSMP_A = 0
		,U04.ARWU04_OOS_SCOPE_FIN_TRGT_ASSMP_A = 0
		,U04.ARWU04_CURR_SURGT_A = 0
		,U04.ARWU04_OOS_CURR_SURGT_CNTNT_A = 0
		,U04.ARWU04_CURR_STRT_PT_A = 0
		,U04.ARWU04_OOS_CURR_STRT_PT_A = 0
		,U04.ARWU04_CURR_JOB_LAST_COST_A = 0
		,U04.ARWU04_CURR_LEFT_ATTR_A = 0
		,U04.ARWU04_OOS_CURR_LEFT_ATTR_A = 0
		,U04.ARWU04_CURR_CMPTBL_EFIC_A = 0
		,U04.ARWU04_OOS_CURR_CMPTBL_EFIC_A = 0
		,U04.ARWU04_CURR_MEV_A = 0
		,U04.ARWU04_OOS_CURR_MEV_A = 0
		,U04.ARWU04_CURR_RIGHT_ATTRS_A = 0
		,U04.ARWU04_OOS_CURR_RIGHT_ATTRS_A = 0
		,U04.ARWU04_CURR_JOB1_ATTR_EFIC_A = 0
		,U04.ARWU04_OOS_CURR_JOB1_ATTR_EFIC_A = 0
		,U04.ARWU04_CURR_FIN_TRGT_ASSMP_A = 0
		,U04.ARWU04_OOS_CURR_FIN_TRGT_ASSMP_A = 0
		,U04.ARWU04_LAST_UPDT_S = @TIME_STAMP
		,U04.ARWU04_LAST_UPDT_USER_C = @cdsid
	FROM PARWU04_CCTSS_VRNT as U04
	where U04.ARWU01_CCTSS_K in (select ARWU01_CCTSS_K  from @TYGRA_U04_VRNT_UPDATE mvd )

	SET @RESULT = 'SUCCESS';

