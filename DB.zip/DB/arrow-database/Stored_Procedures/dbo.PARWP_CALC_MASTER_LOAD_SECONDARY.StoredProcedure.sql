SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASOLOSKY
-- Create date: 12/07/2021
-- Description:	Master procedure to call all secondary procedures that will run the data dump procedures used by the UI
--   It uses a User-Defined Table Type that is defined in the database. It's found in SMS under TYPES
--   The Table type will be loaded with the designs needed for processing the calc tables.
-- Input Parameters
-- @U01_k - ARWU01_CCTSS_K and it must always be passed in 
-- @U06_k - ARWU06_CCTSS_DSGN_K only passed in when processing by design, otherwise it must be set to -1.
--          negative 1 means to process by the @U01_k parameter
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- 02-08-2022 rwesley2 US3273098 add ARWU01_CCTSS_K to table, load and read (clone)2c) SPs
-- 03-28-2022 rwesley2 US3436207 added D20 delete and load 
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_MASTER_LOAD_SECONDARY]
 @U01_k					    INT   
,@CDSID                  varchar(8)
,@Secondary_output_error varchar(5000) OUTPUT

AS

SET NOCOUNT ON;
--Declare @T06_CCTSS_DSGN   [dbo].[PARWT06_CCTSS_DSGN];


BEGIN
 BEGIN TRY
-- Declare @Start_Time DATETIME = GETUTCDATE();
 Declare @LWST_IDC_DSGN_K         INT;
 Declare @Secondary_delete_error  varchar(5000);
 Declare @TIME_STAMP              DATETIME = GETUTCDATE();

 --get study method which will be used to determine if the study is DC or not
 Declare @DC_Study_F              varchar(1);
 execute @DC_Study_F = dbo.PARWF_IS_STUDY_DC @U01_k

 Set @Secondary_output_error = '';

Execute PARWP_CALC_MASTER_DELETE_SECONDARY @U01_k, @DC_Study_F, @CDSID, @Secondary_delete_error OUTPUT
If @Secondary_delete_error = ''
BEGIN
  IF @DC_Study_F = 'N'
  Begin  
    SET @LWST_IDC_DSGN_K = (SELECT ARWU06_CCTSS_DSGN_K 
	                           FROM PARWD06_LOWEST_IDC_DESIGN
	 								 where ARWU01_CCTSS_K = @U01_k);
    Execute [dbo].[PARWP_CALC_LOAD_D05_DSGN_DA_TRADEOFF_PART_DETAIL]        @U01_k, @CDSID, @TIME_STAMP;  
    Execute [dbo].[PARWP_CALC_LOAD_D07_DSGN_INTENT_ADJ]                     @U01_k, 'Y', @CDSID, @TIME_STAMP;  --'Y'=@EXCLUDED_REQ_FLAG
    Execute [dbo].[PARWP_CALC_LOAD_D07_DSGN_INTENT_ADJ]                     @U01_k, 'N', @CDSID, @TIME_STAMP;  --'N'=@EXCLUDED_REQ_FLAG 
    Execute [dbo].[PARWP_CALC_LOAD_D08_DSGN_II_TRADEOFF_PART_DETAIL]        @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D09_VA_DA_TRADEOFF_PART_DETAIL]          @U01_k, @LWST_IDC_DSGN_K, @CDSID,  @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D10_VARIANT_COST_OVRVW]                  @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D12_DSGN_INTENT_ADJ_L2]                  @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D13_COST_ALLOCATION_EI]                  @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D14_TRADEOFF_SUMMARY]                    @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D15_VA_TRADEOFF_LIST_SLIDE]              @U01_k, @LWST_IDC_DSGN_K, @CDSID,  @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D16_RISKS_AND_OPPS]                      @U01_k, @LWST_IDC_DSGN_K, @CDSID,  @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D17_AVG_VEH_COST]                        @U01_k, @LWST_IDC_DSGN_K, @CDSID,  @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D18_COST_ALLOCATION_EI_ASM]              @U01_k, @CDSID, @TIME_STAMP;
  End;
  Else --DC Study
  Begin
    Execute [dbo].[PARWP_CALC_LOAD_D19_DC_COST_ALLOCATION_EI]               @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D20_DC_COST_ALLOCATION_EI_ASM]           @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D21_DC_CT_VRNT_COST]                     @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D22_DC_DSGN_II_TRADEOFF_PART_DETAIL]     @U01_k, @CDSID, @TIME_STAMP;
    Execute [dbo].[PARWP_CALC_LOAD_D23_DC_VRNT_SUP_COST]                    @U01_k, @CDSID, @TIME_STAMP;
  End;
End;
ELSE
  SET @Secondary_output_error = @Secondary_delete_error;

-- COMMIT TRANSACTION; 
-- Select OBJECT_NAME(@@PROCID)                      as Procedure_Name 
--       ,convert(time, GETUTCDATE() - @Start_Time ) as run_time;

END TRY

BEGIN CATCH
   --Rollback;

    Declare @u01_Study Varchar(100);
    Set @u01_Study = (Select U01.ARWU31_CTSP_N            + ' ' +
                             U01.ARWA06_RGN_C             + ' ' +
                      	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                      	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                        from PARWU01_CCTSS_FLAT U01
                       where U01.ARWU01_CCTSS_K = @U01_k
    				      );

    Set @Secondary_output_error = 'Study Key: '      + cast(@U01_k as varchar(20)) + 
	                               ' |Study: '         + ISNULL(@u01_Study, '') +
	                               ' |GMT Date/Time: ' + CONVERT(varchar, GETUTCDATE(), 120) +
	                               ' |CDS: '           + @CDSID +
	                               ' |Procedure: '     + ERROR_PROCEDURE() + 
								          ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
								          ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

END CATCH;	

END;
GO
