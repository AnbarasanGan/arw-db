DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_MFG_MARKUPS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 04/02/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 07/12/2019	asolosky		  Moved the deletes to PARWP_DAII_LOAD_ADJUSTMENT_DETAILS procedure
-- 01/14/2020   Ashaik12          Added Time_Stamp parameter and removed filter on Processing Status
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_MFG_MARKUPS] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;


------------------- Insert into U42
INSERT INTO [dbo].PARWU42_MFG_MRKP_DSGN_ADJ
SELECT
   V04.ARWU08_CCTSS_DSGN_SUPL_K              as [ARWU08_CCTSS_DSGN_SUPL_K]
  ,A38.ARWA38_MFG_MRKP_TYP_K                       as [ARWA38_MFG_MRKP_TYP_K]
  ,isNULL(S43.manufacturing_markup_value,0)        as [ARWU42_MFG_MRKP_P]
  ,isNULL(S43.comments,'')                         as [ARWU42_MFG_MRKP_ASSMP_CMT_X]
  ,@TIME_STAMP                                    as [ARWU42_CREATE_S]
  ,@CDSID                                          as  ARWU42_CREATE_USER_C
  ,@TIME_STAMP                                    as  ARWU42_LAST_UPDT_S
  ,@CDSID                                          as  ARWU42_LAST_UPDT_USER_C
 from [dbo].PARWS43_DAII_MANUFACTURING_MARKUPS_INFO S43
 JOIN [dbo].PARWS34_DAII_COVER_PAGE_INFO            S34
   ON S34.Processing_ID       = S43.Processing_ID
  AND S34.filename            = S43.filename

-- SUPPLIER QUOTE MFG MARKUPS VIEW
 JOIN dbo.PARWV04_DSGN_SUPL V04
    ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

-- Get A38 Key
JOIN [dbo].[PARWA38_MFG_MRKP_TYP] A38
ON S43.manufacturing_markup_desc=A38.[ARWA38_MFG_MRKP_TYP_X]
where S34.Processing_ID               = @Processing_ID
  AND S34.Skip_loading_due_to_error_f = 0
  AND S43.sub_assembly_name           = 'Adjustment Costs'  
  --AND S43.manufacturing_markup_value != 0
 ;


INSERT INTO [dbo].PARWU44_FNLASSY_MRKP_DSGN_ADJ
Select 
       -- [ARWU54_FNLASSYMRKP_DSGN_IMPV_K]
	   V04.ARWU08_CCTSS_DSGN_SUPL_K                 as ARWU08_CCTSS_DSGN_SUPL_K
      ,Staging.ARWA38_MFG_MRKP_TYP_K                as ARWA38_MFG_MRKP_TYP_K
      ,isNULL(Staging.manufacturing_markup_value,0) as ARWU44_FNL_ASSY_MRKP_P
      ,isNULL(Staging.comments,'')                  as ARWU44_FNLASSYMRKP_ASSMP_CMT_X
      ,@TIME_STAMP                                 as ARWU44_CREATE_S
      ,@CDSID                                       as ARWU44_CREATE_USER_C
      ,@TIME_STAMP                                 as ARWU44_LAST_UPDT_S
	  ,@CDSID                                       as ARWU44_LAST_UPDT_USER_C
  From PARWV04_DSGN_SUPL V04
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
			 ,S43.manufacturing_markup_value
			 ,S43.comments
             ,A38.ARWA38_MFG_MRKP_TYP_K 
			 ,A38.ARWA38_MFG_MRKP_TYP_C
			 ,A38.ARWA38_MFG_MRKP_TYP_X
       from [dbo].PARWS43_DAII_MANUFACTURING_MARKUPS_INFO S43
 JOIN [dbo].PARWS34_DAII_COVER_PAGE_INFO cover_page_stage
         ON cover_page_stage.Processing_ID       = S43.Processing_ID
        AND cover_page_stage.filename            = S43.filename
	   JOIN [dbo].[PARWA38_MFG_MRKP_TYP] A38
         ON S43.manufacturing_markup_desc        = A38.[ARWA38_MFG_MRKP_TYP_X]
      where cover_page_stage.Processing_ID               = @Processing_ID
		AND cover_page_stage.Skip_loading_due_to_error_f = 0
        AND S43.sub_assembly_name                        = 'Final assembly' 
		AND S43.cost_type                                ='Adjustment Costs'
      ) Staging
    ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X] = V04.[ENG_SUB_CMMDTY_DESC]
   AND Staging.[User_Selected_CTSP_N]            = V04.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]     = V04.[CTSP_REGION_CODE]
   AND Staging.[User_Selected_VEH_MAKE_N]        = V04.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]         = V04.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]      = V04.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]    = V04.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]      = V04.[VARIANT]
   AND Staging.[User_Selected_SUPL_N]            = V04.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]      = V04.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]            = V04.ARWA17_SUPL_C
   --AND Staging.manufacturing_markup_value!=0 
 ;

GO
