DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_COST_QTY_PBOM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 02/10/2021
-- Description:	PRE-PBOM BoBs: Validate the different Cost sheet Quantities match the BOM Sheet. 
--              The same validation is done for Raw Material usage. 
--              The users have been manually updating the quantity and material usage cells on the cost sheets which over-rides the EXCEL formulas.
-- =============================================
-- =============================================
-- Changes
-- Date        CDSID    Feature   Description
-- ----------  -------- -------   -----------
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_COST_QTY_PBOM] 
-- Input Parameter
 @GUID       varchar(5000)
,@CDSID      varchar(30)
,@TIME_STAMP DATETIME

AS

BEGIN TRY
SET NOCOUNT ON;

--******************
--Purchased Parts
--******************
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
 Select 
		 S14.Source_c
		,S14.no_of_pieces
		,'The Purchased Parts "Number of Pieces per Sub-Assembly" does not match the PBOM quantity in ARROW. Verify the formula for "Number of pieces per Sub-Assembly" hasn''t been changed'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S14.ARWS14_CCS_PURCHASED_PARTS_K  
		,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'  
        ,'ERROR'                       
		,S14.sub_assembly_name
	    ,S14.row_idx                               as ARWE02_ROW_IDX
		,S14.part_index
		,U19.ARWU19_DSGN_PART_Q
   from PARWS22_CCS_COVER_PAGE_INFO                     S22
   JOIN PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14
     ON S14.Processing_ID     = S22.Processing_ID
    AND S14.filename          = S22.filename
   JOIN PARWU19_DSGN_PART_FLAT U19
     ON S22.User_Selected_CTSP_N            = U19.ARWU31_CTSP_N
    AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U19.ARWA03_ENRG_SUB_CMMDTY_X
    AND S22.User_Selected_CTSP_Region_C     = U19.ARWA06_RGN_C
    AND S22.User_Selected_BNCMK_VRNT_N      = U19.ARWU01_BNCHMK_VRNT_N
    AND S22.User_Selected_VEH_MAKE_N        = U19.ARWA14_VEH_MAKE_N
    AND S22.User_Selected_VEH_MDL_N         = U19.ARWA34_VEH_MDL_N
    AND S22.User_Selected_VEH_MDL_YR_C      = U19.ARWA35_DSGN_VEH_MDL_YR_C
    AND S22.User_Selected_VEH_MDL_VRNT_X    = U19.ARWA35_DSGN_VEH_MDL_VRNT_X
    AND S14.sub_assembly_name               = U19.ARWU17_BOM_SUB_ASSY_N
    AND S14.part_index                      = U19.ARWU18_BOM_PART_IX_N
   where S22.Processing_ID = @GUID
    AND round(S14.no_of_pieces,9) != round(U19.ARWU19_DSGN_PART_Q,9)
;

--******************
--Raw Materials
--******************
--Quantity
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
    Select 
		 S15.Source_c
		,S15.no_of_pieces
		,'The Raw Materials "Number of Pieces per Sub-Assembly" does not match the PBOM quantity in ARROW. Verify the formula for "Number of pieces per Sub-Assembly" hasn''t been changed'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S15.ARWS15_CCS_RAW_MATERIALS_K  
		,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO'  
        ,'ERROR'                       
		,S15.sub_assembly_name
	    ,S15.row_idx                               as ARWE02_ROW_IDX
		,S15.part_index
		,U19.ARWU19_DSGN_PART_Q
   From PARWS22_CCS_COVER_PAGE_INFO                     S22
   JOIN PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO   S15
     ON S15.Processing_ID     = S22.Processing_ID
    AND S15.filename          = S22.filename
   JOIN PARWU19_DSGN_PART_FLAT U19
     ON S22.User_Selected_CTSP_N            = U19.ARWU31_CTSP_N
    AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U19.ARWA03_ENRG_SUB_CMMDTY_X
    AND S22.User_Selected_CTSP_Region_C     = U19.ARWA06_RGN_C
    AND S22.User_Selected_BNCMK_VRNT_N      = U19.ARWU01_BNCHMK_VRNT_N
    AND S22.User_Selected_VEH_MAKE_N        = U19.ARWA14_VEH_MAKE_N
    AND S22.User_Selected_VEH_MDL_N         = U19.ARWA34_VEH_MDL_N
    AND S22.User_Selected_VEH_MDL_YR_C      = U19.ARWA35_DSGN_VEH_MDL_YR_C
    AND S22.User_Selected_VEH_MDL_VRNT_X    = U19.ARWA35_DSGN_VEH_MDL_VRNT_X
    AND S15.sub_assembly_name               = U19.ARWU17_BOM_SUB_ASSY_N
    AND S15.part_index                      = U19.ARWU18_BOM_PART_IX_N
  where S22.Processing_ID = @GUID
    AND round(S15.no_of_pieces,9) != round(U19.ARWU19_DSGN_PART_Q,9)
;
--******************
--Raw Materials
--******************
--Net Usage
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
 Select 
		 S15.Source_c
		,S15.net_usage_per_piece
		,'The Raw Materials "Net Usage per piece" does not match the PBOM Material Usage in ARROW. Verify the formula for "Net Usage per piece" hasn''t been changed'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S15.ARWS15_CCS_RAW_MATERIALS_K  
		,'PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO'  
        ,'ERROR'                       
		,S15.sub_assembly_name
	    ,S15.row_idx                               as ARWE02_ROW_IDX
		,S15.part_index
		,U19.ARWU19_DSGN_PART_MTRL_USG_Q
   From PARWS22_CCS_COVER_PAGE_INFO                     S22
   JOIN PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO   S15
     ON S15.Processing_ID     = S22.Processing_ID
    AND S15.filename          = S22.filename
   JOIN PARWU19_DSGN_PART_FLAT U19
     ON S22.User_Selected_CTSP_N            = U19.ARWU31_CTSP_N
    AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U19.ARWA03_ENRG_SUB_CMMDTY_X
    AND S22.User_Selected_CTSP_Region_C     = U19.ARWA06_RGN_C
    AND S22.User_Selected_BNCMK_VRNT_N      = U19.ARWU01_BNCHMK_VRNT_N
    AND S22.User_Selected_VEH_MAKE_N        = U19.ARWA14_VEH_MAKE_N
    AND S22.User_Selected_VEH_MDL_N         = U19.ARWA34_VEH_MDL_N
    AND S22.User_Selected_VEH_MDL_YR_C      = U19.ARWA35_DSGN_VEH_MDL_YR_C
    AND S22.User_Selected_VEH_MDL_VRNT_X    = U19.ARWA35_DSGN_VEH_MDL_VRNT_X
    AND S15.sub_assembly_name               = U19.ARWU17_BOM_SUB_ASSY_N
    AND S15.part_index                      = U19.ARWU18_BOM_PART_IX_N
  where S22.Processing_ID = @GUID
    AND round(S15.net_usage_per_piece,9) != round(U19.ARWU19_DSGN_PART_MTRL_USG_Q,9)
;

--******************
--Processing
--******************
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
  Select 
		 S16.Source_c
		,S16.no_of_pieces_per_subassy
		,'The Processing "Number of Pieces per Sub-Assembly" does not match the BOM quantity. Verify the formula for "Number of pieces per Sub-Assembly" hasn''t been changed'  as Error_Msg
        ,S22.Processing_ID 
		,S22.filename
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,S16.ARWS16_CCS_PROCESSING_PARTS_K  
		,'PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO'  
        ,'ERROR'                       
		,S16.sub_assembly_name
	    ,S16.row_idx                               as ARWE02_ROW_IDX
		,S16.part_index
		,U19.ARWU19_DSGN_PART_Q
   from PARWS22_CCS_COVER_PAGE_INFO                        S22
   JOIN PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO   S16
     ON S16.Processing_ID     = S22.Processing_ID
    AND S16.filename          = S22.filename
   JOIN PARWU19_DSGN_PART_FLAT U19
     ON S22.User_Selected_CTSP_N            = U19.ARWU31_CTSP_N
    AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U19.ARWA03_ENRG_SUB_CMMDTY_X
    AND S22.User_Selected_CTSP_Region_C     = U19.ARWA06_RGN_C
    AND S22.User_Selected_BNCMK_VRNT_N      = U19.ARWU01_BNCHMK_VRNT_N
    AND S22.User_Selected_VEH_MAKE_N        = U19.ARWA14_VEH_MAKE_N
    AND S22.User_Selected_VEH_MDL_N         = U19.ARWA34_VEH_MDL_N
    AND S22.User_Selected_VEH_MDL_YR_C      = U19.ARWA35_DSGN_VEH_MDL_YR_C
    AND S22.User_Selected_VEH_MDL_VRNT_X    = U19.ARWA35_DSGN_VEH_MDL_VRNT_X
    AND S16.sub_assembly_name               = U19.ARWU17_BOM_SUB_ASSY_N
    AND S16.part_index                      = U19.ARWU18_BOM_PART_IX_N
  where S22.Processing_ID = @GUID
    AND round(S16.no_of_pieces_per_subassy,9) != round(U19.ARWU19_DSGN_PART_Q,9)
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                  --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''  --Part_index
		,''  --Arrow value	
    ;

END CATCH;
GO
