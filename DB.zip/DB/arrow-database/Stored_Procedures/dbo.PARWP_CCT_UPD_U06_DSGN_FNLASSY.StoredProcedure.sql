DROP PROCEDURE [dbo].[PARWP_CCT_UPD_U06_DSGN_FNLASSY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 06/05/2019
-- Description:	First Merge statement Updates the column ARWU06_FNLASSY_ORIG_BOB_A when matched, when not matched it inserts a row.
--              Second Merge statement updates the column ARWU06_FNLASSY_ORIG_BOB_MRKP_P
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ashaik12   08/14/2019  Ignore 0's when doing the min.
-- Ashaik12   01/10/2020  Added TimeStamp parameter
-- Ashaik12   11/30/2020  US2096264 -- Use calculated total instead of adding 6 columns to get the original bob amount
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCT_UPD_U06_DSGN_FNLASSY] 
-- Input Parameter
@CCTSS_K INT,
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME


AS

SET NOCOUNT ON;
----------------------------------------------------------
-- Merge statement to update PARWU06_CCTSS_DSGN
----------------------------------------------------------
MERGE INTO [dbo].PARWU06_CCTSS_DSGN   U06
USING
(
  Select ARWU01_CCTSS_K
        ,ARWU06_CCTSS_DSGN_K
  	    ,min(1 + IsNull(COMPOUNDED_TOTAL,0)) as comp_total_p
    From
        (Select [ARWU01_CCTSS_K]
               ,[ARWU06_CCTSS_DSGN_K]
        	    ,COMPOUNDED_TOTAL 
           From PARWV21_FINAL_ASSEMBLY_MFG_MRKP
          Where ARWU01_CCTSS_K        = @CCTSS_K
		  and COMPOUNDED_TOTAL !=0
        
          Union ALL
        
          Select V14.ARWU01_CCTSS_K
                ,U06.ARWU06_CCTSS_DSGN_K
        		,COMPOUNDED_TOTAL
        	From PARWV14_PROGRAM_MRKUP V14
           --Design
           Join [dbo].[PARWU06_CCTSS_DSGN]          U06
             On U06.ARWU01_CCTSS_K  = V14.ARWU01_CCTSS_K
          Where V14.ARWU01_CCTSS_K        = @CCTSS_K
		  and COMPOUNDED_TOTAL !=0
        ) Mrkup_Union
  Group by ARWU01_CCTSS_K
          ,ARWU06_CCTSS_DSGN_K
)Comp_Tot_Part

ON (Comp_Tot_Part.ARWU06_CCTSS_DSGN_K   = U06.ARWU06_CCTSS_DSGN_K)
	 
WHEN MATCHED THEN
     UPDATE SET          
	    U06.ARWU06_FNLASSY_ORIG_BOB_MRKP_P = comp_total_p
	   ,U06.ARWU06_LAST_UPDT_S             = @TIME_STAMP 
	   ,U06.ARWU06_LAST_UPDT_USER_C        = @CDSID
;

----------------------------------------------------------
-- Merge statement to update PARWU06_CCTSS_DSGN
----------------------------------------------------------

MERGE INTO [dbo].PARWU06_CCTSS_DSGN   U06_Target
USING
(
 select Min_Labor.Min_FINAL_ASSEMBLY_Labor * ARWU06_FNLASSY_ORIG_BOB_MRKP_P as ORIG_BOB_MRKP_A
       ,Min_Labor.ARWU06_CCTSS_DSGN_K
   FROM PARWU06_CCTSS_DSGN U06
   JOIN
     (
     select min(FINAL_ASSEMBLY_COST_LoCurr) as Min_FINAL_ASSEMBLY_Labor
           ,ARWU31_CTSP_N
           ,ARWU06_CCTSS_DSGN_K
       from
           (
           select
				  SUM(V16.FINAL_ASSEMBLY_COST_LoCurr*V16.ARWU33_CRCY_PER_USD_R) AS FINAL_ASSEMBLY_COST_LoCurr
                 ,ARWU31_CTSP_N
                 ,ARWU06_CCTSS_DSGN_K
				 ,ARWU08_CCTSS_DSGN_SUPL_K
             FROM PARWV16_CCS_FINAL_ASSEMBLY_FLAT V16
            WHERE ARWU01_CCTSS_K = @CCTSS_K
            GROUP BY ARWU31_CTSP_N
			        ,ARWU06_CCTSS_DSGN_K
                    ,ARWU08_CCTSS_DSGN_SUPL_K

           ) V16
     
      Group by ARWU31_CTSP_N
              ,ARWU06_CCTSS_DSGN_K
     
     ) Min_Labor
  ON Min_Labor.ARWU06_CCTSS_DSGN_K = U06.ARWU06_CCTSS_DSGN_K

) U06_Source
ON U06_Target.ARWU06_CCTSS_DSGN_K=U06_Source.ARWU06_CCTSS_DSGN_K
WHEN MATCHED THEN
     UPDATE SET 
	  U06_Target.ARWU06_FNLASSY_ORIG_BOB_A = U06_Source.ORIG_BOB_MRKP_A
	 ,U06_Target.ARWU06_LAST_UPDT_S        = @TIME_STAMP 
	 ,U06_Target.ARWU06_LAST_UPDT_USER_C   = @CDSID
;


GO
