DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_ASSEMBLY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		Asolosky
-- Create date: 4/01/2019
-- Description:	Validate Assembly data
-- =============================================
-- Changes
-- =============================================
--                      User
-- Author     Date      Story    Description
-- ------     -----     -------- -----------
-- ASHAIK12  06/25                Added validation for calculated field
-- ASHAIK12  07/31                Changed Calculated field validations to WARNINGS
-- Asolosky  09/10/2019           Added row_idx
-- rwesley2  09/13/2019           added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019           changed warning to error for calculated field validations
-- rwesley2  10/01/2019           temporarily changed error back to warning per Glenn 
-- rwesley2	 10/08/2019	          removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	          F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- ashaik12  12/25/2019           Removed Case when statements in Error Desc as we have tab name in display on UI.
-- Ashaik12  01/10/2020           Added TimeStamp parameter and removed filter on Processing Status
-- Ashaik12  08/31/2020           Added formulas to handle different versions in validation of Total labor costs and Direct labor cost per piece .
-- Asolosky  09/11/2020 US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Ashaik12  09/17/2020           For CCS 10.1 made formula changes to have division by 60
-- Asolosky  01/21/2021 US2209131 Use ARWA10_COST_EST_PERFD_F instead of ARWA10_CCTSS_METHD_N like '%DEA%'
-- Asolosky  04/07/2021 US2430167 Added validation for Cost sheet exchange rate
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_ASSEMBLY] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;



--++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.local_currency                    as ARWE02_ERROR_VALUE
	  ,'Assembly: Invalid Currency Code'     as ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS17_CCS_ASSEMBLY_PARTS_K       as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,part_index
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS17_CCS_ASSEMBLY_PARTS_K,
			   row_idx,
			   part_index
          FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
         WHERE Processing_ID= @GUID
	       and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where S17.[local_currency] = A29.[ARWA29_CRCY_C]
	             )	
                 
        ) Err
;

--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Machine / operation overhead costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.machine_op_overhead_costs         as ARWE02_ERROR_VALUE
	  ,'Assembly: Machine/operation overhead costs has a difference between calculated value and the total. It exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS17_CCS_ASSEMBLY_PARTS_K       as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,part_index
	  ,'Calculated Value: ' + CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS17_CCS_ASSEMBLY_PARTS_K,
			   part_index,
			   machine_op_overhead_costs,
			   assembly_secs_operation*(machinehourly_operation_overhead/3600) as Calculated_value,
			   row_idx
         FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
        WHERE Processing_ID= @GUID
	      and ABS((assembly_secs_operation*(machinehourly_operation_overhead/3600)) - (machine_op_overhead_costs)) > @threshold 
        ) ERR
;

--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Direct labor cost per operation [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.direct_labor_cost_op              as ARWE02_ERROR_VALUE
	  ,'Assembly: Direct labor cost per operation has a difference between calculated value and the total. It exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS17_CCS_ASSEMBLY_PARTS_K       as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,ERR.part_index
	  ,'Calculated Value: ' + CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
        SELECT 
               s22.Processing_ID,
			   sub_assembly_name,
               operation_location,
		       s22.Processing_Status_x,
		       s22.Source_c,
		       s22.filename,
               ARWS17_CCS_ASSEMBLY_PARTS_K,
			   part_index,
			   direct_labor_cost_op,
			   CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and [ARWA53_LGCY_CCS_PGM_N] is NULL    
			        THEN NULL 
					ELSE (assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount) 
			   End as Calculated_value,
			   s17.row_idx 
         FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
        JOIN PARWS22_CCS_COVER_PAGE_INFO S22 On s17.Processing_ID=s22.Processing_ID and s17.filename=s22.filename
		  JOIN PARWU01_CCTSS_FLAT u01 
			on s22.User_Selected_CTSP_N = u01.ARWU31_CTSP_N 
			and s22.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
			and s22.User_Selected_CTSP_Region_C = u01.ARWA06_RGN_C
			and s22.User_Selected_BNCMK_VRNT_N = u01.ARWU01_BNCHMK_VRNT_N
		LEFT JOIN PARWA53_LGCY_CCS_PGM A53 ON u01.ARWU31_CTSP_N = A53.[ARWA53_LGCY_CCS_PGM_N]
        WHERE s22.Processing_ID= @GUID
        ) ERR
	   Where ABS(Calculated_value) - ABS(direct_labor_cost_op) > @threshold 
;

--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Total labor costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.total_labor_costs                 as ARWE02_ERROR_VALUE
	  ,'Assembly: Total labor costs has a difference between calculated value and the total. It exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                           as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                           as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.ARWS17_CCS_ASSEMBLY_PARTS_K       as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,ERR.part_index
	  ,'Calculated Value: ' + CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
        SELECT 
               s22.Processing_ID,
			   sub_assembly_name,
               operation_location,
		       s22.Processing_Status_x,
		       s22.Source_c,
		       s22.filename,
               ARWS17_CCS_ASSEMBLY_PARTS_K,
			   part_index,
			   total_labor_costs,
			   CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and [ARWA53_LGCY_CCS_PGM_N] is NULL    			     
			        THEN direct_hourly_labor_headcount*[total_labor_minutes]/60 
				    ELSE ((assembly_secs_operation*(direct_hourly_labor_headcount/3600))*direct_headcount*(1+[indirect_labor_costs])*(1+[fringes])) 
			   END as Calculated_value,
			   s17.row_idx
         FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
        JOIN PARWS22_CCS_COVER_PAGE_INFO S22 On s17.Processing_ID=s22.Processing_ID and s17.filename=s22.filename
		  JOIN PARWU01_CCTSS_FLAT u01 
			on s22.User_Selected_CTSP_N = u01.ARWU31_CTSP_N 
			and s22.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
			and s22.User_Selected_CTSP_Region_C = u01.ARWA06_RGN_C
			and s22.User_Selected_BNCMK_VRNT_N = u01.ARWU01_BNCHMK_VRNT_N
		LEFT JOIN PARWA53_LGCY_CCS_PGM A53 ON u01.ARWU31_CTSP_N = A53.[ARWA53_LGCY_CCS_PGM_N]
        WHERE s22.Processing_ID= @GUID
       ) ERR
	   Where ABS(Calculated_value) - ABS(total_labor_costs) > @threshold 
;

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Assembly: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS17_CCS_ASSEMBLY_PARTS_K
	  ,'PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,'' --supplier_picked_crcy_c + ' Per Local Currency from Exchange rates sheet: ' +  CAST(usd_per_local_currency as Varchar(50))  --ARROW Value
  FROM 
      (
        SELECT 
               S17.Processing_ID
              ,s17.exchange_rate
  		      ,s17.Source_c
  		      ,s17.filename
              ,s17.ARWS17_CCS_ASSEMBLY_PARTS_K
  		      ,s17.sub_assembly_name
  		      ,s17.part_index
			  ,s17.row_idx
			  ,S27.usd_per_local_currency
			  ,S27.supplier_picked_crcy_c
          FROM PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
		  Join PARWS27_CCS_EXCHANGE_RATE_TAB                  S27
		    On S27.Processing_ID  = S17.Processing_ID
		   And S27.filename       = S17.filename
		   And S27.currency_code  = S17.local_currency
         WHERE S17.Processing_ID  = @GUID
		   and S17.exchange_rate != S27.usd_per_local_currency
      ) Err
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''                                --ARWE02_STAGING_TABLE_X
		,'PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO' --ARWE02_BATCH_ERRORS_K
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''  --Part_index
		,''  --No ARROW Value
;
END CATCH;		



GO
