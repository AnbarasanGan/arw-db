SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ASHAIK12
-- Create date: 07/29/2022
-- Description:	Delete Procedure for variant II summary table.  
--              UI Exchange rate update only needs to delete the summary tables before recalculating.
--              
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12   07/29/2022  US3876656 : New SP to delete UD9 summary table before re-calculating
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VAII_CONSL_DELETE_SUM_TBLS] 
@CCTSS_K       Int

AS

SET NOCOUNT ON;


-- UD9
MERGE INTO  [dbo].[PARWUD9_SUPL_VRNT_IMPRV]  UD9_Target
Using
(
Select UD9.ARWU09_CCTSS_VRNT_SUPL_K
  From [PARWUD9_SUPL_VRNT_IMPRV]  UD9
  Join PARWU09_CCTSS_VRNT_SUPL_FLAT U09 On UD9.ARWU09_CCTSS_VRNT_SUPL_K = U09.ARWU09_CCTSS_VRNT_SUPL_K
 Where U09.ARWU01_CCTSS_K = @CCTSS_K
) as UD9_Source

ON (UD9_Target.ARWU09_CCTSS_VRNT_SUPL_K = UD9_Source.ARWU09_CCTSS_VRNT_SUPL_K)
WHEN MATCHED THEN DELETE;


GO


