DROP PROCEDURE [dbo].[PARWP_DAII_SCRUB_SPCL_CHARS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 10/31/2019
-- Description:	scub procedure to remove special characters from the DAII staging tables.
-- =============================================
-- CHANGES                User   
-- Date			CDSID	  Story	     Description
-- ----------   --------  -------    -----------
-- 12-12/2019   rwesley2             fix: add missing double spac replace to assembly
-- 01/10/2020   rwesley2             add scrubbing for part index and remove cdsid and date from update and processing status from Where 
-- 06/24/2020   asolosky  US1714209  When there is char(10)Line Feed or char(13)carriage return at the end of a character string, the LF and CR are removed.
--                                   S35: ford_spec_sds,competitive_dsgn_attr, ford_intended_dsgn_attr, comments
--                                   S44: idea_description
--                                   Also, there were multiple update statements per table. Changed the code so it's one update per table.
-- 07/01/2020   asolosky  US1714209  Added Char(9) Tab, Char(32) space and char(34) double quote to the list of special characters. The start and end of the value is scrubbed for these special characters.
--                                   Created a 2nd update for the left trim of special character.  
-- 07/24/2020   asolosky  US1771016  Removed scrubbing for LF and CR on part_index, part_name, change_id, improvement_id.  There will be validation procedure to reject when there's LF or CR.
--                                   Removed the scrub on S39, S40, S41, S42 for LF and CR.  Those tables will also have validation procedures to reject LF or CR.
-- 09/11/2020   Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================	
CREATE PROCEDURE [dbo].[PARWP_DAII_SCRUB_SPCL_CHARS]
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
AS
DECLARE @pat NvarCHAR(100) = '%[^'+CHAR(9)+CHAR(10)+CHAR(13)+CHAR(32)+CHAR(34)+']%';

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

---- SCRUB S35  
--Right Trim special characters
UPDATE PARWS35_DAII_ADJUSTMENT_DETAILS_INFO
   SET ford_spec_sds            = IsNull(LEFT(ford_spec_sds,DATALENGTH(ford_spec_sds) - PATINDEX(@pat,REVERSE(ford_spec_sds))+1),'')
	  ,competitive_dsgn_attr    = IsNull(LEFT(competitive_dsgn_attr,DATALENGTH(competitive_dsgn_attr) - PATINDEX(@pat,REVERSE(competitive_dsgn_attr))+1),'')
	  ,ford_intended_dsgn_attr  = IsNull(LEFT(ford_intended_dsgn_attr,DATALENGTH(ford_intended_dsgn_attr) - PATINDEX(@pat,REVERSE(ford_intended_dsgn_attr))+1),'')
	  ,comments                 = IsNull(LEFT(comments,DATALENGTH(comments)-PATINDEX(@pat,REVERSE(comments))+1),'')
  FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO s35
 WHERE s35.Processing_ID       = @GUID
;
--Left Trim special characters
UPDATE PARWS35_DAII_ADJUSTMENT_DETAILS_INFO
   SET ford_spec_sds            = IsNull(STUFF(ford_spec_sds,1,ISNULL(NULLIF(PATINDEX(@pat,ford_spec_sds),0)-1,0),''),'') 
	  ,competitive_dsgn_attr    = IsNull(STUFF(competitive_dsgn_attr,1,ISNULL(NULLIF(PATINDEX(@pat,competitive_dsgn_attr),0)-1,0),''),'')  
	  ,ford_intended_dsgn_attr  = IsNull(STUFF(ford_intended_dsgn_attr,1,ISNULL(NULLIF(PATINDEX(@pat,ford_intended_dsgn_attr),0)-1,0),''),'') 
	  ,comments                 = IsNull(STUFF(comments,1,ISNULL(NULLIF(PATINDEX(@pat,comments),0)-1,0),''),'') 
  FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO s35
 WHERE s35.Processing_ID       = @GUID
;

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,GETUTCDATE() 
             ,@CDSID
             ,GETUTCDATE()
             ,@CDSID
			 ,''
			 ,'PARWP_DAII_SCRUB_SPCL_CHAR' 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH



GO
