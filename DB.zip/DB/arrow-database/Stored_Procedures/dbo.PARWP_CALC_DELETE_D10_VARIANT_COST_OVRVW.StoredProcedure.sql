SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 12/03/2021
-- Description:	Procedure to Delete the d10 variant cost ovrvw dump
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- rwesley2   02-08-2022  US3273098 add ARWU01_CCTSS_K to table, load and read (clone)2c) SPs.  Delete b       y U01 instead of U04
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_DELETE_D10_VARIANT_COST_OVRVW]
@ARWU01_CCTSS_K        INTEGER
AS
--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

  Delete PARWD10_VARIANT_COST_OVRVW 
   Where ARWU01_CCTSS_K    = @ARWU01_CCTSS_K  
  ;

--    Select OBJECT_NAME(@@PROCID) as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
