SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- ============================================================================================
-- Author:		btemkow
-- Create date: 11/19/2019
-- Description:	This SP either deletes a CCTSS entirely, or resets it (deletes all of its
--              data but leaves the initial CCTSS setup intact (Variants, Designs, Suppliers)
--              so that users can start over and re-import the files.
-- Input Parameters:
--		 @ARWU01_CCTSS_K
--		,@DELETE_OR_RESET
--		,@LSTUPDT_USER_C
-- Output:
--		@RESULT - Returns 'SUCCESS' if successful, SQL error message if error occurred
-- How to Run: First declare and set input parameters, then 
--	  EXECUTE @RC = [dbo].[PARWP_DELETE_CCTSS] 
--		 @ARWU01_CCTSS_K
--		,@DELETE_OR_RESET
--		,@LSTUPDT_USER_C
--		,@RESULT OUTPUT
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow	  11/19/2019  initial version (DB ver. 1.26 compatible)
-- btemkow    11/20/2019  added deletes for U85-U91 (1.27 compatible)
-- btemkow    01/14/2020  added delete for U14 (1.28 compatible)
-- btemkow    02/11/2020  added update to U01 when 'R' (Reset) option is selected 
-- btemkow    02/27/2020  added deletes for U63 and A47; refactored U18 delete to accomodate
-- btemkow    03/02/2020  removed deletes from U36, U45 and U64 because of UI issues
-- btemkow    03/25/2020  added deletes for the 14 new MNLSLCT_STAT tables
-- btemkow    03/25/2020  added additional deletes for the 14 MNLSLCT tables because the keys
--                        used to delete them are now NULLable; new deletes based on other keys
-- btemkow    06/02/2020  added new delete for U63 based on U04_K since FK to U04 was added
-- asolosky   10/28/2020  US2026025 added template Ver_K to the reset for U01, U08, U09
-- asolosky   11/16/2020  I removed the comments around the U36 and U45 delete tables because I was getting a FK constraint error when deleting my BoB
-- btemkow    01/12/2021  removed comments around (added deletes back in) for U64, like for U36, U45. see change on 03/02/2020
-- btemkow    01/12/2021  removed Ford End Item deletes (commented out the A47 deletes)
-- asolosky   03/18/2021  Commented out for now.  New user story was created to do the delete of Tygra added call to procedure PARWP_DELETE_REVISION_CCTSS_TYGRA to delete Tygra data mapped to a BoB
-- asolosky   03/18/2021  US2385952 Table PARWU63_BOM_PART_END_ITM was changed to PARWU63_VRNT_BOM_PART_END_ITM
-- btemkow    04/28/2021  added delete for the new U15 table
-- btemkow    05/26/2021  added deletes for the new UB7 and UB8 tables
-- asolosky   03/18/2021  US2748203 Database change on ARWU01_BNCHMK_VRNT_N, ARWU04_VRNT_N from 128 to 256 character. Updated parameters to MAX
-- asolosky   08/19/2021  US2778994 Added UB9 and UC0 to the U01 Delete area. Added UA9,UB0,UC1,UC2 to the U04 Delete area. Only UA9 and UB0 tables are not touched on Reset.
-- asolosky   08/19/2021  US2393782 Added PARWP_DELETE_REVISION_CCTSS_TYGRA in the U01 Delete area. This is for UB5 and UB6, only deletes. No action on BoB Reset.
-- btemkow    09/09/2021  US2867461 updated UC2 table reference from the old (PARWUC2_VRNT_ATTR_LVL_VRNT) to the new (PARWUC2_DC_COST_TRGT_VRNT_SUPL) and moved it to the U09 delete section
-- btemkow    10/08/2021  US2963522 UC2 and UC3 are deleted during both Resets and Deletes. Action Detail text fields on UC1 are cleared during Resets.
-- btemkow    10/14/2021  US2945196 Changed the parameters for the procedure to be invoked by the UI
-- Asolosky   01/07/2021  US1859270   Added new logic (PARWP_CALC_MASTER_LOAD_PRIMARY) for populating the Calc tables
-- btemkow    2022-03-14  US3416696 Added deletes for UC6, UC7 and UC8
-- btemkow    2022-03-16  US3425919 Added deletes for UC4 and UC5
-- asolosky   2022-03-28  DE249449 Had to move D table delete to the top of the procedure.
-- btemkow    2022-05-14  US3619811 Added UD1 delete to U04_K section
-- btemkow    2022-05-24  US3592087 Added Secondary table delete
-- btemkow    2022-07-07  US3808449 Added deletes for VII tables
-- ============================================================================================


CREATE OR ALTER PROCEDURE [dbo].[PARWP_DELETE_CCTSS] 
 @ARWU01_CCTSS_K int
,@DELETE_OR_RESET char(1)  --'D' Delete or 'R' Reset
,@LSTUPDT_USER_C varchar(8)
,@RESULT VARCHAR(MAX) OUTPUT

AS

SET NOCOUNT ON;

BEGIN TRY
 DECLARE @Primary_delete_error  VARCHAR(5000);
 DECLARE @Secondary_delete_error VARCHAR(5000);

 DECLARE @TIME_STAMP            DATETIME = GETUTCDATE();
 DECLARE @u01_Study             Varchar(100);
 Set @u01_Study = (Select U01.ARWU31_CTSP_N    + ' ' +
                          U01.ARWA06_RGN_C     + ' ' +
                   	      substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	      substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                     from PARWU01_CCTSS_FLAT  U01
                    where U01.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
 				  );

 --get study method which will be used to determine if the study is DC or not
 Declare @DC_Study_F              varchar(1);
 execute @DC_Study_F = dbo.PARWF_IS_STUDY_DC @ARWU01_CCTSS_K


	BEGIN TRANSACTION
	---------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table Deletes 
--++++++++++++++++++++++++++++++++++++++++++++++++

    EXEC [dbo].[PARWP_CALC_MASTER_DELETE_PRIMARY] 
         @U01_k                = @ARWU01_CCTSS_K
       , @U06_k                = -1
       , @U04_k                = -1
       , @CDSID                = @LSTUPDT_USER_C   
       , @TRIGGER              = 'STUDY DELETE'
       , @Primary_delete_error = @Primary_delete_error OUTPUT
    ;   

   EXEC [dbo].[PARWP_CALC_MASTER_DELETE_SECONDARY] 
         @U01_k                = @ARWU01_CCTSS_K
       , @DC_Study_F		   = @DC_Study_F
       , @CDSID                = @LSTUPDT_USER_C   
       , @Secondary_delete_error = @Secondary_delete_error OUTPUT
    ;   

If (@Primary_delete_error = '' and @Secondary_delete_error = '')
Begin
	--select 1/0;
      
	--U09 delete keys
	declare @U09_delete_keys table (
	ARWU09_CCTSS_VRNT_SUPL_K int
	)

	insert into @U09_delete_keys
	select ARWU09_CCTSS_VRNT_SUPL_K
	from PARWU09_CCTSS_VRNT_SUPL_FLAT
	where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWUE2_VII_MNLSLCT_FNL_ASSY
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUE1_VII_MNLSLCT_SUB_ASSY
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUE0_VII_MNLSLCT_BOM_PART
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUD9_SUPL_VRNT_IMPRV
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUD8_FNL_ASSY_VRNT_IMPRV
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUD7_ASSY_VRNT_IMPRV
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUD6_PROCG_VRNT_IMPRV
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUD5_RAW_MTRL_VRNT_IMPRV
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUD4_PURC_PART_VRNT_IMPRV
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU84_VA_MNLSLCT_FNL_ASSY
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU83_VA_MNLSLCT_SUB_ASSY
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU82_VA_MNLSLCT_BOM_PART
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU81_SUPL_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU72_FNLASSY_MRKP_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU71_FNL_ASSY_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU70_MFG_MRKP_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU69_ASSY_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU68_PROCG_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU67_RAW_MTRL_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWU66_PURC_PART_VRNT_ADJ
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	delete from PARWUC2_DC_COST_TRGT_VRNT_SUPL
	where ARWU09_CCTSS_VRNT_SUPL_K in (
		select ARWU09_CCTSS_VRNT_SUPL_K
		from @U09_delete_keys
	)

	if (@DELETE_OR_RESET = 'R')
	begin
		update PARWU09_CCTSS_VRNT_SUPL
		set
				ARWA22_VRNT_SUPL_QTE_STAT_K = (select ARWA22_VRNT_SUPL_QTE_STAT_K from PARWA22_VRNT_SUPL_QTE_STAT 
				where ARWA22_VRNT_SUPL_QTE_STAT_N = 'Not Imported')
			,ARWU09_VA_LAST_IMPT_FILE_N = ''
			,ARWU09_VA_LAST_IMPT_S = '9999-12-31'
			,ARWU09_VA_LAST_IMPT_USER_C = ''
			,ARWU09_LAST_UPDT_S = GETUTCDATE()
			,ARWU09_LAST_UPDT_USER_C = @LSTUPDT_USER_C
			,ARWA52_VA_FILE_VER_K = (Select ARWA52_VA_FILE_VER_K from PARWA52_VA_FILE_VER Where ARWA52_VA_FILE_VER_N = '')
		where ARWU09_CCTSS_VRNT_SUPL_K in (
			select ARWU09_CCTSS_VRNT_SUPL_K
			from @U09_delete_keys
		)
	end
	else
	begin

		delete from PARWU09_CCTSS_VRNT_SUPL
		where ARWU09_CCTSS_VRNT_SUPL_K in (
			select ARWU09_CCTSS_VRNT_SUPL_K
			from @U09_delete_keys
	)
	end
	---------------------------------------------------------------
	--U08 delete keys
	declare @U08_delete_keys table (
	ARWU08_CCTSS_DSGN_SUPL_K int
	)

	insert into @U08_delete_keys
	select ARWU08_CCTSS_DSGN_SUPL_K
	from PARWU08_CCTSS_DSGN_SUPL_FLAT
	where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWU80_II_MNLSLCT_FNL_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU79_II_MNLSLCT_SUB_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU78_II_MNLSLCT_BOM_PART
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU77_DA_MNLSLCT_FNL_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU76_DA_MNLSLCT_SUB_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU75_DA_MNLSLCT_BOM_PART
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU74_SUPL_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU73_SUPL_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU62_MNLSLCT_FNL_ASSY_MRKP
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU61_MNLSLCT_FNL_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU60_MNLSLCT_SUB_ASSY_MRKP
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU59_MNLSLCT_SUB_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU58_MNLSLCT_DSGN_PART
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU56_SUPL_SUB_ASSY
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU55_SUPL_DSGN_PART
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU54_FNLASSYMRKP_DSGN_IMPV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU53_FNL_ASSY_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU52_MFG_MRKP_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU51_ASSY_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU50_PROCG_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU49_RAW_MTRL_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU48_PURC_PART_DSGN_IMPRV
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU44_FNLASSY_MRKP_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU43_FNL_ASSY_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU42_MFG_MRKP_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU41_ASSY_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU40_PROCG_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU39_RAW_MTRL_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU38_PURC_PART_DSGN_ADJ
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU30_FNL_ASSY_MRKP
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU29_FNL_ASSY_COST
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU28_MFG_MRKP
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU27_ASSY_COST
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU26_PROCG_COST
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU25_RAW_MTRL_COST
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	delete from PARWU24_PURC_PART_COST_PARNT
	where ARWU23_PURC_PART_COST_K in (
		select ARWU23_PURC_PART_COST_K
		from PARWU23_PURC_PART_COST as U23
		join @U08_delete_keys as U08_del
			on U23.ARWU08_CCTSS_DSGN_SUPL_K = U08_del.ARWU08_CCTSS_DSGN_SUPL_K
	)

	delete from PARWU23_PURC_PART_COST
	where ARWU08_CCTSS_DSGN_SUPL_K in (
		select ARWU08_CCTSS_DSGN_SUPL_K
		from @U08_delete_keys
	)

	if (@DELETE_OR_RESET = 'R')
	begin
		update PARWU08_CCTSS_DSGN_SUPL
		set
			ARWA24_DSGN_SUPL_QTE_STAT_K = (select ARWA24_DSGN_SUPL_QTE_STAT_K from PARWA24_DSGN_SUPL_QTE_STAT
			where ARWA24_DSGN_SUPL_QTE_STAT_N = 'Not Imported')
		,ARWU08_DSGN_SUPL_QTE_A = 0
		,ARWU08_CCS_LAST_IMPT_FILE_N = ''
		,ARWU08_CCS_LAST_IMPT_S = '9999-12-31'
		,ARWU08_CCS_LAST_IMPT_USER_C = ''
		,ARWA23_DSGNADJ_SUPL_QTE_STAT_K = (select ARWA23_DSGNADJ_SUPL_QTE_STAT_K from PARWA23_DSGNADJ_SUPL_QTE_STAT
			where ARWA23_DSGNADJ_SUPL_QTE_STAT_N = 'Not Imported')
		,ARWU08_DAII_LAST_IMPT_FILE_N = ''
		,ARWU08_DAII_LAST_IMPT_S = '9999-12-31'
		,ARWU08_DAII_LAST_IMPT_USER_C = ''
		,ARWU08_FNL_ASSY_DIR_LBR_A = 0
		,ARWU08_FNL_ASSY_DIR_FRNG_A = 0
		,ARWU08_FNL_ASSY_INDIR_LBR_A = 0
		,ARWU08_FNL_ASSY_INDIR_FRNG_A = 0
		,ARWU08_FNL_ASSY_OVRHD_A = 0
		,ARWU08_FNL_ASSY_MISC_A = 0
		,ARWU08_FNL_ASSY_TOT_A = 0
		,ARWU08_FNL_ASSY_TOT_W_MRKP_A = 0
		,ARWU08_LAST_UPDT_S = GETUTCDATE()
		,ARWU08_LAST_UPDT_USER_C = @LSTUPDT_USER_C
		,ARWA50_CCS_FILE_VER_K  = (Select ARWA50_CCS_FILE_VER_K  from PARWA50_CCS_FILE_VER  Where ARWA50_CCS_FILE_VER_N  = '')
		,ARWA51_DAII_FILE_VER_K = (Select ARWA51_DAII_FILE_VER_K from PARWA51_DAII_FILE_VER Where ARWA51_DAII_FILE_VER_N = '')
		where ARWU08_CCTSS_DSGN_SUPL_K in (
			select ARWU08_CCTSS_DSGN_SUPL_K
			from @U08_delete_keys
		)
	end
	else
	begin
		delete from PARWU08_CCTSS_DSGN_SUPL
		where ARWU08_CCTSS_DSGN_SUPL_K in (
			select ARWU08_CCTSS_DSGN_SUPL_K
			from @U08_delete_keys
	)
	end

	---------------------------------------------------------------
	--U07 delete keys
	declare @U07_delete_keys table (
	ARWU07_CCTSS_SUPL_K int
	)

	insert into @U07_delete_keys
	select ARWU07_CCTSS_SUPL_K
	from PARWU07_CCTSS_SUPL_FLAT
	where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWU22_SUPL_CRCY_EXCHG_RATE
	where ARWU07_CCTSS_SUPL_K in (
		select ARWU07_CCTSS_SUPL_K
		from @U07_delete_keys
	)

	delete from PARWU21_CCTSS_SUPL_CRCY
	where ARWU07_CCTSS_SUPL_K in (
		select ARWU07_CCTSS_SUPL_K
		from @U07_delete_keys
	)

	if (@DELETE_OR_RESET = 'D')
	begin
		delete from PARWU13_CCTSS_SUPL_DSPLY
		where ARWU07_CCTSS_SUPL_K in (
			select ARWU07_CCTSS_SUPL_K
			from @U07_delete_keys
		)

		delete from PARWU12_CCTSS_SUPL_TARFF_RATE
		where ARWU07_CCTSS_SUPL_K in (
			select ARWU07_CCTSS_SUPL_K
			from @U07_delete_keys
		)

		delete from PARWU07_CCTSS_SUPL
		where ARWU07_CCTSS_SUPL_K in (
			select ARWU07_CCTSS_SUPL_K
			from @U07_delete_keys
		)
	end

	---------------------------------------------------------------
	--U06 delete keys
	declare @U06_delete_keys table (
	ARWU06_CCTSS_DSGN_K int
	)

	insert into @U06_delete_keys
	select ARWU06_CCTSS_DSGN_K
	from PARWU06_CCTSS_DSGN_FLAT
	where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWUC8_TRDOFF_ACTN_DTL_DSGN
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWUC5_CNSTR_SYS_VRNT_BM_DSGN
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWUA5_II_MNLSLCT_FNL_ASSY_STAT
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWUA4_II_MNLSLCT_SUB_ASSY_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWUA3_II_MNLSLCT_BOM_PART_STAT
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWUA2_DA_MNLSLCT_FNL_ASSY_STAT
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWUA1_DA_MNLSLCT_SUB_ASSY_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWUA0_DA_MNLSLCT_BOM_PART_STAT
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU99_MNLSLCT_FNLASSYMKRP_STAT
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU98_MNLSLCT_FNL_ASSY_STAT
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU97_MNLSLCT_SUBASSYMKRP_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWU96_MNLSLCT_SUB_ASSY_STAT
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU80_II_MNLSLCT_FNL_ASSY
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU79_II_MNLSLCT_SUB_ASSY
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU78_II_MNLSLCT_BOM_PART
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU77_DA_MNLSLCT_FNL_ASSY
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU76_DA_MNLSLCT_SUB_ASSY
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU75_DA_MNLSLCT_BOM_PART
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU62_MNLSLCT_FNL_ASSY_MRKP
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU61_MNLSLCT_FNL_ASSY
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU60_MNLSLCT_SUB_ASSY_MRKP
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU59_MNLSLCT_SUB_ASSY
	where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
		select ARWU57_CCTSS_DSGN_SUB_ASSY_K
		from PARWU57_CCTSS_DSGN_SUB_ASSY as U57
		join @U06_delete_keys as U06_del
			on U57.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)
	
	delete from PARWU57_CCTSS_DSGN_SUB_ASSY
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU87_DSGN_IMPRV_TRDOFF
	where ARWU46_CCTSS_DSGN_IMPRV_K in (
		select ARWU46_CCTSS_DSGN_IMPRV_K
		from PARWU46_CCTSS_DSGN_IMPRV as U46
		join @U06_delete_keys as U06_del
			on U46.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWU47_DSGN_IMPRV_LVL2_CATG
	where ARWU46_CCTSS_DSGN_IMPRV_K in (
		select ARWU46_CCTSS_DSGN_IMPRV_K
		from PARWU46_CCTSS_DSGN_IMPRV as U46
		join @U06_delete_keys as U06_del
			on U46.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWU46_CCTSS_DSGN_IMPRV
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU45_CCTSS_DSGN_IMPRV_GRP
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU86_DSGN_ADJ_TRDOFF
	where ARWU37_CCTSS_DSGN_ADJ_K in (
		select ARWU37_CCTSS_DSGN_ADJ_K
		from PARWU37_CCTSS_DSGN_ADJ as U37
		join @U06_delete_keys as U06_del
			on U37.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWU37_CCTSS_DSGN_ADJ
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	delete from PARWU36_CCTSS_DSGN_ADJ_GRP
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)


	delete from PARWU95_MNLSLCT_DSGN_PART_STAT
	where ARWU19_DSGN_PART_K in (
		select ARWU19_DSGN_PART_K
		from PARWU19_DSGN_PART as U19
		join @U06_delete_keys as U06_del
			on U19.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	--2nd delete attempt on this table (because U08 key can be NULL)
	delete from PARWU58_MNLSLCT_DSGN_PART
	where ARWU19_DSGN_PART_K in (
		select ARWU19_DSGN_PART_K
		from PARWU19_DSGN_PART as U19
		join @U06_delete_keys as U06_del
			on U19.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWU20_DSGN_PART_GRP_IX
	where ARWU19_DSGN_PART_K in (
		select ARWU19_DSGN_PART_K
		from PARWU19_DSGN_PART as U19
		join @U06_delete_keys as U06_del
			on U19.ARWU06_CCTSS_DSGN_K = U06_del.ARWU06_CCTSS_DSGN_K
	)

	delete from PARWU19_DSGN_PART
	where ARWU06_CCTSS_DSGN_K in (
		select ARWU06_CCTSS_DSGN_K
		from @U06_delete_keys
	)

	if (@DELETE_OR_RESET = 'R')
	begin
		update PARWU06_CCTSS_DSGN
		set 
			ARWU06_DSGN_BOB_A = 0
		,ARWU06_FNLASSY_ORIG_BOB_A = 0
		,ARWU06_FNLASSY_ORIG_BOB_MRKP_P = 0
		,ARWU06_LAST_UPDT_S = GETUTCDATE()
		,ARWU06_LAST_UPDT_USER_C = @LSTUPDT_USER_C
		where ARWU06_CCTSS_DSGN_K in (
			select ARWU06_CCTSS_DSGN_K
			from @U06_delete_keys
		)
	end
	else
	begin
		delete from PARWU14_CCTSS_DSGN_DSPLY
		where ARWU06_CCTSS_DSGN_K in (
			select ARWU06_CCTSS_DSGN_K
			from @U06_delete_keys
		)

		delete from PARWU06_CCTSS_DSGN
		where ARWU06_CCTSS_DSGN_K in (
			select ARWU06_CCTSS_DSGN_K
			from @U06_delete_keys
		)
	end

	---------------------------------------------------------------
	--U04 delete keys
	declare @U04_delete_keys table (
	ARWU04_CCTSS_VRNT_K int
	)

	insert into @U04_delete_keys
	select ARWU04_CCTSS_VRNT_K
	from PARWU04_CCTSS_VRNT_FLAT
	where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWUD1_CCTSS_VRNT_RISK
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUE5_VII_MNLSLCT_FNL_ASSY_STAT
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUE4_VII_MNLSLCT_SUB_ASSY_STAT
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUE3_VII_MNLSLCT_BOM_PART_STAT
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUA8_VA_MNLSLCT_FNL_ASSY_STAT
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUA7_VA_MNLSLCT_SUB_ASSY_STAT
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUA6_VA_MNLSLCT_BOM_PART_STAT
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	--2nd delete attempt on this table (because U09 key can be NULL)
	delete from PARWUE2_VII_MNLSLCT_FNL_ASSY
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	--2nd delete attempt on this table (because U09 key can be NULL)
	delete from PARWUE1_VII_MNLSLCT_SUB_ASSY
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	--2nd delete attempt on this table (because U09 key can be NULL)
	delete from PARWUE0_VII_MNLSLCT_BOM_PART
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	--2nd delete attempt on this table (because U09 key can be NULL)
	delete from PARWU84_VA_MNLSLCT_FNL_ASSY
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	--2nd delete attempt on this table (because U09 key can be NULL)
	delete from PARWU83_VA_MNLSLCT_SUB_ASSY
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	--2nd delete attempt on this table (because U09 key can be NULL)
	delete from PARWU82_VA_MNLSLCT_BOM_PART
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWUD3_VRNT_IMPRV_TRDOFF
	where ARWUD2_CCTSS_VRNT_IMPRV_K in (
		select ARWUD2_CCTSS_VRNT_IMPRV_K
		from PARWUD2_CCTSS_VRNT_IMPRV as UD2
		join @U04_delete_keys as U04_del
			on UD2.ARWU04_CCTSS_VRNT_K = U04_del.ARWU04_CCTSS_VRNT_K
	)

	delete from PARWUD2_CCTSS_VRNT_IMPRV
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWU91_VRNT_ADJ_TRDOFF
	where ARWU65_CCTSS_VRNT_ADJ_K in (
		select ARWU65_CCTSS_VRNT_ADJ_K
		from PARWU65_CCTSS_VRNT_ADJ as U65
		join @U04_delete_keys as U04_del
			on U65.ARWU04_CCTSS_VRNT_K = U04_del.ARWU04_CCTSS_VRNT_K
	)

	delete from PARWU65_CCTSS_VRNT_ADJ
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

	delete from PARWU64_CCTSS_VRNT_ADJ_GRP
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)


	delete from PARWU63_VRNT_BOM_PART_END_ITM
	where ARWU04_CCTSS_VRNT_K in (
		select ARWU04_CCTSS_VRNT_K
		from @U04_delete_keys
	)

    delete UB0
		From PARWUB0_VRNT_END_ITM_SUB_ASSY  UB0
		Join PARWUA9_VRNT_END_ITM           UB9
		On UB9.ARWUA9_VRNT_END_ITM_K = UB0.ARWUA9_VRNT_END_ITM_K
		Where UB9.ARWU04_CCTSS_VRNT_K  in (select ARWU04_CCTSS_VRNT_K	from @U04_delete_keys);

	delete from PARWUA9_VRNT_END_ITM
		where ARWU04_CCTSS_VRNT_K in (select ARWU04_CCTSS_VRNT_K from @U04_delete_keys);

	delete from PARWUC3_DC_ATTR_LVL_STKHLDR
	where ARWUC1_DC_ATTR_PERF_LVL_VRNT_K in (
		select ARWUC1_DC_ATTR_PERF_LVL_VRNT_K
		from PARWUC1_DC_ATTR_PERF_LVL_VRNT
		where ARWU04_CCTSS_VRNT_K in (
			select ARWU04_CCTSS_VRNT_K
			from @U04_delete_keys
		)
	)

	if (@DELETE_OR_RESET = 'D')
	begin

		declare @UB7_keys table (
			ARWUB7_CNSTR_SYS_K int
		)

		insert into @UB7_keys
		select UB7.ARWUB7_CNSTR_SYS_K
		from PARWUB7_CNSTR_SYS as UB7
		join PARWUB8_CNSTR_SYS_VRNT as UB8
			on UB7.ARWUB7_CNSTR_SYS_K = UB8.ARWUB7_CNSTR_SYS_K
			and UB8.ARWU04_CCTSS_VRNT_K in (
				select ARWU04_CCTSS_VRNT_K
				from @U04_delete_keys
			)

		delete from PARWUB8_CNSTR_SYS_VRNT
		where ARWU04_CCTSS_VRNT_K in (
			select ARWU04_CCTSS_VRNT_K
			from @U04_delete_keys
		)
				
		--delete any Systems that are left without any Variants after
		--the Variants in this BoB are deleted
		delete from PARWUB7_CNSTR_SYS
		where ARWUB7_CNSTR_SYS_K in (
			select UB7_K.ARWUB7_CNSTR_SYS_K from @UB7_keys as UB7_K
			left join PARWUB8_CNSTR_SYS_VRNT as UB8
				on UB7_K.ARWUB7_CNSTR_SYS_K = UB8.ARWUB7_CNSTR_SYS_K
			where UB8.ARWUB7_CNSTR_SYS_K is null
		)

		delete from PARWUC1_DC_ATTR_PERF_LVL_VRNT
		where ARWU04_CCTSS_VRNT_K in (
			select ARWU04_CCTSS_VRNT_K
			from @U04_delete_keys
		);

		delete from PARWU05_CCTSS_VRNT_CCM
		where ARWU04_CCTSS_VRNT_K in (
			select ARWU04_CCTSS_VRNT_K
			from @U04_delete_keys
		)

		delete from PARWU04_CCTSS_VRNT
		where ARWU04_CCTSS_VRNT_K in (
			select ARWU04_CCTSS_VRNT_K
			from @U04_delete_keys
		)
	end
	else   /* Reset - clear Action Details text fields */
	begin
		update PARWUC1_DC_ATTR_PERF_LVL_VRNT
		set  ARWUC1_LAST_UPDT_S = GETUTCDATE()
			,ARWUC1_LAST_UPDT_USER_C = @LSTUPDT_USER_C
			,ARWUC1_DC_ATTR_LVL_PROS_X = ''
			,ARWUC1_DC_ATTR_LVL_CONS_X = ''
			,ARWUC1_DC_ATTR_LVL_RECMD_RTNL_X = ''
		where ARWU04_CCTSS_VRNT_K in (
			select ARWU04_CCTSS_VRNT_K
			from @U04_delete_keys
		)
		and (ARWUC1_DC_ATTR_LVL_PROS_X <> '' 
				or ARWUC1_DC_ATTR_LVL_CONS_X <> ''
				or ARWUC1_DC_ATTR_LVL_RECMD_RTNL_X <> ''
		)
	end

	------------------------------------------------------------------------------
	--U18_A47 delete keys  (includes the A47 keys related to the U18 keys)
	declare @U18_A47_delete_keys table (
			ARWU18_BOM_PART_K int
		,ARWA47_FORD_END_ITM_K int
	)

	insert into @U18_A47_delete_keys
	select
			U18.ARWU18_BOM_PART_K
		,A47.ARWA47_FORD_END_ITM_K
	from PARWU01_CCTSS_FLAT as U01_FLAT
	join PARWU18_BOM_PART as U18 
		on U01_FLAT.ARWU01_CCTSS_K = U18.ARWU01_CCTSS_K
	left join PARWU63_VRNT_BOM_PART_END_ITM as U63
		on U18.ARWU18_BOM_PART_K = U63.ARWU18_BOM_PART_K
	left join PARWA47_FORD_END_ITM as A47
		on U63.ARWA47_FORD_END_ITM_K = A47.ARWA47_FORD_END_ITM_K
	where U01_FLAT.ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWU63_VRNT_BOM_PART_END_ITM
	where ARWU18_BOM_PART_K in (
		select ARWU18_BOM_PART_K
		from @U18_A47_delete_keys
	)

	delete from PARWU18_BOM_PART
	where ARWU18_BOM_PART_K in (
		select ARWU18_BOM_PART_K
		from @U18_A47_delete_keys
	)
/*
	--++++++++++++++++++++++++++++++++++++++++++++++
	-- Delete any Ford End Items that were used only
	-- for BOM Parts that were just deleted
	--++++++++++++++++++++++++++++++++++++++++++++++
	delete from PARWA47_FORD_END_ITM
	where ARWA47_FORD_END_ITM_K in (
		select A47_del.ARWA47_FORD_END_ITM_K
		from @U18_A47_delete_keys as A47_del
		left join PARWU63_BOM_PART_END_ITM as U63
			on A47_del.ARWA47_FORD_END_ITM_K = U63.ARWA47_FORD_END_ITM_K
		where U63.ARWA47_FORD_END_ITM_K is null
	)
*/
	---------------------------------------------------------------
	--U01 delete keys
	declare @U01_delete_keys table (
	ARWU01_CCTSS_K int
	)

	insert into @U01_delete_keys
	select ARWU01_CCTSS_K
	from PARWU01_CCTSS_FLAT
	where ARWU01_CCTSS_K = @ARWU01_CCTSS_K

	delete from PARWUC4_CCTSS_COST_TRGT_DSGN_TYPE
	where ARWU01_CCTSS_K in (
		select ARWU01_CCTSS_K
		from @U01_delete_keys
	)

	delete from PARWU90_CCTSS_RISK
	where ARWU01_CCTSS_K in (
		select ARWU01_CCTSS_K
		from @U01_delete_keys
	)

	delete from PARWUC7_TRDOFF_ACTN_DTL_STKHLDR
	where ARWUC6_TRDOFF_ACTN_DTL_K in (
		select ARWUC6_TRDOFF_ACTN_DTL_K
		from PARWUC6_TRDOFF_ACTN_DTL
		where ARWU85_CCTSS_TRDOFF_K in (
			select ARWU85_CCTSS_TRDOFF_K
			from PARWU85_CCTSS_TRDOFF
			where ARWU01_CCTSS_K in (
				select ARWU01_CCTSS_K
				from @U01_delete_keys
			)
		)
	)

	delete from PARWUC6_TRDOFF_ACTN_DTL
	where ARWU85_CCTSS_TRDOFF_K in (
		select ARWU85_CCTSS_TRDOFF_K
		from PARWU85_CCTSS_TRDOFF
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)
	)

	delete from PARWU89_TRDOFF_LVL2_CATG
	where ARWU85_CCTSS_TRDOFF_K in (
		select ARWU85_CCTSS_TRDOFF_K from PARWU85_CCTSS_TRDOFF as U85
		join @U01_delete_keys as U01_del
			on U85.ARWU01_CCTSS_K = U01_del.ARWU01_CCTSS_K
	)

	delete from PARWU88_CCTSS_TRDOFF_REF
	where ARWU85_CCTSS_TRDOFF_K in (
		select ARWU85_CCTSS_TRDOFF_K from PARWU85_CCTSS_TRDOFF as U85
		join @U01_delete_keys as U01_del
			on U85.ARWU01_CCTSS_K = U01_del.ARWU01_CCTSS_K
	)

	delete from PARWU85_CCTSS_TRDOFF
	where ARWU01_CCTSS_K in (
		select ARWU01_CCTSS_K
		from @U01_delete_keys
	)

	delete from PARWU17_BOM_SUB_ASSY
	where ARWU01_CCTSS_K in (
		select ARWU01_CCTSS_K
		from @U01_delete_keys
	)

	if (@DELETE_OR_RESET = 'R')
	begin
		update PARWU01_CCTSS
		set
				ARWA45_PBOM_STAT_K = (select ARWA45_PBOM_STAT_K from PARWA45_PBOM_STAT
				where ARWA45_PBOM_STAT_N = 'Not Imported')						
			,ARWU01_PBOM_LAST_IMPT_FILE_N = ''
			,ARWU01_PBOM_LAST_IMPT_S = '9999-12-31'
			,ARWU01_PBOM_LAST_IMPT_USER_C = ''
			,ARWU01_LAST_UPDT_S = GETUTCDATE()
			,ARWU01_LAST_UPDT_USER_C = @LSTUPDT_USER_C
			--,ARWU01_TRGT_CMPLTN_Y    = '9999-12-31'
			--,ARWU01_MTCH_PAIR_Y      = '9999-12-31'
			,ARWA49_PBOM_FILE_VER_K  = (Select ARWA49_PBOM_FILE_VER_K from PARWA49_PBOM_FILE_VER Where ARWA49_PBOM_FILE_VER_N = '')
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)
	end
	else
	begin
		--Delete UB5 and UB6 Tygra tables
        Declare @U01_k int;
    	Select @U01_k = (Select ARWU01_CCTSS_K from @U01_delete_keys);
    	EXEC [dbo].PARWP_DELETE_REVISION_CCTSS_TYGRA   @ARWU01_CCTSS_K = @U01_k, @DELETE_OR_REVISION = 'D', @file_type = 0, @CDSID = @LSTUPDT_USER_C; 

        delete UC0
			From PARWUC0_DC_ATTR_PERF_LVL  UC0
			Join PARWUB9_CCTSS_DC_ATTR     UB9
			On UB9.ARWUB9_CCTSS_DC_ATTR_K = UC0.ARWUB9_CCTSS_DC_ATTR_K
			Where UB9.ARWU01_CCTSS_K in (select ARWU01_CCTSS_K	from @U01_delete_keys);

        delete 
			From PARWUB9_CCTSS_DC_ATTR  
			Where ARWU01_CCTSS_K in (select ARWU01_CCTSS_K	from @U01_delete_keys);

		delete from PARWU16_CCTSS_ENRG_SURGT_PGM
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)

		delete from PARWU15_CCTSS_WALK_CTSP
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)

		delete from PARWU11_CCTSS_TO4_MBR
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)

		delete from PARWU03_CCTSS_MRKP_RGN
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)

		delete from PARWU02_CCTSS_STAT_UPDT
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)

		delete from PARWU01_CCTSS
		where ARWU01_CCTSS_K in (
			select ARWU01_CCTSS_K
			from @U01_delete_keys
		)
	end
End --For If @Primary_delete_error = ''

If (@Primary_delete_error = '' and @Secondary_delete_error = '')
   Begin
     COMMIT TRANSACTION
     Set @RESULT = 'SUCCESS';
   End
Else
   Begin
     Rollback
     Set @RESULT =  @Primary_delete_error + ' ' + @Secondary_delete_error;
   End


END TRY

BEGIN CATCH
	ROLLBACK TRANSACTION
    SET @RESULT = 'Study Delete SYSTEM ERROR: ' +              
  	              'Study Key: '       + cast(@ARWU01_CCTSS_K as varchar(20)) + 
  	              ' |Study: '         + ISNULL(@u01_Study, '') +
  	              ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
  --              ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
  	              ' |CDS: '           + @LSTUPDT_USER_C +
  	              ' |Procedure: '     + ERROR_PROCEDURE() + 
  				  ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
  				  ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
END CATCH


GO


