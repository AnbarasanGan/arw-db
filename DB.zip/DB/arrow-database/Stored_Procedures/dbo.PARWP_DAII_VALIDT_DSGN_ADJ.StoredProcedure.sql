SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		btemkow
-- Create date: 2020-02-10
-- Description:	validates Adjustment Details tab
--              during DAII import for 'PBOM and 
--               DA UI' version BoBs
-- =============================================
-- Changes
-- =============================================
-- Date        Author    Description
-- ----------  --------  -----------------------
-- 05/04/2020  rwesley2  US1575405 removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s35.sheet_name. 
--                       Only applies to DA not II
-- =============================================
-- Author     Date     User Story  Description
-- ------     -----    ----------  -----------
-- Asolosky  07/27/2020 US1771016  Part name error message: added <LF> to display when line feed is present. 
-- Asolosky  09/11/2020 US1910882  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  06/25/2021 US2561600  Message changed for: Design Adjustment in Arrow does not appear in an Adjustment Details tab (ADJ-). 
--                                 Added more detail to say there may be blank rows in the Excel sheet.
-- Asolosky  10/19/2021 US2979369  New ERROR for: The Design Adjustment (ADJ-) Change ID sheet name does not match the sub assembly in Arrow
--                                 We had a user that selected the wrong sub-assembly in the DA manage adjustment screen and tried to fix by manually changing the ADJ sheet.
-- Asolosky  05/09/2022 US3411440  Users didn't like the message for 2nd validation
--                                 'Design Adjustment in Arrow does not appear in an Adjustment Details tab (ADJ-)'. So changed to this
--                                 'The Design Adjustement in Arrow is missing from the sheet'.  Also gave the exact sheet name where it was missing from.
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_ADJ] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Change ID in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
		,'The Change ID does not match a Design Adjustment in Arrow.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s35.sheet_name
		,S35.row_idx
		,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
		,''  --No ARROW Value
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	LEFT JOIN PARWU37_CCTSS_DSGN_ADJ as U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	WHERE S35.Processing_ID = @GUID 
		AND U37.ARWU37_CCTSS_DSGN_ADJ_ID_N IS NULL

	--++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Change ID in Arrow does not match file
	--++++++++++++++++++++++++++++++++++++++++++++++

		INSERT INTO PARWE02_BATCH_ERRORS
	SELECT
		 S34.Source_c
		,IsNull(change_id,'"Missing"')
		,'The Design Adjustment in Arrow is missing from the sheet. Also check if the import file''s Sheet has 2 or more blank rows between parts. If it does, remove the extra blank rows.' 
		,S34.Processing_ID
		,S34.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,0
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,'ADJ-' + U17.ARWU17_BOM_SUB_ASSY_N
		,0
		,U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  --ARROW change_id
		,U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  --ARROW Value
	FROM PARWS34_DAII_COVER_PAGE_INFO AS S34 
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ U37 ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
   JOIN PARWU18_BOM_PART       U18 on U18.ARWU18_BOM_PART_K        = U37.ARWU18_BOM_PART_K
   JOIN PARWU17_BOM_SUB_ASSY   U17 on U17.ARWU17_BOM_SUB_ASSY_K    = U18.ARWU17_BOM_SUB_ASSY_K
	LEFT JOIN PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
		ON S34.Processing_ID = S35.Processing_ID
		AND S34.filename = S35.filename
		AND U37.ARWU37_CCTSS_DSGN_ADJ_ID_N = S35.change_id
	WHERE S34.Processing_ID = @GUID 
		AND S35.change_id IS NULL;

	--++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Sub Assembly in Arrow does not match file
	--++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT
		 S34.Source_c
		,IsNull(Substring(S35.sheet_name,5,datalength(S35.sheet_name)),'')
		,'The Design Adjustment (ADJ-) Change ID sub assembly does not match ARROW. Verify all new Adds have the correct sub-assembly in the Manage Adjustment screen or there wasn''t a manual change in the ADJ- sheet' 
		,S34.Processing_ID
		,S34.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		--ARWE02_BATCH_ERRORS_K  Identity key
		,'ERROR'
		,S35.sheet_name
		,s35.row_idx
		,U37.ARWU37_CCTSS_DSGN_ADJ_ID_N  --ARROW change_id
		,U17.ARWU17_BOM_SUB_ASSY_N       --ARROW Value
	FROM PARWS34_DAII_COVER_PAGE_INFO         AS S34 
	JOIN PARWU06_CCTSS_DSGN_FLAT              AS U06_FLAT    
	  ON S34.User_Selected_CTSP_N            = U06_FLAT.ARWU31_CTSP_N
	 AND S34.User_Selected_CTSP_Region_C     = U06_FLAT.ARWA06_RGN_C
	 AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
	 AND S34.User_Selected_BNCMK_VRNT_N      = U06_FLAT.ARWU01_BNCHMK_VRNT_N
	 AND S34.User_Selected_VEH_MAKE_N        = U06_FLAT.ARWA14_VEH_MAKE_N
	 AND S34.User_Selected_VEH_MDL_N         = U06_FLAT.ARWA34_VEH_MDL_N
	 AND S34.User_Selected_VEH_MDL_VRNT_X    = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
	 AND S34.User_Selected_VEH_MDL_YR_C      = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ               AS U37
	  ON U06_FLAT.ARWU06_CCTSS_DSGN_K        = U37.ARWU06_CCTSS_DSGN_K
	JOIN PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	  ON S34.Processing_ID                   = S35.Processing_ID
	 AND S34.filename                        = S35.filename
	 AND U37.ARWU37_CCTSS_DSGN_ADJ_ID_N      = S35.change_id
	JOIN PARWU18_BOM_PART                     AS U18
	  ON U18.ARWU18_BOM_PART_K               = U37.ARWU18_BOM_PART_K
	Join PARWU17_BOM_SUB_ASSY                 AS U17
	  ON U17.ARWU17_BOM_SUB_ASSY_K           = U18.ARWU17_BOM_SUB_ASSY_K
	WHERE S34.Processing_ID = @GUID
	  AND Substring(S35.sheet_name,5,datalength(S35.sheet_name)) != U17.ARWU17_BOM_SUB_ASSY_N
    ;

	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Index in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')
		,'The Design Adjustment Change ID has a Part Index that does not match the ARROW Part Index. Please update the file to match ARROW.'
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s35.sheet_name
		,S35.row_idx
		,U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
		,U18.ARWU18_BOM_PART_IX_N --ARROW Value
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	JOIN PARWU18_BOM_PART AS U18
		ON U37.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K
	WHERE S35.Processing_ID = @GUID 
		AND S35.part_index <> U18.ARWU18_BOM_PART_IX_N

	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Name in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>')
		,'The Part Name does not match ARROW part name. Please update the file to match ARROW.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s35.sheet_name
		,S35.row_idx
		,S35.change_id 
		,U18.ARWU18_BOM_PART_X
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	JOIN PARWU18_BOM_PART AS U18
		ON U37.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K
	WHERE S35.Processing_ID = @GUID 
		AND S35.part_name <> U18.ARWU18_BOM_PART_X

	--+++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Type of Change in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,S35.type_of_change
		,'Type of Change does not match Change Type in Arrow. Please update the file to match ARROW.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s35.sheet_name
		,S35.row_idx
		,S35.change_id  
		,A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	JOIN PARWA40_DSGN_ADJ_PART_CHG_TYP AS A40
		ON U37.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
	WHERE S35.Processing_ID = @GUID 
		AND S35.type_of_change <> A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X

	--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Competitive Design Attribute in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,replace(replace( S35.competitive_dsgn_attr,char(10),'<LF>'),char(13),'<CR>')
		,'Competitive Design Attribute does not match Competitive DA in Arrow. Please update the file to match ARROW.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s35.sheet_name
		,S35.row_idx
		,S35.change_id  
		,U37.ARWU37_CMPETV_DSGN_ATTR_X
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	WHERE S35.Processing_ID = @GUID 
		AND S35.competitive_dsgn_attr <> U37.ARWU37_CMPETV_DSGN_ATTR_X

	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Ford Intended Design Attribute in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,replace(replace( S35.ford_intended_dsgn_attr,char(10),'<LF>'),char(13),'<CR>')
		,'Ford Intended Design Attribute does not match Ford DA in Arrow. Please update the file to match ARROW.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'ERROR'
		,s35.sheet_name
		,S35.row_idx
		,S35.change_id  
		,U37.ARWU37_FORD_INTD_DSGN_ATTR_X
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	WHERE S35.Processing_ID = @GUID 
		AND S35.ford_intended_dsgn_attr <> U37.ARWU37_FORD_INTD_DSGN_ATTR_X

	--+++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Comments in file do not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++
/*
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		 ,S35.comments
		,'Comments: ' + S35.comments + ' do not match Comments for Change ID: ' + U37.ARWU37_CCTSS_DSGN_ADJ_ID_N + ' in Arrow.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'WARNING'
		,s35.sheet_name
		,S35.row_idx
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	WHERE S35.Processing_ID = @GUID 
		AND S35.comments <> U37.ARWU37_CCTSS_DSGN_ADJ_CMT_X
*/
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Ford Spec SDS# in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		 ,S35.ford_spec_sds
		,'Ford Spec SDS#: ' + S35.ford_spec_sds + ' does not match Ford Spec SDS#: ' + U37.ARWU37_SPEC_SDS_NUM_X 
			+ ' for Change ID: ' + U37.ARWU37_CCTSS_DSGN_ADJ_ID_N + ' in Arrow.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'WARNING'
		,s35.sheet_name
		,S35.row_idx
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	WHERE S35.Processing_ID = @GUID 
		AND S35.ford_spec_sds <> U37.ARWU37_SPEC_SDS_NUM_X
*/
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Level 1 Waterfall Category in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S35.Source_c
		,S35.lvl1_waterfall_cat
		,'Level 1 Waterfall Category: ' + S35.lvl1_waterfall_cat + ' does not match Level 1: ' 
			+ coalesce(A18.ARWA18_LVL1_ADJ_CATG_ABBR_N,'') + ' for Change ID: ' + U37.ARWU37_CCTSS_DSGN_ADJ_ID_N + ' in Arrow.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'WARNING'
		,s35.sheet_name
		,S35.row_idx
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	JOIN PARWU86_DSGN_ADJ_TRDOFF AS U86
		ON U37.ARWU37_CCTSS_DSGN_ADJ_K = U86.ARWU37_CCTSS_DSGN_ADJ_K
	LEFT JOIN PARWU89_TRDOFF_LVL2_CATG AS U89
		ON U86.ARWU85_CCTSS_TRDOFF_K = U89.ARWU85_CCTSS_TRDOFF_K
	LEFT JOIN PARWA19_LVL2_ADJ_CATG AS A19
		ON U89.ARWA19_LVL2_ADJ_CATG_K = A19.ARWA19_LVL2_ADJ_CATG_K
	LEFT JOIN PARWA18_LVL1_ADJ_CATG AS A18
		ON A19.ARWA18_LVL1_ADJ_CATG_K = A18.ARWA18_LVL1_ADJ_CATG_K
	WHERE S35.Processing_ID = @GUID 
		AND S35.lvl1_waterfall_cat <> coalesce(A18.ARWA18_LVL1_ADJ_CATG_ABBR_N,'')
*/
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Level 2 Waterfall Category in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		  S35.Source_c
		 ,S35.lvl2_waterfall_cat
		,'Level 2 Waterfall Category: ' + S35.lvl2_waterfall_cat + ' does not match Level 2: ' 
			+ coalesce(A19.ARWA19_LVL2_ADJ_CATG_N,'') + ' for Change ID: ' + U37.ARWU37_CCTSS_DSGN_ADJ_ID_N + ' in Arrow.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'WARNING'
		,s35.sheet_name
		,S35.row_idx
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	JOIN PARWU86_DSGN_ADJ_TRDOFF AS U86
		ON U37.ARWU37_CCTSS_DSGN_ADJ_K = U86.ARWU37_CCTSS_DSGN_ADJ_K
	LEFT JOIN PARWU89_TRDOFF_LVL2_CATG AS U89
		ON U86.ARWU85_CCTSS_TRDOFF_K = U89.ARWU85_CCTSS_TRDOFF_K
	LEFT JOIN PARWA19_LVL2_ADJ_CATG AS A19
		ON U89.ARWA19_LVL2_ADJ_CATG_K = A19.ARWA19_LVL2_ADJ_CATG_K
	WHERE S35.Processing_ID = @GUID 
		AND S35.lvl2_waterfall_cat <> coalesce(A19.ARWA19_LVL2_ADJ_CATG_N,'')
*/
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Tough Choice Grouping in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		  S35.Source_c
		 ,S35.tough_choice_grouping
		,'Tough Choice Grouping: ' + S35.tough_choice_grouping + ' does not match Tradeoff: ' 
			+ U85.ARWU85_CCTSS_TRDOFF_X + ' for Change ID: ' + U37.ARWU37_CCTSS_DSGN_ADJ_ID_N + ' in Arrow.' 
		,S35.Processing_ID
		,S35.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S35.ARWS35_DAII_ADJUSTMENT_DETAILS_INFO_K
		,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
		,'WARNING'
		,s35.sheet_name
		,S35.row_idx
	FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO AS S35
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S35.Processing_ID = S34.Processing_ID
		AND S35.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU37_CCTSS_DSGN_ADJ AS U37
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U37.ARWU06_CCTSS_DSGN_K
		AND S35.change_id = U37.ARWU37_CCTSS_DSGN_ADJ_ID_N
	JOIN PARWU86_DSGN_ADJ_TRDOFF AS U86
		ON U37.ARWU37_CCTSS_DSGN_ADJ_K = U86.ARWU37_CCTSS_DSGN_ADJ_K
	JOIN PARWU85_CCTSS_TRDOFF AS U85
		ON U86.ARWU85_CCTSS_TRDOFF_K = U85.ARWU85_CCTSS_TRDOFF_K
	WHERE S35.Processing_ID = @GUID 
		AND S35.tough_choice_grouping <> U85.ARWU85_CCTSS_TRDOFF_X
*/

END TRY

BEGIN CATCH
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,'' 
			 ,'PARWS34_DAII_COVER_PAGE_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH
GO
