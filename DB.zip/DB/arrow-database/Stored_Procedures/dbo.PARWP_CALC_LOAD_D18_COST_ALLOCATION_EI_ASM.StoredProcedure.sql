SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO





-- =========================================================================================
-- Author:		KVIJAYAB
-- Create date: MAR/25/2021
-- Description:	This SP should be called after running [PARWP_UI_COST_ALLOCATION_EI] SP
--				For given U04 key, this SP gives the already allocated 
--				end-item cost per subassembly. And the total sub assembly cost.
--				Called from Cost Allocation screen. 
-- Input Parameter: 
--		@ARWU04_CCTSS_VRNT_K = the variant key for which the data is required, 
--		@LWST_IDC_DSGN_KEY	 = the lowest IDC design key, 
--		@PROCESSING_ID		 = the processing id that the PARWP_UI_COST_ALLOCATION_EI SP returned
-- Output: Returns the values from a select statement
-- How to Run:  Execute [PARWP_UI_COST_ALLOCATION_EI_ASM] @ARWU04_CCTSS_VRNT_K = 1, @LWST_IDC_DSGN_KEY = 55, @PROCESSING_ID = '9A447857-2946-475A-A719-69E0C668659B'
-- Changes
-- =========================================================================================
-- Author     Date         Description
-- ------     -----        -----------
-- kvijayab	  MAR/25/2021  initial version
-- rwesley2   03-18-2022   US3426269 load all variants by U01 key
-- =========================================================================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_LOAD_D18_COST_ALLOCATION_EI_ASM] 
@ARWU01_CCTSS_K INT,
@CDSID VARCHAR (8),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;
--Declare @Start_Time DATETIME = GETUTCDATE();
DECLARE @LWST_IDC_DSGN_KEY INT
SET @LWST_IDC_DSGN_KEY = (SELECT ARWU06_CCTSS_DSGN_K FROM [dbo].[PARWD06_LOWEST_IDC_DESIGN] where ARWU01_CCTSS_K = @ARWU01_CCTSS_K);

INSERT INTO PARWD18_COST_ALLOCATION_EI_ASM
	-- row wise allocation per assembly
	SELECT 
	ARWU04_CCTSS_VRNT_K,
	CONCAT('ROW_', ARWA47_FORD_END_ITM_K, '_', ARWU17_BOM_SUB_ASSY_K) AS DATATYPE, ARWA47_FORD_END_ITM_K, ARWU17_BOM_SUB_ASSY_K, ARWUB0_SUB_ASSY_ALLOC_A AS ASM_QUOTE
	,@TIME_STAMP
	,@CDSID
	,@ARWU01_CCTSS_K
	FROM PARWUA9_VRNT_END_ITM UA9
	JOIN PARWUB0_VRNT_END_ITM_SUB_ASSY UB0 ON UB0.ARWUA9_VRNT_END_ITM_K = UA9.ARWUA9_VRNT_END_ITM_K
	WHERE UA9.ARWU04_CCTSS_VRNT_K in (select ARWU04_CCTSS_VRNT_K from PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K = @ARWU01_CCTSS_K)

	UNION
	
	--total quote per assembly
	SELECT 
	ARWU04_CCTSS_VRNT_K, 
	CONCAT('TOTAL_', ARWU17_BOM_SUB_ASSY_K) AS DATATYPE, NULL AS ARWA47_FORD_END_ITM_K, ARWU17_BOM_SUB_ASSY_K, ADJ_BOB AS ASM_QUOTE
	,@TIME_STAMP
	,@CDSID
	,@ARWU01_CCTSS_K
	FROM PARWD02_BOB_DAII_ASM_SUMMARY d02
	join PARWU06_CCTSS_DSGN U06 ON u06.ARWU06_CCTSS_DSGN_K = d02.ARWU06_CCTSS_DSGN_K
	join PARWU04_CCTSS_VRNT u04 ON u04.ARWU01_CCTSS_K      = u06.ARWU01_CCTSS_K
	WHERE d02.ARWU06_CCTSS_DSGN_K = @LWST_IDC_DSGN_KEY
	and u04.ARWU04_CCTSS_VRNT_K in (select ARWU04_CCTSS_VRNT_K from PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K = @ARWU01_CCTSS_K)
	GROUP BY ARWU04_CCTSS_VRNT_K,ARWU17_BOM_SUB_ASSY_K, ADJ_BOB


--	Select OBJECT_NAME(@@PROCID) as Procedure_Name 
--      ,@@Rowcount                                 as Records_Inserted
--      ,convert(time, GETUTCDATE() - @Start_Time ) as run_time;
GO
