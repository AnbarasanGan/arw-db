DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_NUMERIC]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 01/09/2020
-- Description:	Validate the PARWS59_PBOM_PARTS staging table's numeric columns
--              Verify quantity, material usage, length, width
--              Procedure uses 2 functions to determine a value is numeric.  An empty string '' will evalute as not numeric 
--              PARWF_NUMERIC_AND_NOTEMPTY_VAL(Value) - Use when the value can't be an empty string
--              PARWF_NUMERIC_AND_EMPTY_VAL(Value)    - Use when the value can   be an empty string
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- Asolosky   02/18/2020  Removed Depth from the validation.  The column was changed from decimal to character
-- Asolosky   05/14/2020  Added diameter to the validation.
-- Rwesley2   07/14/2020  US1742436 when there is a comma in any of the dimension columns create an ERROR	
-- rwesley2   09-11-2020  US1910880 Add part index and Arrow value to error. Write error to new E02 error table	
-- Asolosky   10/12/2020  US1989948 changed the numeric message and removed the validation query for comma's that was done for US1742436 on 07/14/2020. The numeric validation will handle the error.  
-- Asolosky   10/20/2020  US1996362 Switch from E02 to E03 and include Excel column
-- Asolosky   02/11/2021  US2284375 Changed the quantity_num_f error message to include zero.
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_PBOM_VALIDT_NUMERIC] 
-- Input Parameter
 @Processing_ID Varchar(5000)
,@CDSID         Varchar(30)
,@TIME_STAMP      datetime

AS
BEGIN TRY
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Numeric Field validation
--++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
      SELECT
	   Err.[Source_c]            as ARWE03_SOURCE_C
	  ,staging_data_error_value  as ARWE03_ERROR_VALUE
	  ,error_msg                 as ARWE03_ERROR_X
	  ,Err.[Processing_ID]       as ARWE03_PROCESSING_ID
	  ,Err.file_name             as ARWE03_FILENAME
	  ,OBJECT_NAME(@@PROCID)     as ARWE03_PROCEDURE_X
	  ,@TIME_STAMP               as ARWE03_CREATE_S 
	  ,@CDSID                    as ARWE03_CREATE_USER_C 
	  ,@TIME_STAMP               as ARWE03_LAST_UPDT_S
	  ,@CDSID                    as ARWE03_LAST_UPDT_USER_C
	  ,Err.ARWS59_PBOM_PARTS     as ARWE03_BATCH_ERRORS_REF_K
	  ,'PARWS59_PBOM_PARTS'      as ARWE03_STAGING_TABLE_X
	  --ARWE03_BATCH_ERRORS_K (identity key)
	  ,'ERROR'                   as ARWE03_ERROR_TYPE_X
	  ,Err.sub_assembly_name     as ARWE03_EXCEL_TAB_X
	  ,row_idx                   as ARWE03_ROW_IDX
	  ,Err.part_index            as ARWE03_Part_Index
	  ,''                        as ARWE03_Arrow_value
	  ,error_column_Cell         as ARWE03_COLUMN
       FROM  
	   (select
			   Processing_ID
			  ,file_name
			  ,ARWS59_PBOM_PARTS
              ,Source_c
			  ,sub_assembly_name
			  ,row_idx
              ,CASE 
				    when error_col = 'quantity_num_f'           then quantity
                    when error_col = 'material_usage_num_f'     then material_usage
				    when error_col = 'material_thickness_num_f' then material_thickness
				    when error_col = 'length_num_f'             then length 
				    when error_col = 'width_num_f'              then width 
				    when error_col = 'diameter_num_f'           then diameter 
			   END as staging_data_error_value
              ,CASE 
				    when error_col = 'quantity_num_f'           then 'Quantity is missing, zero or not numeric. For Example the column can''t have values like: 0 A B c $ % + - '','' etc...' 
                    when error_col = 'material_usage_num_f'     then 'Material Usage is not numeric. For Example the column can''t have values like: A B c $ % + - '','' etc...'
				    when error_col = 'material_thickness_num_f' then 'Material Thickness is not numeric. For Example the column can''t have values like: A B c $ % + - '','' etc...'
				    when error_col = 'length_num_f'             then 'Length is not numeric. For Example the column can''t have values like: A B c $ % + - '','' etc...' 
				    when error_col = 'width_num_f'              then 'Width is not numeric. For Example the column can''t have values like: A B c $ % + - '','' etc...'   
				    when error_col = 'diameter_num_f'           then 'Diameter is not numeric. For Example the column can''t have values like: A B c $ % + - '','' etc...'   
			   END as error_msg
              ,CASE 
				    when error_col = 'quantity_num_f'           then quantity_column
                    when error_col = 'material_usage_num_f'     then material_usage_column
				    when error_col = 'material_thickness_num_f' then material_thickness_column
				    when error_col = 'length_num_f'             then length_column
				    when error_col = 'width_num_f'              then width_column
				    when error_col = 'diameter_num_f'           then diameter_column 
			   END as error_column_Cell
			  ,part_index
			 from 
             (SELECT 
 			         Processing_ID
				    ,file_name
				    ,ARWS59_PBOM_PARTS
                    ,Source_c
					,sub_assembly_name
					,row_idx
					,quantity 
					,quantity_column
					,dbo.PARWF_ISNUMERIC_AND_NOTEMPTY_VAL(quantity)        as quantity_num_f
					,material_usage
					,material_usage_column
					,dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(material_usage)      as material_usage_num_f
					,material_thickness
					,material_thickness_column
					,dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(material_thickness)  as material_thickness_num_f
					,length
					,length_column
					,dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(length)              as length_num_f
					,width
				    ,width_column          							    
					,dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(width)               as width_num_f
					,diameter
					,diameter_column
					,dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(diameter)            as diameter_num_f
					,part_index
                FROM PARWS59_PBOM_PARTS S59
               WHERE Processing_ID= @Processing_ID						
        ) S59
 
       unpivot (error_value for error_col in (
                                               quantity_num_f 
                                              ,material_usage_num_f
                                              ,material_thickness_num_f
                                              ,length_num_f
                                              ,width_num_f
											  ,diameter_num_f
          									)
               ) unpvt
        Where error_value = 0
      ) Err
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE03_BATCH_PBOM_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,NULL                              --ARWE03_BATCH_ERRORS_REF_K
		,'PARWS59_PBOM_PARTS'              --ARWE03_STAGING_TABLE_X
		--ARWE03_BATCH_ERRORS_K Identity key
		,'ERROR'                           --ARWE03_ERROR_TYPE_X
		,'SYSTEM'                          --ARWE03_EXCEL_TAB_X
		,0                                 --row_idx
        ,''                                --part_index 
		,''                                --ARROW_VALUE
		,''                                --Column
;
END CATCH;	


GO
