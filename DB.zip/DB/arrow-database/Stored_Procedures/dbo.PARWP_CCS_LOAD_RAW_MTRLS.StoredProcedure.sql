DROP PROCEDURE [dbo].[PARWP_CCS_LOAD_RAW_MTRLS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ashaik12
-- Create date: 04/01/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 06/13/2019  ASHAIK12  N/A      Make all join conditions from cover page columns to user selected columns. And Remove the join for Engineering Commodity.
-- 06/17/2019  asolosky  N/A      Change the delete from design_supplier/sub-assembly to just design_supplier
-- 06/25/2019  rwesley2  N/A      changed ROW_NUMBER function to order by stage table row_idx col
-- 06/26/2019  rwesley2  N/A      removed ROW_NUMBER function and replaced with row_idx col on U25 INSERT
-- 06/26/2019  asolosky			  Added Skip_loading_due_to_error_f to all Cover Page filters
-- 07/16/2019  asolosky			  Removed the ISNULL function from the insert because they served no purpose.  The UI writes empty string to the staging tables.
-- 08/13/2019  ashaik12           Removed the Delete Statements
-- 01/10/2020  Ashaik12           Added TimeStamp parameter and removed filter on Processing Status
-- 07/13/2020  Ashaik12           In Process Scrap % added to load procedure
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_LOAD_RAW_MTRLS] 
-- Input Parameter
@Processing_ID Varchar(5000),
@CDSID	       Varchar(30),
@TIME_STAMP DATETIME
AS

SET NOCOUNT ON;
----------------------------------------------------------------------------------------------------- 


-------------------------------------------------
INSERT INTO [dbo].[PARWU25_RAW_MTRL_COST]

SELECT
  V08.ARWU08_CCTSS_DSGN_SUPL_K as [ARWU08_CCTSS_DSGN_SUPL_K]
 ,V08.ARWU17_BOM_SUB_ASSY_K as [ARWU17_BOM_SUB_ASSY_K]
 ,raw_matrl_stage.[row_idx] AS [ARWU25_RAW_MTRL_DSPLY_SEQ_R]
 ,V08.ARWU19_DSGN_PART_K as [ARWU19_DSGN_PART_K]
 ,raw_matrl_stage.material_specification as [ARWU25_RAW_MTRL_SPEC_X]
 ,raw_matrl_stage.source_supplier as [ARWU25_SRC_SUPL_N] 
 ,Case When CNTRY.ARWA28_CNTRY_K is Null then 
		     a28_EmptyStr.ARWA28_CNTRY_K 
	   Else CNTRY.ARWA28_CNTRY_K 
  End as ARWA28_SRC_CNTRY_K
 ,CRCY.ARWA29_CRCY_K as [ARWA29_LCL_CRCY_K]
 ,raw_matrl_stage.gross_usage_per_piece as [ARWU25_GRS_USG_PER_PCE_Q]
 ,raw_matrl_stage.material_price as [ARWU25_MTRL_PEL_RATE_PER_UOM_A]
 ,raw_matrl_stage.inbound_packaging_costs as [ARWU25_INBND_PKNG_COST_UOM_A]
 ,raw_matrl_stage.inbound_logistics_costs as [ARWU25_INBND_LGSTCS_COST_UOM_A]
 ,raw_matrl_stage.tax_duty_per_uom as [ARWU25_TAX_AND_DUTY_PER_UOM_A]
 ,raw_matrl_stage.[reclamation_pcntg] as [ARWU25_RCLMTN_P]
 --,CASE WHEN raw_matrl_stage.reclamation_pcntg is NULL THEN '0' ELSE raw_matrl_stage.reclamation_pcntg*100 END AS [ARWU25_RCLMTN_P]
 ,raw_matrl_stage.[scrap_price] as [ARWU25_SCRAP_PRCE_PER_UOM_A]
 ,raw_matrl_stage.comments as [ARWU25_RAW_MTRL_ASSMP_CMT_X]
 ,@TIME_STAMP                                    AS ARWU25_CREATE_S
 ,@CDSID                                          AS ARWU25_CREATE_USER_C
 ,@TIME_STAMP                                    AS ARWU25_LAST_UPDT_S
 ,@CDSID                                          AS ARWU25_LAST_UPDT_USER_C
 ,raw_matrl_stage.[in_process_scrap_pctg]         AS [ARWU25_INPROC_SCRAP_P]
 From [dbo].[PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO] raw_matrl_stage
 JOIN [dbo].[PARWS22_CCS_COVER_PAGE_INFO] cover_page_stage
   ON cover_page_stage.Processing_ID=raw_matrl_stage.Processing_ID
  AND cover_page_stage.filename=raw_matrl_stage.filename

 -- Join with Supplier Qoute View
 JOIN [dbo].[PARWV08_CCS_SUPL_QUOTE_FLAT] V08
  ON  cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]= V08.[ARWA03_ENRG_SUB_CMMDTY_X]
 --and cover_page_stage.Eng_commodity_name   = V08.ARWA02_ENRG_CMMDTY_X
 AND cover_page_stage.[User_Selected_CTSP_N]=V08.ARWU31_CTSP_N
 AND cover_page_stage.[User_Selected_CTSP_Region_C]=V08.[ARWA06_RGN_C]
 AND cover_page_stage.[User_Selected_VEH_MAKE_N]=V08.[ARWA14_VEH_MAKE_N]
 AND cover_page_stage.[User_Selected_VEH_MDL_N]=V08.[ARWA34_VEH_MDL_N]
 AND cover_page_stage.[User_Selected_VEH_MDL_YR_C]=V08.ARWA35_DSGN_VEH_MDL_YR_C
 AND cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]=V08.ARWA35_DSGN_VEH_MDL_VRNT_X
 AND cover_page_stage.[User_Selected_BNCMK_VRNT_N]=V08.[ARWU01_BNCHMK_VRNT_N]
 AND raw_matrl_stage.part_index=V08.[ARWU18_BOM_PART_IX_N]
 AND cover_page_stage.[User_Selected_SUPL_N]=V08.[ARWA17_SUPL_N]
 AND cover_page_stage.[User_Selected_SUPL_CNTRY_N]=V08.ARWA28_CNTRY_N
 AND cover_page_stage.[User_Selected_SUPL_C]   =V08.ARWA17_SUPL_C

      JOIN [dbo].[PARWA29_CRCY] CRCY
        ON raw_matrl_stage.local_currency   = CRCY.ARWA29_CRCY_C

 Left JOIN [dbo].[PARWA28_CNTRY] CNTRY
        ON raw_matrl_stage.source_country   = CNTRY.ARWA28_CNTRY_N

      JOIN [dbo].PARWA28_CNTRY a28_EmptyStr
        on a28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

 where cover_page_stage.Processing_ID               = @Processing_ID
   AND cover_page_stage.Skip_loading_due_to_error_f = 0
;



GO
