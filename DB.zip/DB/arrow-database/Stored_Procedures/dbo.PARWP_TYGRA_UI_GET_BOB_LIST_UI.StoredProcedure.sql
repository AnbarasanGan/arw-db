DROP PROCEDURE IF EXISTS [dbo].[PARWP_TYGRA_UI_GET_BOB_LIST_UI] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 08/18/2021
-- Description:	Get list of BoBs by program that you want to load a Tygra file for.
-- UI will allow the user to select all the BoBs for a program or select individual BoBs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- 
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_BOB_LIST_UI] 

-- Add the parameters for the stored procedure here

-- Input Parameter
@U41_ProgramNm varchar(50) 

AS
SET NOCOUNT ON;
 
CREATE TABLE #bob_list (
         ProgramNm   varchar(max)   
        ,Enrg_cmmdty_x varchar(max)
		,Enrg_sub_cmmdty_x varchar(max)
		,FileNameSPTygra Varchar(max)
		,ARWU01_CCTSS_K INT
		,ARWUB1_TYGRA_FILE_K INT
		,ARWU01_TYGRA_REQD_F bit
		                        )
 	;

---******************************************************
-- in UI user selects program.  Program is passed to ACT V53 and a list of file names is returned to UI. 
 --******************************************************

-- returns all distinct files
INSERT INTO #bob_list
select u01.ARWU31_CTSP_N
,u01.ARWA02_ENRG_CMMDTY_X
,u01.ARWA03_ENRG_SUB_CMMDTY_X
,ub1.ARWUB1_TYGRA_FILE_N
,u01.ARWU01_CCTSS_K 
,ub6.ARWUB1_TYGRA_FILE_K
,u01.ARWU01_TYGRA_REQD_F
 from  [dbo].[PARWU01_CCTSS_FLAT] u01
left join PARWUB6_CCTSS_TYGRA_FILE ub6
 on u01.ARWU01_CCTSS_K = ub6.ARWU01_CCTSS_K
left join PARWUB1_TYGRA_FILE ub1
 on ub6.ARWUB1_TYGRA_FILE_K = ub1.ARWUB1_TYGRA_FILE_K
 where u01.[ARWU31_CTSP_N] = @U41_ProgramNm

-- displays list for user to select from
select * from  #bob_list



GO


