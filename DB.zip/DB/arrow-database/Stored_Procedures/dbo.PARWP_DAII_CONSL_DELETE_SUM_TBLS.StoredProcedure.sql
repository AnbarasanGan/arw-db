DROP PROCEDURE [dbo].[PARWP_DAII_CONSL_DELETE_SUM_TBLS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 03/20/2020
-- Description:	Delete Procedure for DAII summary tables.  
--              UI Exchange rate update only needs to delete the summary tables before recalculating.
--              Copied the deletes from PARWP_DAII_LOAD_ADJUSTMENT_DETAILS
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- =============================================

CREATE PROCEDURE  [dbo].[PARWP_DAII_CONSL_DELETE_SUM_TBLS] 
-- Input Parameter
@CCTSS_K  Int

AS

SET NOCOUNT ON;

--Delete PARWU73_SUPL_DSGN_ADJ
MERGE INTO [dbo].[PARWU73_SUPL_DSGN_ADJ]   U73_Target
Using
(
 Select U73.ARWU08_CCTSS_DSGN_SUPL_K
   From PARWU73_SUPL_DSGN_ADJ   U73
   Join PARWU08_CCTSS_DSGN_SUPL U08
     On U08.ARWU08_CCTSS_DSGN_SUPL_K = U73.ARWU08_CCTSS_DSGN_SUPL_K
   Join PARWU06_CCTSS_DSGN      U06
     On U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
  Where U06.ARWU01_CCTSS_K      = @CCTSS_K
) as U73_Source
ON (U73_Target.ARWU08_CCTSS_DSGN_SUPL_K = U73_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

--Delete PARWU74_SUPL_DSGN_IMPRV
MERGE INTO [dbo].PARWU74_SUPL_DSGN_IMPRV   U74_Target
Using
(
 Select U74.ARWU08_CCTSS_DSGN_SUPL_K
   From PARWU74_SUPL_DSGN_IMPRV U74
   Join PARWU08_CCTSS_DSGN_SUPL U08
     On U08.ARWU08_CCTSS_DSGN_SUPL_K = U74.ARWU08_CCTSS_DSGN_SUPL_K
   Join PARWU06_CCTSS_DSGN      U06
     On U06.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
  Where U06.ARWU01_CCTSS_K      = @CCTSS_K
) as U74_Source
ON (U74_Target.ARWU08_CCTSS_DSGN_SUPL_K = U74_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

GO
