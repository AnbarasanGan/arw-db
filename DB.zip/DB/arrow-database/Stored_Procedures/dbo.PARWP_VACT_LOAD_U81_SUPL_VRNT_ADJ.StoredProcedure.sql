SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 09/04/2019
-- Description:	Load data from the Variant Consolidation Views to the final table
--              Procedure was copied from PARWP_DACT_LOAD_U73_SUPL_DSGN
-- =============================================
-- Changes
-- Date        CDSID     Feature   Description
-- ----------  --------  -------   -----------
-- 01/14/2020  Ashaik12            Added Time_Stamp parameter
-- 07/13/2022  Asolosky  US3612620 Added the ARWU81_VA_DELETE_DERIVED_AMT_F column to indicated ARROW took the cost amount from D01 
-- 08/11/2022  ASolosky  US3924554 Problem happened after release of VA delete and not getting negative value for parts Added in 
--                                 Design Adjustments. The Case statement now determines which cost to put into ARWU81_PURC_PART_TOT_W_MRKP_A
--                                 and ARWU81_DSGN_PART_TOT_W_MRKP_A. ARWU81_RAW_MTRL_TOT_A and ARWU81_PROC_TOT_A will still be zero.
-- =============================================
CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VACT_LOAD_U81_SUPL_VRNT_ADJ] 
-- Input Parameter
@CCTSS_K Int,
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS
SET NOCOUNT ON;

INSERT INTO PARWU81_SUPL_VRNT_ADJ
Select CCT_PART_SUPPLIER_Sum.ARWU09_CCTSS_VRNT_SUPL_K                         AS ARWU09_CCTSS_VRNT_SUPL_K
      ,CCT_PART_SUPPLIER_Sum.ARWU65_CCTSS_VRNT_ADJ_K                          AS ARWU65_CCTSS_VRNT_ADJ_K
	  ,Pur_Qty                                                                 AS [ARWU81_PURC_PART_Q]
	  ,Case WHEN A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D'
	        Then 0
			  Else Purch_Cost
      END                                                                     AS [ARWU81_PURC_PART_TOT_A]
	  ,Pur_Tier2_MarkUp                                                        AS [ARWU81_PURC_PART_MRKP_A]
     ,Case WHEN A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D'
           THEN Case When Purch_Total_Cost != 0  
			            Then Purch_Total_Cost
					      When Raw_Cost         != 0  
					      Then Raw_Cost
					      Else Pro_Total_Cost
					 END
           ELSE Purch_Total_Cost
      END                                                                     AS [ARWU81_PURC_PART_TOT_W_MRKP_A]
	  ,Raw_Qty                                                                 AS [ARWU81_RAW_MTRL_Q]
	  ,Case WHEN A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D'
	        Then 0
			  Else Raw_Cost
      END                                                                     AS [ARWU81_RAW_MTRL_TOT_A]
	  ,Pro_Qty                                                                 AS [ARWU81_PROC_Q]
	  ,Pro_Direct_Labor                                                        AS [ARWU81_PROC_DIR_LBR_A]
	  ,Pro_Direct_Fringe                                                       AS [ARWU81_PROC_DIR_FRNG_A]
	  ,Pro_InDirect_Labor                                                      AS [ARWU81_PROC_INDIR_LBR_A]
	  ,Pro_InDirect_Fringe                                                     AS [ARWU81_PROC_INDIR_FRNG_A]
	  ,Pro_Overhead                                                            AS [ARWU81_PROC_OVRHD_A]
	  ,Pro_Misc                                                                AS [ARWU81_PROC_MISC_A]
	  ,Case WHEN A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D'
	        Then 0
			  Else Pro_Total_Cost
      END                                                                     AS [ARWU81_PROC_TOT_A]
     ,Case WHEN A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D'
           THEN Case When Purch_Total_Cost != 0  
			            Then Purch_Total_Cost
					      When Raw_Cost         != 0  
					      Then Raw_Cost
					      Else Pro_Total_Cost
					 End
           ELSE Purch_Total_Cost + ((Raw_Cost + Pro_Total_Cost) * (1+IsNull(V20.COMPOUNDED_TOTAL,0)))
      END                                                                     AS [ARWU81_DSGN_PART_TOT_W_MRKP_A]
	  ,0                                                                       AS ARWU81_DSGN_PART_TOTADJMRKP_A  --set to zero until we figure this out
	  ,Direct_Labor                                                            AS [ARWU81_ASSY_DIR_LBR_A]
	  ,Direct_Fringe                                                           AS [ARWU81_ASSY_DIR_FRNG_A]
	  ,Indirect_Labor                                                          AS [ARWU81_ASSY_INDIR_LBR_A]
	  ,Indirect_Fringe                                                         AS [ARWU81_ASSY_INDIR_FRNG_A]
	  ,Overhead                                                                AS [ARWU81_ASSY_OVRHD_A]
	  ,Misc                                                                    AS [ARWU81_ASSY_MISC_A]
	  ,Sub_Assy_total                                                          AS [ARWU81_ASSY_TOT_A]
	  ,Sub_Assy_total * (1+IsNull(V20.COMPOUNDED_TOTAL,0))                     AS [ARWU81_ASSY_TOT_W_MRKP_A]
	  ,0                                                                       AS ARWU81_ASSY_TOTADJMRKP_A  --set to zero until we figure this out
	  ,Final_Direct_Labor                                                      AS [ARWU81_FNL_ASSY_DIR_LBR_A]
	  ,Final_Direct_Fringe                                                     AS [ARWU81_FNL_ASSY_DIR_FRNG_A]
	  ,Final_Indirect_Labor                                                    AS [ARWU81_FNL_ASSY_INDIR_LBR_A]
	  ,Final_Indirect_Fringe                                                   AS [ARWU81_FNL_ASSY_INDIR_FRNG_A]
	  ,Final_Overhead                                                          AS [ARWU81_FNL_ASSY_OVRHD_A]
	  ,Final_Misc                                                              AS [ARWU81_FNL_ASSY_MISC_A]
	  ,Final_Sub_Assy_Total                                                    AS [ARWU81_FNL_ASSY_TOT_A]
	  ,isNULL(Final_Sub_Assy_Total* (1+IsNull(V21.COMPOUNDED_TOTAL,0)),0)      AS [ARWU81_FNL_ASSY_TOT_W_MRKP_A]
	  ,0                                                                       AS ARWU81_FNL_ASSY_TOTADJMRKP_A  --set to zero until we figure this out
      ,@TIME_STAMP                                                            AS [ARWU81_CREATE_S]
	  ,@CDSID                                                                  AS [ARWU81_CREATE_USER_C]
	  ,@TIME_STAMP                                                            AS [ARWU81_LAST_UPDT_S]
	  ,@CDSID                                                                  AS [ARWU81_LAST_UPDT_USER_C]
     ,Case WHEN A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_C = 'D'
           THEN 1  --The part cost was auto generated by ARROW using D01.CAII_CHRYPKD * -1 because of a VA type=DELETE. The Base table data can't be added up to match the U81 cost
           ELSE 0
      END                                                                     AS [ARWU81_VA_DELETE_DERIVED_AMT_F]
  From
(

Select CCT_PART_SUPPLIER.ARWU01_CCTSS_K            as ARWU01_CCTSS_K
      ,CCT_PART_SUPPLIER.ARWU09_CCTSS_VRNT_SUPL_K  as ARWU09_CCTSS_VRNT_SUPL_K
      ,CCT_PART_SUPPLIER.ARWU65_CCTSS_VRNT_ADJ_K   as ARWU65_CCTSS_VRNT_ADJ_K 
	  ,CCT_PART_SUPPLIER.ARWU17_BOM_SUB_ASSY_K     as ARWU17_BOM_SUB_ASSY_K
	  ,Sum(Pur_Qty)                                as Pur_Qty
	  ,Sum(Purch_Cost)                             as Purch_Cost
	  ,Sum(Pur_Tier2_MarkUp)                       as Pur_Tier2_MarkUp
	  ,Sum([Purch_Total_Cost])                     as Purch_Total_Cost
	  ,Sum(Raw_Qty)                                as Raw_Qty
      ,Sum(Raw_Cost)                               as Raw_Cost
	  ,Sum(Pro_Qty)                                as Pro_Qty
	  ,Sum(Pro_Direct_Labor)                       as Pro_Direct_Labor
	  ,Sum(Pro_Direct_Fringe)                      as Pro_Direct_Fringe
	  ,Sum(Pro_InDirect_Labor)                     as Pro_InDirect_Labor
	  ,Sum(Pro_InDirect_Fringe)                    as Pro_InDirect_Fringe
	  ,Sum(Pro_Overhead)                           as Pro_Overhead   
	  ,Sum(Pro_Misc)                               as Pro_Misc
	  ,Sum(Pro_Total_Cost)                         as Pro_Total_Cost
	  ,SUM(Direct_Labor)                           AS Direct_Labor  
	  ,SUM(Direct_Fringe)                          AS Direct_Fringe
	  ,SUM(Indirect_Labor)                         AS Indirect_Labor
	  ,SUM(Indirect_Fringe)                        AS Indirect_Fringe
	  ,SUM(Overhead)	                           AS Overhead
	  ,SUM(Misc)		                           AS Misc
	  ,SUM(Sub_Assy_total)                         AS Sub_Assy_total
	  ,SUM(Final_Direct_Labor)                     AS Final_Direct_Labor
	  ,SUM(Final_Direct_Fringe)		               AS Final_Direct_Fringe
	  ,SUM(Final_Indirect_Labor)	               AS Final_Indirect_Labor
	  ,SUM(Final_Indirect_Fringe)	               AS Final_Indirect_Fringe
	  ,SUM(Final_Overhead)			               AS Final_Overhead
	  ,SUM(Final_Misc)				               AS Final_Misc
	  ,SUM(Final_Sub_Assy_Total)	               AS Final_Sub_Assy_Total
  From
(
Select ARWU01_CCTSS_K
      ,ARWU09_CCTSS_VRNT_SUPL_K
      ,ARWU65_CCTSS_VRNT_ADJ_K
	  ,ARWU17_BOM_SUB_ASSY_K
	  ,Pur_Qty         
	  ,Purch_Cost       
	  ,Pur_Tier2_MarkUp
	  ,Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,0                               AS Pro_Qty 
	  ,0                               AS Pro_Direct_Labor   
	  ,0                               AS Pro_Direct_Fringe  
	  ,0                               AS Pro_InDirect_Labor
	  ,0                               AS Pro_InDirect_Fringe
	  ,0                               AS Pro_Overhead  
	  ,0                               AS Pro_Misc
	  ,0                               AS Pro_Total_Cost
	  ,0                               AS Direct_Labor
      ,0                               AS Direct_Fringe
      ,0                               AS Indirect_Labor
      ,0                               AS Indirect_Fringe
      ,0                               AS Overhead
      ,0                               AS Misc
	  ,0                               AS Sub_Assy_total
	  ,0                               AS Final_Direct_Labor
	  ,0                               AS Final_Direct_Fringe
	  ,0                               AS Final_Indirect_Labor
	  ,0                               AS Final_Indirect_Fringe
	  ,0                               AS Final_Overhead
	  ,0                               AS Final_Misc
	  ,0                               AS Final_Sub_Assy_Total
  From PARWV76_VACT_PART_SUPPLIER_PURCHPART
 Where ARWU01_CCTSS_K = @CCTSS_K
Union All
Select ARWU01_CCTSS_K
      ,ARWU09_CCTSS_VRNT_SUPL_K
      ,ARWU65_CCTSS_VRNT_ADJ_K
	  ,ARWU17_BOM_SUB_ASSY_K
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
      ,Raw_Qty  
      ,Raw_Cost
	  ,0                               AS Pro_Qty 
	  ,0                               AS Pro_Direct_Labor   
	  ,0                               AS Pro_Direct_Fringe  
	  ,0                               AS Pro_InDirect_Labor
	  ,0                               AS Pro_InDirect_Fringe
	  ,0                               AS Pro_Overhead  
	  ,0                               AS Pro_Misc
	  ,0                               AS Pro_Total_Cost
	  ,0                               AS Direct_Labor
      ,0                               AS Direct_Fringe
      ,0                               AS Indirect_Labor
      ,0                               AS Indirect_Fringe
      ,0                               AS Overhead
      ,0                               AS Misc
	  ,0                               AS Sub_Assy_total
	  ,0                               AS Final_Direct_Labor
	  ,0                               AS Final_Direct_Fringe
	  ,0                               AS Final_Indirect_Labor
	  ,0                               AS Final_Indirect_Fringe
	  ,0                               AS Final_Overhead
	  ,0                               AS Final_Misc
	  ,0                               AS Final_Sub_Assy_Total
  From PARWV77_VACT_PART_SUPPLIER_RAW
 Where ARWU01_CCTSS_K = @CCTSS_K
Union All
Select ARWU01_CCTSS_K
      ,ARWU09_CCTSS_VRNT_SUPL_K
      ,ARWU65_CCTSS_VRNT_ADJ_K
	  ,ARWU17_BOM_SUB_ASSY_K
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,Pro_Qty             
	  ,Pro_Direct_Labor    
	  ,Pro_Direct_Fringe   
	  ,Pro_InDirect_Labor  
	  ,Pro_InDirect_Fringe 
	  ,Pro_Overhead        	   
	  ,Pro_Misc            
	  ,Pro_Total_Cost      
	  ,0                                AS Direct_Labor
      ,0                                AS Direct_Fringe
      ,0                                AS Indirect_Labor
      ,0                                AS Indirect_Fringe
      ,0                                AS Overhead
      ,0                                AS Misc
	  ,0                                AS Sub_Assy_total
	  ,0                                AS Final_Direct_Labor
	  ,0                                AS Final_Direct_Fringe
	  ,0                                AS Final_Indirect_Labor
	  ,0                                AS Final_Indirect_Fringe
	  ,0                                AS Final_Overhead
	  ,0                                AS Final_Misc
	  ,0                                AS Final_Sub_Assy_Total
  From PARWV78_VACT_PART_SUPPLIER_PROCESS
 Where ARWU01_CCTSS_K = @CCTSS_K

 Union All
 select
       ARWU01_CCTSS_K
      ,ARWU09_CCTSS_VRNT_SUPL_K
      ,ARWU65_CCTSS_VRNT_ADJ_K
	  ,ARWU17_BOM_SUB_ASSY_K
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,0                               AS Pro_Qty             
	  ,0                               AS Pro_Direct_Labor    
	  ,0                               AS Pro_Direct_Fringe   
	  ,0                               AS Pro_InDirect_Labor  
	  ,0                               AS Pro_InDirect_Fringe 
	  ,0                               AS Pro_Overhead        	   
	  ,0                               AS Pro_Misc            
	  ,0                               AS Pro_Total_Cost      
      ,Direct_Labor
      ,Direct_Fringe
      ,Indirect_Labor
      ,Indirect_Fringe
      ,Overhead
      ,Misc
      ,(Direct_Labor+Direct_Fringe+Indirect_Labor+Indirect_Fringe+Overhead+Misc) as Sub_Assy_total
	  ,0                                                                         AS Final_Direct_Labor
	  ,0                                                                         AS Final_Direct_Fringe
	  ,0                                                                         AS Final_Indirect_Labor
	  ,0                                                                         AS Final_Indirect_Fringe
	  ,0                                                                         AS Final_Overhead
	  ,0                                                                         AS Final_Misc
	  ,0                                                                         AS Final_Sub_Assy_Total
  FROM PARWV79_VACT_ASSEMBLY 
 Where ARWU01_CCTSS_K = @CCTSS_K

Union All
 Select
       ARWU01_CCTSS_K
      ,ARWU09_CCTSS_VRNT_SUPL_K
      ,ARWU65_CCTSS_VRNT_ADJ_K
	  ,ARWU17_BOM_SUB_ASSY_K
	  ,0                               AS Pur_Qty  
	  ,0                               AS Purch_Cost     
	  ,0                               AS Pur_Tier2_MarkUp
	  ,0                               AS Purch_Total_Cost
	  ,0                               AS Raw_QTY 
      ,0                               AS Raw_Cost
	  ,0                               AS Pro_Qty             
	  ,0                               AS Pro_Direct_Labor    
	  ,0                               AS Pro_Direct_Fringe   
	  ,0                               AS Pro_InDirect_Labor  
	  ,0                               AS Pro_InDirect_Fringe 
	  ,0                               AS Pro_Overhead        	   
	  ,0                               AS Pro_Misc            
	  ,0                               AS Pro_Total_Cost      
      ,0                               AS Direct_Labor
      ,0                               AS Direct_Fringe
      ,0                               AS Indirect_Labor
      ,0                               AS Indirect_Fringe
      ,0                               AS Overhead
      ,0                               AS Misc
      ,0                               as Sub_Assy_total
	  ,Final_Direct_Labor
	  ,Final_Direct_Fringe
	  ,Final_Indirect_Labor
	  ,Final_Indirect_Fringe
	  ,Final_Overhead
	  ,Final_Misc
	  ,(Final_Direct_Labor+Final_Direct_Fringe+Final_Indirect_Labor+Final_Indirect_Fringe+Final_Overhead+Final_Misc) as Final_Sub_Assy_Total
  FROM PARWV80_VACT_FINAL_ASSEMBLY 
 Where ARWU01_CCTSS_K = @CCTSS_K
) CCT_PART_SUPPLIER

Group by 
 CCT_PART_SUPPLIER.ARWU01_CCTSS_K
,CCT_PART_SUPPLIER.ARWU09_CCTSS_VRNT_SUPL_K
,CCT_PART_SUPPLIER.ARWU65_CCTSS_VRNT_ADJ_K
,CCT_PART_SUPPLIER.ARWU17_BOM_SUB_ASSY_K
) CCT_PART_SUPPLIER_Sum

-- MFG Markup
     Join PARWU09_CCTSS_VRNT_SUPL_FLAT     U09
	   on CCT_PART_SUPPLIER_Sum.ARWU09_CCTSS_VRNT_SUPL_K = U09.ARWU09_CCTSS_VRNT_SUPL_K
     Join PARWV83_LOWEST_IDC_DSGN_BY_CCTSS V83
       on CCT_PART_SUPPLIER_Sum.ARWU01_CCTSS_K = V83.ARWU01_CCTSS_K
     join PARWU08_CCTSS_DSGN_SUPL          U08
       on U09.ARWU07_CCTSS_SUPL_K = U08.ARWU07_CCTSS_SUPL_K
      and V83.ARWU06_CCTSS_DSGN_K = U08.ARWU06_CCTSS_DSGN_K
	  Join PARWU65_CCTSS_VRNT_ADJ           U65 ON U65.ARWU65_CCTSS_VRNT_ADJ_K        = CCT_PART_SUPPLIER_Sum.ARWU65_CCTSS_VRNT_ADJ_K
     Join PARWA40_DSGN_ADJ_PART_CHG_TYP    A40 ON A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K = U65.ARWA40_DSGN_ADJ_PART_CHG_TYP_K
Left Join PARWV20_MFG_MRKP                 V20
       ON V20.ARWU08_CCTSS_DSGN_SUPL_K = U08.ARWU08_CCTSS_DSGN_SUPL_K
      AND V20.ARWU17_BOM_SUB_ASSY_K    = CCT_PART_SUPPLIER_Sum.ARWU17_BOM_SUB_ASSY_K

--Final Assembly MFG Markup
Left Join PARWV21_FINAL_ASSEMBLY_MFG_MRKP  V21
       ON V21.ARWU08_CCTSS_DSGN_SUPL_K = U08.ARWU08_CCTSS_DSGN_SUPL_K
Where CCT_PART_SUPPLIER_sum.ARWU01_CCTSS_K = @CCTSS_K
;

GO
