SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASOLOSKY
-- Create date: 09/05/2019
-- Description:	Delete Script for all Variant tables including the consolidation table U81.
--              Delete Statements need to run prior to loading VA tables to avoid having any orphaned records.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   01/14/2020  Removed filter on Processing Status
-- Asolosky   06/17/2022  We had a procedure to delete U81 so I refactored the code to use it in this Proc.
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VA_DELETE_TABLES] 
@GUIDIN        Varchar(5000),
@CDSID	       Varchar(30),
@CCTSS_K       Int
AS

SET NOCOUNT ON;

--********** Delete Statements for Variant related tables U66 - U72 and U81 **********--

--DELETE: Delete data in the PARWU81_SUPL_VRNT_ADJ table.
Exec [dbo].[PARWP_VA_CONSL_DELETE_SUM_TBLS] @CCTSS_K

--DELETE: PARWU66_PURC_PART_VRNT_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU66_PURC_PART_VRNT_ADJ   U66_Target
Using
	 (Select U09_VRNT.[ARWU09_CCTSS_VRNT_SUPL_K] 
        From PARWS45_VA_COVER_PAGE_INFO       S45 

      -- Join with Supplier Quote View
        JOIN [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT]   U09_VRNT
         ON S45.Eng_SubCommodity_name        = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
        AND S45.User_Selected_CTSP_N         = U09_VRNT.ARWU31_CTSP_N
        AND S45.User_Selected_CTSP_Region_C  = U09_VRNT.ARWA06_RGN_C 
        AND S45.User_Selected_BNCMK_VRNT_N   = U09_VRNT.[ARWU01_BNCHMK_VRNT_N]  --BoB variant
        AND S45.User_Selected_SUPL_N         = U09_VRNT.ARWA17_SUPL_N
        AND S45.User_Selected_SUPL_CNTRY_N   = U09_VRNT.ARWA28_CNTRY_N
        AND S45.User_Selected_SUPL_C         = U09_VRNT.ARWA17_SUPL_C
		AND U09_VRNT.ARWU04_VRNT_N           = S45.User_selected_WALK_VRNT_X

       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f =0
      ) as U66_Source
ON ( 
         U66_Target.ARWU09_CCTSS_VRNT_SUPL_K          = U66_Source.ARWU09_CCTSS_VRNT_SUPL_K
    )
WHEN MATCHED THEN DELETE;

--DELETE: PARWU67_RAW_MTRL_VRNT_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU67_RAW_MTRL_VRNT_ADJ   U67_Target
Using
	 (Select U09_VRNT.[ARWU09_CCTSS_VRNT_SUPL_K] 
        From PARWS45_VA_COVER_PAGE_INFO     S45 

       -- Join with Design and Supplier View
        JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
          ON U09_VRNT.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
         AND U09_VRNT.ARWA06_RGN_C               = S45.User_Selected_CTSP_Region_C
         AND U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   = S45.User_Selected_ENRG_SUB_CMMDTY_X 
         AND U09_VRNT.[ARWU01_BNCHMK_VRNT_N]     = S45.User_Selected_BNCMK_VRNT_N
         AND U09_VRNT.ARWA17_SUPL_N              = S45.User_Selected_SUPL_N
         AND U09_VRNT.ARWA17_SUPL_C              = S45.User_Selected_SUPL_C
         AND U09_VRNT.ARWA28_CNTRY_N             = S45.User_Selected_SUPL_CNTRY_N
		 AND U09_VRNT.ARWU04_VRNT_N              = S45.User_selected_WALK_VRNT_X
       Where S45.Processing_ID               = @GUIDIN
         And S45.Skip_loading_due_to_error_f =0
      ) as U67_Source
 ON (U67_Target.ARWU09_CCTSS_VRNT_SUPL_K = U67_Source.ARWU09_CCTSS_VRNT_SUPL_K)
WHEN MATCHED THEN DELETE;


--DELETE: PARWU68_PROCG_VRNT_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU68_PROCG_VRNT_ADJ U68_target
USING
  (select  
          U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K
     From PARWS45_VA_COVER_PAGE_INFO       S45 
      
    -- Join with Supplier Qoute View
     JOIN dbo.PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON S45.Eng_SubCommodity_name        = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
   AND S45.User_Selected_CTSP_N         = U09_VRNT.ARWU31_CTSP_N
   AND S45.User_Selected_CTSP_Region_C  = U09_VRNT.ARWA06_RGN_C
 --  AND S45.User_Selected_VEH_MDL_YR_C   = U09_VRNT.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S45.User_Selected_BNCMK_VRNT_N   = U09_VRNT.[ARWU01_BNCHMK_VRNT_N]      --BoB variant
   AND S45.User_Selected_SUPL_N         = U09_VRNT.ARWA17_SUPL_N
   AND S45.User_Selected_SUPL_CNTRY_N   = U09_VRNT.ARWA28_CNTRY_N
   AND S45.User_Selected_SUPL_C         = U09_VRNT.ARWA17_SUPL_C
   AND U09_VRNT.ARWU04_VRNT_N              = S45.User_selected_WALK_VRNT_X
    
      where S45.Processing_ID             = @GUIDIN
        AND S45.Skip_loading_due_to_error_f =0
      ) as u68_source
 
ON (u68_target.ARWU09_CCTSS_VRNT_SUPL_K = u68_source.ARWU09_CCTSS_VRNT_SUPL_K)
when MATCHED THEN DELETE
;

--DELETE: PARWU69_ASSY_VRNT_ADJ table. This will handle reloading of a file.
MERGE INTO PARWU69_ASSY_VRNT_ADJ   U69_Target
Using
	 (Select U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K
        From dbo.PARWS45_VA_COVER_PAGE_INFO                  COVER_PAGE_STAGE

      -- Join with Supplier Quote View
        JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U09_VRNT.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U09_VRNT.ARWA06_RGN_C
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U09_VRNT.[ARWU01_BNCHMK_VRNT_N]
   --      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = U09_VRNT.ARWA35_DSGN_VEH_MDL_YR_C
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U09_VRNT.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U09_VRNT.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U09_VRNT.ARWA28_CNTRY_N
		 AND U09_VRNT.ARWU04_VRNT_N                              = COVER_PAGE_STAGE.User_selected_WALK_VRNT_X
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f =0
      ) as U69_Source
 ON (U69_Target.ARWU09_CCTSS_VRNT_SUPL_K = U69_Source.ARWU09_CCTSS_VRNT_SUPL_K)
WHEN MATCHED THEN DELETE;

--DELETE: Final Assembly using Merge statement to Delete data in the PARWU71_FNL_ASSY_VRNT_ADJ table. This will handle reloading of a file.
MERGE INTO PARWU71_FNL_ASSY_VRNT_ADJ   U71_Target
Using
	 ( Select U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K
        From dbo.PARWS45_VA_COVER_PAGE_INFO                  COVER_PAGE_STAGE

      -- Join with Supplier Quote View
    JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = U09_VRNT.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = U09_VRNT.ARWA06_RGN_C
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = U09_VRNT.[ARWU01_BNCHMK_VRNT_N]
   --   AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = U09_VRNT.ARWA35_DSGN_VEH_MDL_YR_C
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = U09_VRNT.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = U09_VRNT.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = U09_VRNT.ARWA28_CNTRY_N
	  AND U09_VRNT.ARWU04_VRNT_N              = COVER_PAGE_STAGE.User_selected_WALK_VRNT_X
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f =0
      ) as U71_Source
 ON ( 
         U71_Target.ARWU09_CCTSS_VRNT_SUPL_K = U71_Source.ARWU09_CCTSS_VRNT_SUPL_K
    )
WHEN MATCHED THEN DELETE;

-- Delete for PARWU70_MFG_MRKP_VRNT_ADJ
MERGE INTO [dbo].PARWU70_MFG_MRKP_VRNT_ADJ U70_Target
USING
(
SELECT U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K 
  from [dbo].PARWS45_VA_COVER_PAGE_INFO            S45
  -- SUPPLIER QUOTE VIEW
  JOIN dbo.PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
      ON S45.Eng_SubCommodity_name      = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
   AND S45.User_Selected_CTSP_N         = U09_VRNT.ARWU31_CTSP_N
   AND S45.User_Selected_CTSP_Region_C  = U09_VRNT.ARWA06_RGN_C
   AND S45.User_Selected_BNCMK_VRNT_N   = U09_VRNT.[ARWU01_BNCHMK_VRNT_N]     --BoB variant
   AND S45.User_Selected_SUPL_N         = U09_VRNT.ARWA17_SUPL_N
   AND S45.User_Selected_SUPL_CNTRY_N   = U09_VRNT.ARWA28_CNTRY_N
   AND S45.User_Selected_SUPL_C         = U09_VRNT.ARWA17_SUPL_C
   AND U09_VRNT.ARWU04_VRNT_N              = S45.User_selected_WALK_VRNT_X
  
 where S45.Processing_ID               = @GUIDIN
   AND S45.Skip_loading_due_to_error_f =0
) as U70_SOURCE
ON
(
U70_Target.ARWU09_CCTSS_VRNT_SUPL_K=U70_SOURCE.ARWU09_CCTSS_VRNT_SUPL_K
--AND U52_Target.[ARWA38_MFG_MRKP_TYP_K] = U52_Source.[ARWA38_MFG_MRKP_TYP_K]
)
WHEN MATCHED THEN DELETE;

--Delete for PARWU72_FNLASSY_MRKP_VRNT_ADJ
MERGE INTO  [dbo].PARWU72_FNLASSY_MRKP_VRNT_ADJ U72_Target
USING
(
Select U09_VRNT.ARWU09_CCTSS_VRNT_SUPL_K
  From PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
			 ,cover_page_stage.User_selected_WALK_VRNT_X
        from [dbo].PARWS45_VA_COVER_PAGE_INFO cover_page_stage
      where cover_page_stage.Processing_ID               = @GUIDIN
        AND cover_page_stage.Skip_loading_due_to_error_f =0
      ) Staging
   -- ON Staging.Eng_commodity_name    = V04.[ENG_CMMDTY_DESC]
   ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X]     = U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X
   AND Staging.[User_Selected_CTSP_N]               = U09_VRNT.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]        = U09_VRNT.ARWA06_RGN_C
--   AND Staging.[User_Selected_VEH_MDL_YR_C]         = U09_VRNT.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_BNCMK_VRNT_N]         = U09_VRNT.[ARWU01_BNCHMK_VRNT_N]
   AND Staging.[User_Selected_SUPL_N]               = U09_VRNT.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]         = U09_VRNT.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]               = U09_VRNT.ARWA17_SUPL_C

   AND U09_VRNT.ARWU04_VRNT_N              = Staging.User_selected_WALK_VRNT_X
) as U72_SOURCE
ON (U72_Target.ARWU09_CCTSS_VRNT_SUPL_K = U72_SOURCE.ARWU09_CCTSS_VRNT_SUPL_K
    -- AND U54_Target.ARWA38_MFG_MRKP_TYP_K = U54_Source.ARWA38_MFG_MRKP_TYP_K
	)
WHEN MATCHED THEN DELETE;

GO
