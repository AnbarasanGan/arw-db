SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 03/01/2021
-- Description:	Load UB1 based on file passed in from UI
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2	  4-06-2021   added check for attempted insert of a file already loaded
-- rwesley2   4-20-2021   U2453456 use MAX length when declaring a variable   
-- rwesley2   4-20-2021   US2456552 remove hard-coded cdsid
-- rwesley2   05-10-2021  US2522370 Remove reference to U31 key and replace with new UB1 table and UB1 key
-- ASHAIK12   06-16-2021  US2628806 Use fl.BCJU41_ProgramNm to load into [ARWUB1_TYGRA_FILE_PGM_N], no join to U31 table to get program name,
--                        Program name in ACT does not match program name in ARROW
-- rwesley2    09-15-2021  US2879211 - load Curent files.  Added file name to Not Matched condition
-- rwesley2    05-16-2022  US3617161	replace GETUTCDATE with @time_stamp to keep all SP dates in Synch
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_UI_LOAD_UB1] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@CDSID varchar(MAX)
,@file_type varchar(MAX)
,@file_name_selected varchar(MAX)
,@version_selected  int
,@time_stamp datetime
--,@input_pgm varchar(MAX)

AS

SET NOCOUNT ON;

--******************************************************
-- in UI user selects a single file to load to ARROW.  UI passes in file_name and version
-- 
 --******************************************************


--declare @file_name_selected varchar(500)
--declare @version_selected  int
--
--set @file_name_selected = 'U71X Tygra 10.3.2020.xlsx'
--set @version_selected = 8

select @file_type 
select @file_name_selected 
select @version_selected


--***************************************
-- check if the Tygra file has already been loaded
--***************************************

update  ##file_list
set file_selected = 'D'
from PARWUB1_TYGRA_FILE ub1
join ##file_list FL
on ub1.ARWUB1_TYGRA_FILE_N = fl.bcju41_filenamesptygra
and ub1.ARWUB1_TYGRA_FILE_REV_R = fl.bcju51_version_f
and Case when fl.bcju41_wrkshp_num_c = 'Arrow-Scope' then '1'
            when fl.bcju41_wrkshp_num_c = 'Arrow-Current' then '2'
			else fl.bcju41_wrkshp_num_c end = ub1.ARWA54_TYGRA_FILE_TYPE_K

where ub1.ARWUB1_TYGRA_FILE_N = @file_name_selected   -- file name
and Case when ub1.ARWUB1_WRKSHP_N = 'Arrow-Scope' then 'Scope'
            when ub1.ARWUB1_WRKSHP_N = 'Arrow-Current' then 'Current'
			else ub1.ARWUB1_WRKSHP_N end = @file_type  -- file type = scope or current
and ub1.ARWUB1_TYGRA_FILE_REV_R = @version_selected    -- version 
;

declare @dup_insert int

select @dup_insert = 
 Count(*)
from ##file_list
where file_selected = 'D'
;

Begin
If @dup_insert > 0 
GOTO EOJ
END


-- set records to be processed
update  ##file_list
set file_selected = 'Y'
where BCJU41_FileNameSPTygra = @file_name_selected 
and   BCJU51_VERSION_F = @version_selected
 

--SELECT * FROM ##file_list

-- load UB1
MERGE INTO PARWUB1_TYGRA_FILE UB1
USING (
select * from (
select 
fl.BCJU41_ProgramNm as ARWUB1_TYGRA_FILE_PGM_N
--select [ARWU31_CTSP_K] as ARWU31_CTSP_K
,[ARWA54_TYGRA_FILE_TYPE_K] as ARWA54_TYGRA_FILE_TYPE_K
,1 as [ARWA55_TYGRA_FILE_VER_K]   -- default to 1 as we don't care about template version
,BCJU41_FileNameSPTygra         as ARWUB1_TYGRA_FILE_N
,@time_stamp as [ARWUB1_CREATE_S]
,@CDSID as [ARWUB1_CREATE_USER_C]
,@time_stamp as [ARWUB1_LAST_UPDT_S]
,@CDSID as [ARWUB1_LAST_UPDT_USER_C]
,BCJU51_VERSION_F as [ARWUB1_TYGRA_FILE_REV_R]  
,BCJU41_WRKSHP_NUM_C   as ARWUB1_WRKSHP_N 
,BCJU41_WRKSHP_STATUS_C  as ARWUB1_REV_STAT_N
,[BCJU41_TygraSPFileLastModifiedDtTm] as [ARWUB1_REV_S]    
from ##file_list fl
--join PARWU31_CTSP u31
--on fl.BCJU41_ProgramNm = u31.ARWU31_CTSP_N
join PARWA54_TYGRA_FILE_TYPE a54
on @file_type = a54.ARWA54_TYGRA_FILE_TYPE_N
where file_selected = 'Y'
)x

)y

on ub1.[ARWUB1_TYGRA_FILE_PGM_N] = y.[ARWUB1_TYGRA_FILE_PGM_N]
and ub1.ARWA54_TYGRA_FILE_TYPE_K = y.ARWA54_TYGRA_FILE_TYPE_K
and ub1.ARWUB1_TYGRA_FILE_REV_R  = y.ARWUB1_TYGRA_FILE_REV_R 
and ub1.ARWUB1_TYGRA_FILE_N = y.ARWUB1_TYGRA_FILE_N 
--)y
When NOT MATCHED THEN
     INSERT 
     VALUES (
	 y.ARWUB1_TYGRA_FILE_PGM_N
	 ,y.ARWA54_TYGRA_FILE_TYPE_K
     ,y.ARWA55_TYGRA_FILE_VER_K
     ,y.ARWUB1_TYGRA_FILE_N
     ,y.ARWUB1_TYGRA_FILE_REV_R  
     ,y.ARWUB1_WRKSHP_N 
     ,y.ARWUB1_REV_STAT_N
     ,y.ARWUB1_REV_S
     ,y.ARWUB1_CREATE_S
     ,y.ARWUB1_CREATE_USER_C
     ,y.ARWUB1_LAST_UPDT_S
     ,y.ARWUB1_LAST_UPDT_USER_C
	 )   
	 ; 


--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- in case there are multiple files with the same version number, set those to 'Y' also
-- want to load them to staged tables. files will have same version number but different file names
--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
update  ##file_list
set file_selected = 'Y'
where BCJU51_VERSION_F = @version_selected
;

select 'UB loaded'
--SELECT * FROM ##file_list

EOJ: select 'eoj' ;




GO
