DROP PROCEDURE If Exists [dbo].[PARWP_CALC_DELETE_D03_VA_PART_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 12/03/2021
-- Description:	Procedure to Delete the d03 va part summary dump
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- 01-03-2022 rwesley2	US3175890  replace varialbes with user Defined Table_Types
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CALC_DELETE_D03_VA_PART_SUMMARY]
@T04_CCTSS_VRNT [dbo].[PARWT04_CCTSS_VRNT] READONLY
AS

--Declare @Start_Time DATETIME = GETUTCDATE();

Begin

  Delete PARWD03_VA_PART_SUMM 
   Where [ARWU04_CCTSS_VRNT_K] IN (select ARWU04_CCTSS_VRNT_K from @T04_CCTSS_VRNT  )
  ;

--    Select OBJECT_NAME(@@PROCID) as Procedure_Name 
 --       ,@@Rowcount                                 as Records_Deleted
--       ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;

GO
