DROP PROCEDURE [dbo].[PARWP_PBOM_DELETE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		asolosky
-- Create date: 01/13/2019
-- Description:	Select the records in the Staging table for the import Processing_id. These staging records will be loaded into Arrow.
--              If CCS is present then Insert
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 02/25/2020  rwesley2           added PBOM 5.5 delet for end item tables (A47 & U63)
-- 04/03/2020  asolosky           added PARWU57_CCTSS_DSGN_SUB_ASSY to the procedure 
-- 07/03/2020  asolosky US1573358 had a processing error in Dev on the delete while testing. In the TI, it was determined that we should not delete from the A47 table.  The A47 delete was removed.
-- 03/18/2021  asolosky US2385952 Table PARWU63_BOM_PART_END_ITM was changed to PARWU63_VRNT_BOM_PART_END_ITM
-- 05/27/2021  asolosky US2406558 Changed U63 delete to remove all records and variants.  
--                                Created a Delete for PARWUA9_VRNT_END_ITM (Cost Allocation) and PARWUB0_VRNT_END_ITM_SUB_ASSY
-- =============================================

Create PROCEDURE  [dbo].[PARWP_PBOM_DELETE] 
-- Input Parameter
 @CCTSS_K       Int
AS

SET NOCOUNT ON;

-----------------------------------------------
--Deletes
-----------------------------------------------

Declare @ARWA57_END_ITM_MAP_TYPE_K INT;
Select @ARWA57_END_ITM_MAP_TYPE_K=( SELECT [dbo].[PARWF_ARWA57_TYPE_X] ('Scope') ); --Function call

--Delete PARWU63_VRNT_BOM_PART_END_ITM all scope and current records, plus all variants
MERGE INTO PARWU63_VRNT_BOM_PART_END_ITM u63
Using (
       select u18.ARWU01_CCTSS_K
	         ,u18.ARWU18_BOM_PART_K
			 ,U04.ARWU04_CCTSS_VRNT_K
         from PARWU18_BOM_PART    u18
         Join PARWU04_CCTSS_VRNT  U04  --Added the U04 table
           On U04.ARWU01_CCTSS_K  = U18.ARWU01_CCTSS_K
        where u18.ARWU01_CCTSS_K  = @CCTSS_K
	   ) u18S
 ON U63.ARWU04_CCTSS_VRNT_K       = u18S.ARWU04_CCTSS_VRNT_K --Added the ARWU04_CCTSS_VRNT_K and 
and u63.ARWU18_BOM_PART_K         = u18s.ARWU18_BOM_PART_K
WHEN MATCHED THEN DELETE;

--Delete PARWUB0_VRNT_END_ITM_SUB_ASSY
MERGE [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0_Target
using
(
  Select ARWUB0_VRNT_END_ITM_SUB_ASSY_K
    From PARWUB0_VRNT_END_ITM_SUB_ASSY UB0
    JOIN PARWUA9_VRNT_END_ITM          UA9 ON UA9.ARWUA9_VRNT_END_ITM_K = UB0.ARWUA9_VRNT_END_ITM_K
    JOIN PARWU04_CCTSS_VRNT            U04 ON UA9.ARWU04_CCTSS_VRNT_K   = U04.ARWU04_CCTSS_VRNT_K
   WHERE ARWU01_CCTSS_K = @CCTSS_K
) UB0_Source
ON UB0_Source.ARWUB0_VRNT_END_ITM_SUB_ASSY_K = UB0_Target.ARWUB0_VRNT_END_ITM_SUB_ASSY_K
WHEN MATCHED THEN DELETE
;

--Delete PARWUA9_VRNT_END_ITM
MERGE INTO PARWUA9_VRNT_END_ITM UA9_Target
Using (
       select UA9.ARWUA9_VRNT_END_ITM_K
	         ,UA9.ARWU04_CCTSS_VRNT_K
			 ,UA9.ARWUA9_VRNT_END_ITM_Q
			 ,UA9.ARWA47_FORD_END_ITM_K
			 ,U04.ARWU04_VRNT_N
         FROM PARWU04_CCTSS_VRNT   U04  
		 Join PARWUA9_VRNT_END_ITM UA9  On UA9.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
		Where U04.ARWU01_CCTSS_K      = @CCTSS_K
      ) UA9_Source
   ON UA9_Target.ARWUA9_VRNT_END_ITM_K = UA9_Source.ARWUA9_VRNT_END_ITM_K
 When Matched Then DELETE;

--Delete PARWU57_CCTSS_DSGN_SUB_ASSY.  
Delete From PARWU57_CCTSS_DSGN_SUB_ASSY
  Where ARWU06_CCTSS_DSGN_K IN
       (Select U57.ARWU06_CCTSS_DSGN_K
	      From PARWU57_CCTSS_DSGN_SUB_ASSY  U57
		  Join PARWU06_CCTSS_DSGN_FLAT      U06 on U06.ARWU06_CCTSS_DSGN_K = U57.ARWU06_CCTSS_DSGN_K
		 Where U06.ARWU01_CCTSS_K = @CCTSS_K
	   );

-- Delete PARWU19_DSGN_PART
MERGE INTO PARWU19_DSGN_PART   U19_Target
Using
(
Select ARWU06_CCTSS_DSGN_K
  From PARWU06_CCTSS_DSGN 
 Where ARWU01_CCTSS_K = @CCTSS_K
) as U19_Source
ON (U19_Target.ARWU06_CCTSS_DSGN_K = U19_Source.ARWU06_CCTSS_DSGN_K)
WHEN MATCHED THEN DELETE;

-- Delete PARWU18_BOM_PART
Delete From PARWU18_BOM_PART
 Where ARWU01_CCTSS_K = @CCTSS_K

-- Delete PARWU17_BOM_SUB_ASSY
Delete From PARWU17_BOM_SUB_ASSY
 Where ARWU01_CCTSS_K = @CCTSS_K






GO
