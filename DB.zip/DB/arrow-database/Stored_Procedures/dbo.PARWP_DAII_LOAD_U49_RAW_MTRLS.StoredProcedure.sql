DROP PROCEDURE [dbo].[PARWP_DAII_LOAD_U49_RAW_MTRLS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASHAIk12
-- Create date: 06/27/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08-20-2019  ashaik12  na	      add logic to add supplier key to improvement id name when originator is SUPPLIER 
--                                and FORD when originator is FORD on the Join Condition to match on what is inserted in U46
-- 08-20-2019  ashaik12           Updated [ARWU49_MTRL_PEL_RATE_PER_UOM_A] field mapping from staging.
-- 08/28/2019  Asolosky  US1154597 Changed UoM from a _K column to a description column to handle text. 
--                                 Removed join on the PARWA27_UOM table.
--                                 Moved Delete to the PARWP_DAII_IMPRV_DELETE procedure
-- 01/14/2020  Ashaik12            Added Time_Stamp parameter and removed filter on Processing Status
-- 07/28/2020  Ashaik12           US1798783 -- update CAST on U07_K to CONVERT
-- ==============================================
CREATE PROCEDURE  [dbo].[PARWP_DAII_LOAD_U49_RAW_MTRLS] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

INSERT INTO [dbo].[PARWU49_RAW_MTRL_DSGN_IMPRV]
SELECT --[ARWU49_RAW_MTRL_DSGN_IMPRV_K] is an identity 
       V04.ARWU08_CCTSS_DSGN_SUPL_K                      AS ARWU08_CCTSS_DSGN_SUPL_K
	  ,S40.row_idx                           AS [ARWU49_RAW_MTRL_DSPLY_SEQ_R]
      ,U46.[ARWU46_CCTSS_DSGN_IMPRV_K]       AS ARWU46_CCTSS_DSGN_IMPRV_K
	  ,S40.material_specification            AS [ARWU49_RAW_MTRL_SPEC_X]
	  ,S40.source_supplier                   AS [ARWU49_SRC_SUPL_N]
	  ,Case When A28.ARWA28_CNTRY_K is Null then A28_EmptyStr.ARWA28_CNTRY_K Else A28.ARWA28_CNTRY_K  End AS ARWA28_SRC_CNTRY_K
	  ,A29.ARWA29_CRCY_K                     AS ARWA29_LCL_CRCY_K
	  ,S40.no_of_pieces                      AS [ARWU49_PCE_PER_SUB_ASSY_Q]
	  ,S40.uom                               AS ARWU39_RAW_MTRL_UOM_X
	  ,S40.gross_usage_per_piece             AS [ARWU49_PCE_PER_SUB_ASSY_Q]
	  ,IsNULL(S40.material_price,0)          AS [ARWU49_MTRL_PEL_RATE_PER_UOM_A] 
      ,IsNULL(S40.inbound_packaging_costs,0) AS [ARWU49_INBND_PKNG_COST_UOM_A]
      ,IsNULL(S40.inbound_logistics_costs,0) AS [ARWU49_INBND_LGSTCS_COST_UOM_A]
      ,IsNULL(S40.tax_duty_per_uom,0)        AS [ARWU49_TAX_AND_DUTY_PER_UOM_A]
      ,IsNULL(S40.reclamation_pcntg,0)       AS [ARWU49_RCLMTN_P]
      ,IsNULL(S40.scrap_price,0)             AS [ARWU49_SCRAP_PRCE_PER_UOM_A]
      ,IsNULL(S40.comments,0)                AS [ARWU49_RAW_MTRL_ASSMP_CMT_X]
	  ,@TIME_STAMP                          AS ARWU49_CREATE_S
	  ,@CDSID                                AS ARWU49_CREATE_USER_C
	  ,@TIME_STAMP                          AS ARWU49_LAST_UPDT_S
	  ,@CDSID                                AS ARWU49_LAST_UPDT_USER_C

  From PARWS34_DAII_COVER_PAGE_INFO     S34 
  JOIN PARWS40_DAII_RAW_MATERIALS_INFO  S40
    ON S40.Processing_ID       = S34.Processing_ID
   AND S40.filename            = S34.filename
   JOIN PARWS44_DAII_IMPROVEMENT_IDEAS_INFO  S44
    ON S34.Processing_ID       = S44.Processing_ID
   AND S34.filename            = S44.filename
   AND S40.change_improvement_id = S44.improvement_id

 -- Join with Supplier Quote View
  JOIN PARWV04_DSGN_SUPL   V04
          ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
         AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
         AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
         AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
         AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
         AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
         AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
         AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
         AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
         AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
         AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N

--Design Adjustment Part
  Join [dbo].[PARWU46_CCTSS_DSGN_IMPRV]  U46
    ON U46.ARWU06_CCTSS_DSGN_K         = V04.ARWU06_CCTSS_DSGN_K
   AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = (CASE 
	      WHEN S44.originator = 'Supplier'
		      THEN  S40.change_improvement_id + '#' + CONVERT(VARCHAR,[ARWU07_CCTSS_SUPL_K])  
	       WHEN S44.originator = 'FORD' THEN  S40.change_improvement_id  + '#' + 'Ford'	            
		  ELSE S40.change_improvement_id + '#' + 'UNK'   
        END)

 --Currency
  JOIN PARWA29_CRCY      A29           ON S40.local_currency   = A29.ARWA29_CRCY_C

 --Source-Country
 Left JOIN PARWA28_CNTRY A28           ON S40.source_country   = A28.ARWA28_CNTRY_N
  JOIN PARWA28_CNTRY     A28_EmptyStr  ON A28_EmptyStr.ARWA28_ISO3_CNTRY_C = ''

  Where S34.Processing_ID       = @GUIDIN
	And S40.cost_type ='Improvement Costs'
	AND S34.Skip_loading_due_to_error_f = 0
;

GO
