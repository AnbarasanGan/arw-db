
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 04/11/2022
-- Description:	Validates the Tygra UB table loads
--              
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2	  05-16-2022  US3617161	replace GETUTCDATE with @time_stamp to keep all SP dates in Synch 
-- rwesley2   05-19-2022  USS617161  QC testing issue:  replace userID with @CDSID
--                        fix UB6 message
--rwesley2    06-20-2022  US3283898 DE256745 changed validation logic as below
--                        source = ACT is @file_source
--                        new file file name on UB1 only once. version will match passed in and time stamp should equal passed in time_stamp 
--                        old file + new version file name already on UB1.
--                          in this case, the file is picked from ACT and loaded to UB1.  however the file name will already be on UB1 more than once. 
--                          There will be a new version number and last update will match time stamp/    
--                          have to check UB1 to see if file name appears more than once
--                        source = ARROW is @file_source
--                        existing file + existing version on UB1 file_name, version will match passed in and time stamp will not equal passed in time_stamp
-- rwesley2    07-19-2022 US3846558 - refactor WARNING/ERROR logic.   
-- rwesley2    08-11-2022 US3283898 DE262236 - change UB2, UB3, and UB4 message for ARROW, EXISTING, STUDY from ERROR to WARNING
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_POST_LOAD_UI] 
-- Input Parameter
 @processing_id varchar(MAX)
,@CDSID         varchar(MAX)
,@Program_name varchar(max)
,@Tygra_file_name varchar(max) 
,@Tygra_file_version INT
,@file_source varchar(max) 
,@BoB_key INT  
,@load_to_pgm_name varchar(max)
,@TIME_STAMP DATETIME
,@TYGRA_LOAD_ERROR varchar(MAX) OUTPUT


AS

--BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

set	@TYGRA_LOAD_ERROR = 'No errors'

-- need to count how many times a file name appears on UB1 to know if file is new or existing.  count > 1 is existing file,
declare @file_name_cnt int = (select count(*) from PARWUB1_TYGRA_FILE where ARWUB1_TYGRA_FILE_N = @tygra_file_name group by ARWUB1_TYGRA_FILE_N)

declare @error_cnt INT  

--- table to load some info about file being processed
DECLARE @file_info TABLE
(source varchar(max)
 ,new_existing varchar(maX)
 ,load_to_progam varchar(max)
 ,file_name varchar(max) 
 ,version varchar(max)
 ,ub1_tygra_file_k int
 ,load_type varchar(max)
 ,ub1_last_updt_s varchar(max)
)

-- load temp table
IF @file_source = 'ACT'
BEGIN
--ACT new file name and version on UB1
IF @file_name_cnt = 1
begin
insert into @file_info
select @file_source
,'NEW'
,@load_to_pgm_name 
,ARWUB1_TYGRA_FILE_N
,ARWUB1_TYGRA_FILE_REV_R
,ARWUB1_TYGRA_FILE_K
,CASE when @BoB_key = -1 then 'initial' else 'study'
  END
,ARWUB1_LAST_UPDT_S
from PARWUB1_TYGRA_FILE 
where ARWUB1_TYGRA_FILE_N = @tygra_file_name
and ARWUB1_TYGRA_FILE_REV_R = @tygra_file_version 
and ARWUB1_LAST_UPDT_S = @TIME_STAMP
END

--ACT file name already loaded to UB1 but new version
IF @file_name_cnt > 1
begin
insert into @file_info
select @file_source
,'EXISTING'
,@load_to_pgm_name 
,ARWUB1_TYGRA_FILE_N
,ARWUB1_TYGRA_FILE_REV_R
,ARWUB1_TYGRA_FILE_K
,CASE when @BoB_key = -1 then 'initial' else 'study'
  END
,ARWUB1_LAST_UPDT_S
from PARWUB1_TYGRA_FILE 
where ARWUB1_TYGRA_FILE_N = @tygra_file_name
and ARWUB1_TYGRA_FILE_REV_R = @tygra_file_version 
and ARWUB1_LAST_UPDT_S = @TIME_STAMP
END
END -- for file source = ACT

--ARROW file name and version already loaded to UB1
IF @file_source = 'Arrow'
--Begin
--IF @file_name_cnt > 1
begin
insert into @file_info
select @file_source
,'EXISTING'
,@load_to_pgm_name 
,ARWUB1_TYGRA_FILE_N
,ARWUB1_TYGRA_FILE_REV_R
,ARWUB1_TYGRA_FILE_K
,CASE when @BoB_key = -1 then 'initial' else 'study'
  END
,ARWUB1_LAST_UPDT_S
from PARWUB1_TYGRA_FILE 
where ARWUB1_TYGRA_FILE_N = @tygra_file_name
and ARWUB1_TYGRA_FILE_REV_R = @tygra_file_version 
and ARWUB1_LAST_UPDT_S <> @TIME_STAMP
--END
END -- for file source = ARROW


-- set to a value to fake that the table loaded and to see the error for the other tables
declare @ub2_cnt int 
set @ub2_cnt = (select count(*) from [dbo].[PARWUB2_TYGRA_FILE_CCM] where [ARWUB2_LAST_UPDT_S] = @time_stamp);
declare @ub3_cnt int 
set @ub3_cnt = (select count(*) from [dbo].[PARWUB3_TYGRA_FILE_REC] where [ARWUB3_LAST_UPDT_S] = @time_stamp);
declare @ub4_cnt int 
set @ub4_cnt = (select count(*) from [dbo].[PARWUB4_TYGRA_FILE_REC_CCM] where [ARWUB4_LAST_UPDT_S] = @time_stamp);
declare @ub6_cnt int 
set @ub6_cnt = (select count(*) from [dbo].[PARWUB6_CCTSS_TYGRA_FILE] where [ARWUB6_LAST_UPDT_S] = @time_stamp);

-- file source setup for ACT load block
IF @file_source = 'ACT' 
begin
 IF (@ub2_cnt = 0 and @ub3_cnt = 0 and @ub4_cnt = 0 and @UB6_cnt = 0)
	  begin 
	  set @error_cnt = 1 
	  set @TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,CASE when @bob_key = -1 then cast(@BoB_key as varchar(max)) + cast('  full load' as varchar(max))  
	        else  cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))
	   END as [ARWE02_ERROR_VALUE]
	  ,'None of the Tygra UB tables loaded.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name         as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF @error_cnt > 0
   goto end_validations 

BEGIN
IF  @UB6_cnt = 0
	  begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,CASE when @bob_key = -1 then cast(@BoB_key as varchar(max)) + cast('  full load' as varchar(max))  
	        else  cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))
	   END as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB6 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name              as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub2_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,CASE when @bob_key = -1 then cast(@BoB_key as varchar(max)) + cast('  full load' as varchar(max))  
	        else  cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))
	   END as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB2 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub3_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,CASE when @bob_key = -1 then cast(@BoB_key as varchar(max)) + cast('  full load' as varchar(max))  
	        else  cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))
	   END as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB3 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub4_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,CASE when @bob_key = -1 then cast(@BoB_key as varchar(max)) + cast('  full load' as varchar(max))  
	        else  cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))
	   END as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB4 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

END -- for skip validations
END -- for ACT load block


-- file source setup for Arrow/Existing/initial/file pgm <> load to pgm load block
IF ((@file_source = 'ARROW' and (select new_existing from @file_info) = 'EXISTING' )  -- existing file + new version
   and (@program_name <> @load_to_pgm_name )
   and (select load_type from @file_info) = 'initial' )
   BEGIN
   	IF  @UB6_cnt = 0
	  begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB6 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name              as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub2_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB2 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub3_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB3 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub4_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB4 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

end -- end for Arrow/Existing/initial/file pgm <> load to pgm load block

-- file source setup for Arrow/Existing/Study load block
IF ((@file_source = 'ARROW' and (select new_existing from @file_info) = 'EXISTING' )  -- existing file + new version
   and (select load_type from @file_info) = 'study' )
   BEGIN
   	IF  @UB6_cnt = 0
	  begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB6 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name              as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub2_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB2 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub3_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB3 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

IF  @ub4_cnt = 0
	  Begin 
	  set 	@TYGRA_LOAD_ERROR = 'Load error'
      INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]	
	  Select 'TYGRA'             as [ARWE02_SOURCE_C]
      ,cast('study key =   ' as varchar(max)) + cast(@BoB_key as varchar(max))   as [ARWE02_ERROR_VALUE]
	  ,'No records were loaded to the Tygra UB4 table.'  as [ARWE02_ERROR_x]
      ,@processing_id           as [ARWE02_PROCESSING_ID]
	  ,@Tygra_file_name           as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)    as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP              as [ARWE02_CREATE_S]  --@TIME_STAMP  for error record
	  ,@CDSID                   as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP              as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                   as [ARWE02_LAST_UPDT_USER_C]  
	  ,1                        as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'Post_load validation'   as [ARWE02_STAGING_TABLE_X]
	  ,'WARNING'                  as [ARWE02_ERROR_TYPE_X]
	  ,'file_source:  ' + @file_source    as [ARWE02_EXCEL_TAB_X]
	  ,''                       as [ARWE02_ROW_IDX]
	  ,'file_type:  ' + (select new_existing from @file_info)   as [ARWE02_Part_Index]
	  ,'ub1_tygra_file_k:  ' + (select cast(ub1_tygra_file_k as varchar(max))  from @file_info)   as [ARWE02_ARROW_Value]
	  end

end -- end for Arrow/Existing/Study load block


end_validations:   
 
GO

