SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2020
-- Description:	Master Procedure to call Tygra pre-validation SPs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2	  05-16-2022  US3617161	replace GETUTCDATE with @time_stamp to keep all SP dates in Synch
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_PRE_VALIDATION_MASTER] 
	-- Add the parameters for the stored procedure here
@GUID  varchar(MAX)
,@CDSID  varchar(MAX)      -- = 'rwesley2'
,@Time_stamp DATETIME

AS
Begin  
--DECLARE @TIME_STAMP    DATETIME    = GETUTCDATE();
   
 SET NOCOUNT ON;
-- SET @TIME_STAMP = GETUTCDATE()
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));

Begin TRY
-- load mapping tables
 EXEC [dbo].[PARWP_TYGRA_LOAD_ENRG_CMMDTY_MAPPING]           @CDSID, @TIME_STAMP,@GUID; 
 -- Missing engineering commodity code
 EXEC [dbo].[PARWP_TYGRA_VALIDT_PRE_VALIDATIONS]      @GUID, @CDSID, @TIME_STAMP; 

END TRY 
 


 --CATCH
 BEGIN CATCH
   Rollback;

    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'TYGRA MASTER PROCEDURE'
        ,0                              as ARWE02_ROW_IDX	
	    ,' '                               -- part_index 
	    ,' '                               -- ARROW_VALUE
	;

  END CATCH;	

END;


GO
