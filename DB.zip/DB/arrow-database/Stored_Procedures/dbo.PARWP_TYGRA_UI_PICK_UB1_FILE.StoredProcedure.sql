DROP PROCEDURE [dbo].[PARWP_TYGRA_UI_PICK_UB1_FILE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 05/11/2021
-- Description:	From the UB1 list fro SP PARWP_TYGRA_UI_GET_UB1_LIST, pick the file and update file_selected
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
--
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_PICK_UB1_FILE] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@file_name_selected varchar(MAX)
,@version_selected  int
--,@input_pgm varchar(MAX)

AS

SET NOCOUNT ON;

-- set records to be processed
update  ##file_list
set file_selected = 'Y'
where BCJU41_FileNameSPTygra = @file_name_selected 
and   BCJU51_VERSION_F = @version_selected
 

SELECT * FROM ##file_list



GO
