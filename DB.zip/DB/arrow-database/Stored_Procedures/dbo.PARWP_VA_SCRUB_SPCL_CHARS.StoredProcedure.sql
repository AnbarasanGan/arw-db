DROP PROCEDURE [dbo].[PARWP_VA_SCRUB_SPCL_CHARS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 10/31/2019
-- Description:	scub procedure to remove special characters from 
-- =============================================
-- CHANGES
-- Date			CDSID		Feature	 Description
-- ----------   --------    -------  -----------
-- 01/10/2020   rwesley2             add scrubbing for part index and remove cdsid and date from update and processing status from Where 
-- 06/24/2020   asolosky  US1714209  When there is Line Feed or carriage return at the end of a character string, the LF and CR are removed.
--                                   S46: ford_spec_sds,ford_intended_dsgn_attr, ford_variant_dsgn_attr, comments
--                                   Also, there were multiple update statements per table. Changed the code so it's one update per table.
-- 07/01/2020   asolosky  US1714209  Added Char(9) Tab, Char(32) space and Char(34) double quote to the list of special characters. The start and end of the value is scrubbed for these special characters.
--                                   Created a 2nd update for the left trim of special character. 
-- 07/24/2020   asolosky  US1771016  Removed scrubbing for LF and CR on part_index, part_name, change_id.  There will be validation procedure to reject when there's LF or CR.
--                                   Removed the scrub on S50, S51, S52, S53 for LF and CR.  Those tables will also have validation procedures to reject LF or CR. 
-- 10/20/2020  Ashaik12  US1910884   Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================	
CREATE PROCEDURE [dbo].[PARWP_VA_SCRUB_SPCL_CHARS]
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
AS

DECLARE @pat NvarCHAR(100) = '%[^'+CHAR(9)+CHAR(10)+CHAR(13)+CHAR(32)+CHAR(34)+']%';

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

---- SCRUB S46  
--Right Trim special characters
UPDATE PARWS46_VA_ADJUSTMENT_DETAILS_INFO
   SET ford_spec_sds           = IsNull(LEFT(ford_spec_sds,DATALENGTH(ford_spec_sds) - PATINDEX(@pat,REVERSE(ford_spec_sds))+1),'')
	  ,ford_intended_dsgn_attr = IsNull(LEFT(ford_intended_dsgn_attr,DATALENGTH(ford_intended_dsgn_attr) - PATINDEX(@pat,REVERSE(ford_intended_dsgn_attr))+1),'')
	  ,ford_variant_dsgn_attr  = IsNull(LEFT(ford_variant_dsgn_attr,DATALENGTH(ford_variant_dsgn_attr) - PATINDEX(@pat,REVERSE(ford_variant_dsgn_attr))+1),'')
	  ,comments                = IsNull(LEFT(comments,DATALENGTH(comments) - PATINDEX(@pat,REVERSE(comments))+1),'')
  FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
 WHERE s46.Processing_ID       = @GUID
;
--Left Trim special characters
UPDATE PARWS46_VA_ADJUSTMENT_DETAILS_INFO
   SET ford_spec_sds           = IsNull(STUFF(ford_spec_sds,1,ISNULL(NULLIF(PATINDEX(@pat,ford_spec_sds),0)-1,0),''),'') 
	  ,ford_intended_dsgn_attr = IsNull(STUFF(ford_intended_dsgn_attr,1,ISNULL(NULLIF(PATINDEX(@pat,ford_intended_dsgn_attr),0)-1,0),''),'') 
	  ,ford_variant_dsgn_attr  = IsNull(STUFF(ford_variant_dsgn_attr,1,ISNULL(NULLIF(PATINDEX(@pat,ford_variant_dsgn_attr),0)-1,0),''),'') 
	  ,comments                = IsNull(STUFF(comments,1,ISNULL(NULLIF(PATINDEX(@pat,comments),0)-1,0),''),'') 
  FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO s46
 WHERE s46.Processing_ID       = @GUID
;

END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,GETUTCDATE() 
             ,@CDSID
             ,GETUTCDATE()
             ,@CDSID
			 ,''
			 ,'PARWP_VA_SCRUB_SPCL_CHAR' 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
			 ,''
			 ,''
END CATCH




GO
