DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_PART_INDEX]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 07/26/2019
-- Description:	validate Variant Adjustment Part Index against PBOM
--              at 7/24 mtg, Renata said to ignore tough choice groupig(tradeoffs) when loading, so removed validation
-- =============================================
-- CHANGES
-- Date			CDSID		Feature	 Description
-- ----------   --------    -------  -----------
-- 09/10/2019   Asolosky             Added row_id
-- 10/29/2019   ashaik12             Add new validation to check if Added part index is of one character
-- 11/05/2019   rwesley2             new validation to check if added part has a sub-assembly 
-- 11/21/2019   rwesley2             new business rule:  the first character of a part index defines the sub-assy  
-- 12/02/2019   ashaik12             Moved the part description validation here and deleting the part_name validation
-- 12/12/2019   ashaik12             Fix Part Index & Part Name validation for DELETE/MODIFY (check for parts for that specific U01 key in the U18 table)
-- 01/14/2020   Ashaik12             Added Time_Stamp parameter and removed filter on Processing Status
-- 05/08/2020   rwesley2  US1600015  removed hard-coded value for ARWE02_EXCEL_TAB_X and replaced with s46.sheet_name.
-- 07/14/2020   Asolosky  US1701019  Changed error message from 'VA Part Name Invalid:  ' + Err.[part_name] 
--                                                           to 'Part Name: ' + Err.[part_name] + ', doesn''t match ARROW part name: ' +  ARWU18_BOM_PART_X 
-- 07/28/2020  asolosky   US1771016  Added error message for carriage return and line feed on part_index. Moved part name validation to Validt_part_name
-- 09/30/2020  Ashaik12      US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_PART_INDEX] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  Err.[Source_c] as [ARWE02_SOURCE_C],
	  replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>') as [ARWE02_ERROR_VALUE],
	  'Part Index Not Found for Modify or Delete' as [ARWE02_ERROR_X],
	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  Err.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
      @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  Err.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  Err.sheet_name as [ARWE02_EXCEL_TAB_X],
	  row_idx                               as ARWE02_ROW_IDX,
	  replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>'),
	  ''  --No ARROW Value
       FROM 
       (
        SELECT 
          S46.Processing_ID,
		  S46.part_index,
		  S46.Processing_Status_x,
		  S46.Source_c,
		  S46.filename,
          [ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K],
		  s46.sheet_name,
		  S46.row_idx
        FROM [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO]  s46
		JOIN PARWS45_VA_COVER_PAGE_INFO          S45
          ON S45.Processing_ID       = S46.Processing_ID
         AND S45.filename            = S46.filename
		 JOIN PARWU01_CCTSS_FLAT   U01    
          ON U01.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
         AND U01.ARWA06_RGN_C               = S45.User_Selected_CTSP_Region_C
         AND U01.ARWA03_ENRG_SUB_CMMDTY_X   = S45.User_Selected_ENRG_SUB_CMMDTY_X 
         AND U01.ARWU01_BNCHMK_VRNT_N       = S45.User_Selected_BNCMK_VRNT_N
		 LEFT JOIN PARWU18_BOM_PART U18
		 ON U18.ARWU01_CCTSS_K = U01.ARWU01_CCTSS_K
		 AND U18.ARWU18_BOM_PART_IX_N = S46.part_index
        WHERE S46.Processing_ID         = @GUID
		and s46.type_of_change    in ('DELETE','MODIFY')
	    and U18.ARWU18_BOM_PART_IX_N is NULL
                    
       ) Err

    ;

	
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  S46.[Source_c] as [ARWE02_SOURCE_C],
	  S46.[part_index] as [ARWE02_ERROR_VALUE],
	  'Added Part Index is Less than 2 Characters' as  [ARWE02_ERROR_X],
	  S46.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  S46.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
      @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  S46.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K] as [ARWE02_BATCH_ERRORS_REF_K],
	  'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
      S46.sheet_name                     as [ARWE02_EXCEL_TAB_X],
	  S46.row_idx as [ARWE02_ROW_IDX],
	   replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>'),
	  ''  --No ARROW Value
       FROM 
         [dbo].PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
        WHERE Processing_ID         = @GUID
		and S46.type_of_change    ='ADD'
		and len(S46.part_index) <= 1
    ;

DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
-------------Part_index-------------------
-- Line Feed validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                     as [ARWE02_SOURCE_C],
	       replace(part_index,char(10),'<LF>')          as [ARWE02_ERROR_VALUE],  --replace line feed with <LF>
	       'A part index can''t have an imbedded line feed <LF>'       as [ARWE02_ERROR_X],
	       Processing_ID                                as [ARWE02_PROCESSING_ID],
	       filename                                     as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE02_CREATE_S],
           @CDSID                                       as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE02_LAST_UPDT_S],
	       @CDSID                                       as [ARWE02_LAST_UPDT_USER_C],
	       ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K          as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'         as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE02_ERROR_TYPE_X],
	       sheet_name                                   as [ARWE02_EXCEL_TAB_X],
	       row_idx                                      as [ARWE02_ROW_IDX],
		   replace(part_index,char(10),'<LF>') ,
	       ''  --No ARROW Value
      FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
     WHERE Processing_ID                         =  @GUID
	   and NullIf(PATINDEX(@pat10,part_index),0) > 0  --Looking for Line Feed 
    ;

-- Carriage Return validation
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	       Source_c                                 as [ARWE02_SOURCE_C],
	       replace(part_index,char(13),'<CR>')      as [ARWE02_ERROR_VALUE],  --replace carriage return with <CR>
	       'A part index can''t have an imbedded carriage return <CR>' as [ARWE02_ERROR_X],
	       Processing_ID                            as [ARWE02_PROCESSING_ID],
	       filename                                 as [ARWE02_FILENAME],
	       OBJECT_NAME(@@PROCID)                    as [ARWE02_PROCEDURE_X],
	       @TIME_STAMP                              as [ARWE02_CREATE_S],
           @CDSID                                   as [ARWE02_CREATE_USER_C],
	       @TIME_STAMP                              as [ARWE02_LAST_UPDT_S],
	       @CDSID                                   as [ARWE02_LAST_UPDT_USER_C],
	       ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K      as [ARWE02_BATCH_ERRORS_REF_K],
	       'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'     as [ARWE02_STAGING_TABLE_X],
	       'ERROR'                                  as [ARWE02_ERROR_TYPE_X],
	       sheet_name                               as [ARWE02_EXCEL_TAB_X],
	       row_idx                                  as [ARWE02_ROW_IDX],
		   replace(part_index,char(13),'<CR>'),
		   ''
      FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
     WHERE Processing_ID                         =  @GUID
       and NullIf(PATINDEX(@pat13,part_index),0) > 0  --Looking for carriage 
    ;

-- check Tough Choice Grouping
--	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
--     SELECT
--	  Err.[Source_c] as [ARWE02_SOURCE_C],
--	  Err.[part_index] as [ARWE02_ERROR_VALUE],
--	  'VA Part Index Not Assigned to a Trade-off Grouping:' + ' ' + Err.[part_index] as [ARWE02_ERROR_X],
--	  Err.[Processing_ID] as [ARWE02_PROCESSING_ID],
--	  Err.[filename] as [ARWE02_FILENAME],
--	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
--	  @TIME_STAMP as [ARWE02_CREATE_S],
--     @CDSID as [ARWE02_CREATE_USER_C],
--	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
--	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
--	  Err.[ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K] as [ARWE02_BATCH_ERRORS_REF_K],
--	  'PARWS46_VA_ADJUSTMENT_DETAILS_INFO' as [ARWE02_STAGING_TABLE_X],
--	  'WARNING' as [ARWE02_ERROR_TYPE_X],
--	  'Adjustment Details' as [ARWE02_EXCEL_TAB_X]
--      FROM 
--      (
--       SELECT 
--         Processing_ID,
--		  part_index,
--		  Processing_Status_x,
--		  Source_c,
--		  filename,
--         [ARWS46_VA_ADJUSTMENT_DETAILS_INFO_K]
--       FROM [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
--       WHERE Processing_Status_x = 'PROCESSING'
--		and Processing_ID         =  @GUID
--		and s46.tough_choice_grouping = ' '
--                  
--      ) Err
--
--   ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS46_VA_ADJUSTMENT_DETAILS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
             ,0                                 --row_idx
			 ,''
			 ,''
END CATCH;






GO
