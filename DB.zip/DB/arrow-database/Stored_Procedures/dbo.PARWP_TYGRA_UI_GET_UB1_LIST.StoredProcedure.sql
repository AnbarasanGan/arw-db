DROP PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_UB1_LIST]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 05/11/2021
-- Description:	Get tygra file(s) to process fro UB1
-- business rules: returns list of Tygra file already loaded to UB1 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- 
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_TYGRA_UI_GET_UB1_LIST] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@U41_ProgramNm varchar(50) 
--,@file_type     varchar(50)
--@GUID varchar(500) 

AS


SET NOCOUNT ON;

--DECLARE @U41_ProgramNm varchar(50);
--,@GUID varchar(500) 
--DECLARE @BCJU41_FileNameSPTygra Varchar(1000);  
CREATE TABLE ##file_list (
         BCJU41_ProgramNm   varchar(50)   
        ,BCJU41_WRKSHP_NUM_C  varchar(50)      
        ,BCJU41_WRKSHP_STATUS_C varchar(10)
		,BCJU41_FileNameSPTygra Varchar(1000)
	    ,BCJU51_VERSION_F  INT
		,BCJU41_TygraSPFileLastModifiedDtTm datetime
        ,BCJU41_TYGRA_ID_K INT
		,file_selected    varchar(1)
		                        )
 	;

---******************************************************
-- in UI user selects program.  Program is passed to ACT V53 and a list of file names is 
-- returned to UI. 
 --******************************************************
-- For testing. in prod this will be passed in from UI
--set @U41_ProgramNm = 'u71x' ; -- passed in from UI

-- returns all distinct files fro UB1
INSERT INTO ##file_list
select 
[ARWUB1_TYGRA_FILE_PGM_N]   
,[ARWUB1_WRKSHP_N]      
,[ARWUB1_REV_STAT_N]  
,[ARWUB1_TYGRA_FILE_N]   
,[ARWUB1_TYGRA_FILE_REV_R]
,[ARWUB1_REV_S]
,[BCJU41_TYGRA_ID_K]
,'N'
 from  [dbo].[PARWUB1_TYGRA_FILE] ub1
 join  [dbo].[PBCJV53_TYGRA_ARROW_LNK_SYN] v53
 on ub1.[ARWUB1_TYGRA_FILE_N] = v53.[BCJU41_FileNameSPTygra]
 and ub1.[ARWUB1_TYGRA_FILE_REV_R] = v53.[BCJU51_VERSION_F]
 and ub1.[ARWUB1_TYGRA_FILE_PGM_N] = v53.[BCJU41_ProgramNm]
where BCJU41_ProgramNm = @U41_ProgramNm 

select * from  ##file_list




GO
