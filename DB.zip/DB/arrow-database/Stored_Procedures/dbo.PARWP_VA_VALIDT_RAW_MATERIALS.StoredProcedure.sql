SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 07/29/2019
-- Description:	validate VA Adjustment Costs: raw materials
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2  09/09/19     Added calculated field validations
-- Asolosky  09/10/2019   Added row_idx
-- rwesley2  09/13/2019  added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- asolosky  09/30/2019   Changed error messages to more descriptive
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky  07/24/2020   US1771016 used the replace function for change_id and part_name to display a line feed
-- Ashaik12  09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  04/12/2021   US2430172 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021   US2815039 Added a case statement in the first change id validation. Had to create the case by template version.
--                        When change id does not belong the BOM Sub Assembly display an error. This happens if the user does a copy paste from another sheet. 
-- Asolosky  06/10/2022   US3700154 Added new error to reject a file if the supplier quoted a change id with a type of DELETE 
-- ASHAIK12  06/28/2022   US3778477 Add new validations for Variant Improvement Ideas
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VA_VALIDT_RAW_MATERIALS] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

                 
--++++++++++++++++++++++++++++++++++++
    -- Change ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c                                                                          as [ARWE02_SOURCE_C]
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')                       as [ARWE02_ERROR_VALUE]
	  ,Error_x                                                                           as [ARWE02_ERROR_X]
	  ,Processing_ID                                                                     as [ARWE02_PROCESSING_ID]
	  ,filename                                                                          as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)                                                             as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP                                                                       as [ARWE02_CREATE_S]
	  ,@CDSID                                                                            as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP                                                                       as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                                                                            as [ARWE02_LAST_UPDT_USER_C]
	  ,ARWS51_VA_RAW_MATERIALS_K                                                         as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO'                                                   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                                                                           as ARWE02_ROW_IDX
	  ,change_id
	  ,''
 FROM 
       (
        SELECT 
		       S51.Processing_ID,
               S51.change_id,
		       S51.Source_c,
		       S51.filename,
               S51.ARWS51_VA_RAW_MATERIALS_K,
		       S51.sub_assembly_name,
		       S51.row_idx,
		       Case When S45.TEMPLATE_VERSION < 'V2.5' --For old templates not broken out by sub-assembly
			        Then Case When coalesce(S46.change_id,'~') != S51.change_id  
			                  Then 'Adjustment Costs for Raw Materials - Invalid Change ID.'					 
					          Else ''
						  End
				    Else -- Version >= 'V2.5'  New Template starts at V2.5
			             Case When Substring(S46.sheet_name,5,DATALENGTH(S46.sheet_name)) != Substring(S51.sub_assembly_name,7,DATALENGTH(S51.sub_assembly_name)) 
		                      Then 'Raw Materials: Change Id was found on a different ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  When S46.sheet_name  is Null
			                  Then 'Raw Materials: Change Id was not found on any ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  Else ''
						 End
		       End Error_x
          FROM PARWS51_VA_RAW_MATERIALS_INFO      S51
          Join PARWS45_VA_COVER_PAGE_INFO         S45
		    ON S45.Processing_ID = S51.Processing_ID
		   and S45.filename      = S51.filename
		   and s51.cost_type='Adjustment Costs'
     Left Join PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
            ON S46.change_id     = S51.change_id
		   and S46.filename      = S51.filename
		   and S46.Processing_ID = S51.Processing_ID
         WHERE S51.Processing_ID = @GUID                    
       ) Err
 Where Error_x != ''
;

-- NEW Validation for Improvement Ideas

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')  as [ARWE02_ERROR_VALUE]
	  ,'Improvement Costs for Raw Materials - Improvement ID was not found on the Improvement Ideas Sheet. Please do not copy/paste. Use the drop down to select the Improvement Id.' as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.ARWS51_VA_RAW_MATERIALS_K as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,''  --No ARROW Value 
       FROM 
       (
        SELECT 
		  Processing_ID,
          [change_id],
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS51_VA_RAW_MATERIALS_K,
		  sub_assembly_name,
		  row_idx
        FROM 
          [dbo].[PARWS51_VA_RAW_MATERIALS_INFO] s51
        WHERE Processing_ID=@GUID
			and s51.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s51.[change_id] = s67.improvement_id
				 and s51.[filename] =  s67.filename
				 and s51.Processing_ID=s67.Processing_ID
				 

)
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
    -- Change ID Part Description validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  as [ARWE02_ERROR_VALUE]
	  ,'Raw Materials - Name does not match  Adjustment Details Part Name'   as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS51_VA_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,''
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS51_VA_RAW_MATERIALS_K],
		  sub_assembly_name,
		  row_idx,
		  change_id
        FROM [dbo].[PARWS51_VA_RAW_MATERIALS_INFO] s51
        WHERE Processing_ID= @GUID
	and s51.cost_type='Adjustment Costs'
	   and Not Exists
		      (Select 'X'
               from [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
               where s51.[change_id]      = s46.change_id
			     and s51.part_description = s46.part_name
				 and s51.[filename]       = s46.[filename]
				 and s51.Processing_ID    = s46.Processing_ID

)
                    
       ) Err

    ;
    
 -- New Validation for Improvement Ideas
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  as [ARWE02_ERROR_VALUE]
	  ,'Raw Materials - Name does not match  Adjustment Details Part Name'   as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS51_VA_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,''
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS51_VA_RAW_MATERIALS_K],
		  sub_assembly_name,
		  row_idx,
		  change_id
        FROM [dbo].[PARWS51_VA_RAW_MATERIALS_INFO] s51
        WHERE Processing_ID= @GUID
		and s51.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s51.[change_id]      = s67.improvement_id
			     and s51.part_description = s67.part_name
				 and s51.[filename]       = s67.[filename]
				 and s51.Processing_ID    = s67.Processing_ID

)
                    
       ) Err

    ;

-- New Validation for Improvement Ideas
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  as [ARWE02_ERROR_VALUE]
	  ,'Raw Materials - Name does not match  Adjustment Details Part Name'   as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS51_VA_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,''
       FROM 
       (
        SELECT 
          Processing_ID,
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS51_VA_RAW_MATERIALS_K],
		  sub_assembly_name,
		  row_idx,
		  change_id
        FROM [dbo].[PARWS51_VA_RAW_MATERIALS_INFO] s51
        WHERE Processing_ID= @GUID
		and s51.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s51.[change_id]      = s67.improvement_id
			     and s51.part_description = s67.part_name
				 and s51.[filename]       = s67.[filename]
				 and s51.Processing_ID    = s67.Processing_ID

)
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] as [ARWE02_SOURCE_C]
	  ,Err.[local_currency]  as [ARWE02_ERROR_VALUE]
	  ,'Raw Materials - Invalid Currency Code'  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename]  as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_LAST_UPDT_S]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID   as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS51_VA_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
	  ,''
       FROM 
       (
        SELECT 
          Processing_ID,
          [local_currency],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS51_VA_RAW_MATERIALS_K],
		  sub_assembly_name,
		  row_idx,
		  change_id
        FROM [dbo].[PARWS51_VA_RAW_MATERIALS_INFO] s51
        WHERE Processing_ID=@GUID
			and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s51.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;
---------------------------------------------------------------
--   START calculated field validation
---------------------------------------------------------------
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Reclaim revenue [LoCur/pc]
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c] as ARWE02_SOURCE_C
	  ,Err.reclaim_revenue 
	  ,'Raw materials - Reclaim revenue, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID] as [ARWE02_PROCESSING_ID]
	  ,Err.[filename] as [ARWE02_FILENAME]
	  ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP  as [ARWE02_CREATE_S]
	  ,@CDSID  as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
	  ,@CDSID as [ARWE02_LAST_UPDT_USER_C]
	  ,Err.[ARWS51_VA_RAW_MATERIALS_K] as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS51_VA_RAW_MATERIALS_INFO' as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,change_id
	  ,'Calculated ' + CAST(Err.Calculated_value as Varchar(50)) 
       FROM 
       (
        SELECT 
          Processing_ID,
          change_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS51_VA_RAW_MATERIALS_K,
		  sub_assembly_name,
		  reclaim_revenue, 
 		  ((gross_usage_per_piece-net_usage_per_piece)*reclamation_pcntg*scrap_price) as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS51_VA_RAW_MATERIALS_INFO] s51
        WHERE Processing_ID= @GUID
	        and ABS(((gross_usage_per_piece-net_usage_per_piece)*reclamation_pcntg*scrap_price) - (reclaim_revenue)) > @threshold
			     
       ) Err

    ;

---------------------------------------------------------------
--   END calculated field validation
---------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Raw materials: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS51_VA_RAW_MATERIALS_K
	  ,'PARWS51_VA_RAW_MATERIALS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.change_id 
	  ,'' 
  FROM 
      (
        SELECT 
               S51.Processing_ID
              ,s51.exchange_rate
  		      ,s51.Source_c
  		      ,s51.filename
              ,s51.ARWS51_VA_RAW_MATERIALS_K
  		      ,s51.sub_assembly_name
  		      ,s51.change_id
			  ,s51.row_idx
			  ,S57.usd_per_local_currency
			  ,S57.supplier_picked_crcy_c
          FROM PARWS51_VA_RAW_MATERIALS_INFO   S51
		  Join PARWS57_VA_EXCHANGE_RATE_TAB    S57
		    On S57.Processing_ID  = S51.Processing_ID
		   And S57.filename       = S51.filename
		   And S57.currency_code  = S51.local_currency
         WHERE S51.Processing_ID  = @GUID
		   and S51.exchange_rate != S57.usd_per_local_currency
      ) Err
;
--++++++++++++++++++++++++++++++++++++
-- DA type DELETE validation
--+++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
       S51.Source_c
      ,S51.change_id 
      ,'This Part Index is being deleted. Remove it from Raw Materials. Please quote only the Assembly and Final Assembly adjustment for the DELETE.' AS ARWE02_ERROR_X 
      ,S51.Processing_ID
      ,S51.filename
      ,OBJECT_NAME(@@PROCID) 
      ,@TIME_STAMP 
      ,@CDSID   
      ,@TIME_STAMP   
      ,@CDSID  
      ,S51.ARWS51_VA_RAW_MATERIALS_K 
      ,'PARWS51_VA_RAW_MATERIALS_INFO'     
      ,'ERROR'
      ,S51.sub_assembly_name 
      ,S51.row_idx
      ,S51.change_id
      ,''  --No ARROW Value
  FROM PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
  Join PARWS51_VA_RAW_MATERIALS_INFO      S51  ON S51.Processing_ID  = S46.Processing_ID
                                              AND S51.filename       = S46.filename
	 								                   AND S51.change_id      = S46.change_id
 WHERE S46.Processing_ID  = @GUID          
   AND S46.type_of_change = 'DELETE'
	AND S51.cost_type      = 'Adjustment Costs'
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS51_VA_RAW_MATERIALS_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''
		,''
;
END CATCH;	




GO
