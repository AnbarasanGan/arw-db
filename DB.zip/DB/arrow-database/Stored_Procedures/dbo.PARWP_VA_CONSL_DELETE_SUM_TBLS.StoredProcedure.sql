SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASOLOSKY
-- Create date: 03/20/2020
-- Description:	Delete Procedure for variant summary table.  
--              UI Exchange rate update only needs to delete the summary tables before recalculating.
--              Copied the deletes from PARWP_VA_DELETE_TABLES
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12   07/27/2022  US3876656 : Add UD9 VAII summary table
-- ASHAIK12   07/29/2022  US3876656 : Revert change, we created new SP to delete UD9
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VA_CONSL_DELETE_SUM_TBLS] 
@CCTSS_K       Int

AS

SET NOCOUNT ON;

--********** Delete Statements for Variant related tables U66 - U72 and U81 **********--

--DELETE: using Merge statement to Delete data in the PARWU81_SUPL_VRNT_ADJ table when it's reloaded.
MERGE INTO PARWU81_SUPL_VRNT_ADJ   U81_Target
Using
(
Select u81.ARWU09_CCTSS_VRNT_SUPL_K
  From PARWU81_SUPL_VRNT_ADJ  U81
  Join PARWU09_CCTSS_VRNT_SUPL_FLAT U09 On U81.ARWU09_CCTSS_VRNT_SUPL_K = u09.ARWU09_CCTSS_VRNT_SUPL_K
 Where U09.ARWU01_CCTSS_K = @CCTSS_K
) as U81_Source

ON (U81_Target.ARWU09_CCTSS_VRNT_SUPL_K = U81_Source.ARWU09_CCTSS_VRNT_SUPL_K)
WHEN MATCHED THEN DELETE;


GO
