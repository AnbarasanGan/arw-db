SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ashaik12
-- Create date: 2020-02-17
-- Description:	This procedure contains delete logic pulled from
-- PARWP_DAII_LOAD_ADJUSTMENT_DETAILS in 'Pre PBOM'
-- =============================================
-- Changes
-- =============================================
-- Date       Author   Story      Description
-- ------     -----    ---------  -----------
-- 05/23/2022 asolosky US3612606  Removed the Delete for U73 and U74. Those deletes are now in PARWP_DAII_CONSL_DELETE_SUM_TBLS
-- =============================================
CREATE or ALTER PROCEDURE  [dbo].[PARWP_DAII_ADJ_DELETE] 
-- Input Parameter
@GUIDIN   Varchar(5000),
@CDSID	  Varchar(30),
@CCTSS_K  Int,
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

----------------------------------------------------------------------------------------------------- 
--Delete Section
-----------------------------------------------------------------------------------------------------

--DELETE: using Merge statement to Delete data in the PARWU38_SUPL_DSGN_ADJ_PART table.  This will handle reloading of a file.
MERGE INTO PARWU38_PURC_PART_DSGN_ADJ   U38_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K 
        From PARWS34_DAII_COVER_PAGE_INFO       S34 
        

      -- Join with Supplier Quote View
        JOIN dbo.PARWV04_DSGN_SUPL V04
         ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
        AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
        AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
        AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
        AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
        AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
        AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
        AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
        AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
        AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
        AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

       Where S34.Processing_ID               = @GUIDIN
         And S34.Skip_loading_due_to_error_f         = 0
		 
      ) as U38_Source
 ON ( 
         U38_Target.ARWU08_CCTSS_DSGN_SUPL_K          = U38_Source.ARWU08_CCTSS_DSGN_SUPL_K
    )
WHEN MATCHED THEN DELETE;

--DELETE: PARWU39_RAW_MTRL_DSGN_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU39_RAW_MTRL_DSGN_ADJ   U39_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K 
        From PARWS34_DAII_COVER_PAGE_INFO     S34 
      
       
       -- Join with Design and Supplier View
        JOIN PARWV04_DSGN_SUPL   V04
          ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
         AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
         AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
         AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
         AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
         AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
         AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
         AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
         AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
         AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
         AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N
       Where S34.Processing_ID               = @GUIDIN
         And S34.Skip_loading_due_to_error_f         = 0
	  
      ) as U39_Source
 ON (U39_Target.ARWU08_CCTSS_DSGN_SUPL_K = U39_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;


--DELETE: PARWU40_PROCG_DSGN_ADJ table.  This will handle reloading of a file.
MERGE INTO PARWU40_PROCG_DSGN_ADJ U40_target
USING
  (select  
          v04.ARWU08_CCTSS_DSGN_SUPL_K
     From PARWS34_DAII_COVER_PAGE_INFO       S34 

      
    -- Join with Supplier Qoute View
     JOIN dbo.PARWV04_DSGN_SUPL V04
    ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C
    
      where S34.Processing_ID             = @GUIDIN
        AND S34.Skip_loading_due_to_error_f         = 0

      ) as u40_source
 
ON (u40_target.ARWU08_CCTSS_DSGN_SUPL_K = u40_source.ARWU08_CCTSS_DSGN_SUPL_K)
when MATCHED THEN DELETE
;

--DELETE: PARWU41_ASSY_DSGN_ADJ table. This will handle reloading of a file.
MERGE INTO PARWU41_ASSY_DSGN_ADJ   U41_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
       

      -- Join with Supplier Quote View
        JOIN PARWV04_DSGN_SUPL   V04
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.VARIANT
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	     AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f         = 0

      ) as U41_Source
 ON (U41_Target.ARWU08_CCTSS_DSGN_SUPL_K = U41_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

--DELETE: Final Assembly using Merge statement to Delete data in the PARWU43_FNL_ASSY_DSGN_ADJ table. This will handle reloading of a file.
MERGE INTO PARWU43_FNL_ASSY_DSGN_ADJ   U43_Target
Using
	 ( Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From dbo.PARWS34_DAII_COVER_PAGE_INFO                  COVER_PAGE_STAGE
       

      -- Join with Supplier Quote View
    JOIN [dbo].[PARWV04_DSGN_SUPL]   V04
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V04.[ENG_SUB_CMMDTY_DESC]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.[CTSP_REGION_CODE]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f         = 0

      ) as U43_Source
 ON ( 
         U43_Target.ARWU08_CCTSS_DSGN_SUPL_K = U43_Source.ARWU08_CCTSS_DSGN_SUPL_K
    )
WHEN MATCHED THEN DELETE;

-- Delete for PARWU42_MFG_MRKP_DSGN_ADJ
MERGE INTO [dbo].PARWU42_MFG_MRKP_DSGN_ADJ U42_Target
USING
(
SELECT V04.ARWU08_CCTSS_DSGN_SUPL_K as [ARWU08_CCTSS_DSGN_SUPL_K]
  from [dbo].PARWS34_DAII_COVER_PAGE_INFO            S34
 

  -- SUPPLIER QUOTE VIEW
  JOIN dbo.PARWV04_DSGN_SUPL V04
      ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
   AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
   AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
   AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
   AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
   AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
   AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
   AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
   AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
   AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
   AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C
  
 where S34.Processing_ID               = @GUIDIN
   AND S34.Skip_loading_due_to_error_f         = 0

) as U42_SOURCE
ON
(
U42_Target.[ARWU08_CCTSS_DSGN_SUPL_K]=U42_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K]
--AND U52_Target.[ARWA38_MFG_MRKP_TYP_K] = U52_Source.[ARWA38_MFG_MRKP_TYP_K]
)
WHEN MATCHED THEN DELETE;

--Delete for PARWU44_FNLASSY_MRKP_DSGN_ADJ
MERGE INTO  [dbo].PARWU44_FNLASSY_MRKP_DSGN_ADJ U44_Target
USING
(
Select V04.ARWU08_CCTSS_DSGN_SUPL_K
     -- ,ARWA38_MFG_MRKP_TYP_K 
  From PARWV04_DSGN_SUPL V04
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
        --     ,A38.ARWA38_MFG_MRKP_TYP_K 
        from [dbo].PARWS34_DAII_COVER_PAGE_INFO cover_page_stage
        
      where cover_page_stage.Processing_ID               = @GUIDIN
        AND cover_page_stage.Skip_loading_due_to_error_f         = 0

      ) Staging
   -- ON Staging.Eng_commodity_name    = V04.[ENG_CMMDTY_DESC]
   ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X]     = V04.[ENG_SUB_CMMDTY_DESC]
   AND Staging.[User_Selected_CTSP_N]               = V04.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]        = V04.[CTSP_REGION_CODE]
   AND Staging.[User_Selected_VEH_MAKE_N]           = V04.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]            = V04.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]         = V04.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]       = V04.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]         = V04.[VARIANT]
   AND Staging.[User_Selected_SUPL_N]               = V04.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]         = V04.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]               = V04.ARWA17_SUPL_C
) as U44_SOURCE
ON (U44_Target.[ARWU08_CCTSS_DSGN_SUPL_K] = U44_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K]
    -- AND U54_Target.ARWA38_MFG_MRKP_TYP_K = U54_Source.ARWA38_MFG_MRKP_TYP_K
	)
WHEN MATCHED THEN DELETE;

----------------------------------------------------------------------------------------------------- 
--End Delete Section
-----------------------------------------------------------------------------------------------------
GO
