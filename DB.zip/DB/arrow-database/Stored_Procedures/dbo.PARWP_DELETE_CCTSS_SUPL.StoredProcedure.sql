SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- ============================================================================================
-- Author:		btemkow
-- Create date: 2020-10-19
-- Description:	This SP deletes a CCTSS_SUPL and all data dependent on it. To be invoked via
--				BoB Authoring - Suppliers screen when user chooses to delete a Supplier.
-- Input Parameters:
--		@ARWU07_CCTSS_SUPL_K
-- Output Parameter: 
--		@RESULT - Returns 'SUCCESS' if successful, SQL error message if error occurred
-- How to Run:  
--		EXECUTE @RC = [dbo].[PARWP_DELETE_CCTSS_SUPL] @ARWU07_CCTSS_SUPL_K, @RESULT OUTPUT
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow	  2020-10-23  initial version
-- btemkow    2020-11-19  changed return code to an output parameter
-- btemkow    2021-09-24  US2873403 - added PARWUC2_DC_COST_TRGT_VRNT_SUPL
-- asolosky   2022-01-10  US3190288 Removed the commit and rollback.  The UI will handle it.
-- btemkow    2022-07-07  US3812391 added VII table deletes
-- ============================================================================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_DELETE_CCTSS_SUPL]
 @ARWU07_CCTSS_SUPL_K INT
,@RESULT VARCHAR(MAX) OUTPUT

AS

SET NOCOUNT ON;

	BEGIN TRY
--		BEGIN TRANSACTION

		--U09 delete keys
			declare @U09_delete_keys table (
			ARWU09_CCTSS_VRNT_SUPL_K int
			)

			insert into @U09_delete_keys
			select ARWU09_CCTSS_VRNT_SUPL_K
			from PARWU09_CCTSS_VRNT_SUPL
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			delete from PARWUC2_DC_COST_TRGT_VRNT_SUPL
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUE5_VII_MNLSLCT_FNL_ASSY_STAT
			where ARWU04_CCTSS_VRNT_K in (
				select ARWU04_CCTSS_VRNT_K
				from PARWUE2_VII_MNLSLCT_FNL_ASSY
				where ARWU09_CCTSS_VRNT_SUPL_K in (
					select ARWU09_CCTSS_VRNT_SUPL_K
					from @U09_delete_keys
				)
			)

			delete from PARWUE2_VII_MNLSLCT_FNL_ASSY
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUE4_VII_MNLSLCT_SUB_ASSY_STAT
			where ARWUE4_VII_MNLSLCT_SUB_ASSY_STAT_K in (
				select ARWUE4_VII_MNLSLCT_SUB_ASSY_STAT_K
				from PARWUE4_VII_MNLSLCT_SUB_ASSY_STAT as UE4
				join PARWUE1_VII_MNLSLCT_SUB_ASSY as UE1
					on UE4.ARWU04_CCTSS_VRNT_K = UE1.ARWU04_CCTSS_VRNT_K
					and UE4.ARWU17_BOM_SUB_ASSY_K = UE1.ARWU17_BOM_SUB_ASSY_K
				where UE1.ARWU09_CCTSS_VRNT_SUPL_K in (
					select ARWU09_CCTSS_VRNT_SUPL_K
					from @U09_delete_keys
				)
			)

			delete from PARWUE1_VII_MNLSLCT_SUB_ASSY
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUE3_VII_MNLSLCT_BOM_PART_STAT
			where ARWUE3_VII_MNLSLCT_BOM_PART_STAT_K in (
				select ARWUE3_VII_MNLSLCT_BOM_PART_STAT_K
				from PARWUE3_VII_MNLSLCT_BOM_PART_STAT as UE3
				join PARWUE0_VII_MNLSLCT_BOM_PART as UE0
					on UE3.ARWU04_CCTSS_VRNT_K = UE0.ARWU04_CCTSS_VRNT_K
					and UE3.ARWU18_BOM_PART_K = UE0.ARWU18_BOM_PART_K
				where UE0.ARWU09_CCTSS_VRNT_SUPL_K in (
					select ARWU09_CCTSS_VRNT_SUPL_K
					from @U09_delete_keys
				)
			)

			delete from PARWUE0_VII_MNLSLCT_BOM_PART
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUD9_SUPL_VRNT_IMPRV
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUD8_FNL_ASSY_VRNT_IMPRV
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUD7_ASSY_VRNT_IMPRV
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUD6_PROCG_VRNT_IMPRV
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUD5_RAW_MTRL_VRNT_IMPRV
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUD4_PURC_PART_VRNT_IMPRV
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUA8_VA_MNLSLCT_FNL_ASSY_STAT
			where ARWU04_CCTSS_VRNT_K in (
				select ARWU04_CCTSS_VRNT_K
				from PARWU84_VA_MNLSLCT_FNL_ASSY
				where ARWU09_CCTSS_VRNT_SUPL_K in (
					select ARWU09_CCTSS_VRNT_SUPL_K
					from @U09_delete_keys
				)
			)

			delete from PARWU84_VA_MNLSLCT_FNL_ASSY
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUA7_VA_MNLSLCT_SUB_ASSY_STAT
			where ARWUA7_VA_MNLSLCT_SUB_ASSY_STAT_K in (
				select ARWUA7_VA_MNLSLCT_SUB_ASSY_STAT_K
				from PARWUA7_VA_MNLSLCT_SUB_ASSY_STAT as UA7
				join PARWU83_VA_MNLSLCT_SUB_ASSY as U83
					on UA7.ARWU04_CCTSS_VRNT_K = U83.ARWU04_CCTSS_VRNT_K
					and UA7.ARWU17_BOM_SUB_ASSY_K = U83.ARWU17_BOM_SUB_ASSY_K
				where U83.ARWU09_CCTSS_VRNT_SUPL_K in (
					select ARWU09_CCTSS_VRNT_SUPL_K
					from @U09_delete_keys
				)
			)

			delete from PARWU83_VA_MNLSLCT_SUB_ASSY
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWUA6_VA_MNLSLCT_BOM_PART_STAT
			where ARWUA6_VA_MNLSLCT_BOM_PART_STAT_K in (
				select ARWUA6_VA_MNLSLCT_BOM_PART_STAT_K
				from PARWUA6_VA_MNLSLCT_BOM_PART_STAT as UA6
				join PARWU82_VA_MNLSLCT_BOM_PART as U82
					on UA6.ARWU04_CCTSS_VRNT_K = U82.ARWU04_CCTSS_VRNT_K
					and UA6.ARWU18_BOM_PART_K = U82.ARWU18_BOM_PART_K
				where U82.ARWU09_CCTSS_VRNT_SUPL_K in (
					select ARWU09_CCTSS_VRNT_SUPL_K
					from @U09_delete_keys
				)
			)

			delete from PARWU82_VA_MNLSLCT_BOM_PART
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU81_SUPL_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU72_FNLASSY_MRKP_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU71_FNL_ASSY_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU70_MFG_MRKP_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU69_ASSY_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU68_PROCG_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU67_RAW_MTRL_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU66_PURC_PART_VRNT_ADJ
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)

			delete from PARWU09_CCTSS_VRNT_SUPL
			where ARWU09_CCTSS_VRNT_SUPL_K in (
				select ARWU09_CCTSS_VRNT_SUPL_K
				from @U09_delete_keys
			)


		--U08 key deletes
			declare @U08_delete_keys table (
			ARWU08_CCTSS_DSGN_SUPL_K int
			)

			insert into @U08_delete_keys
			select ARWU08_CCTSS_DSGN_SUPL_K
			from PARWU08_CCTSS_DSGN_SUPL
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			delete from PARWUA5_II_MNLSLCT_FNL_ASSY_STAT
			where ARWU06_CCTSS_DSGN_K in (
				select ARWU06_CCTSS_DSGN_K
				from PARWU80_II_MNLSLCT_FNL_ASSY
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU80_II_MNLSLCT_FNL_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWUA4_II_MNLSLCT_SUB_ASSY_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU79_II_MNLSLCT_SUB_ASSY
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU79_II_MNLSLCT_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWUA3_II_MNLSLCT_BOM_PART_STAT
			where ARWUA3_II_MNLSLCT_BOM_PART_STAT_K in (
				select ARWUA3_II_MNLSLCT_BOM_PART_STAT_K
				from PARWUA3_II_MNLSLCT_BOM_PART_STAT as UA3
				join PARWU78_II_MNLSLCT_BOM_PART as U78
					on UA3.ARWU06_CCTSS_DSGN_K = U78.ARWU06_CCTSS_DSGN_K
					and UA3.ARWU18_BOM_PART_K = U78.ARWU18_BOM_PART_K
				where U78.ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU78_II_MNLSLCT_BOM_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWUA2_DA_MNLSLCT_FNL_ASSY_STAT
			where ARWU06_CCTSS_DSGN_K in (
				select ARWU06_CCTSS_DSGN_K
				from PARWU77_DA_MNLSLCT_FNL_ASSY
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU77_DA_MNLSLCT_FNL_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWUA1_DA_MNLSLCT_SUB_ASSY_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU76_DA_MNLSLCT_SUB_ASSY
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU76_DA_MNLSLCT_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWUA0_DA_MNLSLCT_BOM_PART_STAT
			where ARWUA0_DA_MNLSLCT_BOM_PART_STAT_K in (
				select ARWUA0_DA_MNLSLCT_BOM_PART_STAT_K
				from PARWUA0_DA_MNLSLCT_BOM_PART_STAT as UA0
				join PARWU75_DA_MNLSLCT_BOM_PART as U75
					on UA0.ARWU06_CCTSS_DSGN_K = U75.ARWU06_CCTSS_DSGN_K
					and UA0.ARWU18_BOM_PART_K = U75.ARWU18_BOM_PART_K
				where U75.ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU75_DA_MNLSLCT_BOM_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU74_SUPL_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU73_SUPL_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU99_MNLSLCT_FNLASSYMKRP_STAT
			where ARWU06_CCTSS_DSGN_K in (
				select ARWU06_CCTSS_DSGN_K
				from PARWU62_MNLSLCT_FNL_ASSY_MRKP
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU62_MNLSLCT_FNL_ASSY_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU98_MNLSLCT_FNL_ASSY_STAT
			where ARWU06_CCTSS_DSGN_K in (
				select ARWU06_CCTSS_DSGN_K
				from PARWU61_MNLSLCT_FNL_ASSY
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			) 

			delete from PARWU61_MNLSLCT_FNL_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU97_MNLSLCT_SUBASSYMKRP_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU60_MNLSLCT_SUB_ASSY_MRKP
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU60_MNLSLCT_SUB_ASSY_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU96_MNLSLCT_SUB_ASSY_STAT
			where ARWU57_CCTSS_DSGN_SUB_ASSY_K in (
				select ARWU57_CCTSS_DSGN_SUB_ASSY_K
				from PARWU59_MNLSLCT_SUB_ASSY
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU59_MNLSLCT_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU95_MNLSLCT_DSGN_PART_STAT
			where ARWU19_DSGN_PART_K in (
				select ARWU19_DSGN_PART_K
				from PARWU58_MNLSLCT_DSGN_PART
				where ARWU08_CCTSS_DSGN_SUPL_K in (
					select ARWU08_CCTSS_DSGN_SUPL_K
					from @U08_delete_keys
				)
			)

			delete from PARWU58_MNLSLCT_DSGN_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU56_SUPL_SUB_ASSY
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU55_SUPL_DSGN_PART
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU54_FNLASSYMRKP_DSGN_IMPV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU53_FNL_ASSY_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU52_MFG_MRKP_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU51_ASSY_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU50_PROCG_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU49_RAW_MTRL_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU48_PURC_PART_DSGN_IMPRV
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU44_FNLASSY_MRKP_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU43_FNL_ASSY_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU42_MFG_MRKP_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU41_ASSY_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU40_PROCG_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU39_RAW_MTRL_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU38_PURC_PART_DSGN_ADJ
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU30_FNL_ASSY_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU29_FNL_ASSY_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU28_MFG_MRKP
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU27_ASSY_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU26_PROCG_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU25_RAW_MTRL_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU24_PURC_PART_COST_PARNT
			where ARWU23_PURC_PART_COST_K in (
				select ARWU23_PURC_PART_COST_K
				from PARWU23_PURC_PART_COST as U23
				join @U08_delete_keys as U08_del
					on U23.ARWU08_CCTSS_DSGN_SUPL_K = U08_del.ARWU08_CCTSS_DSGN_SUPL_K
			)

			delete from PARWU23_PURC_PART_COST
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

			delete from PARWU08_CCTSS_DSGN_SUPL
			where ARWU08_CCTSS_DSGN_SUPL_K in (
				select ARWU08_CCTSS_DSGN_SUPL_K
				from @U08_delete_keys
			)

		--U07 key deletes

			delete from PARWU22_SUPL_CRCY_EXCHG_RATE
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			delete from PARWU21_CCTSS_SUPL_CRCY
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			delete from PARWU13_CCTSS_SUPL_DSPLY
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			delete from PARWU12_CCTSS_SUPL_TARFF_RATE
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			delete from PARWU07_CCTSS_SUPL
			where ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K

			--IF (@ARWU07_CCTSS_SUPL_K = 414) begin select 1/0 end;

--			COMMIT TRANSACTION
			SET @RESULT = 'SUCCESS'
		END TRY
		BEGIN CATCH
--			ROLLBACK TRANSACTION
            Declare @u01_Study Varchar(100);
            Set @u01_Study = (Select U07.ARWU31_CTSP_N            + ' ' +
                                     U07.ARWA06_RGN_C             + ' ' +
                              	     substring(u07.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                              	     substring(u07.ARWU01_BNCHMK_VRNT_N,1,25)
                                from PARWU07_CCTSS_SUPL_FLAT U07
                               where U07.ARWU07_CCTSS_SUPL_K = @ARWU07_CCTSS_SUPL_K
            				 );
         
            Set @RESULT = 'Supplier Key: '    + cast(@ARWU07_CCTSS_SUPL_K as varchar(20)) + 
                          ' |Study: '         + ISNULL(@u01_Study, '') +
                          ' |GMT Date/Time: ' + CONVERT(varchar, getutcdate(), 120) +
--                        ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
--                        ' |CDS: '           + SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER)) +
                          ' |Procedure: '     + ERROR_PROCEDURE() + 
					      ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
					      ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
		END CATCH

GO


