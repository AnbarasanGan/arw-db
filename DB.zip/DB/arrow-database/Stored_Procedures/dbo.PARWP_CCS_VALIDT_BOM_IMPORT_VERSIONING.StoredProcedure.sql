DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_IMPORT_VERSIONING]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		asolosky
-- Create date: 2020-02-11
-- Description:	validates Bom tabs when import versioning = 'PBOM and DA UI'  
--              The CCS PBOM information must match the data imported from the PBOM file, except comments.
--              If the data doesn't match, the UI will display all errors. Files with errors aren't loaded.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asolosky   05/20/2020  Added diameter to the validation
-- asolosky   07/16/2020  US1771016  Display  carriage return and line feed for part index and name in error message.
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky   06/04/2021  US2559876 Expanding to 25 sub-assemblies.  Changed the error for Part Index not in BOM tab, to also indicate it might be because of blank Excel rows. 
-- =============================================

-- =============================================
--DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_IMPORT_VERSIONING] 

CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOM_IMPORT_VERSIONING] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Index in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
   SELECT 
	      S13.Source_c
	     ,replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')
	     ,'Part Index does not match a PBOM part that was loaded into Arrow.' 
	     ,S13.Processing_ID
	     ,S13.file_name 
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
	     ,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
	     ,'ERROR'
	     ,'BOM - ' + part_sub_assembly_name
	     ,S13.row_idx
		 ,replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')
		 ,''  --No ARROW Value
     From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
     JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
       ON S22.Processing_ID       = S13.Processing_ID
      And S22.filename            = S13.file_name
     JOIN PARWU06_CCTSS_DSGN_FLAT          U06
       ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
      AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
      AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
      AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
      AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
      AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
      AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
      AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
Left Join PARWU19_DSGN_PART_BOM            U19 
       on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
      And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
    WHERE S22.Processing_ID = @GUID 
	   AND U19.ARWU19_DSGN_PART_K IS NULL;

--++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Index in Arrow does not match file
--++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
    SELECT
	       S22.Source_c
	      ,U19.ARWU18_BOM_PART_IX_N 
	      ,'Part Index in Arrow does not appear in a BOM tab. Verify the part index is in the PBOM file.  Also check if the import file''s BOM sheet has 2 or more blank rows between parts and remove the extra blank rows.' 
	      ,S22.Processing_ID
	      ,S22.filename 
	      ,OBJECT_NAME(@@PROCID)	  
	      ,@TIME_STAMP  
	      ,@CDSID 
	      ,@TIME_STAMP  
	      ,@CDSID
	      ,0
	      ,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
	      ,'ERROR'
	      ,'BOM - ' + ARWU17_BOM_SUB_ASSY_N
	      ,0
		 ,replace(replace(U19.ARWU18_BOM_PART_IX_N,char(10),'<LF>'),char(13),'<CR>')
		 ,''  --No ARROW Value
     FROM PARWS22_CCS_COVER_PAGE_INFO      S22
     JOIN PARWU06_CCTSS_DSGN_FLAT          U06
       ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
	  AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
      AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
      AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
      AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
      AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
      AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
      AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
     Join PARWU19_DSGN_PART_BOM            U19 
       ON U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
LEFT JOIN PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
       ON S13.Processing_ID              = S22.Processing_ID
      AND S13.file_name                  = S22.filename
	  AND S13.part_index                 = U19.ARWU18_BOM_PART_IX_N
    WHERE S22.Processing_ID = @GUID 
	  AND S13.part_index IS NULL;

--++++++++++++++++++++++++++++++++++++++++++++++++
--No sub-assembly validation since it's already done in PARWP_CCS_VALIDT_BOM_PART
--++++++++++++++++++++++++++++++++++++++++++++++++

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Name in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.part_name
        	,'Part Name does not match ARROW Part Name' 
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU18_BOM_PART_IX_N
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.part_name != ARWU18_BOM_PART_X;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Quantity in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.quantity
			,'Quantity does not match ARROW Part Quantity'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND round(S13.quantity,9) != ARWU19_DSGN_PART_Q;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Material Usage in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.material_usage
        	,'Material Usage does not match ARROW Part Material Usage' 
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_MTRL_USG_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND round(S13.material_usage,9) != ARWU19_DSGN_PART_MTRL_USG_Q;


--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Unit of Measure in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.uom
        	,'Unit of Measure does not match ARROW Unit of Measure'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWA27_UOM_C
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.uom != ARWA27_UOM_C;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Material Specification in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.material_spec
        	,'Material Specs does not match ARROW Material Specs'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_MTRL_SPEC_X
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.material_spec != ARWU19_DSGN_PART_MTRL_SPEC_X;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Material Thickness in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.material_thickness
        	,'Material Thickness does not match ARROW Part Thickness'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_MTRL_THK_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND round(S13.material_thickness,9) != ARWU19_DSGN_PART_MTRL_THK_Q;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Length in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.length
        	,'Length does not match ARROW Part Length' 
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_LEN_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND round(S13.length,9) != ARWU19_DSGN_PART_LEN_Q;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Width in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.width
        	,'Width does not match ARROW Part Width' 
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_WID_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND round(S13.Width,9) != ARWU19_DSGN_PART_WID_Q;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Depth in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.depth
        	,'Depth does not match ARROW Part Depth'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_MTRL_DEPTH_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.depth != ARWU19_DSGN_PART_MTRL_DEPTH_Q;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Commodity Specific 1 in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.cmmdty_spec1
        	,'Commodity Specific 1 does not match ARROW Commodity Specific 1'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_CMMDTY_SPCFC1_X
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.cmmdty_spec1 != ARWU19_CMMDTY_SPCFC1_X;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Commodity Specific 2 in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.cmmdty_spec2
        	,'Commodity Specific 2 does not match ARROW Commodity Specific 2'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_CMMDTY_SPCFC2_X
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.cmmdty_spec2 != ARWU19_CMMDTY_SPCFC2_X;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part Commodity Specific 3 in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.cmmdty_spec3
        	,'Commodity Specific 3 does not match ARROW Commodity Specific 3'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_CMMDTY_SPCFC3_X
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID = @GUID 
	     AND S13.cmmdty_spec3 != ARWU19_CMMDTY_SPCFC3_X;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- ERROR: Part diameter in file does not match Arrow
--++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
      SELECT 
        	 S13.Source_c
        	,S13.diameter
        	,'Diameter does not match ARROW Part Diameter'
        	,S22.Processing_ID
        	,S22.filename 
        	,OBJECT_NAME(@@PROCID)	  
        	,@TIME_STAMP  
        	,@CDSID 
        	,@TIME_STAMP  
        	,@CDSID
        	,S13.ARWS13_CCS_FORD_BOM_PARTS_INFO_K
        	,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
        	,'ERROR'
        	,'BOM - ' + S13.part_sub_assembly_name
        	,S13.row_idx
		    ,part_index
		    ,U19.ARWU19_DSGN_PART_DIA_Q
	    From PARWS13_CCS_FORD_BOM_PARTS_INFO  S13
		JOIN PARWS22_CCS_COVER_PAGE_INFO      S22
		  ON S22.Processing_ID              = S13.Processing_ID
		 And S22.filename                   = S13.file_name
	    JOIN PARWU06_CCTSS_DSGN_FLAT          U06
	      ON U06.ARWU31_CTSP_N              = S22.User_Selected_CTSP_N
         AND U06.ARWA06_RGN_C               = S22.User_Selected_CTSP_Region_C
		 AND U06.ARWA03_ENRG_SUB_CMMDTY_X   = S22.User_Selected_ENRG_SUB_CMMDTY_X
		 AND U06.ARWU01_BNCHMK_VRNT_N       = s22.User_Selected_BNCMK_VRNT_N
		 AND U06.ARWA14_VEH_MAKE_N          = S22.User_Selected_VEH_MAKE_N
		 AND U06.ARWA34_VEH_MDL_N           = S22.User_Selected_VEH_MDL_N
		 AND U06.ARWA35_DSGN_VEH_MDL_YR_C   = S22.User_Selected_VEH_MDL_YR_C
		 AND U06.ARWA35_DSGN_VEH_MDL_VRNT_X = S22.User_Selected_VEH_MDL_VRNT_X
        Join PARWU19_DSGN_PART_BOM            U19 
          on U19.ARWU06_CCTSS_DSGN_K        = U06.ARWU06_CCTSS_DSGN_K
		 And U19.ARWU18_BOM_PART_IX_N       = S13.part_index
       Where S22.Processing_ID      = @GUID 
	     AND round(S13.diameter,9) != ARWU19_DSGN_PART_DIA_Q;

END TRY

BEGIN CATCH
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,'' 
			 ,'PARWS13_CCS_FORD_BOM_PARTS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value

END CATCH



GO
