SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =========================================================================================
-- Author:		KVIJAYAB
-- Create date: OCT/06/2021
-- Description:	This should be called only for DC2.0 Studies from cost allocation screen
--				For given U04 key, this SP gives the already allocated 
--				end-item cost per subassembly. And the total sub assembly cost.
-- Input Parameter: 
--		@ARWU04_CCTSS_VRNT_K = the variant key for which the data is required, 
--		@BOV_DSGN_SPLR_KEY	 = the bov design splr key, 
-- Output: Returns the values from a select statement
-- How to Run:  Execute [PARWP_UI_DC_COST_ALLOCATION_EI_ASM] @ARWU04_CCTSS_VRNT_K = 127, @BOV_DSGN_SPLR_KEY = 120
-- Changes
-- =========================================================================================
-- Author     Date         Description
-- ------     -----        -----------
-- kvijayab	  OCT/06/2021  initial version
-- rwesley2   03-28-2022   US3436207 load all variants by U01 key
--                         added join to A19 and A47 to get BOV_DSGN_SPLR_KEY from D19 table. 
-- asolosky   04-28-2022   Removed the joins on D19 and A47 and created a variable to hold the @BOV_DSGN_SPLR_KEY 
-- =========================================================================================


CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_LOAD_D20_DC_COST_ALLOCATION_EI_ASM] 
@ARWU01_CCTSS_K INT,
@CDSID VARCHAR (8),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--The BOV supplier will be the same for each variant in the Study so it only needs to get the first row.
DECLARE @BOV_DSGN_SPLR_KEY INTEGER =
(
 Select top 1 D19.BOV_DSGN_SPLR_KEY
   From PARWU04_CCTSS_VRNT As U04
   Join PARWD19_DC_COST_ALLOCATION_EI D19 On D19.ARWU04_CCTSS_VRNT_K = U04.ARWU04_CCTSS_VRNT_K
  Where U04.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
);

INSERT INTO PARWD20_DC_COST_ALLOCATION_EI_ASM
	-- row wise allocation per assembly
	SELECT  ARWU04_CCTSS_VRNT_K, CONCAT('ROW_', ARWA47_FORD_END_ITM_K, '_', ARWU17_BOM_SUB_ASSY_K) AS DATATYPE, ARWA47_FORD_END_ITM_K, ARWU17_BOM_SUB_ASSY_K, ARWUB0_SUB_ASSY_ALLOC_A AS ASM_QUOTE
	,@TIME_STAMP
	,@CDSID
	,@ARWU01_CCTSS_K
	FROM PARWUA9_VRNT_END_ITM UA9
	JOIN PARWUB0_VRNT_END_ITM_SUB_ASSY UB0 ON UB0.ARWUA9_VRNT_END_ITM_K = UA9.ARWUA9_VRNT_END_ITM_K
	WHERE UA9.ARWU04_CCTSS_VRNT_K in (select ARWU04_CCTSS_VRNT_K from PARWU04_CCTSS_VRNT where ARWU01_CCTSS_K = @ARWU01_CCTSS_K)

	UNION
	
	--total quote per subassembly
	SELECT u04.ARWU04_CCTSS_VRNT_K
	      ,CONCAT('TOTAL_', U56.ARWU17_BOM_SUB_ASSY_K) AS DATATYPE
	      ,NULL                                        AS ARWA47_FORD_END_ITM_K 
	      ,U56.ARWU17_BOM_SUB_ASSY_K
			,SUM(ARWU56_ASSY_TOT_W_MRKP_A)               AS ASM_QUOTE 
         ,@TIME_STAMP
         ,@CDSID	
         ,@ARWU01_CCTSS_K
	 FROM PARWU56_SUPL_SUB_ASSY         U56
	 join PARWU08_CCTSS_DSGN_SUPL_FLAT  u08	on u56.ARWU08_CCTSS_DSGN_SUPL_K = u08.ARWU08_CCTSS_DSGN_SUPL_K
	 join PARWU04_CCTSS_VRNT            u04	on u08.ARWU01_CCTSS_K           = u04.ARWU01_CCTSS_K
	WHERE u08.ARWU08_CCTSS_DSGN_SUPL_K = @BOV_DSGN_SPLR_KEY
     and u04.ARWU04_BNCHMK_F          = 0 
	  and ARWU04_VARIANT_ADJ_ONLY_F    = 0
	GROUP BY u04.ARWU04_CCTSS_VRNT_K,ARWU17_BOM_SUB_ASSY_K

	UNION

	--total quote for final assembly
	SELECT u04.ARWU04_CCTSS_VRNT_K      AS ARWU04_CCTSS_VRNT_K
         ,CONCAT('TOTAL_', 0)          AS DATATYPE
         ,NULL                         AS ARWA47_FORD_END_ITM_K
         ,0                            AS ARWU17_BOM_SUB_ASSY_K
         ,ARWU08_FNL_ASSY_TOT_W_MRKP_A AS SUP_W_MRKUP 
         ,@TIME_STAMP
         ,@CDSID
         ,@ARWU01_CCTSS_K
	 FROM PARWU08_CCTSS_DSGN_SUPL_FLAT U08
	 join PARWU04_CCTSS_VRNT           u04	on u08.ARWU01_CCTSS_K = u04.ARWU01_CCTSS_K
	WHERE u08.ARWU08_CCTSS_DSGN_SUPL_K = @BOV_DSGN_SPLR_KEY
     and u04.ARWU04_BNCHMK_F          = 0 
	  and ARWU04_VARIANT_ADJ_ONLY_F    = 0
;
GO
