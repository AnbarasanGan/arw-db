SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		btemkow
-- Create date: 2021-12-09
-- Description:	
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
--
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_CALC_DELETE_D19_DC_COST_ALLOCATION_EI]
@ARWU01_CCTSS_K        int

AS
--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

DELETE 
  FROM PARWD19_DC_COST_ALLOCATION_EI
 Where ARWU04_CCTSS_VRNT_K in (select ARWU04_CCTSS_VRNT_K 
                                 from PARWU04_CCTSS_VRNT
										  where ARWU01_CCTSS_K = @ARWU01_CCTSS_K);

--  Select 'PARWP_CALC_DELETE_D19_DC_COST_ALLOCATION_EI' as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
--        ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
