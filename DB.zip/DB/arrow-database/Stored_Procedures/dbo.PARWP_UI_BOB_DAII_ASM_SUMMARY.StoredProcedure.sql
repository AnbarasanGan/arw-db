DROP PROCEDURE IF EXISTS [dbo].[PARWP_UI_BOB_DAII_ASM_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =================================================================================================================================================
-- Author:		btemkow
-- Create date: 2021-12-02
-- Description:	
-- =================================================================================================================================================
-- Changes
-- =================================================================================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- 
-- =================================================================================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_BOB_DAII_ASM_SUMMARY] 
-- Parameters for the stored procedure
@ARWU06_CCTSS_DSGN_K        int
AS
SET NOCOUNT ON;


SELECT ROW_KEY
      ,D02.ARWU06_CCTSS_DSGN_K
      ,D02.ARWU08_CCTSS_DSGN_SUPL_K
      ,D02.ARWU17_BOM_SUB_ASSY_K
      ,IsNull(U17.ARWU17_BOM_SUB_ASSY_N, 'Final Assembly') as ARWU17_BOM_SUB_ASSY_N
      ,D02.QTE_TOT
      ,D02.QTE_TOT_W_SUP_MRKP
      ,D02.QTE_TOT_W_ADJ_MRKP
      ,D02.ADJ_BOB
      ,D02.BOB_MANUAL_SEL_KEY
      ,D02.BOB_MANUAL_SEL_COMMENT
      ,D02.DA_TOT
      ,D02.DA_TOT_W_SUP_MRKP
      ,D02.DA_TOT_W_ADJ_MRKP
      ,D02.DA_MIN_SUP_KEY
      ,D02.MIN_DA
      ,D02.ADJ_DA
      ,D02.DA_MANUAL_SEL_KEY
      ,D02.DA_MANUAL_SEL_COMMENT
      ,D02.DA_MANUAL_SEL_TYPE
      ,D02.ADJ_DA_SUP_QTE
      ,D02.II_TOT
      ,D02.II_TOT_W_SUP_MRKP
      ,D02.II_TOT_W_ADJ_MRKP
      ,D02.II_MIN_SUP_KEY
      ,D02.MIN_II
      ,D02.ADJ_II
      ,D02.II_MANUAL_SEL_KEY
      ,D02.II_MANUAL_SEL_COMMENT
      ,D02.II_MANUAL_SEL_TYPE
      ,D02.II_ADJ_QTE
      ,D02.II_ADJ_DA
      ,D02.Display_SEQ
      ,D02.BOB_DVNT_STATUS_KEY
      ,D02.BOB_DVNT_STATUS
      ,D02.BOB_DVNT_CMT
      ,D02.DA_DVNT_STATUS_KEY
      ,D02.DA_DVNT_STATUS
      ,D02.DA_DVNT_CMT
      ,D02.II_DVNT_STATUS_KEY
      ,D02.II_DVNT_STATUS
      ,D02.II_DVNT_CMT
      ,D02.CADA_AUTO
      ,D02.ADJ_BOB_DA
      ,D02.CADA_CHRYPKD
      ,D02.DA_DELTA
      ,D02.CAII_AUTO
      ,D02.CAII_CHRYPKD
      ,D02.II_DELTA
      ,D02.DA_RATIO
      ,D02.II_RATIO
      ,D02.ARWD02_CREATE_S
      ,D02.ARWD02_CREATE_USER_C 
  FROM PARWD02_BOB_DAII_ASM_SUMMARY D02
  LEFT
  JOIN PARWU17_BOM_SUB_ASSY         U17  ON U17.ARWU17_BOM_SUB_ASSY_K = D02.ARWU17_BOM_SUB_ASSY_K
 WHERE D02.ARWU06_CCTSS_DSGN_K = @ARWU06_CCTSS_DSGN_K
 ORDER BY DISPLAY_SEQ
;		



GO
