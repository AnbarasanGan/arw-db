DROP PROCEDURE IF EXISTS [dbo].[PARWP_UI_BOB_TYGRA_MAPPING_SAVE]
GO

/****** Object:  StoredProcedure [dbo].[PARWP_UI_BOB_TYGRA_MAPPING_SAVE]    Script Date: 7/28/2021 10:34:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ============================================================================================
-- Author:		ASHAIK12
-- Create date: 06/30/2021
-- Description:	This SP either deletes the Tygra associated tables or updates based on the action performed in tygra mapping screen.
-- Output: None
--
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   08/05/2021  DE228003: Modify the way we insert into U02.
--                        Change update comment.
-- btemkow    2022-04-06   US3501484 updated status names
-- ============================================================================================

CREATE PROCEDURE [dbo].[PARWP_UI_BOB_TYGRA_MAPPING_SAVE] 

 @ARWU01_CCTSS_K        INT  -- BoB key
,@SCOPE_OR_CURRENT	    VARCHAR(30) -- Scope or Current
,@UB3_K                 INT -- UB3 key of record being modified
,@UB5_K                 INT  -- Exact Ub5 record to update / -1 when its a new insert into ub5 
,@NEW_MAPPING           INT -- 1 for In-Scope , 0 for Out-of-Scope and -1 for Not Applicable
,@CDSID                 VARCHAR(MAX)
,@RESULT                INT OUTPUT

AS

SET NOCOUNT ON;

DECLARE @TIME_STAMP DATETIME = GETUTCDATE();
DECLARE @ARWA11_k   INT;
DECLARE @A47        VARCHAR(MAX);

SET @A47 = (Select A47.ARWA47_FORD_END_ITM_PREF_N + '-' + A47.ARWA47_FORD_END_ITM_BSE_N +'-'+ A47.ARWA47_FORD_END_ITM_SFX_N FROM PARWUB3_TYGRA_FILE_REC UB3 JOIN PARWA47_FORD_END_ITM A47 ON UB3.ARWA47_FEDEBOM_PLN_END_ITM_K=A47.ARWA47_FORD_END_ITM_K where Ub3.ARWUB3_TYGRA_FILE_REC_K=@UB3_K);
--DECLARE @Comment    VARCHAR(1024) = 'Update(s) in Tygra Mapping screen identified for '+ @A47 + ' Starting point record';
Select @ARWA11_k = ARWA11_CCTSS_STAT_K
   From PARWA11_CCTSS_STAT
  Where ARWA11_CCTSS_STAT_N = 'To be Reconciled'
DECLARE @CURRENT_MAPPING INT  -- Get current mapping for the tygra record


if @UB5_K= -1 
Begin 
set @CURRENT_MAPPING= -1
end
else
Begin
SELECT @CURRENT_MAPPING = [ARWUB5_IN_SCOPE_F] FROM PARWUB5_CCTSS_TYGRA_FILE_REC where [ARWUB5_CCTSS_TYGRA_FILE_REC_K]=@UB5_K
end

DECLARE @Comment    VARCHAR(max) = 'Tygra Mapping updated from '+ CASE WHEN @CURRENT_MAPPING=1 THEN 'In-Scope' 
																		 WHEN @CURRENT_MAPPING=0 THEN 'Out of Scope'
																		 WHEN @CURRENT_MAPPING=-1 THEN 'NA' END 
															 + ' to '  + CASE WHEN @NEW_MAPPING=1 THEN 'In-Scope' 
																		 WHEN @NEW_MAPPING=0 THEN 'Out of Scope'
																		 WHEN @NEW_MAPPING=-1 THEN 'NA' END + ' for '+ @A47 + ' Starting point record.';

BEGIN TRY

--IF (@SCOPE_OR_CURRENT ='Scope')
--Begin
	IF (@CURRENT_MAPPING=1 AND @NEW_MAPPING=0) -- Updating the mapping from In-Scope to Out-of-Scope.
		BEGIN -- Begin for In-Scope to Out-of-Scope
	       	UPDATE PARWUB5_CCTSS_TYGRA_FILE_REC 
	       	SET
	         [ARWUB5_IN_SCOPE_F]= @NEW_MAPPING
	        ,[ARWUB5_LAST_UPDT_S]=@TIME_STAMP
	        ,[ARWUB5_LAST_UPDT_USER_C]=@CDSID
	        WHERE [ARWUB5_CCTSS_TYGRA_FILE_REC_K]=@UB5_K
	
	  -- Delete the U63 records 
			MERGE  [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63_T
			using
			(
			select
			[ARWU63_VRNT_BOM_PART_END_ITM_K]
			 from [dbo].[PARWUB3_TYGRA_FILE_REC] UB3
			 JOIN [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63
			 ON U63.[ARWA47_FORD_END_ITM_K] = UB3.[ARWA47_FEDEBOM_PLN_END_ITM_K]
			 AND UB3.ARWUB3_TYGRA_FILE_REC_K=@UB3_K
			 JOIN [dbo].[PARWU04_CCTSS_VRNT] U04
			 ON U04.[ARWU04_CCTSS_VRNT_K]=U63.[ARWU04_CCTSS_VRNT_K]
			 Where U04.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
			 AND [ARWA57_END_ITM_MAP_TYPE_K] = (select [ARWA54_TYGRA_FILE_TYPE_K] FROM [dbo].[PARWA54_TYGRA_FILE_TYPE] 
												where [ARWA54_TYGRA_FILE_TYPE_N]= @SCOPE_OR_CURRENT)
			) SRC
			ON SRC.[ARWU63_VRNT_BOM_PART_END_ITM_K] = U63_T.[ARWU63_VRNT_BOM_PART_END_ITM_K]
			WHEN MATCHED THEN DELETE;

			IF (@SCOPE_OR_CURRENT='Current')
					Begin -- Begin for deleting cost allocation
					-- UB0
						MERGE [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0_T
						using
						(
						Select [ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						From [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0
						JOIN [dbo].[PARWUA9_VRNT_END_ITM] UA9
						ON UA9.[ARWUA9_VRNT_END_ITM_K] = UB0.[ARWUA9_VRNT_END_ITM_K]
						JOIN [dbo].[PARWUB3_TYGRA_FILE_REC] UB3
						ON UB3.[ARWA47_FEDEBOM_PLN_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND UB3.[ARWUB3_TYGRA_FILE_REC_K]=@UB3_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
						WHERE [ARWU01_CCTSS_K]=@ARWU01_CCTSS_K
						) SRC
						ON SRC.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K] = UB0_T.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						WHEN MATCHED THEN DELETE
						;
						
					-- UA9
						MERGE [dbo].[PARWUA9_VRNT_END_ITM] UA9_T
						using
						(
						Select [ARWUA9_VRNT_END_ITM_K]
						From [dbo].[PARWUA9_VRNT_END_ITM] UA9
						JOIN [dbo].[PARWUB3_TYGRA_FILE_REC] UB3
						ON UB3.[ARWA47_FEDEBOM_PLN_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND UB3.[ARWUB3_TYGRA_FILE_REC_K]=@UB3_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
						WHERE [ARWU01_CCTSS_K]=@ARWU01_CCTSS_K
						) SRC
						ON SRC.[ARWUA9_VRNT_END_ITM_K] = UA9_T.[ARWUA9_VRNT_END_ITM_K]
						WHEN MATCHED THEN DELETE
						;

					End; -- End for deleting cost allocation

		End; -- End for In-Scope to Out-of-Scope
			
	
		IF (@CURRENT_MAPPING=0 AND @NEW_MAPPING=1) -- Updating the mapping from Out-of-Scope to In-Scope.
		BEGIN -- Begin for Out-of-Scope to In-Scope
			UPDATE PARWUB5_CCTSS_TYGRA_FILE_REC 
			SET
			   [ARWUB5_IN_SCOPE_F]= @NEW_MAPPING
			  ,[ARWUB5_LAST_UPDT_S]=@TIME_STAMP
			  ,[ARWUB5_LAST_UPDT_USER_C]=@CDSID
				WHERE [ARWUB5_CCTSS_TYGRA_FILE_REC_K]=@UB5_K
		END; -- End for Out-of-Scope to In-Scope

		IF (@CURRENT_MAPPING = -1 AND @NEW_MAPPING=1) -- Updating the mapping from NA to In-Scope.
		BEGIN  -- Begin for NA to In-Scope
			INSERT INTO PARWUB5_CCTSS_TYGRA_FILE_REC 
			SELECT
			    @ARWU01_CCTSS_K  AS [ARWU01_CCTSS_K]
			   ,@UB3_K          AS [ARWUB3_TYGRA_FILE_REC_K]
			   ,@NEW_MAPPING    AS [ARWUB5_IN_SCOPE_F]
			   ,@TIME_STAMP     AS [ARWUB5_CREATE_S]
			   ,@CDSID          AS [ARWUB5_CREATE_USER_C]
			   ,@TIME_STAMP     AS [ARWUB5_LAST_UPDT_S]
			   ,@CDSID          AS [ARWUB5_LAST_UPDT_USER_C]
		END; -- End for NA to In-Scope

		IF (@CURRENT_MAPPING = -1 AND @NEW_MAPPING=0) -- Updating the mapping from NA to Out-of-Scope.
		BEGIN -- Begin for NA to Out-of-Scope
			INSERT INTO PARWUB5_CCTSS_TYGRA_FILE_REC 
			SELECT
			   @ARWU01_CCTSS_K  AS [ARWU01_CCTSS_K]
			   ,@UB3_K          AS [ARWUB3_TYGRA_FILE_REC_K]
			   ,@NEW_MAPPING    AS [ARWUB5_IN_SCOPE_F]
			   ,@TIME_STAMP     AS [ARWUB5_CREATE_S]
			   ,@CDSID          AS [ARWUB5_CREATE_USER_C]
			   ,@TIME_STAMP     AS [ARWUB5_LAST_UPDT_S]
			   ,@CDSID          AS [ARWUB5_LAST_UPDT_USER_C]
		END; -- End for NA to Out-of-Scope



		IF (@CURRENT_MAPPING=0 AND @NEW_MAPPING = -1) -- Updating the mapping from Out-of-Scope to NA.
		BEGIN -- Begin for Out-of-Scope to NA
			DELETE FROM PARWUB5_CCTSS_TYGRA_FILE_REC WHERE ARWUB5_CCTSS_TYGRA_FILE_REC_K = @UB5_K
		END; -- End for Out-of-Scope to NA


		IF (@CURRENT_MAPPING=1 AND @NEW_MAPPING = -1) -- Updating the mapping from In-Scope to NA.
		BEGIN -- Begin for In-Scope to NA
		   -- Delete from UB5 table
			DELETE FROM PARWUB5_CCTSS_TYGRA_FILE_REC WHERE ARWUB5_CCTSS_TYGRA_FILE_REC_K = @UB5_K

			-- Delete the U63 records 
			MERGE  [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63_T
			using
			(
			select
			[ARWU63_VRNT_BOM_PART_END_ITM_K]
			 from [dbo].[PARWUB3_TYGRA_FILE_REC] UB3
			 JOIN [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63
			 ON U63.[ARWA47_FORD_END_ITM_K] = UB3.[ARWA47_FEDEBOM_PLN_END_ITM_K]
			 AND UB3.ARWUB3_TYGRA_FILE_REC_K=@UB3_K
			 JOIN [dbo].[PARWU04_CCTSS_VRNT] U04
			 ON U04.[ARWU04_CCTSS_VRNT_K]=U63.[ARWU04_CCTSS_VRNT_K]
			 Where U04.ARWU01_CCTSS_K = @ARWU01_CCTSS_K
			 AND [ARWA57_END_ITM_MAP_TYPE_K] = (select [ARWA54_TYGRA_FILE_TYPE_K] FROM [dbo].[PARWA54_TYGRA_FILE_TYPE] 
												where [ARWA54_TYGRA_FILE_TYPE_N]= @SCOPE_OR_CURRENT)
			) SRC
			ON SRC.[ARWU63_VRNT_BOM_PART_END_ITM_K] = U63_T.[ARWU63_VRNT_BOM_PART_END_ITM_K]
			WHEN MATCHED THEN DELETE;

				IF (@SCOPE_OR_CURRENT='Current')
					Begin -- Begin for deleting cost allocation
					-- UB0
						MERGE [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0_T
						using
						(
						Select [ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						From [dbo].[PARWUB0_VRNT_END_ITM_SUB_ASSY] UB0
						JOIN [dbo].[PARWUA9_VRNT_END_ITM] UA9
						ON UA9.[ARWUA9_VRNT_END_ITM_K] = UB0.[ARWUA9_VRNT_END_ITM_K]
						JOIN [dbo].[PARWUB3_TYGRA_FILE_REC] UB3
						ON UB3.[ARWA47_FEDEBOM_PLN_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND UB3.[ARWUB3_TYGRA_FILE_REC_K]=@UB3_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
						WHERE [ARWU01_CCTSS_K]=@ARWU01_CCTSS_K
						) SRC
						ON SRC.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K] = UB0_T.[ARWUB0_VRNT_END_ITM_SUB_ASSY_K]
						WHEN MATCHED THEN DELETE
						;
						
					-- UA9
						MERGE [dbo].[PARWUA9_VRNT_END_ITM] UA9_T
						using
						(
						Select [ARWUA9_VRNT_END_ITM_K]
						From [dbo].[PARWUA9_VRNT_END_ITM] UA9
						JOIN [dbo].[PARWUB3_TYGRA_FILE_REC] UB3
						ON UB3.[ARWA47_FEDEBOM_PLN_END_ITM_K] = UA9.[ARWA47_FORD_END_ITM_K]
						AND UB3.[ARWUB3_TYGRA_FILE_REC_K]=@UB3_K
						JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
						WHERE [ARWU01_CCTSS_K]=@ARWU01_CCTSS_K
						) SRC
						ON SRC.[ARWUA9_VRNT_END_ITM_K] = UA9_T.[ARWUA9_VRNT_END_ITM_K]
						WHEN MATCHED THEN DELETE
						;

					End; -- End for deleting cost allocation 

		END; -- End for In-Scope to NA

-- INVALIDATE THE BoB if PBoM is loaded.

DECLARE @PBOM_IMPORTED INT
SET @PBOM_IMPORTED = (select CASE WHEN [ARWU01_PBOM_LAST_IMPT_FILE_N]!='' THEN 1 ELSE 0 END FROM [dbo].[PARWU01_CCTSS_FLAT] 
								where ARWU01_CCTSS_K=@ARWU01_CCTSS_K)
if (@PBOM_IMPORTED=1)  AND 
						( 
						   (@CURRENT_MAPPING=1 AND @NEW_MAPPING=0)    -- In-Scope to Out-of-Scope
						OR (@CURRENT_MAPPING=0 AND @NEW_MAPPING=1)    -- Out-of-Scope to In-Scope
						OR (@CURRENT_MAPPING=1 AND @NEW_MAPPING = -1) -- In-Scope to NA
						OR (@CURRENT_MAPPING = -1 AND @NEW_MAPPING=1) -- NA to In-Scope
						) 
				BEGIN	
					-- INVALIDATE THE BoB
					--EXEC  [dbo].[PARWP_CCTSS_INSERT_BOB_STATUS]        @ARWU01_CCTSS_K, @CDSID, @TIME_STAMP, @ARWA11_k, @Comment;


					MERGE INTO PARWU02_CCTSS_STAT_UPDT U02_Target
					using
					(
					SELECT 
				     @ARWU01_CCTSS_K as [ARWU01_CCTSS_K]
					,GETUTCDATE() as [ARWU02_CCTSS_STAT_EFF_Y]
					) as U02_Source
					on 
					(U02_Target.[ARWU01_CCTSS_K] = U02_Source.[ARWU01_CCTSS_K]
					and U02_Target.[ARWU02_CCTSS_STAT_EFF_Y] = U02_Source.[ARWU02_CCTSS_STAT_EFF_Y])
					WHEN NOT MATCHED THEN 
					INSERT VALUES
					(
					@ARWU01_CCTSS_K          --[ARWU01_CCTSS_K]
					,GETUTCDATE()            -- [ARWU02_CCTSS_STAT_EFF_Y]
					,@ARWA11_k               -- ARWA11_CCTSS_STAT_K
					,@CDSID                  -- ARWU02_CCTSS_STAT_UPDT_USER_C
					,@Comment                -- ARWU02_CCTSS_STAT_UPDT_CMT_X 
					,GETUTCDATE()            -- [ARWU02_CREATE_S]
					,@CDSID                  -- [ARWU02_CREATE_USER_C]
					,GETUTCDATE()            -- [ARWU02_LAST_UPDT_S]
					,@CDSID                  -- ARWU02_LAST_UPDT_USER_C
					)
					;
				




				END

SET @RESULT = 1
END TRY

BEGIN CATCH

SET @RESULT = 0

END CATCH

RETURN @RESULT
GO

