DROP PROCEDURE [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS_USAGE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		rwesley2
-- Create date: 3/18/2019
-- Description:	validate supplier name
-- =============================================
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- Ashaik12   01/10/2020  Added TimeStamp parameter
-- Asolosky   09/11/2020  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value.  Changed NullIf functions to IsNULL
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS_USAGE]

      @GUID varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[source_c]
	  ,Err.usage
	  ,'Supplier Material Usage less than 5% of PBOM Usage' 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)
	  ,@TIME_STAMP  
      ,@CDSID 
	  ,@TIME_STAMP  
	  ,@CDSID 
	  ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	  ,'Material Usage'
	  -- indentity key place holder
	  ,'WARNING' as [ARWE02_ERROR_TYPE_X] 
	  ,'Sub Assembly'  + ' - ' + Err.[ARWU17_BOM_SUB_ASSY_N] as [ARWE02_EXCEL_TAB_X]
	  ,0 AS ARWE02_ROW_IDX
	  ,ARWU18_BOM_PART_IX_N
	  ,''
       FROM 
       (
	   SELECT ARWU31_CTSP_N
      ,[ARWA06_RGN_C]
      ,[ARWA03_ENRG_SUB_CMMDTY_X]
      ,[ARWU01_BNCHMK_VRNT_N]
      ,[ARWA34_VEH_MDL_N]
      ,[ARWA35_DSGN_VEH_MDL_YR_C]
      ,[ARWA35_DSGN_VEH_MDL_VRNT_X]
      ,[ARWU17_BOM_SUB_ASSY_N]
      ,[ARWU18_BOM_PART_IX_N]
      ,[ARWU18_BOM_PART_X]
      ,[ARWU25_GRS_USG_PER_PCE_Q]  as supplier_usage
      ,[ARWU19_DSGN_PART_MTRL_USG_Q]  as pbom_usage
	  ,NULLIF ([ARWU19_DSGN_PART_MTRL_USG_Q],0) * .95   as usage
	  ,s22.[source_c]
	  ,s22.Processing_ID
	  ,s22.filename
	  ,s22.[ARWS22_CCS_COVER_PAGE_INFO_K]
 
  FROM [dbo].[PARWV10_CCS_RAW_MATERIALS_FLAT] v10
  join [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
    on v10.ARWU31_CTSP_N             = s22.[User_Selected_CTSP_N]
      AND v10.[ARWA06_RGN_C]               = s22.[User_Selected_CTSP_Region_C]
      AND v10.[ARWA03_ENRG_SUB_CMMDTY_X]   = s22.[User_Selected_ENRG_SUB_CMMDTY_X]
	  AND V10.ARWU01_BNCHMK_VRNT_N         = s22.[User_Selected_BNCMK_VRNT_N]
      AND v10.[ARWA34_VEH_MDL_N]           = s22.[User_Selected_VEH_MDL_N]
      AND v10.[ARWA35_DSGN_VEH_MDL_YR_C]   = s22.[User_Selected_VEH_MDL_YR_C]
      AND v10.[ARWA35_DSGN_VEH_MDL_VRNT_X] = s22.[User_Selected_VEH_MDL_VRNT_X]
	  AND v10.[ARWA17_SUPL_N]              = s22.[User_Selected_SUPL_N]
	  AND V10.ARWA28_CNTRY_N               = s22.[User_Selected_SUPL_CNTRY_N]
	  AND V10.ARWA17_SUPL_C			       = s22.[User_Selected_SUPL_C]
where IsNULL ([ARWU25_GRS_USG_PER_PCE_Q],0) < IsNULL ([ARWU19_DSGN_PART_MTRL_USG_Q],0)  * 0.95
      AND S22.Processing_ID                = @GUID
       ) Err
    ;


INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[source_c]
	  ,Err.usage
	  ,'Supplier Material Usage more than 15% of PBOM Usage' 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)
	  ,@TIME_STAMP  
      ,@CDSID 
	  ,@TIME_STAMP  
	  ,@CDSID 
	  ,Err.[ARWS22_CCS_COVER_PAGE_INFO_K]
	  ,'Material Usage'
	  -- indentity key place holder
	  ,'WARNING' as [ARWE02_ERROR_TYPE_X] 
	  ,'Sub Assembly'  + ' - ' + Err.[ARWU17_BOM_SUB_ASSY_N] as [ARWE02_EXCEL_TAB_X]
	  ,0 AS ARWE02_ROW_IDX
	  ,ARWU18_BOM_PART_IX_N
	  ,''
       FROM 
       (
	   SELECT ARWU31_CTSP_N
      ,[ARWA06_RGN_C]
      ,[ARWA03_ENRG_SUB_CMMDTY_X]
      ,[ARWU01_BNCHMK_VRNT_N]
      ,[ARWA34_VEH_MDL_N]
      ,[ARWA35_DSGN_VEH_MDL_YR_C]
      ,[ARWA35_DSGN_VEH_MDL_VRNT_X]
      ,[ARWU17_BOM_SUB_ASSY_N]
      ,[ARWU18_BOM_PART_IX_N]
      ,[ARWU18_BOM_PART_X]
      ,[ARWU25_GRS_USG_PER_PCE_Q]  as supplier_usage
      ,[ARWU19_DSGN_PART_MTRL_USG_Q]  as pbom_usage
	  ,NULLIF ([ARWU19_DSGN_PART_MTRL_USG_Q],0) * 1.15  as usage
	  ,s22.[source_c]
	  ,s22.Processing_ID
	  ,s22.filename
	  ,s22.[ARWS22_CCS_COVER_PAGE_INFO_K]
 
  FROM [dbo].[PARWV10_CCS_RAW_MATERIALS_FLAT] v10
  join [dbo].[PARWS22_CCS_COVER_PAGE_INFO] s22
      on v10.ARWU31_CTSP_N             = s22.[User_Selected_CTSP_N]
      AND v10.[ARWA06_RGN_C]               = s22.[User_Selected_CTSP_Region_C]
      AND v10.[ARWA03_ENRG_SUB_CMMDTY_X]   = s22.[User_Selected_ENRG_SUB_CMMDTY_X]
	  AND V10.ARWU01_BNCHMK_VRNT_N         = s22.[User_Selected_BNCMK_VRNT_N]
      AND v10.[ARWA34_VEH_MDL_N]           = s22.[User_Selected_VEH_MDL_N]
      AND v10.[ARWA35_DSGN_VEH_MDL_YR_C]   = s22.[User_Selected_VEH_MDL_YR_C]
      AND v10.[ARWA35_DSGN_VEH_MDL_VRNT_X] = s22.[User_Selected_VEH_MDL_VRNT_X]
	  AND v10.[ARWA17_SUPL_N]              = s22.[User_Selected_SUPL_N]
	  AND V10.ARWA28_CNTRY_N               = s22.[User_Selected_SUPL_CNTRY_N]
	  AND V10.ARWA17_SUPL_C			       = s22.[User_Selected_SUPL_C]
   where IsNULL ([ARWU25_GRS_USG_PER_PCE_Q],0) >  IsNULL ([ARWU19_DSGN_PART_MTRL_USG_Q],0) * 1.15
      AND S22.Processing_ID                = @GUID
        ) Err
    ;

GO
