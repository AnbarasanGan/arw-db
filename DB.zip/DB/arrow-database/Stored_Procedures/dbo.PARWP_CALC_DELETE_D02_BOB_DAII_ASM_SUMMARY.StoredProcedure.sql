DROP PROCEDURE If Exists [dbo].[PARWP_CALC_DELETE_D02_BOB_DAII_ASM_SUMMARY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 10/22/2021
-- Description:	Procedure to Delete the PARWD02_BOB_DAII_ASM_SUMMARY table based on the design passed in
-- =============================================
-- Changes
-- =============================================
-- Date       Author   User Story  Description
-- ------     -----    ----------  -----------
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CALC_DELETE_D02_BOB_DAII_ASM_SUMMARY]
@T06_CCTSS_DSGN  [dbo].[PARWT06_CCTSS_DSGN] READONLY
AS

--Declare @Start_Time DATETIME = GETUTCDATE();
Begin

--  Select * FROM @T06_CCTSS_DSGN;

  Delete PARWD02_BOB_DAII_ASM_SUMMARY
   Where ARWU06_CCTSS_DSGN_K In (Select ARWU06_CCTSS_DSGN_K FROM @T06_CCTSS_DSGN)
  ;
--  Select OBJECT_NAME(@@PROCID)                      as Procedure_Name 
--        ,@@Rowcount                                 as Records_Deleted
 --       ,convert(time, GETUTCDATE() - @Start_Time ) as run_time
END;
GO
