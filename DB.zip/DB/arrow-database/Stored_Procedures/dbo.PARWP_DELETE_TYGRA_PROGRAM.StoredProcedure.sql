DROP PROCEDURE [dbo].[PARWP_DELETE_TYGRA_PROGRAM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ============================================================================================
-- Author:	rwesley2
-- Create date: 06/02/2021
-- Description:	Deletes a Tygra program
-- if @file_type is 1 (scope) then it deletes UB6, UB5, and U63.  
-- if @file_type is 2 (current) then it deletes UB6, UB5, U63, UB0 and UA9
-- the deletes for UB63, UB5, and UB6 is common to both Scope andCurrent file types
-- The SP is ON REQUEST ONLY and requires Business and IT approval to run
-- 
-- Output: @ERROR
-- 
-- Changes:
-- ============================================================================================
-- Author     Date        Description
-- ------     -----       -----------
-- ============================================================================================

CREATE PROCEDURE [dbo].[PARWP_DELETE_TYGRA_PROGRAM] 
 @Program_name varchar(MAX)
,@file_type INT
,@ERROR          Varchar(MAX) OUTPUT

AS

SET NOCOUNT ON;

-- Common Deletes for SCOPE and CURRENT file types
Drop TABLE if Exists #delete_key
CREATE TABLE #delete_key (ARWU01_CCTSS_K INT, ARWA54_TYGRA_FILE_TYPE_K INT,ARWUB1_TYGRA_FILE_K INT)
INSERT into #delete_key 
Select u01.ARWU01_CCTSS_K ,ARWA54_TYGRA_FILE_TYPE_K, ARWUB1_TYGRA_FILE_K
FROM PARWU01_CCTSS_flat    U01 
join [dbo].[PARWUB6_CCTSS_TYGRA_FILE] ub6 
on u01.ARWU01_CCTSS_K = ub6.ARWU01_CCTSS_K
Where U01.ARWU31_CTSP_N = @Program_name;


BEGIN TRY
  BEGIN TRANSACTION
  
  MERGE  PARWU63_VRNT_BOM_PART_END_ITM U63 
using
(
 select
[ARWU63_VRNT_BOM_PART_END_ITM_K]
 from [dbo].PARWU63_VRNT_BOM_PART_END_ITM U63
 JOIN [dbo].[PARWU04_CCTSS_VRNT_FLAT] U04
 ON U04.[ARWU04_CCTSS_VRNT_K]=U63.[ARWU04_CCTSS_VRNT_K]
 Join #delete_key                                  
  ON u04.ARWU01_CCTSS_K = #delete_key.ARWU01_CCTSS_K
 where [ARWA57_END_ITM_MAP_TYPE_K] = #delete_key.ARWA54_TYGRA_FILE_TYPE_K
) X
ON X.ARWU63_VRNT_BOM_PART_END_ITM_K = U63.ARWU63_VRNT_BOM_PART_END_ITM_K
WHEN MATCHED THEN DELETE
;

   DELETE ub6
	   From [dbo].PARWUB6_CCTSS_TYGRA_FILE UB6
		    Join #delete_key ON #delete_key.ARWU01_CCTSS_K = UB6.ARWU01_CCTSS_K
			and #delete_key.ARWA54_TYGRA_FILE_TYPE_K = ub6.ARWA54_TYGRA_FILE_TYPE_K
       ;

   DELETE ub5
      From [dbo].PARWUB5_CCTSS_TYGRA_FILE_REC UB5
 		   Join #delete_key ON #delete_key.ARWU01_CCTSS_K = UB5.ARWU01_CCTSS_K
	  ;

-- Delete for SCOPE file type
IF (@file_type = 1)  
Begin
select '5'
-- cureate cursor
-- add invalidate BoBs SP
End;



-- Delete for CURRENT file type
IF (@file_type = 2)  
Begin

-- deletes all variants including the benchmark
MERGE  PARWUB0_VRNT_END_ITM_SUB_ASSY  UB0
using
(
Select ARWUB0_VRNT_END_ITM_SUB_ASSY_K
From PARWUB0_VRNT_END_ITM_SUB_ASSY UB0D
JOIN PARWUA9_VRNT_END_ITM UA9
  ON UA9.ARWUA9_VRNT_END_ITM_K = UB0D.ARWUA9_VRNT_END_ITM_K
JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 
  ON UA9.[ARWU04_CCTSS_VRNT_K]=U04.[ARWU04_CCTSS_VRNT_K]
join #delete_key             -- this join replaces the code below
on u04.ARWU01_CCTSS_K = #delete_key.ARWU01_CCTSS_K
--AND ARWU04_CCTSS_VRNT_K in (Select ARWU04_CCTSS_VRNT_K
--     FROM PARWU04_CCTSS_VRNT u04
--	 join #delete_key
--	 on u04.ARWU01_CCTSS_K = #delete_key.ARWU01_CCTSS_K)
)X
ON X.ARWUB0_VRNT_END_ITM_SUB_ASSY_K = UB0.ARWUB0_VRNT_END_ITM_SUB_ASSY_K
WHEN MATCHED THEN DELETE
;

MERGE  PARWUA9_VRNT_END_ITM UA9
using
( 
Select ARWUA9_VRNT_END_ITM_K
From PARWUA9_VRNT_END_ITM UA9D
JOIN [dbo].[PARWU04_CCTSS_VRNT] U04 
ON UA9D.[ARWU04_CCTSS_VRNT_K] = U04.[ARWU04_CCTSS_VRNT_K]
join #delete_key             -- this join replaces the code below
on u04.ARWU01_CCTSS_K = #delete_key.ARWU01_CCTSS_K
--WHERE ARWU04_CCTSS_VRNT_K in (Select ARWU04_CCTSS_VRNT_K 
--     FROM PARWU04_CCTSS_VRNT u04
--	 join #delete_key
--	 on u04.ARWU01_CCTSS_K = #delete_key.ARWU01_CCTSS_K)
) X
ON X.ARWUA9_VRNT_END_ITM_K = UA9.ARWUA9_VRNT_END_ITM_K
WHEN MATCHED THEN DELETE
;


END

  COMMIT TRANSACTION
  PRINT 'PARWP_DELETE_TYGRA_PROGRAM success'
END TRY

BEGIN CATCH
   ROLLBACK TRANSACTION
   Set @ERROR = ERROR_PROCEDURE() + ' Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900);
   Print @ERROR;
END CATCH
;


GO
