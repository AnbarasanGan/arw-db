SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 6/21/2019
-- Description:	validate DAII Adjustment Costs: purchased parts
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12  07/30        Added Validations to check Improvement Id against Improevement Ideas table
-- rwesley2  07/31/19     Added calculated field validations
-- asolosky  08/15/19     Changed the warning message from "Tax and Duty" to "Total Cost (TC) [LoCur/pc]"
-- asamriya  09/10/2019   Added row_idx
-- rwesley2  09/13/2019   added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky  07/24/2020   US1771016 used the replace function for change_id and part_name to display a line feed
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  04/12/2021   US2430169 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021   US2815039 Added a case statement in the first change id validation. Had to create the case by template version.
--                        When change id does not belong the BOM Sub Assembly display an error. This happens if the user does a copy paste from another sheet.
-- Asolosky  06/01/2022   US3664508 Added new error to reject a file if the supplier quoted a change id with a type of DELETE 
-- =============================================
CREATE or ALTER PROCEDURE [dbo].[PARWP_DAII_VALIDT_PURCHASED_PARTS] 

@GUID varchar(5000), 
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


--++++++++++++++++++++++++++++++++++++
-- Change improvement ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_improvement_id,char(10),'<LF>'),char(13),'<CR>') 
      ,Error_x              AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS39_DAII_PURCHASED_PARTS_K 
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
  FROM 
       (
        SELECT 
		       S39.Processing_ID,
               S39.change_improvement_id,
		       S39.Processing_Status_x,
		       S39.Source_c,
		       S39.filename,
               S39.ARWS39_DAII_PURCHASED_PARTS_K,
		       S39.sub_assembly_name,
		       S39.row_idx,
		       Case When S34.TEMPLATE_VERSION < 'V2.6' --For old templates not broken out by sub-assembly
			        Then Case When coalesce(S35.change_id,'~')    != S39.change_improvement_id  
			                  Then 'Adjustment Costs for Purchased Parts - Invalid Change ID.'					 
					          Else ''
						  End
				    Else -- Version >= 'V2.6'
			             Case When Substring(S35.sheet_name,5,DATALENGTH(S35.sheet_name)) != Substring(S39.sub_assembly_name,7,DATALENGTH(S39.sub_assembly_name)) 
		                      Then 'Purchased Parts: Change Id was found on a different ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  When S35.sheet_name               is Null
			                  Then 'Purchased Parts: Change Id was not found on any ADJ Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the Change Id.'
			                  Else ''
						 End
		       End Error_x
          FROM PARWS39_DAII_PURCHASED_PARTS_INFO    S39
          Join PARWS34_DAII_COVER_PAGE_INFO         S34
		    ON S34.Processing_ID = S39.Processing_ID
		   and S34.filename      = S39.filename
     Left Join PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
            ON S35.change_id     = S39.change_improvement_id
		   and S35.filename      = S39.filename
		   and S35.Processing_ID = S39.Processing_ID
         WHERE S39.Processing_ID = @GUID          
		   and S39.cost_type     = 'Adjustment Costs'              
       ) Err
 Where Error_x != ''
;

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_improvement_id,char(10),'<LF>'),char(13),'<CR>')
      ,'Improvement Costs for Purchased Parts - Improvement ID was not found on the Improvement Ideas Sheet. Please do not copy/paste. Use the drop down to select the Improvement Id.'    AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS39_DAII_PURCHASED_PARTS_K 
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          change_improvement_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS39_DAII_PURCHASED_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM  [dbo].[PARWS39_DAII_PURCHASED_PARTS_INFO] s39
        WHERE Processing_ID= @GUID
			and S39.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO s44
               where s39.[change_improvement_id] = s44.improvement_id
				 and s39.[filename] = s44.[filename]
				 and s39.Processing_ID = s44.Processing_ID
				 

)
                    
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.[local_currency] 
      ,'Purchased Parts - Invalid Currency Code'    AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID   
	  ,Err.[ARWS39_DAII_PURCHASED_PARTS_K]
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
         [local_currency],
		  Processing_Status_x,
		  change_improvement_id,
		  Source_c,
		  filename,
          [ARWS39_DAII_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM 
          [dbo].[PARWS39_DAII_PURCHASED_PARTS_INFO] s39
        WHERE Processing_ID=@GUID
			and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s39.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Change improvement ID Part Description Validation 
--++++++++++++++++++++++++++++++++++++++++++++++++++
   Insert Into  [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  
      ,'Adjustment Costs for Purchased Parts - Part Name does not match Adjustment Details Part Name' AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.[ARWS39_DAII_PURCHASED_PARTS_K] 
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [change_improvement_id],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS39_DAII_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM  [dbo].[PARWS39_DAII_PURCHASED_PARTS_INFO] s39
        WHERE Processing_ID= @GUID
			and S39.cost_type='Adjustment Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS35_DAII_ADJUSTMENT_DETAILS_INFO] s35
               where s39.[change_improvement_id] = s35.change_id
			     and s39.[part_description] = s35.[part_name]
				 and s39.[filename] = s35.[filename]
				 and s39.Processing_ID = s35.Processing_ID
				 

)
                    
       ) Err
;

   Insert Into  [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>') 
      ,'Improvement Costs for Purchased Parts - Part Name does not match Improvement Ideas Part Name'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.[ARWS39_DAII_PURCHASED_PARTS_K] 
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,Err.row_idx
	  ,change_improvement_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [change_improvement_id],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS39_DAII_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM  [dbo].[PARWS39_DAII_PURCHASED_PARTS_INFO] s39
        WHERE Processing_ID= @GUID
			and S39.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS44_DAII_IMPROVEMENT_IDEAS_INFO s44
               where s39.[change_improvement_id] = s44.improvement_id
			     and s39.[part_description] = s44.[part_name]
				 and s39.[filename] = s44.[filename]
				 and s39.Processing_ID = s44.Processing_ID
				 

)
                    
       ) Err
;
-------------------------------------------------------------
--  START calculated field validations
-------------------------------------------------------------
--++++++++++++++++++++++++++++++++++++
-- Calculated fields validation check for Total Cost (TC) [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.total_cost
      ,'Purchased Parts -  Total Cost, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.[ARWS39_DAII_PURCHASED_PARTS_K]
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,Err.row_idx
	  ,change_improvement_id
	  ,'Calculated ' +  CAST(Err.Calculated_value as Varchar(50))
       FROM 
       (
        SELECT 
          Processing_ID,
          s39.total_cost,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS39_DAII_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  [change_improvement_id],
		  (purchased_price_per_piece+inbound_packaging_costs+inbound_logistics_costs+tax_duty) as Calculated_value,
		  row_idx
        FROM [dbo].[PARWS39_DAII_PURCHASED_PARTS_INFO] s39
           WHERE Processing_ID=@GUID
		   AND ABS((purchased_price_per_piece+inbound_packaging_costs+inbound_logistics_costs+tax_duty) - (total_cost)) > @threshold
	
       ) Err

    ;
-------------------------------------------------------------
--  END calculated field validations
-------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--+++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Purchased Parts: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS39_DAII_PURCHASED_PARTS_K
	  ,'PARWS39_DAII_PURCHASED_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.change_improvement_id 
	  ,'' 
  FROM 
      (
        SELECT 
               S39.Processing_ID
              ,s39.exchange_rate
  		      ,s39.Source_c
  		      ,s39.filename
              ,s39.ARWS39_DAII_PURCHASED_PARTS_K
  		      ,s39.sub_assembly_name
  		      ,s39.change_improvement_id
			  ,s39.row_idx
			  ,S55.usd_per_local_currency
			  ,S55.supplier_picked_crcy_c
          FROM PARWS39_DAII_PURCHASED_PARTS_INFO S39
		  Join PARWS55_DAII_EXCHANGE_RATE_TAB    S55
		    On S55.processing_id  = S39.Processing_ID
		   And S55.filename       = S39.filename
		   And S55.currency_code  = S39.local_currency
         WHERE S39.Processing_ID  = @GUID
		   and S39.exchange_rate != S55.usd_per_local_currency
      ) Err
;

--++++++++++++++++++++++++++++++++++++
-- DA type DELETE validation
--+++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
       S39.Source_c
      ,S39.change_improvement_id 
      ,'This Part Index is being deleted. Remove it from Purchased Parts. Please quote only the Assembly and Final Assembly adjustment for the DELETE.' AS ARWE02_ERROR_X 
      ,S39.Processing_ID
      ,S39.filename
      ,OBJECT_NAME(@@PROCID) 
      ,@TIME_STAMP 
      ,@CDSID   
      ,@TIME_STAMP   
      ,@CDSID  
      ,S39.ARWS39_DAII_PURCHASED_PARTS_K 
      ,'PARWS39_DAII_PURCHASED_PARTS_INFO'     
      ,'ERROR'
      ,S39.sub_assembly_name 
      ,S39.row_idx
      ,S39.change_improvement_id
      ,''  --No ARROW Value
  FROM PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
  Join PARWS39_DAII_PURCHASED_PARTS_INFO    S39  ON S39.Processing_ID         = S35.Processing_ID
                                                AND S39.filename              = S35.filename
	 								                     AND S39.change_improvement_id = S35.change_id
 WHERE S35.Processing_ID  = @GUID          
   AND S35.type_of_change = 'DELETE'
   AND S39.cost_type      = 'Adjustment Costs'              
;

END TRY
BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
	         ,@CDSID  
             ,@TIME_STAMP
	         ,@CDSID  
			 ,''
			 ,'PARWS39_DAII_PURCHASED_PARTS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;

GO
