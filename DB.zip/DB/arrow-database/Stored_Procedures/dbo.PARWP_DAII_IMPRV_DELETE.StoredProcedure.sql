DROP PROCEDURE [dbo].[PARWP_DAII_IMPRV_DELETE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		asolosky
-- Create date: 08/28/2019
-- Description:	Moved all the improvement idea deletes to one procedure and removed the 2nd staging table joins
--              which included the join by filename.  It's not needed and didn't always delete all data.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 01/14/2020  Ashaik12            Removed filter on Processing Status
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_DAII_IMPRV_DELETE]
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	       Varchar(30)

AS

SET NOCOUNT ON;

--PARWU48_PURC_PART_DSGN_IMPRV delete
MERGE INTO  [dbo].[PARWU48_PURC_PART_DSGN_IMPRV]  U48_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K 
        From PARWS34_DAII_COVER_PAGE_INFO       S34 

      -- Join with Supplier Quote View
         JOIN dbo.PARWV04_DSGN_SUPL V04
          ON S34.Eng_SubCommodity_name        = V04.ENG_SUB_CMMDTY_DESC
         AND S34.User_Selected_CTSP_N         = V04.ARWU31_CTSP_N
         AND S34.User_Selected_CTSP_Region_C  = V04.CTSP_REGION_CODE
         AND S34.User_Selected_VEH_MAKE_N     = V04.ARWA14_VEH_MAKE_N
         AND S34.User_Selected_VEH_MDL_N      = V04.ARWA34_VEH_MDL_N
         AND S34.User_Selected_VEH_MDL_YR_C   = V04.ARWA35_DSGN_VEH_MDL_YR_C    
         AND S34.User_Selected_VEH_MDL_VRNT_X = V04.ARWA35_DSGN_VEH_MDL_VRNT_X  --design variant
         AND S34.User_Selected_BNCMK_VRNT_N   = V04.VARIANT      --BoB variant
         AND S34.User_Selected_SUPL_N         = V04.ARWA17_SUPL_N
         AND S34.User_Selected_SUPL_CNTRY_N   = V04.ARWA28_CNTRY_N
         AND S34.User_Selected_SUPL_C         = V04.ARWA17_SUPL_C

       Where S34.Processing_ID               = @GUIDIN
         And S34.Skip_loading_due_to_error_f         = 0
      ) as U48_Source
 ON ( U48_Target.ARWU08_CCTSS_DSGN_SUPL_K          = U48_Source.ARWU08_CCTSS_DSGN_SUPL_K )
WHEN MATCHED THEN DELETE;

--PARWU49_RAW_MTRL_DSGN_IMPRV delete
MERGE INTO  [dbo].[PARWU49_RAW_MTRL_DSGN_IMPRV]  U49_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K 
        From PARWS34_DAII_COVER_PAGE_INFO     S34 
       
       -- Join with Design and Supplier View
        JOIN PARWV04_DSGN_SUPL   V04
          ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
         AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
         AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
         AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
         AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
         AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
         AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
         AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
         AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
         AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
         AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N
       Where S34.Processing_ID              = @GUIDIN
         And S34.Skip_loading_due_to_error_f         = 0
      ) as U49_Source
 ON (U49_Target.ARWU08_CCTSS_DSGN_SUPL_K = U49_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

--PARWU50_PROCG_DSGN_IMPRV delete
MERGE INTO PARWU50_PROCG_DSGN_IMPRV U50_target
USING
  (select  
          v04.ARWU08_CCTSS_DSGN_SUPL_K
     From PARWS34_DAII_COVER_PAGE_INFO       S34 
      
    -- Join with Supplier Qoute View
     JOIN PARWV04_DSGN_SUPL   V04
          ON V04.ARWU31_CTSP_N              = S34.User_Selected_CTSP_N
         AND V04.CTSP_REGION_CODE           = S34.User_Selected_CTSP_Region_C
         AND V04.ENG_SUB_CMMDTY_DESC        = S34.User_Selected_ENRG_SUB_CMMDTY_X 
         AND V04.VARIANT                    = S34.User_Selected_BNCMK_VRNT_N
         AND V04.ARWA14_VEH_MAKE_N          = S34.User_Selected_VEH_MAKE_N
         AND V04.ARWA34_VEH_MDL_N           = S34.User_Selected_VEH_MDL_N
         AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = S34.User_Selected_VEH_MDL_YR_C
         AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = S34.User_Selected_VEH_MDL_VRNT_X
         AND V04.ARWA17_SUPL_N              = S34.User_Selected_SUPL_N
         AND V04.ARWA17_SUPL_C              = S34.User_Selected_SUPL_C
         AND V04.ARWA28_CNTRY_N             = S34.User_Selected_SUPL_CNTRY_N
    
      where S34.Processing_ID             = @GUIDIN
        AND S34.Skip_loading_due_to_error_f         = 0
      ) as u50_source

ON (u50_target.ARWU08_CCTSS_DSGN_SUPL_K = u50_source.ARWU08_CCTSS_DSGN_SUPL_K)
when MATCHED THEN DELETE
;

--PARWU51_ASSY_DSGN_IMPRV delete
MERGE INTO  [dbo].[PARWU51_ASSY_DSGN_IMPRV]  U51_Target
Using
	 (Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From PARWS34_DAII_COVER_PAGE_INFO    COVER_PAGE_STAGE

      -- Join with Supplier Quote View
        JOIN PARWV04_DSGN_SUPL   V04
          ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]  = V04.ENG_SUB_CMMDTY_DESC
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
         AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.CTSP_REGION_CODE
	     AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.VARIANT
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
         AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	     AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
         AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
		 AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f         = 0
      ) as U51_Source

 ON (U51_Target.ARWU08_CCTSS_DSGN_SUPL_K = U51_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

--PARWU53_FNL_ASSY_DSGN_IMPRV delete
MERGE INTO PARWU53_FNL_ASSY_DSGN_IMPRV   U53_Target
Using
	 ( Select V04.ARWU08_CCTSS_DSGN_SUPL_K
        From PARWS34_DAII_COVER_PAGE_INFO  COVER_PAGE_STAGE

      -- Join with Supplier Quote View
    JOIN [dbo].[PARWV04_DSGN_SUPL]   V04
      ON COVER_PAGE_STAGE.[User_Selected_ENRG_SUB_CMMDTY_X]   = V04.[ENG_SUB_CMMDTY_DESC]
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_N]             = V04.ARWU31_CTSP_N
      AND COVER_PAGE_STAGE.[User_Selected_CTSP_Region_C]      = V04.[CTSP_REGION_CODE]
	  AND COVER_PAGE_STAGE.[User_Selected_BNCMK_VRNT_N]       = V04.[VARIANT]
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MAKE_N]         = V04.ARWA14_VEH_MAKE_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_N]          = V04.ARWA34_VEH_MDL_N
      AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_YR_C]       = V04.ARWA35_DSGN_VEH_MDL_YR_C
	  AND COVER_PAGE_STAGE.[User_Selected_VEH_MDL_VRNT_X]     = V04.ARWA35_DSGN_VEH_MDL_VRNT_X 
      AND COVER_PAGE_STAGE.[User_Selected_SUPL_N]             = V04.ARWA17_SUPL_N
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_C]             = V04.ARWA17_SUPL_C
	  AND COVER_PAGE_STAGE.[User_Selected_SUPL_CNTRY_N]       = V04.ARWA28_CNTRY_N
       Where cover_page_stage.Processing_ID               = @GUIDIN
         And cover_page_stage.Skip_loading_due_to_error_f = 0 
      ) as U53_Source

 ON ( U53_Target.ARWU08_CCTSS_DSGN_SUPL_K = U53_Source.ARWU08_CCTSS_DSGN_SUPL_K)
WHEN MATCHED THEN DELETE;

--PARWU52_MFG_MRKP_DSGN_IMPRV delete
MERGE INTO [dbo].[PARWU52_MFG_MRKP_DSGN_IMPRV] U52_Target
USING
(
SELECT V04.ARWU08_CCTSS_DSGN_SUPL_K as [ARWU08_CCTSS_DSGN_SUPL_K]  
  from PARWS34_DAII_COVER_PAGE_INFO cover_page_stage

-- SUPPLIER QUOTE VIEW
         JOIN PARWV04_DSGN_SUPL   V04
          ON V04.ARWU31_CTSP_N              = cover_page_stage.User_Selected_CTSP_N
         AND V04.CTSP_REGION_CODE           = cover_page_stage.User_Selected_CTSP_Region_C
         AND V04.ENG_SUB_CMMDTY_DESC        = cover_page_stage.User_Selected_ENRG_SUB_CMMDTY_X 
         AND V04.VARIANT                    = cover_page_stage.User_Selected_BNCMK_VRNT_N
         AND V04.ARWA14_VEH_MAKE_N          = cover_page_stage.User_Selected_VEH_MAKE_N
         AND V04.ARWA34_VEH_MDL_N           = cover_page_stage.User_Selected_VEH_MDL_N
         AND V04.ARWA35_DSGN_VEH_MDL_YR_C   = cover_page_stage.User_Selected_VEH_MDL_YR_C
         AND V04.ARWA35_DSGN_VEH_MDL_VRNT_X = cover_page_stage.User_Selected_VEH_MDL_VRNT_X
         AND V04.ARWA17_SUPL_N              = cover_page_stage.User_Selected_SUPL_N
         AND V04.ARWA17_SUPL_C              = cover_page_stage.User_Selected_SUPL_C
         AND V04.ARWA28_CNTRY_N             = cover_page_stage.User_Selected_SUPL_CNTRY_N
where cover_page_stage.Processing_ID        = @GUIDIN
  AND cover_page_stage.Skip_loading_due_to_error_f         = 0
) as U52_SOURCE

ON (U52_Target.[ARWU08_CCTSS_DSGN_SUPL_K]=U52_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K])
WHEN MATCHED THEN DELETE;

-- PARWU54_FNLASSYMRKP_DSGN_IMPV delete
MERGE INTO  [dbo].[PARWU54_FNLASSYMRKP_DSGN_IMPV] U54_Target
USING
(
Select V04.ARWU08_CCTSS_DSGN_SUPL_K
  From PARWV04_DSGN_SUPL V04
  JOIN
      (SELECT cover_page_stage.[User_Selected_CTSP_N]
			 ,cover_page_stage.[User_Selected_CTSP_Region_C]
			 ,cover_page_stage.Eng_commodity_name
             ,cover_page_stage.[User_Selected_ENRG_SUB_CMMDTY_X]
			 ,cover_page_stage.[User_Selected_BNCMK_VRNT_N]
			 ,cover_page_stage.[User_Selected_VEH_MAKE_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_N]
			 ,cover_page_stage.[User_Selected_VEH_MDL_YR_C]
			 ,cover_page_stage.[User_Selected_VEH_MDL_VRNT_X]
			 ,cover_page_stage.[User_Selected_SUPL_N]
			 ,cover_page_stage.[User_Selected_SUPL_C]
			 ,cover_page_stage.[User_Selected_SUPL_CNTRY_N]
        from PARWS34_DAII_COVER_PAGE_INFO cover_page_stage
       where cover_page_stage.Processing_ID       = @GUIDIN
         AND cover_page_stage.Skip_loading_due_to_error_f         = 0
      ) Staging
    ON Staging.[User_Selected_ENRG_SUB_CMMDTY_X]    = V04.[ENG_SUB_CMMDTY_DESC]
   AND Staging.[User_Selected_CTSP_N]               = V04.ARWU31_CTSP_N
   AND Staging.[User_Selected_CTSP_Region_C]        = V04.[CTSP_REGION_CODE]
   AND Staging.[User_Selected_VEH_MAKE_N]           = V04.ARWA14_VEH_MAKE_N
   AND Staging.[User_Selected_VEH_MDL_N]            = V04.[ARWA34_VEH_MDL_N]
   AND Staging.[User_Selected_VEH_MDL_YR_C]         = V04.ARWA35_DSGN_VEH_MDL_YR_C
   AND Staging.[User_Selected_VEH_MDL_VRNT_X]       = V04.ARWA35_DSGN_VEH_MDL_VRNT_X
   AND Staging.[User_Selected_BNCMK_VRNT_N]         = V04.[VARIANT]
   AND Staging.[User_Selected_SUPL_N]               = V04.ARWA17_SUPL_N
   AND Staging.[User_Selected_SUPL_CNTRY_N]         = V04.ARWA28_CNTRY_N
   AND Staging.[User_Selected_SUPL_C]               = V04.ARWA17_SUPL_C
) as U54_SOURCE

ON (U54_Target.[ARWU08_CCTSS_DSGN_SUPL_K] = U54_SOURCE.[ARWU08_CCTSS_DSGN_SUPL_K])
WHEN MATCHED THEN DELETE;

GO
