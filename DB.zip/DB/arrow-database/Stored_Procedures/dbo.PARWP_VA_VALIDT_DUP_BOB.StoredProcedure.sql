DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_DUP_BOB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 08/07/2019
-- Description:	Validate Variant Adjustment for duplicate BoB for a Design and Supplier in the same Batch.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asamriya  09/10/2019   Added row_idx
-- asolosky  12/19/2019   Dup check against User select data: Had s45.Walked_Var_N which should've been User_selected_WALK_VRNT_X
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- Ashaik12   09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_DUP_BOB] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(5000)
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
-- =============================================
-- Dup check against Cover Page select data
-- =============================================
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   Err.Source_c                          as ARWE02_SOURCE_C
	  ,Err.filename                          as ARWE02_ERROR_VALUE 
	  ,'A duplicate "Cover Page" - BoB (Program, Region, Sub-Commodity, Benchmark Variant Name), Variant Walk, Design and Supplier was imported in the same batch. Only one can be imported per batch.' as ARWE02_ERROR_X
	  ,Err.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,Err.filename                            as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,Err.[ARWS45_VA_COVER_PAGE_INFO_K]     as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS45_VA_COVER_PAGE_INFO' as ARWE02_STAGING_TABLE_X
	  -- Identity Key Column
	  ,'ERROR' as ARWE02_ERROR_TYPE
	  ,'Cover' as ARWE02_EXCEL_TAB
	  ,0                               -- err_idx
	  ,''  --No part index
	  ,''  --No ARROW Value
	  FROM
	  (
select 
 COUNT(*) OVER (PARTITION BY s45.Program,s45.Region,s45.Eng_SubCommodity_name,s45.Benchmark_Var_N,
                             s45.Walked_Var_N,s45.supplier_name,s45.supplier_code,s45.Processing_ID) AS COUNT_BOB1

,filename
	  ,s45.Program
	  ,s45.Region
	  ,s45.Eng_SubCommodity_name
	  ,s45.Benchmark_Var_N
	  ,s45.Walked_Var_N
	  ,s45.supplier_name
	  ,s45.Source_c
	  ,s45.Processing_ID
	  ,s45.[ARWS45_VA_COVER_PAGE_INFO_K]
	 
from  [dbo].[PARWS45_VA_COVER_PAGE_INFO]   s45
where Processing_ID=@GUID
) Err
where COUNT_BOB1>1 ;

-- =============================================
-- Dup check against User select data
-- =============================================
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
     SELECT
	   Err.Source_c                          as ARWE02_SOURCE_C
	  ,Err.filename                          as ARWE02_ERROR_VALUE 
	  ,'A duplicate "User Selected" - BoB (Program, Region, Sub-Commodity, Benchmark Variant Name), Variant Walk, Design and Supplier was imported in the same batch. Only one can be imported per batch.' as ARWE02_ERROR_X
	  ,Err.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,Err.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,Err.[ARWS45_VA_COVER_PAGE_INFO_K]   as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS45_VA_COVER_PAGE_INFO' as ARWE02_STAGING_TABLE_X
	  -- Identity Key Column
	  ,'ERROR' as ARWE02_ERROR_TYPE
	  ,'Cover' as ARWE02_EXCEL_TAB
	  ,0                               -- err_idx
	  ,''  --No part index
	  ,''  --No ARROW Value
	  FROM
	  (
select 
       COUNT(*) OVER (PARTITION BY s45.User_Selected_CTSP_N, s45.User_Selected_CTSP_Region_C, s45.User_Selected_ENRG_SUB_CMMDTY_X, s45.User_Selected_BNCMK_VRNT_N,
                                   s45.User_selected_WALK_VRNT_X ,s45.User_Selected_SUPL_N, s45.User_Selected_SUPL_C ,s45.User_Selected_SUPL_CNTRY_N
			         ) AS COUNT_BOB1
      ,s45.filename
	  ,s45.Source_c
	  ,s45.User_Selected_CTSP_N
	  ,s45.User_Selected_CTSP_Region_C
	  ,s45.User_Selected_ENRG_SUB_CMMDTY_X
	  ,s45.User_Selected_BNCMK_VRNT_N
	  ,s45.User_selected_WALK_VRNT_X
	  ,s45.User_Selected_SUPL_CNTRY_N
	  ,s45.User_Selected_SUPL_C
	  ,s45.User_Selected_SUPL_N
	  ,s45.Processing_ID
	  ,s45.[ARWS45_VA_COVER_PAGE_INFO_K]
	 
from [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
where Processing_ID=@GUID
) Err
where COUNT_BOB1>1 ;

END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS45_VA_COVER_PAGE_INFO'
			 --Identity Key Column
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                              -- row_idx
			 ,''  --No part index
	         ,''  --No ARROW Value
END CATCH;




GO
