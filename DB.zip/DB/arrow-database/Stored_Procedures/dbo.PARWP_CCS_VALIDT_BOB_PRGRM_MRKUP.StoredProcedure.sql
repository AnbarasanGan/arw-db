DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_BOB_PRGRM_MRKUP]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 01/27/2021
-- Description:	Check whether the BoB has Program Markups
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       ----------
-- Ashaik12   02/02/21    Change error message.
-- ASolosky   10/06/21    US2909424: A PPC = TBD will produce an error. Added the If statement to do this validation.
-- =============================================
CREATE PROCEDURE  [dbo].[PARWP_CCS_VALIDT_BOB_PRGRM_MRKUP] 
-- Input Parameter
 @Processing_ID Varchar(5000)
,@CDSID         Varchar(30)
,@TIME_STAMP DATETIME

AS
BEGIN TRY
SET NOCOUNT ON;

Declare @PCC VARCHAR(MAX);

Select @PCC = ARWA15_PCHSNG_CMMDTY_C
  from PARWS22_CCS_COVER_PAGE_INFO  S22
  JOIN PARWU01_CCTSS_FLAT U01
    ON S22.User_Selected_CTSP_N            = U01.ARWU31_CTSP_N
   AND S22.User_Selected_CTSP_Region_C     = U01.ARWA06_RGN_C
   AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U01.ARWA03_ENRG_SUB_CMMDTY_X
   AND S22.User_Selected_BNCMK_VRNT_N      = U01.ARWU01_BNCHMK_VRNT_N
 Where S22.Processing_ID                   = @Processing_ID
              
If IsNULL(@PCC,'~!@!~') = 'TBD' 
   INSERT INTO PARWE02_BATCH_ERRORS
   select 
          S22.Source_c                     as ARWE02_SOURCE_C
         ,Purch_Cmmdty_C                   as ARWE02_ERROR_VALUE
         ,'The Program/Study Purchasing Commodity Code is set to TBD and needs a valid code. Please send a message in the Webex Teams group, Arrow Feedback, with the Correct code so it can get updated in ARROW.' as ARWE02_ERROR_X
         ,S22.Processing_ID                as ARWE02_PROCESSING_ID
         ,S22.filename                     as ARWE02_FILENAME
         ,object_name(@@PROCID)            as ARWE02_PROCEDURE_X
         ,@TIME_STAMP                      as ARWE02_CREATE_S
         ,@CDSID                           as ARWE02_CREATE_USER_C
         ,@TIME_STAMP                      as ARWE02_LAST_UPDT_S
         ,@CDSID                           as ARWE02_LAST_UPDT_USER_C
         ,S22.ARWS22_CCS_COVER_PAGE_INFO_K as ARWE02_BATCH_ERRORS_REF_K
         ,'PARWS22_CCS_COVER_PAGE_INFO'    as ARWE02_STAGING_TABLE_X
         ,'ERROR'                          as ARWE02_ERROR_TYPE_X
         ,''                               as ARWE02_EXCEL_TAB_X
         ,0                                as ARWE02_ROW_IDX
         ,''                               as ARWE02_Part_Index
         ,'TBD'                            as ARWE02_ARROW_Value
     from PARWS22_CCS_COVER_PAGE_INFO S22
Else
   INSERT INTO PARWE02_BATCH_ERRORS
   select 
          S22.Source_c                     as ARWE02_SOURCE_C
         ,''                               as ARWE02_ERROR_VALUE
         ,'Program Markups (Deloitte Markups) are missing for the BoB. Please message in Arrow Feedback Webex Teams group so IT can look into it or contact ARROW Support.' as ARWE02_ERROR_X
         ,S22.Processing_ID                as ARWE02_PROCESSING_ID
         ,S22.filename                     as ARWE02_FILENAME
         ,object_name(@@PROCID)            as ARWE02_PROCEDURE_X
         ,@TIME_STAMP                      as ARWE02_CREATE_S
         ,@CDSID                           as ARWE02_CREATE_USER_C
         ,@TIME_STAMP                      as ARWE02_LAST_UPDT_S
         ,@CDSID                           as ARWE02_LAST_UPDT_USER_C
         ,S22.ARWS22_CCS_COVER_PAGE_INFO_K as ARWE02_BATCH_ERRORS_REF_K
         ,'PARWS22_CCS_COVER_PAGE_INFO'    as ARWE02_STAGING_TABLE_X
         ,'ERROR'                          as ARWE02_ERROR_TYPE_X
         ,''                               as ARWE02_EXCEL_TAB_X
         ,0                                as ARWE02_ROW_IDX
         ,''                               as ARWE02_Part_Index
         ,''                               as ARWE02_ARROW_Value
         --U01.ARWU31_CTSP_N, U01.ARWA06_RGN_C,U01.ARWA03_ENRG_SUB_CMMDTY_X , U01.ARWU01_BNCHMK_VRNT_N 
     from PARWS22_CCS_COVER_PAGE_INFO S22
     JOIN PARWU01_CCTSS_FLAT U01
       ON S22.User_Selected_CTSP_N            = U01.ARWU31_CTSP_N
      AND S22.User_Selected_CTSP_Region_C     = U01.ARWA06_RGN_C
      AND S22.User_Selected_ENRG_SUB_CMMDTY_X = U01.ARWA03_ENRG_SUB_CMMDTY_X
      AND S22.User_Selected_BNCMK_VRNT_N      = U01.ARWU01_BNCHMK_VRNT_N
    where S22.Processing_ID = @Processing_ID
    and U01.ARWU01_CCTSS_K NOT IN 
       (select  ARWU01_CCTSS_K from PARWV14_PROGRAM_MRKUP)
; --End of IF

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@Processing_ID                    --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,NULL
		,'PARWS22_CCS_COVER_PAGE_INFO'
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
		,0                                 --row_idx
		,''                                --ARWE02_Part_Index,
		,''                                --ARWE02_ARROW_Value

;
END CATCH;		

GO
