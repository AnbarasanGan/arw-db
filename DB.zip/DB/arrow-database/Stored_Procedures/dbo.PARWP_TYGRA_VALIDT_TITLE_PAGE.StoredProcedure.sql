SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		rwesley2
-- Create date: 05/28/2020
-- Description:	Validate Cost Control Model info on Title Page
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   03-22-2021  changed missing region to ERROR from WARNING
--                        changed missing program to ERROR from WARNING   
--                        added validation for missing model year as an ERROR
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley2   04-04-2022  US3482265 added validation for when there is a cover page but no details page
--                                  changed Control Model CCM missing on Title Page from WARNING to ERROR
-- =============================================
CREATE OR ALTER PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_TITLE_PAGE] 
-- Input Parameter
 @GUID varchar(MAX)
,@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME


AS

select @GUID

BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
   Select 
		 Err.Source_c
		,Err.Vehicle_name
		,'File does not have a cover page.' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,''
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'ERROR'             --'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,''
		,''
		,''
    FROM
    (	
	  SELECT S62.file_name
	  ,s62.Source_c
	  ,s62.Vehicle_name
	  ,s62.processing_id
      from PARWS62_TYGRA_SUMMARY s62
      left join PARWS61_TYGRA_TITLE_PAGE s61  
      on s62.processing_id = s61.processing_id
      where s61.file_name is NULL
	  and S62.processing_ID =  @GUID
      group by S62.file_name
	  ,s62.Source_c
	  ,s62.Vehicle_name
	  ,s62.processing_id
	) Err   


INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
   Select 
		 Err.Source_c
		,Err.program
		,'File does not have a details page.' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,''
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'ERROR'             --'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,''
		,''
		,''
    FROM
    (	
	  SELECT S61.file_name
	  ,s61.Source_c
	  ,s61.program
	  ,s61.processing_id
      from PARWS61_TYGRA_TITLE_PAGE s61  
      left join PARWS62_TYGRA_SUMMARY s62
      on s61.processing_id = s62.processing_id
      where s62.file_name is NULL
	  and S61.processing_ID =  @GUID
      group by S61.file_name
	  ,s61.Source_c
	  ,s61.Program
	  ,s61.processing_id
	) Err   

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[program]
		,'Control Model program missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'ERROR'             --'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.program is NULL
	   and S61.processing_ID = @GUID
	   --+ s61.program + s61.ccm in  (select processing_id + program + ccm from ##variant_tbl
--							 )    
	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[CCM]
		,'Control Model CCM missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'ERROR'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.CCM is NULL 
	   and S61.processing_ID = @GUID
--	   + s61.program + s61.ccm in  (select processing_id + program + ccm from ##variant_tbl )    
			    

	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[region]
		,'Control Model region missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'ERROR'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.region is NULL 
	   	   and S61.processing_ID = @GUID
--	   + s61.program + s61.ccm in  (select processing_id + program + ccm
--	                         from ##variant_tbl
--							 )    			    

	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[region]
		,'Control Model region Invalid from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
	(
	     SELECT 
          Processing_ID,
		  program,
		  ccm,
		  region,
		  Source_c,
          ARWS61_TYGRA_TITLE_PAGE,
		  file_name,
		  row_idx
        FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
        WHERE S61.processing_ID = @GUID
	--	+ s61.program + s61.ccm in  (select processing_id + program + ccm
	--                         from ##variant_tbl
	--						 )    
	    and Not Exists
		      (Select 'X'
			     from  [dbo].[PARWA06_RGN] a06
                where CASE  when s61.region = 'CH' then 'China'
				             when s61.region =  'APO' then 'IMG'
							 else s61.region 
							  end = a06.ARWA06_RGN_C
              )  
       ) Err

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[series]
		,'Control Model series missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.series is NULL 
	   	   and S61.processing_ID = @GUID 
--	   + s61.program + s61.ccm in  (select processing_id + program + ccm
--	                         from ##variant_tbl
--							 )    			    
	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[engine]
		,'Control Model engine missing from Cost Control Models on Title Page'  as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.engine is NULL 
	   and S61.processing_ID = @GUID
	--   + s61.program + s61.ccm in  (select processing_id + program + ccm
	 --                        from ##variant_tbl
	--						 )    			    
	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[Trans_driveline]
		,'Control Model trans/driveline missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
		,object_name(@@PROCID) AS Procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.Trans_driveline is NULL 
	   and S61.processing_ID = @GUID 
	  -- + s61.program + s61.ccm in  (select processing_id + program + ccm
	  --                       from ##variant_tbl							 )    			    
	) Err
	;

	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[description]
		,'Control Model description missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
--		,object_name(@@PROCID) AS Procedure_x
        ,'PARWP_TYGRA_VALIDT_TITLE_PAGE' as procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'WARNING'  --'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE s61.Description is NULL 
	   	   and S61.processing_ID = @GUID 
	  -- + s61.program + s61.ccm in  (select processing_id + program + ccm
	   --                      from ##variant_tbl
	--						 )    			    
	) Err
	;

		INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
     Select 
		 Err.Source_c
		,Err.[CM_MDLYR]
		,'Control Model model year missing from Cost Control Models on Title Page' as Error_Msg
        ,err.Processing_ID 
		,Err.file_name
--		,object_name(@@PROCID) AS Procedure_x
        ,'PARWP_TYGRA_VALIDT_TITLE_PAGE' as procedure_x
 		,@TIME_STAMP 
 		,@CDSID
		,@TIME_STAMP 
		,@CDSID
	    ,err.ARWS61_TYGRA_TITLE_PAGE
		,'PARWS61_TYGRA_TITLE_PAGE'  
        ,'ERROR'  --'WARNING'                       
		,'Tygra Title Page'  as sheet_name
		,Err.row_idx
		,' '
		,err.program + ' ' + err.CCM
    FROM
    (	
	  SELECT S61.*
	    FROM [dbo].[PARWS61_TYGRA_TITLE_PAGE]  S61
	   WHERE (s61.[CM_MDLYR] is NULL or s61.[CM_MDLYR] = '')
	   	   and S61.processing_ID = @GUID 
	  -- + s61.program + s61.ccm in  (select processing_id + program + ccm
	   --                      from ##variant_tbl
	--						 )    			    
	) Err
	;

---- title page does not have a corresponding parts tab in the file
--	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
--     Select 
--		 Err.Source_c
--		,Err.file_name
--		,'File does not have a parts tab' as Error_Msg
--        ,err.Processing_ID 
--		,Err.file_name
--        ,'PARWP_TYGRA_VALIDT_TITLE_PAGE' as procedure_x
-- 		,@TIME_STAMP 
-- 		,@CDSID
--		,@TIME_STAMP 
--		,@CDSID
--	    ,err.ARWS61_TYGRA_TITLE_PAGE 
--		,'PARWS61_TYGRA_TITLE_PAGE'  
--        ,'WARNING'                       
--		,'Tygra Title Page'  as sheet_name
--		,Err.row_idx
--		,' '
--		,' '
--    FROM
--    (	
--      select s61.*
--        ,row_number() OVER (PARTITION BY s61.processing_id, s61.file_name
--			order by s61.processing_id, s61.file_name) as rownum
--     from PARWS61_TYGRA_TITLE_PAGE s61
--     join ##processing_tbl  pt
--     on s61.[Processing_ID] = pt.[Processing_ID]
--     left join PARWS62_TYGRA_SUMMARY s62
--     on s62.[Processing_ID] = s61.[Processing_ID]
--     where s62.Processing_ID IS NULL
--  ) Err
--	 where rownum = 1

	;

END TRY


--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS61_TYGRA_TITLE_PAGE'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,' '
		,' '
		;

END CATCH;	

GO
