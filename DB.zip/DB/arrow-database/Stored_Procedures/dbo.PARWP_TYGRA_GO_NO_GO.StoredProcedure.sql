SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




-- =============================================
-- Author:		rwesley2
-- Create date: 01/07/2020
-- Description:	Stored Procedure to determine whether to stop TYGRA_master from running stopping load of TYGRA base tables.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   4-20-2021   U2453456 use MAX length when declaring a variable   
-- rwesley2   10-22-2021  U2995475 changed @guid to @processing_id for consistency with other Tygra SPs
-- rwesley2   06-14-2022  US3283898 DE256732 added @time_stamp when checking error table for errors
-- rwesley2   08-12-2022  US3283898 DE262236 - Sync QA and EDU code base 
-- =============================================


CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_GO_NO_GO] 
	-- Add the parameters for the stored procedure here
	 @processing_id  varchar(MAX)  
	,@CDSID varchar(MAX)  
	,@TIME_STAMP DATETIME
	,@TYGRA_ERROR_TYPE varchar(MAX) OUTPUT

AS
BEGIN  TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @TYGRASYSERROR INT;  
DECLARE @TYGRAVALIDTERROR INT;


set @TYGRA_ERROR_TYPE = 'NO ERRORS'


-- Title page (S61)
SET @TYGRASyserror =
(select count(*)
  from PARWE02_BATCH_ERRORS     e02 
   Where E02.ARWE02_PROCESSING_ID = @processing_id
   and ARWE02_LAST_UPDT_S = @TIME_STAMP
   and ARWE02_ERROR_TYPE_X = 'ERROR'
   and ARWE02_SOURCE_C = 'SYSTEM'
group by ARWE02_ERROR_TYPE_X)
;

SET @TYGRAVALIDTERROR =
(select count(*)
  from PARWE02_BATCH_ERRORS     e02 
  Where E02.ARWE02_PROCESSING_ID = @processing_id
   and ARWE02_LAST_UPDT_S = @TIME_STAMP
   and ARWE02_ERROR_TYPE_X = 'ERROR'
   and ARWE02_SOURCE_C <> 'SYSTEM'
group by ARWE02_ERROR_TYPE_X)
;


If IsNull(@TYGRASyserror,0) > 0 
   SET @TYGRA_ERROR_TYPE = 'SYSTEM Error'
Else
if IsNull(@TYGRAVALIDTERROR,0)  > 0 
   SET @TYGRA_ERROR_TYPE = 'Validation Error'
Else SET @TYGRA_ERROR_TYPE = 'No Error'
;


END TRY

BEGIN CATCH

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@processing_id							--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'TYGRA FILE'
			 --ARWE02_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
		     ,''                               -- ARROW_VALUE

END CATCH



GO
