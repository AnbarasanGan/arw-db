DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUMMARY_PRE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		ASOLOSKY
-- Create date: 02/03/2021
-- Description:	Consolidated PARWP_CCS_VALIDT_SUMMARY_CST_ASSEMBLY_PRE, PARWP_CCS_VALIDT_SUMMARY_CST_FNL_ASSEMBLY_PRE, 
--              PARWP_CCS_VALIDT_SUMMARY_CST_PROCESSING_PRE, PARWP_CCS_VALIDT_SUMMARY_CST_PURCHASED_PART_PRE, PARWP_CCS_VALIDT_SUMMARY_CST_RAW_MTRL_PRE
--              into this procedure
--              Added Markups to the validation verification
--              Markups are a componded total per business rules.  This matched the Excel file formulas
-- =============================================
-- Changes
-- =============================================
--                     User
-- Author   Date       Story     Description
-- ------   -----      --------  -----------
-- Asolosky 06/04/2021 US2559876 expanding to 25 sub-assemblies. To do so, the UI had to change to stop reading Excel once it hit 2 blank lines between part.
--                               There's a possibility that not all data is loaded which will trigger the error messages in this procedure.
--                               This procedure had to change it's error messages to describe the 2 blank lines possibility.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_SUMMARY_PRE] 
@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS
BEGIN TRY

SET NOCOUNT ON
--For Testing
--Declare @GUID varchar(5000)           = '00D14A23-27CD-4075-924D-6DCF05C20147';
--Declare @CDSID varchar(30)            = 'Asolosky';
--Declare @TIME_STAMP DATETIME          = GETUTCDATE();
--Declare @V_Threshold_A DECIMAL(38,18) = .01;

DROP TABLE IF EXISTS #PRE_VALIDATION;
CREATE TABLE #PRE_VALIDATION (
 TEMPLATE_SECTION  VARCHAR(MAX)
,STAGING_COST      Decimal(38,19)
,ARROW_CALC_COST   Decimal(38,19) 
,SOURCE_C          VARCHAR(MAX)
,PROCESSING_ID     VARCHAR(MAX)
,FILENAME          VARCHAR(MAX)
,BATCH_ERROR_REF_K INT
,STAGING_TABLE     VARCHAR(MAX)
,SUB_ASSEMBLY      VARCHAR(MAX)
);

DROP TABLE IF EXISTS #PARWS18_MARKUPS_FLAT;
CREATE TABLE #PARWS18_MARKUPS_FLAT (
 FILENAME                 VARCHAR(MAX)
,SUB_ASSEMBLY             VARCHAR(MAX)
,Scrap_Markup             Decimal(38,19)
,SGA_TOTAL_Markup         Decimal(38,19)
,PROFIT_Markup            Decimal(38,19)
);

--*****************
--Purchased parts
--*****************
INSERT INTO #PRE_VALIDATION 
Select S21.cost_item          AS TEMPLATE_SECTION   --'1. Purchased parts' 
      ,S21.cost
	  ,S14.ARROW_CALC_COST
      ,S14.Source_c
	  ,S14.Processing_ID
	  ,S14.filename
	  ,S21.ARWS21_CCS_SUMMARY_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,S14.sub_assembly_name
 From
(
select 
       Sum(
	       CASE WHEN S14.sub_assembly_name !='Directed Parts' and S14.pia_directed_bailed  ='B'  
                THEN IsNull ((S14.no_of_pieces)*(S14.purchased_price_per_piece + S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty) *(S14.purchased_parts_markup_cost) ,0) * IsNull(S14.exchange_rate,0)
	            WHEN S14.sub_assembly_name !='Directed Parts' and S14.pia_directed_bailed !='B' 
	            THEN IsNull ((S14.no_of_pieces)*(S14.purchased_price_per_piece + S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty) *(1 + S14.purchased_parts_markup_cost),0) * IsNull(S14.exchange_rate,0)
                WHEN S14.sub_assembly_name  ='Directed Parts' and S14.pia_directed_bailed  ='B'
		    	THEN 0 
                ELSE isNULL((S14.no_of_pieces *(S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty)
		    	             +(S14.purchased_parts_markup_cost*(S14.purchased_price_per_piece + S14.inbound_packaging_costs + S14.inbound_logistics_costs + S14.tax_duty) * S14.no_of_pieces)
		    			    ) ,0)  * IsNull(S14.exchange_rate,0)

	       END 
	      ) as ARROW_CALC_COST
      ,S22.Source_c
	  ,S22.Processing_ID
	  ,S22.filename
      ,S14.sub_assembly_name
 from PARWS22_CCS_COVER_PAGE_INFO                      S22
 JOIN PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO  S14
   ON S14.Processing_ID     = S22.Processing_ID
  and S14.filename          = S22.filename
where S22.Processing_ID     = @GUID
group by S22.Source_c, S22.Processing_ID, S22.filename, S14.sub_assembly_name
) S14
 Join PARWS21_CCS_SUMMARY_TAB_INFO  S21
   ON S21.Processing_ID     = S14.Processing_ID
  AND S21.filename          = S14.filename
  AND S21.part_cluster_type = S14.sub_assembly_name 
where S21.cost_item         = '1. Purchased parts'

--*****************
--Raw materials
--*****************
INSERT INTO #PRE_VALIDATION 
select S21.cost_item AS TEMPLATE_SECTION --'2. Raw materials'   
      ,S21.cost      AS STAGING_COST
      ,ARROW_CALC_COST 										    
      ,S21.Source_c
	  ,S15.Processing_ID
	  ,S15.filename
	  ,S21.ARWS21_CCS_SUMMARY_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,S15.sub_assembly_name
From
(
select 
      Sum(dbo.PARWF_CCS_RAWMATERIAL_MATRL_COST_USD (U01.ARWA10_COST_EST_PERFD_F, ARWA53_LGCY_CCS_PGM_N 
                                                    ,S15.no_of_pieces, S15.gross_usage_per_piece, S15.in_process_scrap_pctg, S15.material_price
                                                    ,S15.inbound_logistics_costs, S15.inbound_packaging_costs, S15.tax_duty_per_uom  
                                                    ,S15.reclamation_pcntg, S15.scrap_price, S15.net_usage_per_piece, S15.exchange_rate)
       ) as ARROW_CALC_COST 										    
      ,S22.Source_c
	  ,S22.Processing_ID
	  ,S22.filename
      ,S15.sub_assembly_name
 from PARWS22_CCS_COVER_PAGE_INFO                   S22
 JOIN PARWS15_CCS_SUPPLIER_QUOTE_RAW_MATERIALS_INFO S15
   ON S15.Processing_ID     = S22.Processing_ID
  and  S15.filename         = S22.filename
 Join PARWU01_CCTSS_FLAT                            U01
   ON U01.ARWU31_CTSP_N            = User_Selected_CTSP_N
  And U01.ARWA06_RGN_C             = User_Selected_CTSP_Region_C
  And U01.ARWA03_ENRG_SUB_CMMDTY_X = User_Selected_ENRG_SUB_CMMDTY_X
  And U01.ARWU01_BNCHMK_VRNT_N     = User_Selected_BNCMK_VRNT_N
 LEFT JOIN PARWA53_LGCY_CCS_PGM                     A53 
   ON u01.ARWU31_CTSP_N            = A53.ARWA53_LGCY_CCS_PGM_N
where S22.Processing_ID = @GUID
group by S22.Source_c, S22.Processing_ID, S22.filename, S15.sub_assembly_name
) S15
 JOIN PARWS21_CCS_SUMMARY_TAB_INFO S21
   ON S21.Processing_ID     = S15.Processing_ID
  and S21.filename          = S15.filename
  and S21.part_cluster_type = S15.sub_assembly_name
where S21.cost_item     = '2. Raw materials'

--*****************
--Processing
--*****************
INSERT INTO #PRE_VALIDATION 
select S21.cost_item    AS TEMPLATE_SECTION --'3. Processing'
      ,S21.cost         AS STAGING_COST
      ,ARROW_CALC_COST 										    
      ,S21.Source_c
	  ,S16.Processing_ID
	  ,S16.filename
	  ,S21.ARWS21_CCS_SUMMARY_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,S16.sub_assembly_name
  From
(
select Sum(
	   CASE WHEN S16.no_of_pieces_per_cycle = 0 
	        THEN S16.no_of_pieces_per_subassy
		         *(S16.packaging_costs + S16.logistics_cost  + S16.tax_duty_per_piece  + S16.licensing_costs)
			 	* S16.exchange_rate
            ELSE 
	        CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and [ARWA53_LGCY_CCS_PGM_N] is NULL
			     THEN 
	                 (S16.no_of_pieces_per_subassy * ( --K
	                 ((S16.cycle_time_sec * (S16.machinehourly_operation_overhead/3600)) / S16.no_of_pieces_per_cycle) --O
	                 +(S16.total_labor_minutes * (S16.direct_hourly_labor_headcount/60))   --U
	                 + S16.packaging_costs  + S16.logistics_cost   + S16.tax_duty_per_piece  + S16.licensing_costs 
			 		)) * S16.exchange_rate  --V,W,X,Y
 		    
                ELSE 
                    (S16.no_of_pieces_per_subassy * ( 
                    ((S16.cycle_time_sec  * (S16.machinehourly_operation_overhead/3600)) / S16.no_of_pieces_per_cycle)
			        + (((S16.cycle_time_sec * (S16.direct_hourly_labor_headcount/3600)  * S16.direct_headcount)/S16.no_of_pieces_per_cycle )*(1+S16.indirect_labor_costs)*(1+S16.fringes))  
                    + S16.packaging_costs  + S16.logistics_cost   + S16.tax_duty_per_piece  + S16.licensing_costs 
			 	   )) * S16.exchange_rate
            END 
       END 
       ) as ARROW_CALC_COST 										    
      ,S22.Source_c
	  ,S22.Processing_ID
	  ,S22.filename
      ,S16.sub_assembly_name
  from PARWS22_CCS_COVER_PAGE_INFO                      S22
  JOIN PARWS16_CCS_SUPPLIER_QUOTE_PROCESSING_PARTS_INFO S16
    ON S22.Processing_ID     = S16.Processing_ID
   and S22.filename          = S16.filename
  Join PARWU01_CCTSS_FLAT                               U01
    ON U01.ARWU31_CTSP_N            = S22.User_Selected_CTSP_N
   And U01.ARWA06_RGN_C             = S22.User_Selected_CTSP_Region_C
   And U01.ARWA03_ENRG_SUB_CMMDTY_X = S22.User_Selected_ENRG_SUB_CMMDTY_X
   And U01.ARWU01_BNCHMK_VRNT_N     = S22.User_Selected_BNCMK_VRNT_N
  LEFT JOIN PARWA53_LGCY_CCS_PGM                         A53 
    ON u01.ARWU31_CTSP_N = A53.ARWA53_LGCY_CCS_PGM_N
 Where S22.Processing_ID = @GUID
 group by S22.Source_c, S22.Processing_ID, S22.filename, S16.sub_assembly_name
) S16
 Join PARWS21_CCS_SUMMARY_TAB_INFO S21
   On S21.Processing_ID     = S16.Processing_ID
  AND S21.filename          = S16.filename
  AND S21.part_cluster_type = S16.sub_assembly_name
where S21.cost_item         = '3. Processing'

--*****************
--Assembly
--*****************
INSERT INTO #PRE_VALIDATION 
select S21.cost_item    AS TEMPLATE_SECTION --'4. Assembly'
      ,S21.cost         AS STAGING_COST
      ,ARROW_CALC_COST
      ,S17.Source_c
	  ,S17.Processing_ID
	  ,S17.filename
	  ,S21.ARWS21_CCS_SUMMARY_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,S17.sub_assembly_name
  From
(
select SUM(
	       CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and ARWA53_LGCY_CCS_PGM_N is NULL
		    	THEN IsNUll(((S17.assembly_secs_operation * (S17.machinehourly_operation_overhead/3600))
				            +(S17.total_labor_minutes*(S17.direct_hourly_labor_headcount/60)) 
						    + S17.packaging_costs  + S17.logistics_cost + S17.tax_duty_per_operation
						   )* S17.exchange_rate,0)	

		    	ELSE IsNUll(((S17.assembly_secs_operation * (S17.machinehourly_operation_overhead/3600))
				            +((S17.assembly_secs_operation * (S17.direct_hourly_labor_headcount/3600)*S17.direct_headcount)
							*(1+S17.indirect_labor_costs)*(1+S17.fringes))
							+ S17.packaging_costs  + S17.logistics_cost + S17.tax_duty_per_operation
						   )* S17.exchange_rate,0)		
	       END
	   )  as ARROW_CALC_COST
      ,S22.Source_c
	  ,S22.Processing_ID
	  ,S22.filename
      ,S17.sub_assembly_name
  from PARWS22_CCS_COVER_PAGE_INFO                    S22
  JOIN PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
    ON S22.Processing_ID     = S17.Processing_ID
   and S22.filename          = S17.filename
  Join PARWU01_CCTSS_FLAT                             U01
    ON U01.ARWU31_CTSP_N            = User_Selected_CTSP_N
   And U01.ARWA06_RGN_C             = User_Selected_CTSP_Region_C
   And U01.ARWA03_ENRG_SUB_CMMDTY_X = User_Selected_ENRG_SUB_CMMDTY_X
   And U01.ARWU01_BNCHMK_VRNT_N     = User_Selected_BNCMK_VRNT_N
  LEFT JOIN PARWA53_LGCY_CCS_PGM                      A53 
    ON u01.ARWU31_CTSP_N            = A53.[ARWA53_LGCY_CCS_PGM_N]
 where S22.Processing_ID            = @GUID
   and S17.sub_assembly_name       != 'Final Assembly'
 group by S22.Source_c, S22.Processing_ID, S22.filename, S17.sub_assembly_name
 ) S17
 Join PARWS21_CCS_SUMMARY_TAB_INFO S21
   ON S21.Processing_ID     = S17.Processing_ID
  and S21.filename          = S17.filename
  and S21.part_cluster_type = S17.sub_assembly_name
Where S21.cost_item                ='4. Assembly'


--*****************
--Final assembly
--*****************
INSERT INTO #PRE_VALIDATION
select S21.cost_item    AS TEMPLATE_SECTION --'1. Final assembly'
      ,S21.cost         AS STAGING_COST 
      ,ARROW_CALC_COST
      ,S17.Source_c
	  ,S17.Processing_ID
	  ,S17.filename
	  ,S21.ARWS21_CCS_SUMMARY_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,S17.sub_assembly_name
  From
(
select SUM(
	       CASE WHEN U01.ARWA10_COST_EST_PERFD_F = 1 and ARWA53_LGCY_CCS_PGM_N is NULL
		    	THEN IsNUll(((S17.assembly_secs_operation * (S17.machinehourly_operation_overhead/3600))
				            +(S17.total_labor_minutes*(S17.direct_hourly_labor_headcount/60)) 
						    + S17.packaging_costs  + S17.logistics_cost + S17.tax_duty_per_operation
						   )* S17.exchange_rate,0)	

		    	ELSE IsNUll(((S17.assembly_secs_operation * (S17.machinehourly_operation_overhead/3600))
				            +((S17.assembly_secs_operation * (S17.direct_hourly_labor_headcount/3600)*S17.direct_headcount)
							*(1+S17.indirect_labor_costs)*(1+S17.fringes))
							+ S17.packaging_costs  + S17.logistics_cost + S17.tax_duty_per_operation
						   )* S17.exchange_rate,0)		
	       END
	   )  as ARROW_CALC_COST
      ,S22.Source_c
	  ,S22.Processing_ID
	  ,S22.filename
      ,S17.sub_assembly_name
  from PARWS22_CCS_COVER_PAGE_INFO                    S22
  JOIN PARWS17_CCS_SUPPLIER_QUOTE_ASSEMBLY_PARTS_INFO S17
    ON S22.Processing_ID = S17.Processing_ID
   and S22.filename      = S17.filename
  Join PARWU01_CCTSS_FLAT                             U01
    ON U01.ARWU31_CTSP_N            = User_Selected_CTSP_N
   And U01.ARWA06_RGN_C             = User_Selected_CTSP_Region_C
   And U01.ARWA03_ENRG_SUB_CMMDTY_X = User_Selected_ENRG_SUB_CMMDTY_X
   And U01.ARWU01_BNCHMK_VRNT_N     = User_Selected_BNCMK_VRNT_N
  LEFT JOIN PARWA53_LGCY_CCS_PGM                      A53 
    ON u01.ARWU31_CTSP_N = A53.ARWA53_LGCY_CCS_PGM_N
 Where S22.Processing_ID = @GUID
   and S17.sub_assembly_name        = 'Final Assembly'
 group by S22.Source_c, S22.Processing_ID, S22.filename, S17.sub_assembly_name
) S17
  Join PARWS21_CCS_SUMMARY_TAB_INFO S21
    On S21.Processing_ID     = S17.Processing_ID
   AND S21.filename          = S17.filename
   AND S21.part_cluster_type = S17.sub_assembly_name
 where S21.cost_item     = '1. Final assembly'

--*****************
--Setup up the markups From the S18 Staging table so the Scrap, SG&A, Profit are on one line
--*****************
INSERT INTO #PARWS18_MARKUPS_FLAT
Select FILENAME
      ,sub_assembly_name        as SUB_ASSEMBLY
      ,Sum(Scrap_Markup)        as Scrap_Markup
      ,Sum(SGA_TOTAL_Markup)    as SGA_TOTAL_Markup
      ,Sum(PROFIT_Markup)       as PROFIT_Markup
  From
      (
       Select FILENAME
             ,sub_assembly_name
             ,Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value  ELSE 0 END AS Scrap_Markup 
             ,Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value  ELSE 0 END AS SGA_TOTAL_Markup 
             ,Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value  ELSE 0 END AS PROFIT_Markup 
         From PARWS18_CCS_SUPPLIER_QUOTE_MANUFACTURING_MARKUPS_INFO S18
        Where Processing_ID = @GUID
		 and manufacturing_markup_desc in ('Scrap','SG&A - Total','Profit')
      ) MRKUP
group by FILENAME, sub_assembly_name;

/*****************/
--Staging Table Markups without the ARROW calculated formula cost. ARROW_CALC_COST is set to 0
/*****************/
INSERT INTO #PRE_VALIDATION
select S21.cost_item          AS TEMPLATE_SECTION   --'5. Manufacturing markups' and '2. Final assembly markups'
      ,S21.cost               AS STAGING_COST
      ,0                      as ARROW_CALC_COST    --Will update this amount below
      ,S21.Source_c
	  ,S22.Processing_ID
	  ,S22.filename
	  ,S21.ARWS21_CCS_SUMMARY_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,S21.part_cluster_type
 from PARWS21_CCS_SUMMARY_TAB_INFO S21
 JOIN PARWS22_CCS_COVER_PAGE_INFO  S22
   ON S21.Processing_ID=S22.Processing_ID
  AND S21.filename=S22.filename
where S21.cost_item     in ('5. Manufacturing markups','2. Final assembly markups')
  and S22.Processing_ID = @GUID 
;

--*****************
--Update ARROW manufacturing markup amount in Pre_Val_Target
--*****************
MERGE INTO #PRE_VALIDATION   Pre_Val_Target
USING
(--Pre_Val_Source
Select TOT.FILENAME
      ,TOT.SUB_ASSEMBLY
	  ,Case When SUB_ASSEMBLY != 'Final assembly'  
	        Then '5. Manufacturing markups'
	  	    Else '2. Final assembly markups'
	   End as Template_Section  --('5. Manufacturing markups', '2. Final assembly markups') :Template_Section Needed for the join 

	  ,SCRAP_MARKUP_TOT    --For testing purpose only
	  ,SGA_MARKUP_TOT      --For testing purpose only
	  ,PROFIT_MARKUP_TOT   --For testing purpose only
	  ,(SCRAP_MARKUP_TOT + SGA_MARKUP_TOT + PROFIT_MARKUP_TOT) As Grand_Total_Markup --This must match the markup subtotal in the Excel file.
  From
(--TOT
Select Split.FILENAME
      ,Split.SUB_ASSEMBLY
--	  ,ARROW_Purchased_COST
--	  ,ARROW_Raw_COST
--	  ,ARROW_Processing_COST
--	  ,ARROW_Assembly_COST
	  ,Without_Markup_Tot
	  ,Scrap_Markup     * (Without_Markup_Tot)                                       as SCRAP_MARKUP_TOT --Markup for Scrap
	  ,SGA_TOTAL_Markup * (Without_Markup_Tot + (Scrap_Markup * Without_Markup_Tot)) as SGA_MARKUP_TOT   --Markup for SGA is a componded calculation per William Brown
	  ,PROFIT_Markup    * (Without_Markup_Tot
	                               + (Scrap_Markup     * (Without_Markup_Tot)) --SCRAP_MARKUP
	                               + (SGA_TOTAL_Markup * (Without_Markup_Tot + (Scrap_Markup * Without_Markup_Tot))) 
								  ) as PROFIT_MARKUP_TOT                                                 --Markup for Profit is a componded calculation per William Brown
  From
(--Split
  Select FILENAME
        ,SUB_ASSEMBLY
--        ,Sum(ARROW_Purchased_COST)          as ARROW_Purchased_COST
--        ,Sum(ARROW_Raw_COST)                as ARROW_Raw_COST
--        ,Sum(ARROW_Processing_COST)         as ARROW_Processing_COST
--        ,Sum(ARROW_Assembly_COST)           as ARROW_Assembly_COST
--        ,Sum(ARROW_Final_Assembly_COST)     as ARROW_Final_Assembly_COST
		,Case When SUB_ASSEMBLY = 'Final assembly' 
		      Then Sum(ARROW_Final_Assembly_COST)                                                  --Amount used for markup calc
			  Else Sum(ARROW_Assembly_COST)   + Sum(ARROW_Processing_COST)   + Sum(ARROW_Raw_COST) --Amount used for markup calc
		 End  Without_Markup_Tot
  From
      (--PRE
      --Need to get all the totals already inserted into the temp #PRE_VALIDATION table which will be used to calculate the markups.
      Select FILENAME
            ,SUB_ASSEMBLY
            ,Case When Template_Section = '1. Purchased parts' Then ARROW_CALC_COST ELSE 0 END AS ARROW_Purchased_COST 
            ,Case When Template_Section = '2. Raw materials'   Then ARROW_CALC_COST ELSE 0 END AS ARROW_Raw_COST
            ,Case When Template_Section = '3. Processing'      Then ARROW_CALC_COST ELSE 0 END AS ARROW_Processing_COST
            ,Case When Template_Section = '4. Assembly'        Then ARROW_CALC_COST ELSE 0 END AS ARROW_Assembly_COST
            ,Case When Template_Section = '1. Final assembly'  Then ARROW_CALC_COST ELSE 0 END AS ARROW_Final_Assembly_COST
      
       From #PRE_VALIDATION
      ) PRE
  group by FILENAME, SUB_ASSEMBLY  
) SPLIT
Join #PARWS18_MARKUPS_FLAT S18_FLAT on S18_FLAT.filename     = Split.filename 
                                   and S18_FLAT.SUB_ASSEMBLY = Split.SUB_ASSEMBLY
) TOT
)  Pre_Val_Source
ON (Pre_Val_Target.FILENAME         = Pre_Val_Source.FILENAME      AND
    Pre_Val_Target.SUB_ASSEMBLY     = Pre_Val_Source.SUB_ASSEMBLY  AND
	Pre_Val_Target.Template_Section = Pre_Val_Source.Template_Section

   )
when MATCHED THEN
UPDATE SET          
 	Pre_Val_Target.ARROW_CALC_COST = Grand_Total_Markup
;

--Select * From #PRE_VALIDATION;


/*****************/
--ERRORS
/*****************/
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
       Source_c
      ,CAST(STAGING_COST as Varchar(50)) as ARWE02_ERROR_VALUE

      ,Case When TEMPLATE_SECTION = '1. Purchased parts' Then
	             Case When SUB_ASSEMBLY = 'Directed Parts'
                      Then 'Purchased Parts total in Supplier Quote Summary does not match calculated Purchased Parts total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Directed Parts sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
      	              Else 'Purchased Parts total in Supplier Quote Summary does not match calculated Purchased Parts total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Cost sheets. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			     End
			When TEMPLATE_SECTION = '2. Raw materials' Then
			     'Raw material total in Supplier Quote Summary does not match calculated Raw Material total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Cost sheets. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.' 
			When TEMPLATE_SECTION = '3. Processing' Then
                 'Processing total in Supplier Quote Summary does not match calculated Processing total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Cost sheets. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = '4. Assembly' Then
                 Case When SUB_ASSEMBLY = 'Directed Parts'
                      Then 'Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Directed Parts sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
                 	  Else 'Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z/AB of the Cost sheets. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
                 End
			When TEMPLATE_SECTION = '1. Final assembly' Then
                 'Final Assembly total in Supplier Quote Summary does not match calculated Final Assembly total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column X/Z of the Final Assembly sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = '5. Manufacturing markups' Then
                 'Manufacturing markups total in Supplier Quote Summary does not match calculated Manufacturing markups total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column AB of the Total Markup per Piece section in the Cost sheets. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = '2. Final assembly markups' Then
                 'Final Assembly, Manufacturing markup total in Supplier Quote Summary does not match the calculated Final Assembly Manufacturing markup total. Please verify that the formulas have not been changed in column E of the Summary sheet and/or column Z of the Total Markup per Piece section in the Final Assembly sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
            Else TEMPLATE_SECTION + ' Unknown Template Section. Contact ARROW Support'
       End as ARWE02_ERROR_X

      ,Processing_ID
      ,filename
      ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
      ,@TIME_STAMP  as [ARWE02_CREATE_S]
      ,@CDSID       as [ARWE02_CREATE_USER_C]
      ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
      ,@CDSID       as [ARWE02_LAST_UPDT_USER_C]
      ,BATCH_ERROR_REF_K
      ,STAGING_TABLE
      ,'ERROR'
      ,SUB_ASSEMBLY
      ,0                               as ARWE02_ROW_IDX
      ,''       --Part_index
      ,CAST(ARROW_CALC_COST as varchar(50))       --Arrow value
 FROM #PRE_VALIDATION
Where 
  (
      ABS(ARROW_CALC_COST) <  ABS(STAGING_COST) - @V_Threshold_A
	  or 
	  ABS(ARROW_CALC_COST) >  ABS(STAGING_COST) + @V_Threshold_A
   )
;
DROP TABLE IF EXISTS #PRE_VALIDATION;
DROP TABLE IF EXISTS #PARWS18_MARKUPS_FLAT;
END TRY

BEGIN CATCH
DROP TABLE IF EXISTS #PRE_VALIDATION;
DROP TABLE IF EXISTS #PARWS18_MARKUPS_FLAT;
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS21_CCS_SUMMARY_TAB_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;
GO
