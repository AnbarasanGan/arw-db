SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 06/28/2021
-- Description:	This SP calls all the Tygra UB load scripts. Base on @resulst from PARWP_TYGRA_UI_TYGRA_TYGRA_VALIDATIONS it makes a decision on whether to load the UB tables or not.
--              The UI will submit this script multiple times depending on the number of studies selected in the UI 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   08-18-2021  US2793893 added ACT file last update date 
-- rwesley2	  09-03-2021  US2835340 remove processing ID creation and accept from UI 
--                        changed @result to OUTPUT
-- rwesley    09-15-2021  US2879211 - load Curent files.  Changed @wrkshp_status to @TYGRA_FILE_TYPE_N
--                        Was using @wrkshp_status to hold file type.  name correction for better understanding.
--                        Added Tygra_Master_UI SPs here as Tygra_Load is a unit of work based on P05.
--                        pass processing_id to UB6 load
-- rwesley2   10-20-2021  US2995424 - Add Begin Transaction and Commit.  
--                        removed P05 proc table SP
-- rwesley2   04-05-2022  US3482265 added new validation to PARWP_TYGRA_VALIDT_MISSING_CCM_UI and need to pass in additional parameters 
-- rwesley2   04-11-2022  US3510421 added post validation SP 
-- rwesley2   04-29-2022  US3433185 Update Variant fields for Tygra studies upon load of a Current/Scope Tygra file load 
-- rwesley2   05-12-2022  US3617161 removed RETURN at EOJ 
-- rwesley2   05-25-2022  US3657704 pass in @file_source to determine whether to load stage tables.  If @file_source = ACT then a new processing_id was created and load stage tables.
--                        If @file_source = ARROW the a processing_id from an already loaded file is being used and skip loading stage tables.  
-- rwesley2   06-08-2022  US3704897 move execution of PARWP_TYGRA_UI_VRNT_CALC inside COMMIT for UB table load.  Remove IF statement that checks for post load errors before execution. 
-- rwesley2   06-20-2022  US3283898 DE256745 changed validation logic for post load validation SP
-- rwesley2   06-20-2022  US3283898 DE256744 - pink screen fix, added program name to select for UB1 key
-- rwesley2   06-27-2022  US3283898 remove CDSID and add file name to catch block
-- rwesley2   06-28-2022  US3283898 remove UB1 table load, stage table load and validations from this scrip and placed in new SP PARWP_TYGRA_UI_TYGRA_TYGRA_VALIDATIONS.   
-- rwesley2   07-12-2022  US3820641 remove XACT_ABORT.  It is rolliong back catch errors.
-- rwesley2   07-18-2022  US3820641 Remove Begin Transaction, Commit and Rollback Transaction.  UI will control transactions.  
-- rwesley2   06-20-2022  US3283898 DE261033 - UB1 key being built incorrectly.  changed from @load_to_pgm_name to @Program_name
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_TYGRA_UI_TYGRA_LOAD] 
	-- Add the parameters for the stored procedure here

-- Input Parameter
@CDSID varchar(MAX)
,@processing_id varchar(MAX)
,@Program_name varchar(max)
,@TYGRA_FILE_TYPE_N varchar(max)
,@Tygra_file_version INT
,@Tygra_file_name varchar(max)
,@file_source varchar(max) 
,@BoB_key INT             -- -1 for progam load othewise ARWU01_CCTSS_K for a study
,@load_to_pgm_name varchar(max)
,@TIME_STAMP    DATETIME       
,@result varchar(max) Output



AS
BEGIN
-- SET @result = 0;
 set @result  = 'No Errors';

SET NOCOUNT ON;

 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));


--DECLARE @TIME_STAMP    DATETIME    = GETUTCDATE();
DECLARE @TYGRA_LOAD_ERROR varchar(MAX);

DECLARE @tygra_file_type int = (select ARWA54_TYGRA_FILE_TYPE_K from PARWA54_TYGRA_FILE_TYPE   where ARWA54_TYGRA_FILE_TYPE_N =@TYGRA_FILE_TYPE_N );

DECLARE @ARWUB1_TYGRA_FILE_K  int = (select arwub1_tygra_file_k from  [dbo].[PARWUB1_TYGRA_FILE] 
                                      where ARWUB1_TYGRA_FILE_N = @Tygra_file_name 
                                        and arwub1_tygra_file_rev_r = @Tygra_file_version
                                        and arwa54_tygra_file_type_k = @tygra_file_type 
										and ARWUB1_TYGRA_FILE_PGM_N = @Program_name )


 

 BEGIN TRY
--    BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

	-- Execute the delete revision procedure to delete the mappings for a BoB when the user wants to reload the data.
	IF @BoB_key <> -1  --is NOT NULL 
	BEGIN
	EXEC [dbo].[PARWP_DELETE_REVISION_CCTSS_TYGRA] @BoB_key,'V',@tygra_file_type,@CDSID
	END

-- execute TYGRA Load UB tables stored procedures
-- UB2 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILECCM_UI]    @processing_id, @CDSID, @load_to_pgm_name, @Tygra_file_version, @TIME_STAMP,@tygra_file_type ; 
--   select count(*),'ub2' from [dbo].[PARWUB2_TYGRA_FILE_CCM]
--   where [ARWUB2_LAST_UPDT_S] = @time_stamp
 
---- UB3 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILE_REC_UI]                 @processing_id, @CDSID, @Tygra_file_version , @TIME_STAMP;  
--   select count(*),'ub3' from [dbo].[PARWUB3_TYGRA_FILE_REC] 
--   where [ARWUB3_LAST_UPDT_S] = @time_stamp

-- UB4 load
   EXEC [dbo].[PARWP_TYGRA_LOAD_FILE_REC_CCM_UI]             @processing_id, @CDSID,  @TIME_STAMP,@load_to_pgm_name;  
--   select count(*),'ub4' from [dbo].[PARWUB4_TYGRA_FILE_REC_CCM] 
--   where [ARWUB4_LAST_UPDT_S] = @time_stamp

-- load UB6
  EXEC [dbo].[PARWP_TYGRA_UI_LOAD_UB6_UI]  @CDSID,@TIME_STAMP,@tygra_file_name,@tygra_file_type,@Tygra_file_version,@ARWUB1_TYGRA_FILE_K
                                          ,@load_to_pgm_name,@processing_id;
--  select count(*),'ub6' from [dbo].[PARWUB6_CCTSS_TYGRA_FILE] 
--  where [ARWUB6_LAST_UPDT_S] = @time_stamp


-- update U04 variant from Tygra
   DECLARE @TYGRA_U04_VRNT_UPDATE  [dbo].[PARWT01_CCTSS]

      If @BoB_Key = -1
      Begin
        insert into @TYGRA_U04_VRNT_UPDATE  
           select   ARWU01_CCTSS_K
           from PARWU01_CCTSS_FLAT where ARWU31_CTSP_N = @load_to_pgm_name
 						             and ARWU01_MANL_VRNT_TYGRA_FLD_F = 0
						             and ARWU01_TYGRA_REQD_F = 1
          exec [dbo].[PARWP_TYGRA_UI_VRNT_CALC]  @TYGRA_U04_VRNT_UPDATE,@processing_id,@CDSID,@time_stamp,0
	    END
	 If @BoB_Key <> -1
      Begin
        insert into @TYGRA_U04_VRNT_UPDATE  
          select ARWU01_CCTSS_K
          from PARWU01_CCTSS_FLAT where ARWU01_CCTSS_K = @BoB_key
 						            and ARWU01_MANL_VRNT_TYGRA_FLD_F = 0
						            and ARWU01_TYGRA_REQD_F = 1
          exec [dbo].[PARWP_TYGRA_UI_VRNT_CALC]  @TYGRA_U04_VRNT_UPDATE,@processing_id,@CDSID,@time_stamp,0
       END

--   COMMIT TRANSACTION;

-- validatate UB table loads
  EXEC [dbo].[PARWP_TYGRA_VALIDT_POST_LOAD_UI]  @processing_id ,@CDSID ,@Program_name ,@Tygra_file_name ,@Tygra_file_version ,@file_source ,@BoB_key ,@load_to_pgm_name 
                                               ,@TIME_STAMP ,@TYGRA_LOAD_ERROR OUTPUT


 END TRY	


BEGIN CATCH
--	ROLLBACK Transaction;
	Set @result = 'Error';
--    set @result = 0
 INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@processing_id                           --Processing_id
		,@Tygra_file_name                        --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,GETUTCDATE() 
		,@CDSID
        ,GETUTCDATE() 
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'LOAD TYGRA PROCEDURE'
        ,0                              as ARWE02_ROW_IDX	
	    ,' '                               -- part_index 
	    ,' '                               -- ARROW_VALUE
	;


  END CATCH;	
 



 

END;


GO
