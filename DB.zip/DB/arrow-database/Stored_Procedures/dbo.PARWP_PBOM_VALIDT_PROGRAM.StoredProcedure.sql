DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_PROGRAM]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 01/07/2020
-- Description:	Stored Procedure to validate Program Code on PBOM
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   09-11-2020  US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10-20-2020  US1996362  Switch from E02 to E03 and include Excel column
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDT_PROGRAM] 
	-- Add the parameters for the stored procedure here
	 @GUID  varchar(500)
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Validate Program Code  
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
      SELECT
	      Validate.[Source_c]                          as [ARWE03_SOURCE_C],
	      Validate.[Program]                           as [ARWE03_ERROR_VALUE], 
	      'Program does not match the selected BC@J1 Program' as [ARWE03_ERROR_x],
	      Validate.[Processing_ID]                     as [ARWE03_PROCESSING_ID],
	      Validate.[file_name]                         as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      Validate.[ARWS59_PBOM_PARTS]                 as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  ''                                           as [ARWE03_EXCEL_TAB_X],
		  4                                            as ARWE03_ROW_IDX,
		  ''                                           as ARWE03_Part_Index,
		  User_Selected_CTSP_N                         as ARWE03_Arrow_value,
		  'B'                                          as ARWE03_COLUMN
       FROM 
	   (SELECT 
               Processing_ID,
		       Program,
		       Source_c,
			   Sub_commodity_name,
			   sub_assembly_name,
		       file_name,
			   row_idx,
               ARWS59_PBOM_PARTS,
			   User_Selected_CTSP_N,
			   row_number() over (partition by S59.Processing_ID, S59.file_name,s59.program    Order by s59.program) as rownum
          FROM PARWS59_PBOM_PARTS s59 
          WHERE Processing_ID       = @GUID 
            and Program            != User_Selected_CTSP_N
        ) Validate
		where rownum = 1
		;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
             ,''                               -- ARROW_VALUE
			 ,''                               -- Column
END CATCH




GO
