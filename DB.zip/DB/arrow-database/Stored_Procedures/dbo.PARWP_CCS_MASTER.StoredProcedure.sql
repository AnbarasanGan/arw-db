SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 03/18/2019
-- Description:	Master Procedure to call CCS Validation and data load Stored Procedures
-- How to Run Manually
--    DECLARE @RC int
--    DECLARE @GUIDIN varchar(500) = 'A3A996B4-69A6-4C3D-9A4B-5CEEF65A28B2'
--    DECLARE @CDSID varchar(8)    = 'ASOLOSKY'
--    DECLARE @result int
--    
--    EXECUTE @RC = [dbo].[PARWP_CCS_MASTER] 
--       @GUIDIN
--      ,@CDSID
--      ,@result OUTPUT
--    ;
--    select @RC;
-- =============================================
-- Changes
-- =============================================
-- Author     Date        User Story  Description
-- ------     -----       ----------  -----------
-- Asolosky   05/13/2019              Removed the validation on Purchasing Commodity code.  The code is assigned in the BoB and doesn't need to look at the Purch commodity from Excel.
-- ASHAIK12   06/05/2019              Added CCT Stored Procedures
-- Asolosky   06/07/2019              Added PARWP_CCS_VALIDT_BOM_QUOTED
-- Asolosky   06/26/2019              Added merge/update on Cover page to stop processing a file if there's an error.
-- Ashaik12   06/27/2019              Added the SUPL_CRNCY Validation Procedure
-- ASHAIK12   07/18/2019              Added FILE_TYPE Variable and passing it to the GET_CCTSS_KEY Procedure
-- ASHAIK12   08/13/2019              Added new procedure with all delete statements for CCt and CCS tables. 
-- ASAMRIYA   08/21/2019              Added new parameter and new procedure for Import Fields.
-- rwesley2	  09/17/2019              Added variables for upper/lower limits on SPs Assembly, Processing, Purchased Parts, and Raw Materials and Summary_CST
-- rwesley2	  10/08/2019              removing upper/lower bound and changing to a comparison to a dollar value	 
-- ashaik12   10/25/2019              Add validation for -- If quoted flag is YES check if the part made it to final table
-- rwesley2   11/08/2019              added scrub for special characters on staged tables 
-- ashaik12   12/23/2019              Added new procedure PARWP_CCS_VALIDT_BOM_QTY
-- ashaik12   01/10/2020              Added new parameter @TIME_STAMP
-- ashaik12   01/22/2020              Added new validation for Material Usage
-- Asolosky   02/12/2020              Added the code for import versioning. CCS/GCS files will branch into 2 sections of code depending on the import version
--                                    PARWP_CCS_UPDATE_S22_COVER_ERROR_FLAG was created to hold the existing merge statement that updates the S22.Skip_loading_due_to_error_f 
-- ASHAIK12   02/20/2020              Added [PARWP_GCS_SCRUB] to  Update SG&A to SG&A - Total in S18 table
-- ASHAIK12   06/03/2020              Add new Sub Assembly Validation for Post PBoM Load
-- Asolosky   06/08/2020              execute PARWP_CCS_LOAD_PBOM, added @CCTSS_K as an input parameter.  This load is only for "PRE PBOM" BoBs
-- Asolosky   07/16/2020  US1774947   Remove procedure PARWP_CCS_VALIDT_QUOTED_PART_MISSING.  It was in the PRE-PBOM and PBOM section and added PARWP_GCS_SCRUB to PREPBOM processing
-- Asolosky   09/11/2020  US1910882   Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky   09/11/2020  US2126152   Added procedure PARWP_CCS_VALIDT_SUB_ASSEMBLY_PREPBOM to Pre-PBOM code.
-- Ashaik12   12/12/2020  US2137799   Added new procedure to validate total after loading the base tables.
-- Asolosky   01/19/2021  US2164194   Changed the threshold from a dynamic number, which was in the UpperBound and LowerBound function, to a static number.
-- Ashaik12   01/27/2021  US2229111   Add new validation to check program markup is available or not
-- Asolosky   02/08/2021  US2260893   Replaced the 5 Pre Load Summary Validation procedures with PARWP_CCS_VALIDT_SUMMARY_PRE, which included validation for markups
-- Asolosky   02/11/2021  US2274141   Added new validations for quantity/raw material usage for the cost sheets.
-- Asolosky   08/04/2021  US2429667   Added new validation procedure PARWP_CCS_VALIDT_EXCEL_SUMMARY which is only in the section of code for BoBs marked as PBOM
-- Asolosky   01/06/2022  US3190189   Added new logic (PARWP_CALC_MASTER_LOAD_PRIMARY) for populating the Calc tables at the end of the procedure 
-- Asolosky   06/02/2022  US3612614   Added procedure, PARWP_DA_DEL_TYP_COPY_FROM_GCS, to copy GCS purchpart, raw and processing data  
--                                    to equivalent DA tables when DA part is type Delete.  This will create a zero balance for the part.
-- Asolosky   08/11/2022  US3928682   Changed call to PARWP_CCS_VALIDT_EXCEL_SUMMARY to include threshold parameter
-- =============================================

CREATE or ALTER PROCEDURE [dbo].[PARWP_CCS_MASTER] 
	-- Add the parameters for the stored procedure here
@GUIDIN varchar(500), 
@CDSID  varchar(8),
@result VARCHAR(MAX) Output


AS
Begin
 DECLARE @Processing_Status_x Varchar(500)
 DECLARE @CCTSS_K INT
 DECLARE @FILE_TYPE VARCHAR(50)
 DECLARE @PROCESSING_STATUS VARCHAR(50) 
 DECLARE @threshold DECIMAL(5,3)
 DECLARE @TIME_STAMP DATETIME
 DECLARE @BoB_version VARCHAR(500)
 DECLARE @Error VARCHAR(500)
 DECLARE @Calculated_Value DECIMAL(38,18)
 DECLARE @Staging_Value DECIMAL(38,18)
 DECLARE @File_Name VARCHAR(500)
 DECLARE @Ref_K INT
 DECLARE @V_Threshold_A DECIMAL(38,18)
 DECLARE @AtLeast1_file_loaded int = 0;
 DECLARE @Primary_output_error VARCHAR(5000);
 DECLARE @u01_Study Varchar(100);
 Declare @T08_CCTSS_DSGN_SUPL  dbo.PARWT08_CCTSS_DSGN_SUPL;

 SET NOCOUNT ON;
 SET @PROCESSING_STATUS = 'Regular';
 SET @result            = '';
 SET @TIME_STAMP        = GETUTCDATE();
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));

 SELECT @BoB_version = 
 ( select Distinct u01.ARWA46_CCTSS_IMPT_VER_N 
     from PARWS22_CCS_COVER_PAGE_INFO S22
     JOIN PARWU01_CCTSS_FLAT u01
       on S22.User_Selected_CTSP_N            = u01.ARWU31_CTSP_N
      and S22.User_Selected_ENRG_SUB_CMMDTY_X = u01.ARWA03_ENRG_SUB_CMMDTY_X
      and S22.User_Selected_CTSP_Region_C     = u01.ARWA06_RGN_C
      and S22.User_Selected_BNCMK_VRNT_N      = u01.ARWU01_BNCHMK_VRNT_N
    where S22.Processing_ID                   = @GUIDIN
 );
--select @BoB_version;

Select @V_Threshold_A = (Select ARWT01_THRESHOLD_A from PARWT01_THRESHOLD);

-- GET CCTSS Key
EXEC [dbo].[PARWP_GET_CCTSS_KEY]                @GUIDIN , @CCTSS_K OUTPUT,@FILE_TYPE='CCS'
Set @u01_Study = (Select U01.ARWU31_CTSP_N            + ' ' +
                         U01.ARWA06_RGN_C             + ' ' +
                   	     substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	     substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                    from PARWU01_CCTSS_FLAT U01
                   where U01.ARWU01_CCTSS_K = @CCTSS_K
 				 );
     

IF @BoB_version = 'Pre PBOM'  -- PRE PBoM

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start Pre PBOM import versioning
--++++++++++++++++++++++++++++++++++++++++++++++++

Begin  

 EXEC [dbo].[PARWP_GCS_SCRUB]                        @GUIDIN, @CDSID, @TIME_STAMP;
 -- scrub for special charcters on stage tables
 EXEC [dbo].[PARWP_CCS_SCRUB_SPCL_CHARS]             @GUIDIN, @CDSID;

 --Cover Page, PBOM and Exchange rate Validation
 EXEC [dbo].[PARWP_CCS_VALIDT_SUB_ASSEMBLY_PREPBOM]  @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP;  --Also validates Engineering Commodity
 EXEC [dbo].[PARWP_CCS_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;

 EXEC [dbo].[PARWP_CCS_VALIDT_SUPPLIER]              @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages
 EXEC [dbo].[PARWP_CCS_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages

 
 EXEC [dbo].[PARWP_CCS_VALIDT_DUP_BOB]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_PURCH_CMMDTY]          @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning message
 
 --PBOM Validation
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_PART]              @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_PART_NAME]         @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_UOM]                   @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_QTY]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_MTRL_USG]          @GUIDIN, @CDSID, @TIME_STAMP;
 
 --Exchange Rate tab Validations
 EXEC [dbo].[PARWP_CCS_VALIDT_CRNCY_CODE]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_SUPL_CRNCY]  @GUIDIN, @CDSID, @TIME_STAMP;

 
--Supplier Quote Validation 
 EXEC [dbo].[PARWP_CCS_VALIDT_PURCHASED_PARTS]       @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_RAW_MATERIALS]         @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_PROCESSING_COSTS]      @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_ASSEMBLY]              @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_MFG_MARKUP]            @GUIDIN, @CDSID,@TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_QUOTED]            @GUIDIN, @CDSID,@TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_COST_QTY_PREPBOM]      @GUIDIN, @CDSID,@TIME_STAMP;

-- Pre Load Summary Validations
   EXEC [dbo].[PARWP_CCS_VALIDT_SUMMARY_PRE]         @GUIDIN, @CDSID,@TIME_STAMP,@V_Threshold_A;

-- Check for Program Markup
 EXEC [dbo].[PARWP_CCS_VALIDT_BOB_PRGRM_MRKUP]                @GUIDIN, @CDSID,@TIME_STAMP

  BEGIN TRY
   
   BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

     --	Merge on Cover page to stop processing a file if there's an error 
     EXEC [dbo].[PARWP_CCS_UPDATE_S22_COVER_ERROR_FLAG] @GUIDIN;

	 -- Delete Statements for CCT and CCS tables
	 EXEC [dbo].[PARWP_CST_CONSL_DELETE_SCRIPT]      @GUIDIN , @CDSID , @CCTSS_K
	  
	 --Load CCS
    EXEC [dbo].[PARWP_CCS_LOAD_PBOM]                 @GUIDIN, @CDSID, @TIME_STAMP, @CCTSS_K; -- U17 , U18 , U19
	 EXEC [dbo].[PARWP_CCS_LOAD_EXCHG_RATE]           @GUIDIN, @CDSID, @TIME_STAMP; -- U21, U22
	 EXEC [dbo].[PARWP_CCS_LOAD_PURCHASED_PARTS]      @GUIDIN, @CDSID, @TIME_STAMP; -- U23, U24
    EXEC [dbo].[PARWP_CCS_LOAD_RAW_MTRLS]            @GUIDIN, @CDSID, @TIME_STAMP; -- U25
	 EXEC [dbo].[PARWP_CCS_LOAD_PROCESSING_COSTS]     @GUIDIN, @CDSID, @TIME_STAMP; -- U26
	 EXEC [dbo].[PARWP_CCS_LOAD_ASSEMBLY]             @GUIDIN, @CDSID, @TIME_STAMP; -- U27, U29
	 EXEC [dbo].[PARWP_CCS_LOAD_MFG_MARKUPS]		     @GUIDIN, @CDSID, @TIME_STAMP; -- U28, U30


	-- Scrubbing Post Load
	 EXEC [dbo].[PARWP_CCS_SCRUB_PROCESSING]       	           @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_SCRUB_PURCHASED_COSTS]              @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS]                @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS_USAGE]          @GUIDIN, @CDSID, @TIME_STAMP;
	 

	 -- CCT
	EXEC [dbo].[PARWP_CCT_LOAD_PURCHPART]           @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U56_SUPL_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_UPD_U06_DSGN_FNLASSY]     @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U08_FINAL_ASSY]      @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_UPD_U08_SUPL_QTE_A]       @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP;

	-- DA Type=Delete; copy GCS/CCS to DA for purch part, raw, processing if there's a DA type=DELETE. This will zero out the GCS cost
   Insert into @T08_CCTSS_DSGN_SUPL 
   Select U08.ARWU08_CCTSS_DSGN_SUPL_K
     From PARWS22_CCS_COVER_PAGE_INFO S22
     JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT U08
       ON U08.ARWA03_ENRG_SUB_CMMDTY_X    = S22.User_Selected_ENRG_SUB_CMMDTY_X
      AND U08.ARWU31_CTSP_N					= S22.User_Selected_CTSP_N           
      AND U08.ARWA06_RGN_C						= S22.User_Selected_CTSP_Region_C    
      AND U08.ARWU01_BNCHMK_VRNT_N 			= S22.User_Selected_BNCMK_VRNT_N     
      AND U08.ARWA14_VEH_MAKE_N				= S22.User_Selected_VEH_MAKE_N       
      AND U08.ARWA34_VEH_MDL_N				= S22.User_Selected_VEH_MDL_N        
      AND U08.ARWA35_DSGN_VEH_MDL_VRNT_X	= S22.User_Selected_VEH_MDL_VRNT_X   
      AND U08.ARWA35_DSGN_VEH_MDL_YR_C		= S22.User_Selected_VEH_MDL_YR_C     
      AND U08.ARWA17_SUPL_N					= S22.User_Selected_SUPL_N           
      AND U08.ARWA17_SUPL_C					= S22.User_Selected_SUPL_C           
      AND U08.ARWA28_CNTRY_N					= S22.User_Selected_SUPL_CNTRY_N     
    Where s22.Processing_ID               = @GUIDIN
      and s22.Skip_loading_due_to_error_f = 0;	
	EXEC [dbo].[PARWP_DA_DEL_TYP_COPY_FROM_GCS]     @CCTSS_K, @T08_CCTSS_DSGN_SUPL, @CDSID, @TIME_STAMP;

	EXEC [dbo].[PARWP_CCS_UPDT_LAST_IMPT]   @GUIDIN, @CDSID, @PROCESSING_STATUS

 	-- POST LOAD VALIDATION CHECK
	EXEC [dbo].[PARWP_CCS_VALIDT_SUMMARY_CST_POST] @GUIDIN,@CCTSS_K,@V_Threshold_A ,@Error OUTPUT,@Calculated_Value OUTPUT,@Staging_Value OUTPUT,@File_Name OUTPUT,@Ref_K OUTPUT

   IF @Error != ''  --Check if the post load summary validation generated an error 
      Set @result = '***Post Load Error: Arrow calculated Total $' +CAST(@Calculated_Value as varchar(50)) +' using data loaded into base tables did not equal to Total on Summary sheet $'+CAST(@Staging_Value as varchar(50)) +' for Processing ID '+@GUIDIN  ;    

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table load for Calculations
--++++++++++++++++++++++++++++++++++++++++++++++++
	Set @AtLeast1_file_loaded = (Select Count(*) 
	                               From PARWS22_CCS_COVER_PAGE_INFO S22 
							      Where S22.Processing_ID               = @GUIDIN
								    and S22.Skip_loading_due_to_error_f = 0
							    );
	If IsNULL(@AtLeast1_file_loaded,0) > 0
       BEGIN
          exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
               @U01_k                = @CCTSS_K
             , @U06_k                = -1
             , @U04_k                = -1
             , @CDSID                = @CDSID
             , @TRIGGER              = 'GCS IMPORT'
             , @Primary_output_error = @Primary_output_error OUTPUT
          ;          
          If @Primary_output_error = ''
             Begin
                COMMIT TRANSACTION
                If @result = ''
				     Set @result = 'SUCCESS';
				Else Set @result = @result;  --Didn't need the ELSE but wanted to show there would be a POST load calculation error at this point
             End
          Else
             Begin
                Rollback
				If @result = ''
                     Set @result = 'Master Load Primary Error: ' + @Primary_output_error;
				Else Set @result = SUBSTRING(CONCAT('Master Load Primary Error: ', @Primary_output_error, ' ', @result),1,5000);  
             End
       End
	ELSE
	   BEGIN
          Set @result = 'SUCCESS'; --All files in the batch had a validation error. There should be no data to commit at this point but we should have something to match the begin transaction.
          COMMIT TRANSACTION;
	   End

 END TRY

 --CATCH
 BEGIN CATCH
   Rollback;
   Set @result = 'CCS_MASTER SYSTEM ERROR(Pre-PBOM): ' +              
	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
				 ' |Processing Id: ' + @GUIDIN +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
--	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

   SET @PROCESSING_STATUS = 'Processing_Error';

    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUIDIN                           --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'CCS MASTER PROCEDURE'
		,0                                 --row_idx
		,''                                --Part_index
		,''                                --Arrow value		
;
	
	EXEC [dbo].[PARWP_CCS_UPDT_LAST_IMPT]   @GUIDIN, @CDSID, @PROCESSING_STATUS
		
  END CATCH;	

--  RETURN @result
End;

Else
--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start PBOM import versioning
--++++++++++++++++++++++++++++++++++++++++++++++++

Begin  

 --Removed PARWP_CCS_SCRUB_SPCL_CHARS

 -- GCS Scrub validation to update SG&A to SG&A - Total

 EXEC [dbo].[PARWP_GCS_SCRUB]                      @GUIDIN, @CDSID, @TIME_STAMP;
 -- scrub for special charcters on stage tables
 EXEC [dbo].[PARWP_CCS_SCRUB_SPCL_CHARS]             @GUIDIN, @CDSID;

 --Cover Page, PBOM and Exchange rate Validation
 EXEC [dbo].[PARWP_CCS_VALIDT_PROGRAM]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_REGION]                @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_ENGCOMMDTY_SUBCOMMDTY] @GUIDIN, @CDSID, @TIME_STAMP;  --Also validates Engineering Commodity.  Leaving as is for import versioning. There may be some overlapping messages
 EXEC [dbo].[PARWP_CCS_VALIDT_BNCHMK_VRNT]           @GUIDIN, @CDSID, @TIME_STAMP;

 EXEC [dbo].[PARWP_CCS_VALIDT_SUPPLIER]              @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages
 EXEC [dbo].[PARWP_CCS_VALIDT_DESIGN]                @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning messages

 
 EXEC [dbo].[PARWP_CCS_VALIDT_DUP_BOB]               @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_PURCH_CMMDTY]          @GUIDIN, @CDSID, @TIME_STAMP;  --Produces warning message


 
 --PBOM Validation
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_PART]              @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_PART_NAME]         @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_UOM]                   @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_IMPORT_VERSIONING] @GUIDIN, @CDSID, @TIME_STAMP;  --New for PBOM import versioning
 --Removed [dbo].[PARWP_CCS_VALIDT_BOM_QTY].  Same validation is in BOM_IMPORT_VERSIONING
 --Removed [dbo].[PARWP_CCS_VALIDT_BOM_MTRL_USG].  Same validation is in BOM_IMPORT_VERSIONING
 
 -- Sub - Assembly validation
 EXEC [dbo].[PARWP_CCS_VALIDT_SUB_ASSEMBLY]          @GUIDIN, @CDSID, @TIME_STAMP;

 --Exchange Rate tab Validations
 EXEC [dbo].[PARWP_CCS_VALIDT_CRNCY_CODE]            @GUIDIN, @CDSID, @TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_SUPL_CRNCY]            @GUIDIN, @CDSID, @TIME_STAMP;

 
--Supplier Quote Validation 
 EXEC [dbo].[PARWP_CCS_VALIDT_PURCHASED_PARTS]       @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_RAW_MATERIALS]         @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_PROCESSING_COSTS]      @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_ASSEMBLY]              @GUIDIN, @CDSID,@TIME_STAMP,@threshold=0.005;
 EXEC [dbo].[PARWP_CCS_VALIDT_MFG_MARKUP]            @GUIDIN, @CDSID,@TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_BOM_QUOTED]            @GUIDIN, @CDSID,@TIME_STAMP;
 EXEC [dbo].[PARWP_CCS_VALIDT_COST_QTY_PBOM]         @GUIDIN, @CDSID,@TIME_STAMP;

 --Summary Sheet Validation
 --This procedure is not in Pre-Pbom code because it uses the U17 sub-assembly table for validation.  Pre-Pbom does not have the U17 data loaded yet to do the validation
 EXEC [dbo].[PARWP_CCS_VALIDT_EXCEL_SUMMARY]          @GUIDIN, @CDSID,@TIME_STAMP, @CCTSS_K, @V_Threshold_A;

-- Pre Load Summary Validations
 EXEC [dbo].[PARWP_CCS_VALIDT_SUMMARY_PRE]           @GUIDIN, @CDSID,@TIME_STAMP,@V_Threshold_A;

 -- Check for Program Markup
 EXEC [dbo].[PARWP_CCS_VALIDT_BOB_PRGRM_MRKUP]       @GUIDIN, @CDSID,@TIME_STAMP


  BEGIN TRY
   BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

     --	Merge on Cover page to stop processing a file if there's an error 
     EXEC [dbo].[PARWP_CCS_UPDATE_S22_COVER_ERROR_FLAG] @GUIDIN;

	 -- Delete Statements for CCT and CCS tables
	 EXEC [dbo].[PARWP_CST_CONSL_DELETE_SCRIPT]      @GUIDIN , @CDSID , @CCTSS_K
	  
	 --Load CCS
     --Removed PBOM Load
	 EXEC [dbo].[PARWP_CCS_LOAD_EXCHG_RATE]           @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_LOAD_PURCHASED_PARTS]      @GUIDIN, @CDSID, @TIME_STAMP;
     EXEC [dbo].[PARWP_CCS_LOAD_RAW_MTRLS]            @GUIDIN, @CDSID, @TIME_STAMP;  
	 EXEC [dbo].[PARWP_CCS_LOAD_PROCESSING_COSTS]     @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_LOAD_ASSEMBLY]             @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_LOAD_MFG_MARKUPS]		  @GUIDIN, @CDSID, @TIME_STAMP;




    -- Scrubbing Post Load
	 EXEC [dbo].[PARWP_CCS_SCRUB_PROCESSING]       	           @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_SCRUB_PURCHASED_COSTS]              @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS]                @GUIDIN, @CDSID, @TIME_STAMP;
	 EXEC [dbo].[PARWP_CCS_SCRUB_RAW_MATERIALS_USAGE]          @GUIDIN, @CDSID, @TIME_STAMP;
	 
	 -- CCT
	
	EXEC [dbo].[PARWP_CCT_LOAD_PURCHPART]           @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U56_SUPL_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_UPD_U06_DSGN_FNLASSY]     @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U08_FINAL_ASSY]      @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_UPD_U08_SUPL_QTE_A]       @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP;

	-- DA Type=Delete; copy GCS/CCS to DA for purch part, raw, processing if there's a DA type=DELETE. This will zero out the GCS cost
   Insert into @T08_CCTSS_DSGN_SUPL 
   Select U08.ARWU08_CCTSS_DSGN_SUPL_K
     From PARWS22_CCS_COVER_PAGE_INFO S22
     JOIN PARWU08_CCTSS_DSGN_SUPL_FLAT U08
       ON U08.ARWA03_ENRG_SUB_CMMDTY_X    = S22.User_Selected_ENRG_SUB_CMMDTY_X
      AND U08.ARWU31_CTSP_N					= S22.User_Selected_CTSP_N           
      AND U08.ARWA06_RGN_C						= S22.User_Selected_CTSP_Region_C    
      AND U08.ARWU01_BNCHMK_VRNT_N 			= S22.User_Selected_BNCMK_VRNT_N     
      AND U08.ARWA14_VEH_MAKE_N				= S22.User_Selected_VEH_MAKE_N       
      AND U08.ARWA34_VEH_MDL_N				= S22.User_Selected_VEH_MDL_N        
      AND U08.ARWA35_DSGN_VEH_MDL_VRNT_X	= S22.User_Selected_VEH_MDL_VRNT_X   
      AND U08.ARWA35_DSGN_VEH_MDL_YR_C		= S22.User_Selected_VEH_MDL_YR_C     
      AND U08.ARWA17_SUPL_N					= S22.User_Selected_SUPL_N           
      AND U08.ARWA17_SUPL_C					= S22.User_Selected_SUPL_C           
      AND U08.ARWA28_CNTRY_N					= S22.User_Selected_SUPL_CNTRY_N     
    Where s22.Processing_ID               = @GUIDIN
      and s22.Skip_loading_due_to_error_f = 0;	
	EXEC [dbo].[PARWP_DA_DEL_TYP_COPY_FROM_GCS]     @CCTSS_K, @T08_CCTSS_DSGN_SUPL, @CDSID, @TIME_STAMP;

	EXEC [dbo].[PARWP_CCS_UPDT_LAST_IMPT]   @GUIDIN, @CDSID, @PROCESSING_STATUS

	-- POST LOAD VALIDATION CHECK
	EXEC [dbo].[PARWP_CCS_VALIDT_SUMMARY_CST_POST] @GUIDIN,@CCTSS_K,@V_Threshold_A ,@Error OUTPUT,@Calculated_Value OUTPUT,@Staging_Value OUTPUT,@File_Name OUTPUT,@Ref_K OUTPUT
    IF @Error != ''  --Check if the post load summary validation generated an error 
		Set @result = '***Post Load Error: Arrow calculated Total $' +CAST(@Calculated_Value as varchar(50)) +' using data loaded into base tables did not equal to Total on Summary sheet $'+CAST(@Staging_Value as varchar(50)) +' for Processing ID '+@GUIDIN ;    
--		Set @result = '***Post Load Error: Arrow calculated Total $' + '0' + ' using data loaded into base tables did not equal to Total on Summary sheet $'+ '0'  +' for Processing ID '+@GUIDIN ;

--++++++++++++++++++++++++++++++++++++++++++++++++
-- Start D table load for Calculations
--++++++++++++++++++++++++++++++++++++++++++++++++

	Set @AtLeast1_file_loaded = (Select Count(*) 
	                               From PARWS22_CCS_COVER_PAGE_INFO S22 
							      Where S22.Processing_ID               = @GUIDIN
								    and S22.Skip_loading_due_to_error_f = 0
							    );
	If IsNULL(@AtLeast1_file_loaded,0) > 0
       BEGIN
          exec [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
               @U01_k                = @CCTSS_K
             , @U06_k                = -1
             , @U04_k                = -1
             , @CDSID                = @CDSID
             , @TRIGGER              = 'GCS IMPORT'
             , @Primary_output_error = @Primary_output_error OUTPUT
          ;          
          If @Primary_output_error = ''
             Begin
                COMMIT TRANSACTION
                If @result = ''
				     Set @result = 'SUCCESS';
				Else Set @result = @result;  --Didn't need the ELSE but wanted to show there would be a POST load calculation error at this point
             End
          Else
             Begin
                Rollback
				If @result = ''
                     Set @result = 'Master Load Primary Error: ' + @Primary_output_error;
				Else Set @result = SUBSTRING(CONCAT('Master Load Primary Error: ', @Primary_output_error, ' ', @result),1,5000);  
             End
       End
	ELSE
	   BEGIN
          Set @result = 'SUCCESS'; --All files in the batch had a validation error. There should be no data to commit at this point but we should have something to match the begin transaction.
          COMMIT TRANSACTION;
	   End

 END TRY

 --CATCH
 BEGIN CATCH
   Rollback;

   Set @result = 'CCS_MASTER SYSTEM ERROR: ' +              
	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
				 ' |Processing Id: ' + @GUIDIN +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
--	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);

   SET @PROCESSING_STATUS = 'Processing_Error';

   INSERT INTO PARWE02_BATCH_ERRORS
   SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUIDIN                           --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
        ,NULL 
		,NULL
		--ARWE02_BATCH_ERRORS_K (Identity key)
		,'ERROR'
		,'CCS MASTER PROCEDURE'
		,0                                 --row_idx
		,''                                --Part_index
		,''                                --Arrow value		
   ;
 END CATCH;	

 -- RETURN @result 
END; --PBOM IF
END; --Procedure Begin

GO
