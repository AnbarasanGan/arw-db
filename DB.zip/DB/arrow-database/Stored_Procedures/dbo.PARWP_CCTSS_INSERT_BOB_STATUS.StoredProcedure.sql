DROP PROCEDURE [dbo].[PARWP_CCTSS_INSERT_BOB_STATUS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Asolosky
-- Create date: 03/20/2020
-- Description:	Procedure to Create a new BoB status.  A BoB status can be updated multiple time so a history must be kept.
--              Each time the BoB status is changed, a new record is written. 
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_CCTSS_INSERT_BOB_STATUS]

@CCTSS_K    INT,            -- Pass in BoB key (ARWU01_CCTSS_K)
@CDSID      VARCHAR(20),    -- Needs to be passed for the user that is triggering the update.
@TIME_STAMP DATETIME,       -- GETUTCDATE();
@ARWA11_K   INT,            -- Status Key(ARWA11_CCTSS_STAT_K_ that relates to the status name, ie: Invalid, Draft, Published ...
@Comment    VARCHAR(1024)   -- Needs to be passed as to why the BoB Status is going to be changed
                            --  Example: DA Manage Adjustment, Supplier Exchange rate update, PBOM update

AS

Insert INTO PARWU02_CCTSS_STAT_UPDT
Select --ARWU02_CCTSS_STAT_UPDT_K    -->There is an identity assigned to the Primary Key
       @CCTSS_K     as ARWU01_CCTSS_K
	  ,@TIME_STAMP  as ARWU02_CCTSS_STAT_EFF_Y
	  ,@ARWA11_K    as ARWA11_CCTSS_STAT_K
	  ,@CDSID       as ARWU02_CCTSS_STAT_UPDT_USER_C
	  ,@COMMENT     as ARWU02_CCTSS_STAT_UPDT_CMT_X
      ,@TIME_STAMP  as [ARWU02_CREATE_S]
	  ,@CDSID       as [ARWU02_CREATE_USER_C]
	  ,@TIME_STAMP  as [ARWU02_LAST_UPDT_S]
	  ,@CDSID       as ARWU02_LAST_UPDT_USER_C
;
GO
