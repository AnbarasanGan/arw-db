SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Asolosky
-- Create date: 8/04/2021
-- User Story:  
-- Description:	Validate the Excel Summary Sheet
-- =============================================
-- Changes
-- =============================================
--                        
-- Date       Author   Story     Description
-- -----      ------   --------- -----------
-- 2021-08-27 Asolosky US2825866 The validation on Total and Sub Total was missing a join on supplier name which caused errors 
--                               when multiple files with the same design but different suppliers where imported. 
-- 2022-08-11 Asolosky US3928682 Changed the rounds to use the @Threshold to be less restrictive to errors.
-- =============================================

CREATE OR ALTER PROCEDURE [dbo].[PARWP_CCS_VALIDT_EXCEL_SUMMARY] 
 @GUID           VARCHAR(5000) 
,@CDSID          VARCHAR(30)
,@TIME_STAMP     DATETIME
,@ARWU01_CCTSS_K INT
,@V_Threshold_A  DECIMAL(38,18)

AS
BEGIN TRY
SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
-- part_cluster_type = 'Total' found more than once
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
   SELECT Source_c
	     ,'Total'        as  ARWE02_ERROR_VALUE
	     ,'Total (Column B) was Found more than once. Its a Template defined value and can only be found once on the Summary Sheet'
	     ,Processing_ID
	     ,filename
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,0              as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS21_CCS_SUMMARY_TAB_INFO'
		 ,'ERROR'        as ARWE02_ERROR_TYPE_X
		 ,'SUMMARY'      as ARWE02_EXCEL_TAB_X
	     ,0              as ARWE02_ROW_IDX     
		 ,''             as ARWE02_Part_Index
		 ,''             as ARWE02_ARROW_Value
   FROM 
       (Select Source_c, Processing_ID, filename, commodity_name, supplier_name, design_name
		      ,count(*) cnt
          FROM PARWS21_CCS_SUMMARY_TAB_INFO    S21
         WHERE Processing_id = @GUID
		   and IsNULL(part_cluster_type,'#') = 'Total'
		 Group by Source_c, Processing_ID, filename, commodity_name, supplier_name, design_name
	   ) ToT_cnt
  Where cnt > 1
;

--++++++++++++++++++++++++++++++++++++
-- part_cluster_type = 'Total' not found
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
   SELECT dsgn.Source_c
	     ,''  
	     ,'Total (Column B near the bottom) was not Found. Its a Template defined value and can''t be altered.'
	     ,dsgn.Processing_ID
	     ,dsgn.filename
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,0              as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS21_CCS_SUMMARY_TAB_INFO'
		 ,'ERROR'        as ARWE02_ERROR_TYPE_X
		 ,'SUMMARY'      as ARWE02_EXCEL_TAB_X
	     ,0              as ARWE02_ROW_IDX     
		 ,''             as ARWE02_Part_Index
		 ,''             as ARWE02_ARROW_Value
   FROM 
       (--The select will return 1 record per design/supplier file imported. The result is used to Left join to the next query and see if Total is missing.
	    Select Distinct Source_c, Processing_ID, filename, commodity_name, supplier_name, design_name
          FROM PARWS21_CCS_SUMMARY_TAB_INFO    S21
         WHERE Processing_id = @GUID
       ) dsgn
   Left 
   Join
       (Select Source_c, Processing_ID, filename, commodity_name, supplier_name, design_name
          FROM PARWS21_CCS_SUMMARY_TAB_INFO    S21
         WHERE Processing_id = @GUID
		   and IsNULL(part_cluster_type,'#') = 'Total'
	   ) dsgn_total
	 On dsgn_total.commodity_name = dsgn.commodity_name
	And dsgn_total.supplier_name  = dsgn.supplier_name
	And dsgn_total.design_name    = dsgn.design_name
  Where dsgn_total.Design_name is NULL
;


--++++++++++++++++++++++++++++++++++++
-- cost_item validation
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
   SELECT Source_c
	     ,cost_item  
	     ,'The cost item (Column C) was changed for Part Cluster = ' + IsNull(part_cluster_type,'Unknown part cluster') + '. Its a Template defined value and can''t be altered. Here are the expected values: ' +
		  '1. Purchased parts, 2. Raw materials, 3. Processing, 4. Assembly, 5. Manufacturing markups, ' +
		  'Sub Total, 1. Final assembly, 2. Final assembly markups, Total commodity price'
	     ,Processing_ID
	     ,filename
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,ARWS21_CCS_SUMMARY_K
	     ,'PARWS21_CCS_SUMMARY_TAB_INFO'
		 ,'ERROR'        as ARWE02_ERROR_TYPE_X
		 ,'SUMMARY'      as ARWE02_EXCEL_TAB_X
	     ,0              as ARWE02_ROW_IDX     
		 ,''             as ARWE02_Part_Index
		 ,''             as ARWE02_ARROW_Value
   FROM 
        PARWS21_CCS_SUMMARY_TAB_INFO
  WHERE Processing_ID       = @GUID
    and IsNULL(part_cluster_type,'#') != 'ED&T and Tooling'
    and cost_item NOT IN ('1. Purchased parts', '2. Raw materials', '3. Processing', '4. Assembly', '5. Manufacturing markups',
                          'Sub Total','1. Final assembly','2. Final assembly markups', 'Total commodity price')
;

--++++++++++++++++++++++++++++++++++++
-- part_cluster_type: sub assembly name not found in U17
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
   SELECT Source_c
	     ,part_cluster_type  as  ARWE02_ERROR_VALUE
	     ,'The Part Cluster (Column B) did not match a sub assembly. ' +
		  'First, open the Excel file and be sure to click on the Enable button. This fires off the Macros and populates the sub assemblies. ' + 
		  'Second, the Part Cluster (Column B) formulas may have been changed. Be sure the formulas match the Excel Template'
	     ,Processing_ID
	     ,filename
	     ,OBJECT_NAME(@@PROCID)	  
	     ,@TIME_STAMP  
	     ,@CDSID 
	     ,@TIME_STAMP  
	     ,@CDSID
	     ,0              as ARWE02_BATCH_ERRORS_REF_K
	     ,'PARWS21_CCS_SUMMARY_TAB_INFO'
		 ,'ERROR'        as ARWE02_ERROR_TYPE_X
		 ,'SUMMARY'      as ARWE02_EXCEL_TAB_X
	     ,0              as ARWE02_ROW_IDX     
		 ,''             as ARWE02_Part_Index
		 ,''             as ARWE02_ARROW_Value
   FROM 
       (Select Source_c, Processing_ID, filename, commodity_name, supplier_name, design_name, part_cluster_type
          FROM PARWS21_CCS_SUMMARY_TAB_INFO    S21
         WHERE Processing_id = @GUID
		   and IsNull(cost_item,'#@$') in ('1. Purchased parts', '2. Raw materials', '3. Processing', '4. Assembly', '5. Manufacturing markups')
		   and cost != 0.00  --The Excel summary has all Sub-Assemblies[A-Y] but not all of them will be in the PBOM. Only check the ones with cost amounts
		 Group by Source_c, Processing_ID, filename, commodity_name, supplier_name, design_name, part_cluster_type
	   ) Sub_Assy
    Left Join PARWU17_BOM_SUB_ASSY U17 
	  ON U17.ARWU01_CCTSS_K        = @ARWU01_CCTSS_K
	 And U17.ARWU17_BOM_SUB_ASSY_N = part_cluster_type
   Where U17.ARWU17_BOM_SUB_ASSY_N is NULL
;

--++++++++++++++++++++++++++++++++++++
-- Sub Total Validation
--++++++++++++++++++++++++++++++++++++
--#SubTotal will have a temp table with all the sub totals
--Sub-Totals in the Excel file are missing the part_cluster_type (Sub-Assembly name). So this query will use the LAG function to get them 

--DROP TABLE IF EXISTS #SubTotal
CREATE TABLE #SubTotal
( 
 design_name       VARCHAR(MAX)
,supplier_name     VARCHAR(MAX)
,part_cluster_type VARCHAR(MAX)
,Cost_item         VARCHAR(MAX)
,Cost              DECIMAL(38,19)
)
INSERT INTO #SubTotal
Select design_name
      ,supplier_name
      ,IsNull(part_cluster_type, prev_part_cluster) as part_cluster_type
	  ,cost_item
      ,Cost
  From
      (
       select design_name, supplier_name, part_cluster_type, Cost_item, cost
             ,lag(part_cluster_type) over (order by arwS21_ccs_summary_k) as prev_part_cluster --Lag will get the part_cluster_type (Sub-Assembly) on the previous row
         from PARWS21_CCS_SUMMARY_TAB_INFO
        Where Processing_ID           = @GUID
      ) GET_SUB_ASY
 Where Cost_item in ('Sub Total', 'Total commodity price')
 ;
-- select * from #SubTotal
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT S21.Source_c
      ,Cast(SUBT.Cost as Varchar)  as  ARWE02_ERROR_VALUE
      ,'The Excel Sub Total amount for ' + S21.part_cluster_type + ', did not match the actual sum of the columns. Please check the Sub Total formula so that it matches the Template formula'
      ,S21.Processing_ID
      ,S21.filename
      ,OBJECT_NAME(@@PROCID)	  
      ,@TIME_STAMP  
      ,@CDSID 
      ,@TIME_STAMP  
      ,@CDSID
      ,0                               as ARWE02_BATCH_ERRORS_REF_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,'ERROR'                         as ARWE02_ERROR_TYPE_X
      ,'SUMMARY'                       as ARWE02_EXCEL_TAB_X
      ,0                               as ARWE02_ROW_IDX     
      ,''                              as ARWE02_Part_Index
      ,Cast(S21.S21_SUM_Cost as Varchar) as ARWE02_ARROW_Value
  From
      (
       Select design_name, supplier_name, part_cluster_type, Source_c, Processing_ID, filename
             ,Sum(Cost) as S21_SUM_Cost
        From PARWS21_CCS_SUMMARY_TAB_INFO 
       Where Processing_ID = @GUID
       Group by design_name, supplier_name, part_cluster_type, Source_c, Processing_ID, filename
      ) S21
  Join #SubTotal  SUBT
    On SUBT.design_name       = S21.design_name
   And SUBT.supplier_name     = S21.supplier_name
   And SUBT.part_cluster_type = S21.part_cluster_type
 Where ABS(SUBT.Cost) not between ABS(S21.S21_SUM_Cost) - @V_Threshold_A  --Lower Bound
                              and ABS(S21.S21_SUM_Cost) + @V_Threshold_A  --Upper Bound
 ;

--++++++++++++++++++++++++++++++++++++
-- Total Validation
--++++++++++++++++++++++++++++++++++++
-- select * from #SubTotal
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT S21.Source_c
      ,Cast(SUBT.Cost as Varchar) as  ARWE02_ERROR_VALUE
      ,'The Excel Total amount did not match the actual sum of the columns. Please check the Summary Total formula so that it matches the Template formula'
      ,S21.Processing_ID
      ,S21.filename
      ,OBJECT_NAME(@@PROCID)	  
      ,@TIME_STAMP  
      ,@CDSID 
      ,@TIME_STAMP  
      ,@CDSID
      ,0                               as ARWE02_BATCH_ERRORS_REF_K
      ,'PARWS21_CCS_SUMMARY_TAB_INFO'
      ,'ERROR'                         as ARWE02_ERROR_TYPE_X
      ,'SUMMARY'                       as ARWE02_EXCEL_TAB_X
      ,0                               as ARWE02_ROW_IDX     
      ,''                              as ARWE02_Part_Index
      ,Cast(S21.S21_SUM_Cost as Varchar) as ARWE02_ARROW_Value
  From
      (
       Select design_name, supplier_name, Source_c, Processing_ID, filename
             ,Sum(Cost) as S21_SUM_Cost
        From PARWS21_CCS_SUMMARY_TAB_INFO 
       Where Processing_ID = @GUID
	     and cost_item = 'Sub Total'
       Group by design_name, supplier_name, Source_c, Processing_ID, filename
      ) S21
  Join #SubTotal  SUBT
    On SUBT.design_name    = S21.design_name
   And SUBT.supplier_name  = S21.supplier_name
   And SUBT.cost_item      = 'Total commodity price'
 Where ABS(SUBT.Cost) not between ABS(S21.S21_SUM_Cost) - @V_Threshold_A  --Lower Bound
                              and ABS(S21.S21_SUM_Cost) + @V_Threshold_A  --Upper Bound
;

DROP TABLE IF EXISTS #SubTotal;

END TRY

BEGIN CATCH
DROP TABLE IF EXISTS #SubTotal;

INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''                                --ARWE02_BATCH_ERRORS_REF_K
			 ,'PARWS21_CCS_SUMMARY_TAB_INFO'    --ARWE02_STAGING_TABLE_X
		     --ARWE02_BATCH_ERRORS_K Identity key 
			 ,'ERROR'                           --ARWE02_ERROR_TYPE_X
			 ,'SYSTEM'                          --ARWE02_EXCEL_TAB_X
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;
GO
