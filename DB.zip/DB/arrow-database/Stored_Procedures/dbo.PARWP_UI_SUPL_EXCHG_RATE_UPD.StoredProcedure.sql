SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Asolosky
-- Create date: 03/20/2020
-- Description:	Procedure to call supplier exchange rate update from the UI.
--              This takes the summary procedures from the CCS/GCS, DAII and VA import and
--              consolidates them so the UI can make one call for an update.           
-- =============================================
-- Changes
-- =============================================
-- Author     Date      User Story  Description
-- ------     -----     ----------  -----------
-- Asolosky  09/04/2020 US1859270   Remove PARWP_LOAD_U28_DMMY_SUB_ASSY_MRKUP as it is not needed anymore
-- Asolosky  01/07/2021 US1859270   Added new logic (PARWP_CALC_MASTER_LOAD_PRIMARY) for populating the Calc tables
-- btemkow   2022-04-06 US3501484   updated status names
-- Asolosky  01/07/2021 US3612606   All the DAII summary procedures are now in PARWP_DAIICT_SUMMARY
-- Ashaik12  07/27/2022 US3876656   Add VA II summary table delete SP and load SP
-- =============================================

CREATE or ALTER PROCEDURE [dbo].[PARWP_UI_SUPL_EXCHG_RATE_UPD] 
@CCTSS_K int, 
@CDSID   varchar(8),
@err_msg varchar(max) Output


AS
Begin
 SET NOCOUNT ON;
 DECLARE @TIME_STAMP            DATETIME = GETUTCDATE();
 DECLARE @ARWA11_k              INT;
 DECLARE @Comment               VARCHAR(1024) = 'Supplier Exchange Rate Update';
 DECLARE @Primary_output_error  VARCHAR(5000);
 DECLARE @u01_Study             Varchar(100);
 Set @err_msg = '';
 
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));

 BEGIN TRY
 Set @u01_Study = (Select U01.ARWU31_CTSP_N    + ' ' +
                          U01.ARWA06_RGN_C     + ' ' +
                   	      substring(u01.ARWA03_ENRG_SUB_CMMDTY_X,1,25)  + ' ' +
                   	      substring(u01.ARWU01_BNCHMK_VRNT_N,1,25)
                     from PARWU01_CCTSS_FLAT  U01
                    where U01.ARWU01_CCTSS_K = @CCTSS_K
 				  );

 Select @ARWA11_k = ARWA11_CCTSS_STAT_K
   From PARWA11_CCTSS_STAT
  Where ARWA11_CCTSS_STAT_N = 'To be Reconciled'
   
 BEGIN TRANSACTION; --The following procedures don't have Try and Catch in them and any error will be caught here in the master

-- CCS/GCS Consolidation
    EXEC [dbo].[PARWP_CST_CONSL_DELETE_SUM_TBLS]    @CCTSS_K;

	EXEC [dbo].[PARWP_CCT_LOAD_PURCHPART]           @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U56_SUPL_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_UPD_U06_DSGN_FNLASSY]     @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U08_FINAL_ASSY]      @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_UPD_U08_SUPL_QTE_A]       @CCTSS_K, @CDSID, @TIME_STAMP;
	EXEC [dbo].[PARWP_CCT_LOAD_U57_DSGN_SUB_ASSY]   @CCTSS_K, @CDSID, @TIME_STAMP;

-- DAII Consolidation - Performs DAII_CONSL_DELETE_SUM_TBLS and U57, U73, U74 summary loads
-- There is no commit or catch in PARWP_DAIICT_SUMMARY
    EXEC [dbo].[PARWP_DAIICT_SUMMARY]              @CCTSS_K, @CDSID, @TIME_STAMP;	      
	 
-- Variant Consolidation
    EXEC [dbo].[PARWP_VA_CONSL_DELETE_SUM_TBLS]    @CCTSS_K;

	 EXEC [dbo].[PARWP_VACT_LOAD_U81_SUPL_VRNT_ADJ] @CCTSS_K, @CDSID, @TIME_STAMP;

-- VA II 
	EXEC [dbo].[PARWP_VAII_CONSL_DELETE_SUM_TBLS]  @CCTSS_K;
	EXEC [dbo].[PARWP_VAIICT_LOAD_UD9_SUPL_DSGN_IMPRV] @CCTSS_K, @CDSID, @TIME_STAMP;

-- Set BoB status to Invalid
    EXEC  [dbo].[PARWP_CCTSS_INSERT_BOB_STATUS]    @CCTSS_K, @CDSID, @TIME_STAMP, @ARWA11_k, @Comment;

	--select 1/0;

    EXEC [dbo].[PARWP_CALC_MASTER_LOAD_PRIMARY] 
         @U01_k                = @CCTSS_K
       , @U06_k                = -1
       , @U04_k                = -1
       , @CDSID                = @CDSID
       , @TRIGGER              = 'SUPPLIER EXCHANGE RATE CHANGE'
       , @Primary_output_error = @Primary_output_error OUTPUT
    ;          
    If @Primary_output_error = ''
       Begin
         COMMIT TRANSACTION
         Set @err_msg = 'SUCCESS';
       End
    Else
       Begin
         Rollback
         Set @err_msg = 'Master Load Primary Error: ' + @Primary_output_error;
       End
    --End of: If @Primary_output_error
	  
 END TRY

 --CATCH
 BEGIN CATCH
  Rollback;
  Set @err_msg = 'SUPPLIER EXCHANGE RATE CHANGE SYSTEM ERROR: ' +              
	             'Study Key: '       + cast(@CCTSS_K as varchar(20)) + 
	             ' |Study: '         + ISNULL(@u01_Study, '') +
	             ' |GMT Date/Time: ' + CONVERT(varchar, @TIME_STAMP, 120) +
--	             ' |EST: '           + @TIME_STAMP AT TIME ZONE 'UTC' AT TIME ZONE 'Eastern Standard Time' +
	             ' |CDS: '           + @CDSID +
	             ' |Procedure: '     + ERROR_PROCEDURE() + 
				 ' |Line: '          + cast(ERROR_LINE() as varchar(50)) +
				 ' |Message: '       + Substring(ERROR_MESSAGE(),1,4500);
-- Removed INSERT INTO PARWE01_BATCH_ERRORS and replaced it by returning @err_msg to the UI	
 END CATCH;	
End;
GO
