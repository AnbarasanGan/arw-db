DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_FORD]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		btemkow
-- Create date: 2020-02-13
-- Description:	validates Improvement Ideas tab
--              during DAII import for 'PBOM and 
--               DA UI' version BoBs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- btemkow    02-17-2020  Renamed procedure to 
--                        indicate this validates
--                        Ford-orginated only
-- =============================================
-- 07/29/2020  Asolosky  US1771016  used the replace function to display a line feed
-- 09/11/2020  Asolosky  US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================
--DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_FORD] 

CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_DSGN_IMPRV_FORD] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Ford Improvement ID in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S44.Source_c
		,Case when S44.improvement_id = '' Then '<Blank>' Else replace(replace(S44.improvement_id,char(10),'<LF>'),char(13),'<CR>') end 
		,'Improvement ID does not match an Improvement Idea in Arrow.' 
		,S44.Processing_ID
		,S44.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S44.row_idx
		,Case when S44.improvement_id = '' Then '<Blank>' Else replace(replace(S44.improvement_id,char(10),'<LF>'),char(13),'<CR>') end 
		,''  --No ARROW Value
	FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S44.Processing_ID = S34.Processing_ID
		AND S44.filename = S34.filename
		AND S44.originator = 'Ford'
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	LEFT JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U46.ARWU06_CCTSS_DSGN_K
		AND S44.improvement_id + '#Ford' = U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N
	WHERE S44.Processing_ID = @GUID 
		AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N IS NULL

	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Ford Improvement ID in Arrow does not match file
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT
		 S34.Source_c
		,''  
		,'Improvement Idea in Arrow does not appear in the Improvement Ideas tab.' 
		,S34.Processing_ID
		,S34.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,0
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,0
		,''  --part index
		,replace(replace(U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N,char(10),'<LF>'),char(13),'<CR>') --ARROW Value
	FROM PARWS34_DAII_COVER_PAGE_INFO AS S34 
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U46.ARWU06_CCTSS_DSGN_K
		AND U46.ARWU46_CCTSS_DSGN_IMPRV_ORIG_X = 'Ford'
	LEFT JOIN PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
		ON S34.Processing_ID = S44.Processing_ID
		AND S34.filename = S44.filename
		AND U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N = S44.improvement_id + '#Ford'
	WHERE S34.Processing_ID = @GUID 
		AND S44.improvement_id IS NULL

	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Index in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S44.Source_c
		,replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')
		,'Part Index does not match the Part Index in ARROW'
		,S44.Processing_ID
		,S44.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S44.row_idx
		,U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N  --part index/improvement id
		,U18.ARWU18_BOM_PART_IX_N          --ARROW Value
	FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S44.Processing_ID = S34.Processing_ID
		AND S44.filename = S34.filename
		AND S44.originator = 'Ford'
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U46.ARWU06_CCTSS_DSGN_K
		AND S44.improvement_id + '#Ford' = U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N
	JOIN PARWU18_BOM_PART AS U18
		ON U46.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K
	WHERE S44.Processing_ID = @GUID 
		AND S44.part_index <> U18.ARWU18_BOM_PART_IX_N

	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Name in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S44.Source_c
		,Case when part_name = '' Then '<Blank>' Else replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>') end 
		,'Part Name does not match ARROW Part Name' 
		,S44.Processing_ID
		,S44.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S44.row_idx
		,S44.improvement_id  --part index/improvement id
		,Case when U18.ARWU18_BOM_PART_X = '' Then '<Blank>' Else U18.ARWU18_BOM_PART_X  End    --ARROW Value
	FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S44.Processing_ID = S34.Processing_ID
		AND S44.filename = S34.filename
		AND S44.originator = 'Ford'
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U46.ARWU06_CCTSS_DSGN_K
		AND S44.improvement_id + '#Ford' = U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N
	JOIN PARWU18_BOM_PART AS U18
		ON U46.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K
	WHERE S44.Processing_ID = @GUID 
		AND S44.part_name <> U18.ARWU18_BOM_PART_X

	--+++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Idea Description in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S44.Source_c
		,replace(replace(S44.idea_description,char(10),'<LF>'),char(13),'<CR>')
		,'Idea Description does not match ARROW Idea Description.' 
		,S44.Processing_ID
		,S44.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S44.row_idx
		,U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N     --part index/improvement id
		,U46.ARWU46_CCTSS_DSGN_IMPRV_IDEA_X   --ARROW Value
	FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S44.Processing_ID = S34.Processing_ID
		AND S44.filename = S34.filename
		AND S44.originator = 'Ford'
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U46.ARWU06_CCTSS_DSGN_K
		AND S44.improvement_id + '#Ford' = U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N
	WHERE S44.Processing_ID = @GUID 
		AND S44.idea_description <> U46.ARWU46_CCTSS_DSGN_IMPRV_IDEA_X


	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- WARNING: Tough Choice Grouping in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
/*
	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		  S44.Source_c
		 ,S44.improvement_idea_grouping
		,'Tough Choice Grouping: ' + S44.improvement_idea_grouping + ' does not match Tradeoff: ' 
			+ U85.ARWU85_CCTSS_TRDOFF_X + ' for Change ID: ' + U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N + ' in Arrow.' 
		,S44.Processing_ID
		,S44.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S44.ARWS44_DAII_IMPROVEMENT_IDEA_K
		,'PARWS44_DAII_IMPROVEMENT_IDEAS_INFO'
		,'WARNING'
		,'Improvement Ideas'
		,S44.row_idx
	FROM PARWS44_DAII_IMPROVEMENT_IDEAS_INFO AS S44
	JOIN PARWS34_DAII_COVER_PAGE_INFO AS S34 
		ON S44.Processing_ID = S34.Processing_ID
		AND S44.filename = S34.filename
	JOIN PARWU06_CCTSS_DSGN_FLAT AS U06_FLAT    
		ON S34.User_Selected_CTSP_N = U06_FLAT.ARWU31_CTSP_N
		AND S34.User_Selected_CTSP_Region_C = U06_FLAT.ARWA06_RGN_C
		AND S34.User_Selected_ENRG_SUB_CMMDTY_X = U06_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S34.User_Selected_BNCMK_VRNT_N = U06_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S34.User_Selected_VEH_MAKE_N = U06_FLAT.ARWA14_VEH_MAKE_N
		AND S34.User_Selected_VEH_MDL_N = U06_FLAT.ARWA34_VEH_MDL_N
		AND S34.User_Selected_VEH_MDL_VRNT_X = U06_FLAT.ARWA35_DSGN_VEH_MDL_VRNT_X
		AND S34.User_Selected_VEH_MDL_YR_C = U06_Flat.ARWA35_DSGN_VEH_MDL_YR_C
	JOIN PARWU46_CCTSS_DSGN_IMPRV AS U46
		ON U06_FLAT.ARWU06_CCTSS_DSGN_K = U46.ARWU06_CCTSS_DSGN_K
		AND S44.improvement_id + '#Ford' = U46.ARWU46_CCTSS_DSGN_IMPRV_ID_N
	JOIN PARWU87_DSGN_IMPRV_TRDOFF AS U87
		ON U46.ARWU46_CCTSS_DSGN_IMPRV_K = U87.ARWU46_CCTSS_DSGN_IMPRV_K
	JOIN PARWU85_CCTSS_TRDOFF AS U85
		ON U87.ARWU85_CCTSS_TRDOFF_K = U85.ARWU85_CCTSS_TRDOFF_K
	WHERE S44.Processing_ID = @GUID 
		AND S44.improvement_idea_grouping <> U85.ARWU85_CCTSS_TRDOFF_X
*/

END TRY

BEGIN CATCH
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,'' 
			 ,'PARWS34_DAII_COVER_PAGE_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH
GO
