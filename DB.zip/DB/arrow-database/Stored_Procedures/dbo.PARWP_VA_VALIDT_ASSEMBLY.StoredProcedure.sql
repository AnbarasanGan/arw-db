SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		rwesley2
-- Create date: 7/22/2019
-- Description:	validate Variant Adjustment Costs: assembly
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2  09/09/19     Added calculated field validations
-- asamriya  09/10/2019   Added row_idx
-- rwesley2  09/13/2019  added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	
-- ashaik12  10/17/2019   Changed filter on part description validations to match Sheet name as sub_assembly_name
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- ashaik12  12/25/2019   Removed Case when statements in Error Desc as we have tab name in display on UI.
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- asolosky  07/24/2020   US1771016 used the replace function for change_id and part_name to display a line feed
-- Ashaik12  09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  04/12/2021   US2430172 Added validation for Cost sheet exchange rate
-- Asolosky  10/08/2021   US2954027 Added numeric validation on capital_exp_for_machine and machine_size
-- ASHAIK12  06/28/2022   US3778477 Add new validations for Variant Improvement Ideas
-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VA_VALIDT_ASSEMBLY] 

@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@threshold Decimal(5,3)
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
-- Change ID validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>') 
      ,'Assembly - Change ID not found in Adjustment Details ' + replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')   AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.[ARWS53_VA_ASSEMBLY_PARTS_K]
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name 
	  ,Err.row_idx 
	  ,change_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          change_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS53_VA_ASSEMBLY_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO]  s53
        WHERE Processing_ID= @GUID
	and s53.cost_type='Adjustment Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
               where s53.[change_id] = s46.change_id
				 and s53.[filename] = s46.[filename]
				 and s53.Processing_ID = s46.Processing_ID

)
                    
       ) Err

    ;
  
-- New validation for improvement ideas
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>')
      ,'Improvement Costs for Assembly - Improvement ID not found in Improvement Ideas tab'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,Err.ARWS53_VA_ASSEMBLY_PARTS_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx 
	  ,change_id
	  ,''  --No ARROW Value	   
   FROM 
       (
        SELECT 
		  Processing_ID,
          change_id,
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS53_VA_ASSEMBLY_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].PARWS53_VA_ASSEMBLY_PARTS_INFO  s53
        WHERE Processing_ID= @GUID
			and s53.cost_type='Improvement Costs'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s53.[change_id] =   s67.improvement_id
				 and s53.[filename] =    s67.[filename]
				 and s53.Processing_ID = s67.Processing_ID
				 

)
                    
       ) Err

    ;
--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Change ID Part Description Validation 
--++++++++++++++++++++++++++++++++++++++++++++++++++
   Insert Into  [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[Source_c] 
	  ,replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>') + ' : ' + replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  
      ,'Assembly - Part Description does not match Adjustment Detail Part Name: ' + replace(replace(change_id,char(10),'<LF>'),char(13),'<CR>') + ' : ' 
	      + replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.[ARWS53_VA_ASSEMBLY_PARTS_K]
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'    
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [change_id],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS53_VA_ASSEMBLY_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM  [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO] s53
        WHERE Processing_ID= @GUID
	and s53.cost_type='Adjustment Costs'
	     	and s53.sub_assembly_name <> 'Adjustment Final Assembly'
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS46_VA_ADJUSTMENT_DETAILS_INFO] s46
               where s53.[change_id] = s46.change_id
			     and s53.[part_description] = s46.[part_name]
				 and s53.[filename] = s46.[filename]
				 and s53.Processing_ID = s46.Processing_ID

)
                    
       ) Err
;

-- New validation for improvement ideas
Insert Into  [dbo].[PARWE02_BATCH_ERRORS]
    SELECT
	   Err.[Source_c] 
	  ,replace(replace(part_description,char(10),'<LF>'),char(13),'<CR>')  
      ,'Improvement Costs for Assembly - Part Name does not match Improvement Ideas Part Name'  AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.ARWS53_VA_ASSEMBLY_PARTS_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'     
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_id
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [change_id],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          ARWS53_VA_ASSEMBLY_PARTS_K,
		  sub_assembly_name,
		  row_idx
        FROM [dbo].PARWS53_VA_ASSEMBLY_PARTS_INFO  s53
        WHERE Processing_ID= @GUID
			and s53.cost_type='Improvement Costs'
	     	and s53.sub_assembly_name <> 'Improvement Final Assembly'
	   and Not Exists
		      (Select 'X'
               from  [dbo].PARWS67_VA_IMPROVEMENT_IDEAS_INFO s67
               where s53.[change_id] =        s67.improvement_id
			     and s53.[part_description] = s67.[part_name]
				 and s53.[filename] =         s67.[filename]
				 and s53.Processing_ID =      s67.Processing_ID
              )                   
       ) Err
;
--++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.local_currency                    as ARWE02_ERROR_VALUE
	  ,'Assembly - Invalid Assembly Currency Code: ' +  ERR.local_currency   as ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS53_VA_ASSEMBLY_PARTS_K]     as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_id
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               local_currency,
		       Processing_Status_x,
		       Source_c,
		       filename,
               ARWS53_VA_ASSEMBLY_PARTS_K,
			   row_idx,
			   change_id
          FROM [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO] S53
         WHERE Processing_ID= @GUID
	       and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where S53.[local_currency] = A29.[ARWA29_CRCY_C]
	             )	
                 
        ) Err
;
---------------------------------------------------------------------
--  START Calculated field validations
---------------------------------------------------------------------
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Machine / operation overhead costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.machine_op_overhead_costs                as ARWE02_ERROR_VALUE
	  ,'Assembly - Machine/operation overhead costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as ARWE02_ERROR_X
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS53_VA_ASSEMBLY_PARTS_K]    as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_id
	  ,'Calculated:' + CAST(ERR.Calculated_value as Varchar(50))  -- ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS53_VA_ASSEMBLY_PARTS_K],
			   [change_id],
			   machine_op_overhead_costs,
			   (assembly_secs_operation*(machinehourly_operation_overhead/3600)) as Calculated_value,
			   row_idx
         FROM [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO] s53
        WHERE Processing_ID= @GUID
	      and ABS((assembly_secs_operation*(machinehourly_operation_overhead/3600)) - (machine_op_overhead_costs)) > @threshold
        ) ERR
;
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Direct labor cost per operation [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.direct_labor_cost_op                as ARWE02_ERROR_VALUE
	  ,'Assembly - Direct labor cost per operation, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS53_VA_ASSEMBLY_PARTS_K]     as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO' as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_id
	  ,'Calculated:' + CAST(ERR.Calculated_value as Varchar(50))  -- ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS53_VA_ASSEMBLY_PARTS_K],
			   [change_id],
			   direct_labor_cost_op,
			   (assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount) as Calculated_value,
			   row_idx
         FROM [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO] s53
        WHERE Processing_ID= @GUID
	      and ABS((assembly_secs_operation*(direct_hourly_labor_headcount/3600)*direct_headcount)  - (direct_labor_cost_op)) > @threshold
        ) ERR
;
--++++++++++++++++++++++++++++++++++++
    -- Calculated Field Validation for Total labor costs [LoCur/operation]
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   ERR.Source_c                          as ARWE02_SOURCE_C
	  ,ERR.total_labor_costs                as ARWE02_ERROR_VALUE
	  ,'Assembly - Total labor costs, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,ERR.Processing_ID                     as ARWE02_PROCESSING_ID
	  ,ERR.filename                          as ARWE02_FILENAME
	  ,OBJECT_NAME(@@PROCID)                 as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP                          as ARWE02_CREATE_S
	  ,@CDSID                                as ARWE02_CREATE_USER_C
	  ,@TIME_STAMP                          as ARWE02_LAST_UPDT_S
	  ,@CDSID                                as ARWE02_LAST_UPDT_USER_C
	  ,ERR.[ARWS53_VA_ASSEMBLY_PARTS_K]    as ARWE02_BATCH_ERRORS_REF_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'    as ARWE02_STAGING_TABLE_X
	  ,'ERROR'
	  ,ERR.sub_assembly_name
	  ,Err.row_idx
	  ,change_id
	  ,'Calculated:' + CAST(ERR.Calculated_value as Varchar(50))  -- ARROW Value
       FROM 
       (
        SELECT 
               Processing_ID,
			   sub_assembly_name,
               operation_location,
		       Processing_Status_x,
		       Source_c,
		       filename,
               [ARWS53_VA_ASSEMBLY_PARTS_K],
			   [change_id],
			   total_labor_costs,
			   (((assembly_secs_operation*(direct_hourly_labor_headcount/3600))*direct_headcount)*(1+[indirect_labor_costs])*(1+[fringes])) as Calculated_value,
			   row_idx
         FROM [dbo].[PARWS53_VA_ASSEMBLY_PARTS_INFO] s53
        WHERE Processing_ID= @GUID
	      and ABS((((assembly_secs_operation*(direct_hourly_labor_headcount/3600))*direct_headcount)*(1+[indirect_labor_costs])*(1+[fringes])) - (total_labor_costs)) > @threshold
        ) ERR
;
---------------------------------------------------------------------
--  END Calculated field validations
---------------------------------------------------------------------

--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Assembly: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.ARWS53_VA_ASSEMBLY_PARTS_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.change_id 
	  ,'' 
  FROM 
      (
        SELECT 
               S53.Processing_ID
              ,s53.exchange_rate
  		      ,s53.Source_c
  		      ,s53.filename
              ,s53.ARWS53_VA_ASSEMBLY_PARTS_K
  		      ,s53.sub_assembly_name
  		      ,s53.change_id
			  ,s53.row_idx
			  ,S57.usd_per_local_currency
			  ,S57.supplier_picked_crcy_c
          FROM PARWS53_VA_ASSEMBLY_PARTS_INFO  S53 
		  Join PARWS57_VA_EXCHANGE_RATE_TAB    S57
		    On S57.Processing_ID  = S53.Processing_ID
		   And S57.filename       = S53.filename
		   And S57.currency_code  = S53.local_currency
         WHERE S53.Processing_ID  = @GUID
		   and S53.exchange_rate != S57.usd_per_local_currency
      ) Err
;

--Numeric check on capital_exp_for_machine
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,capital_exp_for_machine
      ,'Assembly: Capital Expenditure for machine has to be a number or you can leave it empty.' as [ARWE02_ERROR_X]
	  ,Processing_ID
	  ,filename 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,ARWS53_VA_ASSEMBLY_PARTS_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'
	  ,'ERROR'
	  ,sub_assembly_name
	  ,row_idx                 as ARWE02_ROW_IDX
	  ,change_id 
	  ,'' 
  FROM PARWS53_VA_ASSEMBLY_PARTS_INFO
 WHERE Processing_ID  = @GUID
   and dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(capital_exp_for_machine) = 0  --0 = Not Numeric, 1 = Numeric, Empty is considered Numeric (1)
;

--Numeric check on Machine Size
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,machine_size
      ,'Assembly: Machine size has to be a number or you can leave it empty.' as [ARWE02_ERROR_X]
	  ,Processing_ID
	  ,filename 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,ARWS53_VA_ASSEMBLY_PARTS_K
	  ,'PARWS53_VA_ASSEMBLY_PARTS_INFO'
	  ,'ERROR'
	  ,sub_assembly_name
	  ,row_idx                 as ARWE02_ROW_IDX
	  ,change_id 
	  ,'' 
  FROM PARWS53_VA_ASSEMBLY_PARTS_INFO
 WHERE Processing_ID  = @GUID
   and dbo.PARWF_ISNUMERIC_OR_EMPTY_VAL(machine_size) = 0  --0 = Not Numeric, 1 = Numeric, Empty is considered Numeric (1)
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@GUID                             --Processing_id
		,'UNKNOWN'                         --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''                                --ARWE02_STAGING_TABLE_X
		,'PARWS53_VA_ASSEMBLY_PARTS_INFO' --ARWE02_BATCH_ERRORS_K
		--ARWE02_BATCH_ERRORS_K Identity key
		,'ERROR'
		,'SYSTEM'
		,0                              --row_idx
		,''  --Part_index
		,''  --Arrow value	
;

END CATCH;



GO
