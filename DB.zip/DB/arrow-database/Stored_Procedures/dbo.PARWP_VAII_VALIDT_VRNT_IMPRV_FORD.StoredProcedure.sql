SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author:		ashaik12
-- Create date: 2022-06-28
-- Description:	validates Improvement Ideas tab
--              during VAII import for 'PBOM and 
--               DA UI' version BoBs
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------

-- =============================================
CREATE OR ALTER PROCEDURE [dbo].[PARWP_VAII_VALIDT_VRNT_IMPRV_FORD] 

      @GUID  varchar(5000) 
	 ,@CDSID varchar(30)
	 ,@TIME_STAMP DATETIME

AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Ford Improvement ID in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S67.Source_c
		,Case when S67.improvement_id = '' Then '<Blank>' Else replace(replace(S67.improvement_id,char(10),'<LF>'),char(13),'<CR>') end 
		,'Improvement ID does not match an Improvement Idea in Arrow.' 
		,S67.Processing_ID
		,S67.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,ARWS67_VA_IMPROVEMENT_IDEA_K
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S67.row_idx
		,Case when S67.improvement_id = '' Then '<Blank>' Else replace(replace(S67.improvement_id,char(10),'<LF>'),char(13),'<CR>') end 
		,''  --No ARROW Value
	FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO AS S67
	JOIN [dbo].[PARWS45_VA_COVER_PAGE_INFO] AS S45
		ON S67.Processing_ID = S45.Processing_ID
		AND S67.filename = S45.filename
		AND S67.originator = 'Ford'
	JOIN PARWU04_CCTSS_VRNT_FLAT AS U04_FLAT    
		ON  S45.User_Selected_CTSP_N =            U04_FLAT.ARWU31_CTSP_N
		AND S45.User_Selected_CTSP_Region_C =     U04_FLAT.ARWA06_RGN_C
		AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U04_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S45.User_Selected_BNCMK_VRNT_N =      U04_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S45.User_selected_WALK_VRNT_X =       U04_FLAT.ARWU04_VRNT_N
	LEFT JOIN PARWUD2_CCTSS_VRNT_IMPRV AS UD2
		ON U04_FLAT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
		AND S67.improvement_id= UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	WHERE S67.Processing_ID = @GUID AND
		UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N IS NULL

	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Ford Improvement ID in Arrow does not match file
	--++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT
		 S45.Source_c
		,''  
		,'Improvement Idea in Arrow does not appear in the Improvement Ideas tab.' 
		,S45.Processing_ID
		,S45.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,0
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,0
		,''  --part index
		,replace(replace(UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N,char(10),'<LF>'),char(13),'<CR>') --ARROW Value
	FROM PARWS45_VA_COVER_PAGE_INFO AS S45 
	JOIN PARWU04_CCTSS_VRNT_FLAT AS U04_FLAT    
		ON  S45.User_Selected_CTSP_N =            U04_FLAT.ARWU31_CTSP_N
		AND S45.User_Selected_CTSP_Region_C =     U04_FLAT.ARWA06_RGN_C
		AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U04_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S45.User_Selected_BNCMK_VRNT_N =      U04_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S45.User_selected_WALK_VRNT_X =       U04_FLAT.ARWU04_VRNT_N
	JOIN PARWUD2_CCTSS_VRNT_IMPRV AS UD2
		ON U04_FLAT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
		AND UD2.ARWUD2_CCTSS_VRNT_IMPRV_ORIG_X = 'Ford'
	LEFT JOIN PARWS67_VA_IMPROVEMENT_IDEAS_INFO AS S67
		ON S45.Processing_ID = S67.Processing_ID
		AND S45.filename = S67.filename
		AND UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N = S67.improvement_id
	WHERE S45.Processing_ID = @GUID 
		AND S67.improvement_id IS NULL

	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Index in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S67.Source_c
		,replace(replace(part_index,char(10),'<LF>'),char(13),'<CR>')
		,'Part Index does not match the Part Index in ARROW'
		,S67.Processing_ID
		,S67.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S67.ARWS67_VA_IMPROVEMENT_IDEA_K
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S67.row_idx
		,UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N  --part index/improvement id
		,U18.ARWU18_BOM_PART_IX_N          --ARROW Value
	FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO AS S67
	JOIN PARWS45_VA_COVER_PAGE_INFO AS S45
		ON  S67.Processing_ID = S45.Processing_ID
		AND S67.filename = S45.filename
		AND S67.originator = 'Ford'
	JOIN PARWU04_CCTSS_VRNT_FLAT AS U04_FLAT    
		ON  S45.User_Selected_CTSP_N =            U04_FLAT.ARWU31_CTSP_N
		AND S45.User_Selected_CTSP_Region_C =     U04_FLAT.ARWA06_RGN_C
		AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U04_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S45.User_Selected_BNCMK_VRNT_N =      U04_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S45.User_selected_WALK_VRNT_X =       U04_FLAT.ARWU04_VRNT_N
	JOIN PARWUD2_CCTSS_VRNT_IMPRV AS UD2
		ON U04_FLAT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
		AND S67.improvement_id= UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	JOIN PARWU18_BOM_PART AS U18
		ON UD2.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K
	WHERE   S67.Processing_ID = @GUID 
		AND S67.part_index <> U18.ARWU18_BOM_PART_IX_N

	--++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Part Name in file does not match Arrow
	--++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S67.Source_c
		,Case when part_name = '' Then '<Blank>' Else replace(replace(part_name,char(10),'<LF>'),char(13),'<CR>') end 
		,'Part Name does not match ARROW Part Name' 
		,S67.Processing_ID
		,S67.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S67.ARWS67_VA_IMPROVEMENT_IDEA_K
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S67.row_idx
		,S67.improvement_id  --part index/improvement id
		,Case when U18.ARWU18_BOM_PART_X = '' Then '<Blank>' Else U18.ARWU18_BOM_PART_X  End    --ARROW Value
	FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO AS S67
	JOIN PARWS45_VA_COVER_PAGE_INFO AS S45
		ON  S67.Processing_ID = S45.Processing_ID
		AND S67.filename = S45.filename
		AND S67.originator = 'Ford'
	JOIN PARWU04_CCTSS_VRNT_FLAT AS U04_FLAT    
		ON  S45.User_Selected_CTSP_N =            U04_FLAT.ARWU31_CTSP_N
		AND S45.User_Selected_CTSP_Region_C =     U04_FLAT.ARWA06_RGN_C
		AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U04_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S45.User_Selected_BNCMK_VRNT_N =      U04_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S45.User_selected_WALK_VRNT_X =       U04_FLAT.ARWU04_VRNT_N
	JOIN PARWUD2_CCTSS_VRNT_IMPRV AS UD2
		ON U04_FLAT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
		AND S67.improvement_id= UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	JOIN PARWU18_BOM_PART AS U18
		ON UD2.ARWU18_BOM_PART_K = U18.ARWU18_BOM_PART_K
	WHERE S67.Processing_ID = @GUID 
		AND S67.part_name <> U18.ARWU18_BOM_PART_X

	--+++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- ERROR: Idea Description in file does not match Arrow
	--+++++++++++++++++++++++++++++++++++++++++++++++++++++

	INSERT INTO PARWE02_BATCH_ERRORS
	SELECT 
		 S67.Source_c
		,replace(replace(S67.idea_description,char(10),'<LF>'),char(13),'<CR>')
		,'Idea Description does not match ARROW Idea Description.' 
		,S67.Processing_ID
		,S67.filename 
		,OBJECT_NAME(@@PROCID)	  
		,@TIME_STAMP  
		,@CDSID 
		,@TIME_STAMP  
		,@CDSID
		,S67.ARWS67_VA_IMPROVEMENT_IDEA_K
		,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
		,'ERROR'
		,'Improvement Ideas'
		,S67.row_idx
		,UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N     --part index/improvement id
		,UD2.ARWUD2_CCTSS_VRNT_IMPRV_IDEA_X   --ARROW Value
	FROM PARWS67_VA_IMPROVEMENT_IDEAS_INFO AS S67
	JOIN PARWS45_VA_COVER_PAGE_INFO AS S45
		ON  S67.Processing_ID = S45.Processing_ID
		AND S67.filename = S45.filename
		AND S67.originator = 'Ford'
	JOIN PARWU04_CCTSS_VRNT_FLAT AS U04_FLAT    
		ON  S45.User_Selected_CTSP_N =            U04_FLAT.ARWU31_CTSP_N
		AND S45.User_Selected_CTSP_Region_C =     U04_FLAT.ARWA06_RGN_C
		AND S45.User_Selected_ENRG_SUB_CMMDTY_X = U04_FLAT.ARWA03_ENRG_SUB_CMMDTY_X
		AND S45.User_Selected_BNCMK_VRNT_N =      U04_FLAT.ARWU01_BNCHMK_VRNT_N
		AND S45.User_selected_WALK_VRNT_X =       U04_FLAT.ARWU04_VRNT_N
	JOIN PARWUD2_CCTSS_VRNT_IMPRV AS UD2
		ON U04_FLAT.ARWU04_CCTSS_VRNT_K = UD2.ARWU04_CCTSS_VRNT_K
		AND S67.improvement_id= UD2.ARWUD2_CCTSS_VRNT_IMPRV_ID_N
	WHERE S67.Processing_ID = @GUID 
		AND S67.idea_description <> UD2.ARWUD2_CCTSS_VRNT_IMPRV_IDEA_X

END TRY

BEGIN CATCH
	INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,'' 
			 ,'PARWS67_VA_IMPROVEMENT_IDEAS_INFO'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH


GO
