DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDT_SUB_ASSEMBLY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 02/10/2020
-- Description:	Stored Procedure to validate Sub Assembly for PBOM Imports. 
--              Validation is for 1st load, kill and fill and surgical
-- =============================================
-- Changes
-- =============================================
-- Author     Date        User Story Description
-- ------     -----       ---------- -----------
-- asolosky   04/30/2020  US1589015  Added new error message for special characters: �[ ] * / \ : ?� 
-- asolosky   04/30/2020             Moved the "greater than 25 char error" to PARWP_PBOM_VALIDT_SUB_ASSEMBLY
-- asolosky   05/19/2020  US1592745  Added validation for sub-assembly name and sub-assembly index
-- rwesley2   09-11-2020  US1910880  Add part index and Arrow value to error. Write error to new E02 error table
-- Asolosky   10/20/2020  US1996362  Switch from E02 to E03 and include Excel column
-- Asolosky   12/14/2020  US2126152  Display a validation error when sub-assembly starts with a space
-- Asolosky   01/29/2021  US2129747  Display a validation error when the sub assembly name or index to have a line Feed/carriage return
-- Asolosky   02/24/2021  US2277923  Display a validation error when the sub assembly's are not in the same order as the first time they are loaded.  
--                                   New sub assemblies must go to the bottom of the Excel file
-- Asolosky   05/19/2021  US2145462  PBOM template change to 6.00 which increases the sub-assemblies from [A-F] to [A-Y] and DP
-- =============================================


CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDT_SUB_ASSEMBLY] 
	 @GUID       varchar(500)
	,@CDSID      varchar(30)
	,@TIME_STAMP DATETIME
AS

BEGIN TRY
	SET NOCOUNT ON;

--******************************************************
--A sub assembly name can''t contain these special characters: [ ] * / \ : ?
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      sub_assembly_name                            as [ARWE03_ERROR_VALUE], 
	      'A sub assembly name can''t contain these special characters: [ ] * / \ : ?' as [ARWE03_ERROR_x],
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                  as ARWE03_ROW_IDX,  -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  'B'                                          as ARWE03_COLUMN
	  FROM 
    	   (select S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_name Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
    		 join PARWU01_CCTSS_FLAT U01    
               on s59.User_Selected_CTSP_N            = U01.ARWU31_CTSP_N
    	      and s59.User_Selected_CTSP_Region_C     = U01.ARWA06_RGN_C
    		  and s59.User_Selected_ENRG_SUB_CMMDTY_X = U01.ARWA03_ENRG_SUB_CMMDTY_X
    		  and s59.User_Selected_BNCMK_VRNT_N      = U01.ARWU01_BNCHMK_VRNT_N

            Where S59.Processing_ID              = @GUID
    		  and (S59.sub_assembly_name like '%~[%' ESCAPE '~' or
			       S59.sub_assembly_name like '%~]%' ESCAPE '~' or
			       S59.sub_assembly_name like '%*%' or
			       S59.sub_assembly_name like '%/%' or
			       S59.sub_assembly_name like '%\%' or
			       S59.sub_assembly_name like '%:%' or
			       S59.sub_assembly_name like '%?%'  
				  )
    		) S59
      Where rownum = 1
;

--******************************************************
--Sub assembly name can''t be more than 25 characters
--******************************************************
	INSERT INTO PARWE03_BATCH_PBOM_ERRORS
      SELECT
	         Validate.[Source_c]                     as [ARWE03SOURCE_C],
	         Validate.sub_assembly_name              as [ARWE03_ERROR_VALUE],
	         'Sub assembly name can''t be more than 25 characters'  as [ARWE03_ERROR_VALUE],
	         Validate.[Processing_ID]                as [ARWE03_PROCESSING_ID],
	         Validate.[file_name]                    as [ARWE03_FILENAME],
	         OBJECT_NAME(@@PROCID)                   as [ARWE03_PROCEDURE_X],
	         @TIME_STAMP                             as [ARWE03_CREATE_S],
	         @CDSID                                  as [ARWE03_CREATE_USER_C],
	         @TIME_STAMP                             as [ARWE03_LAST_UPDT_S],
	         @CDSID                                  as [ARWE03_LAST_UPDT_USER_C],
	         Validate.[ARWS59_PBOM_PARTS]            as [ARWE03_BATCH_ERRORS_REF_K],
	         'PARWS59_PBOM_PARTS'                    as [ARWE03_STAGING_TABLE_X],
	         'ERROR'                                 as [ARWE03_ERROR_TYPE_X],
		     sub_assembly_name                       as [ARWE03_EXCEL_TAB_X],
		     row_idx - 1                             as ARWE03_ROW_IDX,  --must subtract 1 to get the correct row
	    	 ''                                      as ARWE03_Part_Index,
	    	 ''                                      as ARWE03_Arrow_value,
		     'B'                                     as ARWE03_COLUMN
       FROM 
       (
       SELECT Processing_ID,
		      Program,
              commodity_name,
		      Sub_Commodity_name,
			  User_Selected_ENRG_SUB_CMMDTY_X,
			  sub_assembly_name,
		      Source_c,
		      file_name,
			  row_idx,
              ARWS59_PBOM_PARTS,
			  row_number() over (partition by S59.Processing_ID, S59.file_name, S59.sub_assembly_name   
			                         Order by row_idx
								) as rownum
         FROM [dbo].[PARWS59_PBOM_PARTS] s59
        WHERE Processing_ID              = @GUID 
	      And len(S59.sub_assembly_name) > 25                    
       ) Validate
	   where rownum = 1
    ;

--******************************************************
--The sub assembly name is missing
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      sub_assembly_name                            as [ARWE03_ERROR_VALUE], 
	      'The sub assembly name is missing'           as [ARWE03_ERROR_x],
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                  as ARWE03_ROW_IDX,  -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  'B'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_name
		          ,S59.sub_assembly_idx_c
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_name Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID     = @GUID
    		  and ltrim(rtrim(S59.sub_assembly_name))   = ''
    		  and ltrim(rtrim(S59.sub_assembly_idx_c)) != 'DP'
    		) S59
      Where rownum = 1
;

	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
      SELECT
	         Source_c                          as [ARWE03_SOURCE_C],
	         sub_assembly_name                 as [ARWE03_ERROR_VALUE],
	         'Sub Assembly Name starts with a space. Please correct and re-import.' as [ARWE03_ERROR_X],
	         Processing_ID                     as [ARWE03_PROCESSING_ID],
	         file_name                         as [ARWE03_FILENAME],
	         OBJECT_NAME(@@PROCID)             as [ARWE03_PROCEDURE_X],
	         @TIME_STAMP                       as [ARWE03_CREATE_S],
             @CDSID                            as [ARWE03_CREATE_USER_C],
	         @TIME_STAMP                       as [ARWE03_LAST_UPDT_S],
	         @CDSID                            as [ARWE03_LAST_UPDT_USER_C],
	         ARWS59_PBOM_PARTS                 as [ARWE03_BATCH_ERRORS_REF_K],
	         'PARWS59_PBOM_PARTS'              as [ARWE03_STAGING_TABLE_X], 
	         'ERROR'                           as [ARWE03_ERROR_TYPE_X],
	         sub_assembly_name                 as [ARWE03_EXCEL_TAB_X], 
	         row_idx -  1                      as [ARWE03_ROW_IDX],
		  ''                                   as ARWE03_Part_Index,
		  ''                                   as ARWE03_Arrow_value,
		  'B'                                  as ARWE03_COLUMN
      FROM 
    	   (select Source_c
		          ,sub_assembly_name
		          ,sub_assembly_idx_c
    			  ,file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,Processing_ID
				  ,row_number() over (partition by file_name, sub_assembly_name Order by row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  
            Where Processing_ID     = @GUID
    		  and SUBSTRING(sub_assembly_name,1,1) =  ' '

    		) S59
      Where rownum = 1
    ;

--******************************************************
--A Directed Parts sub assembly index must have a "Directed Parts" sub assembly name
--*******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      sub_assembly_name                            as [ARWE03_ERROR_VALUE], 
	      'A DP sub assembly index must have a sub assembly name of "Directed Parts"'          as [ARWE03_ERROR_x],
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                  as ARWE03_ROW_IDX , -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  'B'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_name Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID      = @GUID
			  and S59.sub_assembly_idx_c = 'DP'
    		  and S59.sub_assembly_name != 'Directed Parts'
    		) S59
      Where rownum = 1
;

--******************************************************
--A Directed Parts sub assembly name must have a "DP" index
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      sub_assembly_idx_c                           as [ARWE03_ERROR_VALUE], 
	      'A Directed Parts sub assembly name must have a "DP" sub assembly index'          as [ARWE03_ERROR_x],
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                  as ARWE03_ROW_IDX,  -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  'A'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_idx_c
		          ,S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_idx_c Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID       = @GUID
			  and S59.sub_assembly_name   = 'Directed Parts'
    		  and S59.sub_assembly_idx_c != 'DP'
    		) S59
      Where rownum = 1
;

--******************************************************
--A sub-assembly index can only be [A-Y] or DP
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                            as [ARWE03_SOURCE_C],
	      replace(sub_assembly_idx_c,char(10),'<LF>')     as [ARWE03_ERROR_VALUE], 
	      'A sub-assembly index can only be [A-Y] or DP'  as [ARWE03_ERROR_x],
	      @GUID                                           as [ARWE03_PROCESSING_ID],
	      file_name                                       as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                           as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                     as [ARWE03_CREATE_S],
	      @CDSID                                          as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 								      
		  @CDSID                                          as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                               as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                            as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                         as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                               as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                     as ARWE03_ROW_IDX,  -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                              as ARWE03_Part_Index,
		  ''                                              as ARWE03_Arrow_value,
		  'A'                                             as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_idx_c
		          ,S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_idx_c Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID      = @GUID
			  and S59.sub_assembly_idx_c not in ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','DP')
    		) S59
      Where rownum = 1
;

--******************************************************
--The sub-assembly name has 2 different indexes associated to it
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      sub_assembly_name                            as [ARWE03_ERROR_VALUE], 
	      'The sub assembly name was used more than once. It must be unique. Please search the import file for multiple occurences.'  as [ARWE03_ERROR_x],
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                  as ARWE03_ROW_IDX,  -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  'B'                                          as ARWE03_COLUMN
      FROM
	   (Select * 
	      from 
		       -- Determine if  sub_assembly_name has a count > 1
     	      (Select sub_assembly_name
     		         ,row_idx
					 ,file_name
					 ,ARWS59_PBOM_PARTS
     		         ,count(sub_assembly_name) over (partition by S59.sub_assembly_name ) as sub_assembly_cnt
     				 ,row_number()             over (partition by S59.sub_assembly_name 
					                                     Order by S59.row_idx)            as sub_rownum
				 --Get all unique sub_assembly_name, sub_assembly_idx_c  										              
     		     from (select sub_assembly_name
             		          ,sub_assembly_idx_c
                 			  ,file_name
             				  ,ARWS59_PBOM_PARTS
             				  ,row_idx
             				  ,row_number() over (partition by file_name, sub_assembly_name, sub_assembly_idx_c 
							                          Order by row_idx) as rownum
                          FROM PARWS59_PBOM_PARTS  
                         Where Processing_ID      = @GUID
                 		) S59
                 Where rownum = 1
     		  ) Dup_Sub_Name
		 Where sub_assembly_cnt > 1
		   and sub_rownum       = 1
	   ) Dup_Error
;
--******************************************************
--The sub-assembly index has 2 different names associated to it
--******************************************************
INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	      'UI'                                         as [ARWE03_SOURCE_C],
	      sub_assembly_idx_c                           as [ARWE03_ERROR_VALUE], 
	      'The sub assembly index was used more than once. It must be unique. Please search the import file for multiple occurences.'  as [ARWE03_ERROR_x],
	      @GUID                                        as [ARWE03_PROCESSING_ID],
	      file_name                                    as [ARWE03_FILENAME],
	      OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	      @TIME_STAMP                                  as [ARWE03_CREATE_S],
	      @CDSID                                       as [ARWE03_CREATE_USER_C],
	      @TIME_STAMP, 
		  @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	      ARWS59_PBOM_PARTS                            as [ARWE03_BATCH_ERRORS_REF_K],
	      'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
		  'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
		  sub_assembly_name                            as [ARWE03_EXCEL_TAB_X],
		  row_idx - 1                                  as ARWE03_ROW_IDX,  -- Need to subtract 1 to get the actual sub-assembly row
		  ''                                           as ARWE03_Part_Index,
		  ''                                           as ARWE03_Arrow_value,
		  'A'                                          as ARWE03_COLUMN
      FROM
	   (Select * 
	      from 
		  	   -- Determine if  sub_assembly_idx_c has a count > 1
     	      (Select sub_assembly_idx_c
			         ,sub_assembly_name
     		         ,row_idx
					 ,S59.file_name
					 ,ARWS59_PBOM_PARTS
     		         ,count(sub_assembly_idx_c) over (partition by S59.sub_assembly_idx_c ) as sub_assembly_cnt
     				 ,row_number()              over (partition by S59.sub_assembly_idx_c 
					                                      Order by S59.row_idx)            as sub_rownum
                 --Get all unique sub_assembly_name, sub_assembly_idx_c 
     		     from (select S59.sub_assembly_name
             		          ,S59.sub_assembly_idx_c
                 			  ,S59.file_name
             				  ,ARWS59_PBOM_PARTS
             				  ,row_idx
             				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_name, S59.sub_assembly_idx_c 
							                          Order by S59.row_idx) as rownum
                          FROM PARWS59_PBOM_PARTS  S59
                         Where S59.Processing_ID      = @GUID
                 		) S59
                 Where rownum = 1
     		  ) Dup_Sub_Name
		 Where sub_assembly_cnt > 1
		   and sub_rownum       = 1
	   ) Dup_Error
;

-- Line Feed/Carriage return validation on sub assembly name
DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --Line Feed
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(sub_assembly_name,char(10),'<LF>')   as [ARWE03_ERROR_VALUE],  --replace line feed with <LF>
	       'A sub assembly name can''t have an imbedded line feed <LF>'  as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   ''                                           as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value, -- no arrow value
		   'B'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_idx_c
		          ,S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,processing_id
				  ,Source_c
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_name Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID      = @GUID
		   ) S59
     WHERE rownum     = 1  --Remove the duplicates.
       and NullIf(PATINDEX(@pat10,S59.sub_assembly_name),0) > 0  --Looking for line feed
    ;

-- Carriage Return validation
DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --Carriage Return
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(sub_assembly_name,char(13),'<CR>')   as [ARWE03_ERROR_VALUE],  --replace carriage return with <CR>
	       'A sub assembly name can''t have an imbedded carriage return <CR>' as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx                                  as [ARWE03_ROW_IDX],
		   ''                                           as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value, -- no arrow value
		   'B'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_idx_c
		          ,S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,processing_id
				  ,Source_c
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_name Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID      = @GUID
		   ) S59
     WHERE rownum     = 1  --Remove the duplicates
       and NullIf(PATINDEX(@pat13,S59.sub_assembly_name),0) > 0  --Looking for carriage 
    ;

-- Line Feed/Carriage return validation on sub assembly Index
--DECLARE @pat10 NvarCHAR(100) = '%['+CHAR(10)+']%';  --@pat10 already declared above
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(sub_assembly_idx_c,char(10),'<LF>')  as [ARWE03_ERROR_VALUE],  --replace line feed with <LF>
	       'A sub assembly index can''t have an imbedded line feed <LF>'  as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx - 1                              as [ARWE03_ROW_IDX],
		   ''                                           as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value, -- no arrow value
		   'A'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_idx_c
		          ,S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,processing_id
				  ,Source_c
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_idx_c Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID      = @GUID
		   ) S59
     WHERE rownum     = 1  --Remove the duplicates.
       and NullIf(PATINDEX(@pat10,S59.sub_assembly_idx_c),0) > 0  --Looking for line feed
    ;

-- Carriage Return validation
--DECLARE @pat13 NvarCHAR(100) = '%['+CHAR(13)+']%';  --pat13 already declared above
	INSERT INTO [dbo].[PARWE03_BATCH_PBOM_ERRORS]
    SELECT
	       S59.Source_c                                 as [ARWE03_SOURCE_C],
	       replace(sub_assembly_idx_c,char(13),'<CR>')  as [ARWE03_ERROR_VALUE],  --replace carriage return with <CR>
	       'A sub assembly index can''t have an imbedded carriage return <CR>' as [ARWE03_ERROR_X],
	       S59.Processing_ID                            as [ARWE03_PROCESSING_ID],
	       S59.file_name                                as [ARWE03_FILENAME],
	       OBJECT_NAME(@@PROCID)                        as [ARWE03_PROCEDURE_X],
	       @TIME_STAMP                                  as [ARWE03_CREATE_S],
           @CDSID                                       as [ARWE03_CREATE_USER_C],
	       @TIME_STAMP                                  as [ARWE03_LAST_UPDT_S],
	       @CDSID                                       as [ARWE03_LAST_UPDT_USER_C],
	       S59.ARWS59_PBOM_PARTS                        as [ARWE03_BATCH_ERRORS_REF_K],
	       'PARWS59_PBOM_PARTS'                         as [ARWE03_STAGING_TABLE_X],
	       'ERROR'                                      as [ARWE03_ERROR_TYPE_X],
	       S59.sub_assembly_name                        as [ARWE03_EXCEL_TAB_X],
	       S59.row_idx - 1                              as [ARWE03_ROW_IDX],
		   ''                                           as ARWE03_Part_Index,
		   ''                                           as ARWE03_Arrow_value, -- no arrow value
		   'A'                                          as ARWE03_COLUMN
      FROM 
    	   (select S59.sub_assembly_idx_c
		          ,S59.sub_assembly_name
    			  ,S59.file_name
				  ,ARWS59_PBOM_PARTS
				  ,row_idx
				  ,processing_id
				  ,Source_c
				  ,row_number() over (partition by S59.file_name, S59.sub_assembly_idx_c Order by S59.row_idx) as rownum
             FROM PARWS59_PBOM_PARTS  S59
            Where S59.Processing_ID      = @GUID
		   ) S59
     WHERE rownum     = 1  --Remove the duplicates
       and NullIf(PATINDEX(@pat13,S59.sub_assembly_idx_c),0) > 0  --Looking for carriage 
    ;

--******************************************************
--Sub assembly can't be moved from it's original spot in the Excel file
--******************************************************
INSERT INTO PARWE03_BATCH_PBOM_ERRORS
SELECT
      [Source_c]                     as [ARWE03_SOURCE_C],
      sub_assembly_idx_c + '-' + sub_assembly_name            as [ARWE03_ERROR_VALUE],
      'Sub assemblies can''t be moved in the PBOM file after the initial load.  Any new Sub Assemblies must be added at the end of the file or into an existing sub assembly area that isn''t already in use.'  as [ARWE03_ERROR_VALUE],
      [Processing_ID]                as [ARWE03_PROCESSING_ID],
      [file_name]                    as [ARWE03_FILENAME],
      OBJECT_NAME(@@PROCID)          as [ARWE03_PROCEDURE_X],
      @TIME_STAMP                    as [ARWE03_CREATE_S],
      @CDSID                         as [ARWE03_CREATE_USER_C],
      @TIME_STAMP                    as [ARWE03_LAST_UPDT_S],
      @CDSID                         as [ARWE03_LAST_UPDT_USER_C],
      [ARWS59_PBOM_PARTS]            as [ARWE03_BATCH_ERRORS_REF_K],
      'PARWS59_PBOM_PARTS'           as [ARWE03_STAGING_TABLE_X],
      'ERROR'                        as [ARWE03_ERROR_TYPE_X],
      sub_assembly_name              as [ARWE03_EXCEL_TAB_X],
      row_idx - 1                    as ARWE03_ROW_IDX,  --must subtract 1 to get the correct row
      ''                             as ARWE03_Part_Index,
      ARWU17_BOM_SUB_ASSY_IX_C + '-' + ARWU17_BOM_SUB_ASSY_N   as ARWE03_Arrow_value,
      'B'                            as ARWE03_COLUMN
 FROM
(
 Select S59.*
       ,U17.ARWU17_BOM_SUB_ASSY_N
	   ,U17.ARWU17_BOM_SUB_ASSY_IX_C 
	   ,U17.ARWU17_BOM_SUB_ASSY_IX_C + U17.ARWU17_BOM_SUB_ASSY_N as U17_sub_assembly_Idx_name
	   ,S59.sub_assembly_idx_c        + sub_assembly_name        as S59_sub_assembly_Idx_name
   From 
       (
        SELECT Processing_ID,
		       User_Selected_CTSP_N,
			   User_Selected_CTSP_Region_C,
               commodity_name,
		       User_Selected_ENRG_CMMDTY_X,
			   User_Selected_ENRG_SUB_CMMDTY_X,
			   User_Selected_BNCMK_VRNT_N,
			   sub_assembly_name,
			   sub_assembly_idx_c,
		       Source_c,
		       file_name,
			   row_idx,
               ARWS59_PBOM_PARTS,
			   row_number() over (partition by Processing_ID, file_name, sub_assembly_name   
			                          Order by row_idx
								 ) as rownum
          FROM PARWS59_PBOM_PARTS
         WHERE Processing_ID              =  @GUID                
       ) S59
   Join PARWU01_CCTSS_FLAT   U01
     On U01.ARWU31_CTSP_N            = S59.User_Selected_CTSP_N
	And U01.ARWA06_RGN_C             = S59.User_Selected_CTSP_Region_C
	And U01.ARWA03_ENRG_SUB_CMMDTY_X = S59.User_Selected_ENRG_SUB_CMMDTY_X
	And U01.ARWU01_BNCHMK_VRNT_N     = S59.User_Selected_BNCMK_VRNT_N
  Left Join PARWU17_BOM_SUB_ASSY U17 
    On U17.ARWU01_CCTSS_K        = U01.ARWU01_CCTSS_K
   And U17.ARWU17_BOM_SUB_ASSY_N = S59.sub_assembly_name
 where rownum = 1                            --Get rid of dups from the staging table
   and U17.ARWU17_BOM_SUB_ASSY_N is not NULL --don�t include any new sub assemblies
   and (U17.ARWU17_BOM_SUB_ASSY_IX_C + U17.ARWU17_BOM_SUB_ASSY_N) != (S59.sub_assembly_idx_c + sub_assembly_name) --Concat the index and name for comparison between ARROW and the file
) VLDTE
;

END TRY
BEGIN CATCH

INSERT INTO [dbo].PARWE03_BATCH_PBOM_ERRORS
       SELECT  
              'SYSTEM'                          --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID								--Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS59_PBOM_PARTS' 
			 --ARWE03_BATCH_ERRORS_K Identity key 
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                -- row_idx
             ,''                               -- part_index 
	         ,''                               -- ARROW_VALUE
             ,''                               -- Column
END CATCH




GO
