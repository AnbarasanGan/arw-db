DROP PROCEDURE [dbo].[PARWP_PBOM_VALIDATIONS_SRGCL]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		ASHAIK12
-- Create date: 02/03/2020
-- Description:	PBOM Data Validations
-- UI will call this first as part of the flow for PBOM Surgical
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ashaik12   4/15/2020   Added validation for End item
-- asolosky   4/23/2020   Added validation for sub-assembly.  This validation is only for surgical.
--                        Moved the majority of the validations to PARWP_PBOM_VALIDATIONS
-- asolosky   5/21/2020   Removed PARWP_PBOM_VALIDT_SUB_ASSEMBLY_SRGCL 
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_PBOM_VALIDATIONS_SRGCL] 
@GUIDIN varchar(500), 
@CDSID  varchar(8),
@result int OUTPUT

AS
Begin
 SET @result = 0
 DECLARE @TIME_STAMP          DATETIME    = GETUTCDATE();
 SET NOCOUNT ON;
 If @CDSID = NULL 
    Set @CDSID = SUBSTRING(CURRENT_USER, CHARINDEX('\', CURRENT_USER) + 1, LEN(CURRENT_USER));
  
-- scrub special characters for PBOM stage tables
 EXEC [dbo].[PARWP_PBOM_SCRUB_SPCL_CHARS]            @GUIDIN, @CDSID, @TIME_STAMP;

--PBOM Validation
 EXEC [dbo].[PARWP_PBOM_VALIDATIONS]                 @GUIDIN, @CDSID, @TIME_STAMP;
-- EXEC [dbo].[PARWP_PBOM_VALIDT_SUB_ASSEMBLY_SRGCL]   @GUIDIN, @CDSID, @TIME_STAMP;

 SET @result = 1;

 RETURN @result;
END;
GO
