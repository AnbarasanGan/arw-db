DROP PROCEDURE [dbo].[PARWP_CCS_VALIDT_PURCHASED_PARTS]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 3/18/2019
-- Description:	validate Purchased parts
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- ASHAIK12  06/25        Added validation for calculated field
-- ASHAIK12  07/31        Changed Calculated field validations to WARNINGS
-- Asolosky	 08/15/2019   Changed warning message from "Tax and Duty" to "Total cost (TC) [LoCur/pc]"
-- Asolosky  09/10/2019   Added row_idx
-- rwesley2  09/13/2019   added upper/lower bound function on calculated fields
-- rwesley2  09/30/2019   changed warning to error for calculated field validations
-- rwesley2  10/01/2019   temporarily changed error back to warning per Glenn
-- rwesley2	 10/08/2019	  removing upper/lower bound and changing to a comparison to a dollar value	 
-- rwesley2	 12/06/2019	  F151269, US1332651: changing WARNING to ERROR for validations that use threshold
-- Ashaik12  01/10/2020   Added TimeStamp parameter and removed filter on Processing Status
-- Asolosky  09/11/2020   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
-- Asolosky  03/26/2021   US2409827 Added validation on PIA Bailed column
-- Asolosky  04/07/2021   US2430167 Added validation for Cost sheet exchange rate
-- Asolosky  08/26/2021   US2815039 Added a case statement in the first part index validation for Part Index does not belong the BOM Sub Assembly.
--                        This happens if the user does a copy paste from another sheet.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_CCS_VALIDT_PURCHASED_PARTS] 

@GUID           varchar(5000), 
@CDSID          varchar(30),
@TIME_STAMP     DATETIME,
@threshold      Decimal(5,3)


AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

--++++++++++++++++++++++++++++++++++++
-- Part Index validation 
--++++++++++++++++++++++++++++++++++++
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Source_c
	  ,part_index 
      ,Error_x            AS ARWE02_ERROR_X 
	  ,Processing_ID 
	  ,filename
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID  
	  ,ARWS14_CCS_PURCHASED_PARTS_K 
	  ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'     
	  ,'ERROR'
	  ,sub_assembly_name  
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,part_index 
	  ,''  --No ARROW Value
  FROM 
       (
        SELECT 
		       s14.Processing_ID
              ,s14.part_index
		      ,S13.part_index             as S13_part_index
		      ,s14.Source_c
		      ,s14.filename
              ,s14.ARWS14_CCS_PURCHASED_PARTS_K
		      ,s14.sub_assembly_name
		      ,S13.part_sub_assembly_name as S13_part_sub_assembly_name
		      ,s14.row_idx
		      ,Case When S13.part_sub_assembly_name != s14.sub_assembly_name 
		            Then 'Purchased Parts: Part Index was found on a different BOM Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the part index.'
			        When S13.part_sub_assembly_name is Null
			        Then 'Purchased Parts: Part Index was not found on any BOM Sub Assembly sheet. Please do not copy/paste. Use the drop down to select the part index.'
			        Else ''
		       End Error_x
          FROM PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO s14
     Left Join PARWS13_CCS_FORD_BOM_PARTS_INFO                 s13
            ON s14.part_index    = s13.part_index
		   and s14.filename      = s13.file_name
		   and s14.Processing_ID = s13.Processing_ID
         WHERE s14.Processing_ID = @GUID          
       ) Err
  Where Error_x != ''
;

--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Source Country Local Currency Code validation
--++++++++++++++++++++++++++++++++++++++++++++++++++
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.[local_currency] 
      ,'Purchased Parts: Invalid Currency Code' AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID   
	  ,Err.[ARWS14_CCS_PURCHASED_PARTS_K]
	  ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,''  --No ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          local_currency,
		  part_index,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS14_CCS_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO s14 
        WHERE Processing_ID=@GUID
			and Not Exists
			    (Select 'X'
				   From [dbo].[PARWA29_CRCY] A29
                   Where s14.[local_currency] = A29.[ARWA29_CRCY_C]
	             )		
                 
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++++++++++++++++
-- Part Description Validation 
--++++++++++++++++++++++++++++++++++++++++++++++++++
   Insert Into PARWE02_BATCH_ERRORS
    SELECT
	   Err.[Source_c] 
	  ,ERR.[part_description]  
      ,'Purchased Parts: Part Name does not match PBOM name' AS ARWE02_ERROR_X 
	  ,Err.[Processing_ID] 
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID) 
	  ,@TIME_STAMP 
	  ,@CDSID   
	  ,@TIME_STAMP   
	  ,@CDSID   
	  ,Err.[ARWS14_CCS_PURCHASED_PARTS_K] 
	  ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'     
	  ,'ERROR'
	  ,Err.sub_assembly_name  
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,''  --No ARROW Value
   FROM 
       (
        SELECT 
		  Processing_ID,
          [part_index],
          [part_description],
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS14_CCS_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  row_idx
        FROM  [dbo].[PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO] s14

        WHERE Processing_ID= @GUID
	   and Not Exists
		      (Select 'X'
               from  [dbo].[PARWS13_CCS_FORD_BOM_PARTS_INFO] s13
               where s14.[part_index] = s13.[part_index]
			     and s14.[part_description] = s13.[part_name]
				 and s14.[filename] = s13.[file_name]
				 and s14.Processing_ID = s13.Processing_ID

)
                    
       ) Err
;

--++++++++++++++++++++++++++++++++++++
-- Calculated fields validation check for Tax and Duty per piece [LoCur/pc]
--++++++++++++++++++++++++++++++++++++

	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	   Err.[Source_c]
	  ,Err.total_cost
      ,'Purchased Parts: For Total cost, the difference between calculated value and the total exceeds the threshold of $' + CAST(@threshold as VARCHAR(10)) as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.[ARWS14_CCS_PURCHASED_PARTS_K]
	  ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,'Calculated Value: ' +  CAST(Err.Calculated_value as Varchar(50))  --ARROW Value
       FROM 
       (
        SELECT 
          Processing_ID,
          s14.total_cost,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS14_CCS_PURCHASED_PARTS_K],
		  sub_assembly_name,
		  part_index,
		  (purchased_price_per_piece+inbound_packaging_costs+inbound_logistics_costs+tax_duty) as Calculated_value,
		  row_idx
        FROM 
          [dbo].[PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO] s14 
           WHERE Processing_ID=@GUID
		   AND ABS((purchased_price_per_piece+inbound_packaging_costs+inbound_logistics_costs+tax_duty) - (total_cost)) > @threshold
       ) Err

    ;

--++++++++++++++++++++++++++++++++++++
-- PIA Bailed
--++++++++++++++++++++++++++++++++++++

INSERT INTO PARWE02_BATCH_ERRORS
SELECT
	   Err.Source_c
	  ,Err.pia_directed_bailed as ARWE02_ERROR_VALUE
      ,'Purchased Parts: Invalid PIA/Directed/Bailed Code. Please select a code from the drop down list.' AS ARWE02_ERROR_X 
	  ,Err.Processing_ID
	  ,Err.filename 
	  ,OBJECT_NAME(@@PROCID)   as ARWE02_PROCEDURE_X
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID   
	  ,Err.ARWS14_CCS_PURCHASED_PARTS_K                  as ARWE02_STAGING_TABLE_X
	  ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO' as ARWE02_BATCH_ERRORS_K
	  ,'ERROR'                 as ARWE02_ERROR_TYPE_X
	  ,Err.sub_assembly_name   as ARWE02_EXCEL_TAB_X
	  ,row_idx                 as ARWE02_ROW_IDX
	  ,Err.part_index          as ARWE02_Part_Index
	  ,''                      as ARWE02_ARROW_Value  --No ARROW Value
  FROM 
       (
        SELECT 
               Processing_ID
              ,pia_directed_bailed
              ,part_index
              ,Source_c
              ,filename
              ,ARWS14_CCS_PURCHASED_PARTS_K
              ,sub_assembly_name
              ,row_idx
         FROM PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14 
        WHERE Processing_ID=@GUID
		  and Not Exists
			  (Select 'X'
				 From PARWA44_PURC_PART_TYPE A44
                Where A44.ARWA44_PURC_PART_TYPE_C = S14.pia_directed_bailed
	          )		
                 
       ) Err
;
--++++++++++++++++++++++++++++++++++++
-- Exchange Rate validation
--++++++++++++++++++++++++++++++++++++

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
SELECT
	   Err.[Source_c]
	  ,Err.exchange_rate
      ,'Purchased Parts: Exchange rate doesn''t match Exchange rates sheet- ' + CAST(usd_per_local_currency as Varchar(50))  as [ARWE02_ERROR_X]
	  ,Err.[Processing_ID]
	  ,Err.[filename] 
	  ,OBJECT_NAME(@@PROCID)  as PROC_ID 
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,@TIME_STAMP  
	  ,@CDSID  
	  ,Err.[ARWS14_CCS_PURCHASED_PARTS_K]
	  ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'
	  ,'ERROR'
	  ,Err.sub_assembly_name
	  ,row_idx                               as ARWE02_ROW_IDX
	  ,Err.part_index 
	  ,'' --supplier_picked_crcy_c + ' Per Local Currency from Exchange rates sheet: ' +  CAST(usd_per_local_currency as Varchar(50))  --ARROW Value
  FROM 
      (
        SELECT 
               S14.Processing_ID
              ,s14.exchange_rate
  		      ,s14.Source_c
  		      ,s14.filename
              ,s14.ARWS14_CCS_PURCHASED_PARTS_K
  		      ,s14.sub_assembly_name
  		      ,s14.part_index
			  ,s14.row_idx
			  ,S27.usd_per_local_currency
			  ,S27.supplier_picked_crcy_c
          FROM PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO S14 
		  Join PARWS27_CCS_EXCHANGE_RATE_TAB                   S27
		    On S27.Processing_ID  = S14.Processing_ID
		   And S27.filename       = S14.filename
		   And S27.currency_code  = S14.local_currency
         WHERE S14.Processing_ID  = @GUID
		   and S14.exchange_rate != S27.usd_per_local_currency
      ) Err
;

END TRY
BEGIN CATCH
INSERT INTO  [dbo].[PARWE02_BATCH_ERRORS]
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID             --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
	         ,@CDSID  
             ,@TIME_STAMP
	         ,@CDSID  
			 ,''
			 ,'PARWS14_CCS_SUPPLIER_QUOTE_PURCHASED_PARTS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH;



GO
