SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		asamriya
-- Create date: 07/29/2019
-- Description:	Select the records in the Staging table Where Processing_Status_x = PROCESSING
--              These staging records will be loaded into Arrow
--              There is no Try and Catch in this procedure.  The errors will be caught in the main procedure.
-- =============================================
-- Changes
-- Date        CDSID     Feature  Description
-- ----------  --------  -------  -----------
-- 08/16/2019  asolosky           Updated the Level 1 and Level 2 waterfall category logic to match DA logic.
-- 08/26/2019  ashaik12           Added join on User_selected_WALK_VRNT_X
-- 08/27/2019  rwesley			  Added rownum to U65 insert to eliminate duplicate row insert when multiple files are uploaded. 
-- 08/27/2019  asolosky US1162665 Deletes: Remove the filename from the delete statements so the code will do a complete delete.  
--                                Also removed sub_assembly_name and Skip_loading_due_to_error_f from the Where     
-- 08/28/2019  rwesley			  Added CCTSS to U18 temp tbl build and U18 INSERT.  business rule from Glenn: can assign the sub-assembly 
--                                by the first 2 characters of a part index for a given CCTSS. 	
-- 09/05/2019  asolosky           Moved delete statements to PARWP_VA_DELETE_TABLES
-- 10/14/2019  rwesley2           Added CCTSS to U18 temp tbl build and U18 INSERT
-- 11/21/2019  rwesley2           new business rule:  the first character of a part index defines the sub-assy  and removed rownum =1
-- 11/22/2019  rwesley2           business rule change: first look for part index match using first 2 characters of part index to find the sub-assy
--                                if no matches, use first character of part index to find the sub-assy
-- 12/02/2019  asolosky           Added the supplier_c, supplier_n, supplier country name to the U09_view join
--                                Lined up the logic to match DAII.
-- 01/14/2020  Ashaik12           Added Time_Stamp parameter and removed filter on Processing Status
-- 07/30/2020  Ashaik12  US1809333  Increase column sizes in temp table to match database column sizes.
-- 05/06/2022  btemkow   US3601073: Handle CIA ID Number
-- =============================================

CREATE OR ALTER PROCEDURE  [dbo].[PARWP_VA_LOAD_ADJUSTMENT_DETAILS] 
-- Input Parameter
@GUIDIN Varchar(5000),
@CDSID	Varchar(30),
@TIME_STAMP DATETIME

AS

SET NOCOUNT ON;

--==================================================================
--==================================================================
--  U18 and U19 INSERT 
-- TABLE variables to hold new Part Index
 DECLARE @new_part_index TABLE (
         NEW_BOM_PART_IX_N VARCHAR(64) NOT NULL
        ,NEW_PART_NAME VARCHAR (256) NOT NULL
		,NEW_CCTSS int NOT NULL
	    ,row_idx INT
		                        )
 	;
-- get new part index from s46 that is not on u18 when type of change is ADD    
-- when skip loading flag is not 0, nothing is loaded to the temp table, so nothing is inserted to u18 and subsequently u19.
INSERT INTO @new_part_index
    SELECT  not_matched_PI
         ,part_name
     	 ,[ARWU01_CCTSS_K]
         ,[row_idx]
	   from
	   (
       SELECT s46.part_index as not_matched_PI
	         ,s46.part_name
			 ,u09_view.[ARWU01_CCTSS_K]
 	         ,s46.[row_idx]
			 ,row_number() over (Partition by s46.part_index  order by s46.[row_idx]) as rownum
       FROM [dbo].PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
       LEFT JOIN dbo.PARWS45_VA_COVER_PAGE_INFO      S45
         on S45.Processing_ID       = S46.Processing_ID
        and S45.filename            = S46.filename

       LEFT join [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view       
	     on s45.[User_Selected_CTSP_N]            = u09_view.ARWU31_CTSP_N
		and s45.[User_Selected_CTSP_Region_C]     = u09_view.[ARWA06_RGN_C]
		and s45.[User_Selected_ENRG_SUB_CMMDTY_X] = u09_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s45.[User_Selected_BNCMK_VRNT_N]      = u09_view.ARWU01_BNCHMK_VRNT_N
        and s45.[User_selected_WALK_VRNT_X]       = u09_view.[ARWU04_VRNT_N]
		and s45.User_Selected_SUPL_C              = u09_view.ARWA17_SUPL_C
		and s45.User_Selected_SUPL_N              = u09_view.ARWA17_SUPL_N
		and s45.User_Selected_SUPL_CNTRY_N        = u09_view.ARWA28_CNTRY_N

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on S46.[part_index] = U18.ARWU18_BOM_PART_IX_N
		 and u09_view.[ARWU01_CCTSS_K] = u18.[ARWU01_CCTSS_K]
       WHERE s46.Processing_ID       =  @GUIDIN 
	     and s46.type_of_change      = 'ADD'
	     and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	     and S45.Skip_loading_due_to_error_f = 0
	   ) STG
    Where rownum = 1;
;

-- check for part index match using first 2 characters 
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID       as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,2) = substring(npi.NEW_BOM_PART_IX_N,1,2)
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;
-- deleting and reloading the temp table to make sure any parts inserted from the 2 character match above don't get inserted again fromn the 1 character match
-- anything inserted to the u18 from the 2 character match will not be on the temp table
DELETE from @new_part_index
INSERT INTO @new_part_index
    SELECT  not_matched_PI
         ,part_name
     	 ,[ARWU01_CCTSS_K]
         ,[row_idx]
	   from
	   (
       SELECT s46.part_index as not_matched_PI
	         ,s46.part_name
			 ,u09_view.[ARWU01_CCTSS_K]
 	         ,s46.[row_idx]
			 ,row_number() over (Partition by s46.part_index  order by s46.[row_idx]) as rownum
       FROM [dbo].PARWS46_VA_ADJUSTMENT_DETAILS_INFO S46
       LEFT JOIN dbo.PARWS45_VA_COVER_PAGE_INFO      S45
         on S45.Processing_ID       = S46.Processing_ID
        and S45.filename            = S46.filename

       LEFT join [dbo].[PARWU09_CCTSS_VRNT_SUPL_FLAT] u09_view       
	     on s45.[User_Selected_CTSP_N]            = u09_view.ARWU31_CTSP_N
		and s45.[User_Selected_CTSP_Region_C]     = u09_view.[ARWA06_RGN_C]
		and s45.[User_Selected_ENRG_SUB_CMMDTY_X] = u09_view.ARWA03_ENRG_SUB_CMMDTY_X
		and s45.[User_Selected_BNCMK_VRNT_N]      = u09_view.ARWU01_BNCHMK_VRNT_N
        and s45.[User_selected_WALK_VRNT_X]       = u09_view.[ARWU04_VRNT_N]
		and s45.User_Selected_SUPL_C              = u09_view.ARWA17_SUPL_C
		and s45.User_Selected_SUPL_N              = u09_view.ARWA17_SUPL_N
		and s45.User_Selected_SUPL_CNTRY_N        = u09_view.ARWA28_CNTRY_N

	   LEFT join [dbo].[PARWU18_BOM_PART] U18
	     on u09_view.[ARWU01_CCTSS_K] = u18.[ARWU01_CCTSS_K]
		and S46.[part_index] = U18.ARWU18_BOM_PART_IX_N
      WHERE s46.Processing_ID       =  @GUIDIN 
	    and s46.type_of_change      = 'ADD'
	    and u18.[ARWU18_BOM_PART_IX_N] is NULL
 	    and S45.Skip_loading_due_to_error_f = 0
	   ) STG
    Where rownum = 1;
;
-- doing not DP because if only using first character from a directed part may get wrong sub-assy
INSERT INTO [dbo].[PARWU18_BOM_PART] 
     SELECT [ARWU01_CCTSS_K]
           ,[ARWU18_BOM_PART_IX_N]
           ,[ARWU17_BOM_SUB_ASSY_K]
           ,[ARWU18_BOM_PART_DSPLY_SEQ_R]
           ,[ARWU18_BOM_PART_X]
           ,@TIME_STAMP as create_date
           ,@CDSID      as create_user_id
           ,@TIME_STAMP as update_date
           ,@CDSID     as update_user_id
     FROM
     (
      SELECT u17.[ARWU01_CCTSS_K]        as ARWU01_CCTSS_K
            ,npi.NEW_BOM_PART_IX_N       as ARWU18_BOM_PART_IX_N
            ,U17.[ARWU17_BOM_SUB_ASSY_K] as ARWU17_BOM_SUB_ASSY_K
	        ,npi.[row_idx]               as ARWU18_BOM_PART_DSPLY_SEQ_R
	        ,npi.NEW_PART_NAME           as ARWU18_BOM_PART_X
      FROM [dbo].[PARWU18_BOM_PART] u18n
      join @new_part_index npi
        on u18n.[ARWU01_CCTSS_K] = npi.NEW_CCTSS  
	   and substring(u18n.[ARWU18_BOM_PART_IX_N],1,1) = substring(npi.NEW_BOM_PART_IX_N,1,1)
	   and substring(npi.NEW_BOM_PART_IX_N,1,2) <> 'DP'  --DP is loaded in the 2char match.  Don't insert on 1char match.
       and substring(U18n.[ARWU18_BOM_PART_IX_N],1,2) <> 'DP'
      join [dbo].[PARWU17_BOM_SUB_ASSY] u17
        on u17.[ARWU17_BOM_SUB_ASSY_K] = u18n.[ARWU17_BOM_SUB_ASSY_K]
    ) load
group by ARWU01_CCTSS_K,ARWU18_BOM_PART_IX_N, ARWU17_BOM_SUB_ASSY_K, ARWU18_BOM_PART_X,ARWU18_BOM_PART_DSPLY_SEQ_R
;
--==================================================================
--==================================================================

INSERT INTO PARWU64_CCTSS_VRNT_ADJ_GRP
SELECT --ARWU64_CCTSS_VRNT_ADJ_GRP is an identity 
       U09_VRNT.ARWU04_CCTSS_VRNT_K          AS ARWU04_CCTSS_VRNT_K
	  ,S46.tough_choice_grouping        AS ARWU64_CCTSS_VRNT_ADJ_GRP_X
	--  ,1                                as [ARWU36_DSGN_ADJ_GRP_INCL_F]  -- default to Yes (1)
	  ,@TIME_STAMP
	  ,@CDSID
	  ,@TIME_STAMP
	  ,@CDSID
  From PARWS46_VA_ADJUSTMENT_DETAILS_INFO   S46
  JOIN PARWS45_VA_COVER_PAGE_INFO           S45
    ON S45.Processing_ID       = S46.Processing_ID
   AND S45.filename            = S46.filename

 -- Join with Design Supplier View
  JOIN PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON U09_VRNT.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
   AND U09_VRNT.ARWA06_RGN_C           = S45.User_Selected_CTSP_Region_C
   AND U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X        = S45.User_Selected_ENRG_SUB_CMMDTY_X 
   AND U09_VRNT.ARWU01_BNCHMK_VRNT_N                   = S45.User_Selected_BNCMK_VRNT_N
--   AND U09_VRNT.ARWA35_DSGN_VEH_MDL_YR_C   = S45.User_Selected_VEH_MDL_YR_C
   AND U09_VRNT.ARWA17_SUPL_N              = S45.User_Selected_SUPL_N
   AND U09_VRNT.ARWA17_SUPL_C              = S45.User_Selected_SUPL_C
   AND U09_VRNT.ARWA28_CNTRY_N             = S45.User_Selected_SUPL_CNTRY_N
   AND U09_VRNT.ARWU04_VRNT_N              = S45.User_selected_WALK_VRNT_X

Left Join PARWU65_CCTSS_VRNT_ADJ  U65
       ON U65.ARWU04_CCTSS_VRNT_K         = U09_VRNT.ARWU04_CCTSS_VRNT_K
      And U65.ARWU65_CCTSS_VRNT_ADJ_ID_N  = S46.change_id

  Where S45.Processing_ID               = @GUIDIN
    And S45.Skip_loading_due_to_error_f = 0
    And U65.ARWU65_CCTSS_VRNT_ADJ_ID_N  is NULL  --change_id
    And not exists --Can't add a tough group if it already exists
       (Select 'X'
          From PARWU64_CCTSS_VRNT_ADJ_GRP U64_Check
	     Where U64_Check.ARWU04_CCTSS_VRNT_K         = U09_VRNT.ARWU04_CCTSS_VRNT_K
		   And U64_Check.ARWU64_CCTSS_VRNT_ADJ_GRP_X = S46.tough_choice_grouping    
       )
Group by --Get distinct data to write into the U36 table.
       U09_VRNT.ARWU04_CCTSS_VRNT_K          
	  ,S46.tough_choice_grouping
;   
	  
--PARWU65_CCTSS_VRNT_ADJ
INSERT INTO  PARWU65_CCTSS_VRNT_ADJ
SELECT * FROM (
Select 
       ARWU04_CCTSS_VRNT_K
      ,ARWU65_CCTSS_VRNT_ADJ_ID_N
      ,ARWU64_CCTSS_VRNT_ADJ_GRP_K
	  ,ARWU18_BOM_PART_K
	  ,ARWA40_DSGN_ADJ_PART_CHG_TYP_K
	  ,ARWU65_FORD_INTD_DSGN_ATTR_X
	  ,ARWU65_FORD_VRNT_DSGN_ATTR_X
	  ,ARWA19_LVL2_ADJ_CATG_K
	  ,ARWU65_SPEC_SDS_NUM_X
	  ,ARWU65_CCTSS_VRNT_ADJ_CMT_X
	  ,ARWU65_CREATE_S
	  ,ARWU65_CREATE_USER_C
	  ,ARWU65_LAST_UPDT_S
	  ,ARWU65_LAST_UPDT_USER_C
	  ,'' AS ARWU65_CIA_ID_NUM_X
From
(
SELECT 
       U09_VRNT.ARWU04_CCTSS_VRNT_K              AS ARWU04_CCTSS_VRNT_K
      ,S46.change_id                             AS ARWU65_CCTSS_VRNT_ADJ_ID_N
      ,u64.ARWU64_CCTSS_VRNT_ADJ_GRP_K           AS ARWU64_CCTSS_VRNT_ADJ_GRP_K           
	  ,U18.ARWU18_BOM_PART_K                     AS ARWU18_BOM_PART_K
	  ,A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_K        AS ARWA40_DSGN_ADJ_PART_CHG_TYP_K
	  ,S46.ford_intended_dsgn_attr               AS ARWU65_FORD_INTD_DSGN_ATTR_X
	  ,s46.ford_variant_dsgn_attr                AS ARWU65_FORD_VRNT_DSGN_ATTR_X

      ,CASE WHEN WF_CAT.ARWA18_LVL1_ADJ_CATG_ABBR_N is NULL then '' ELSE WF_CAT.ARWA18_LVL1_ADJ_CATG_ABBR_N  END  AS lvl1_waterfall_cat  
	  ,CASE WHEN WF_CAT.ARWA19_LVL2_ADJ_CATG_N      is NULL then '' ELSE WF_CAT.ARWA19_LVL2_ADJ_CATG_N       END  AS lvl2_waterfall_cat

	  ,S46.ford_spec_sds                         AS ARWU65_SPEC_SDS_NUM_X
	  ,S46.comments                              AS ARWU65_CCTSS_VRNT_ADJ_CMT_X
	  ,@TIME_STAMP                              AS ARWU65_CREATE_S
	  ,@CDSID                                    AS ARWU65_CREATE_USER_C
	  ,@TIME_STAMP                              AS ARWU65_LAST_UPDT_S
	  ,@CDSID                                    AS ARWU65_LAST_UPDT_USER_C
	  ,ROW_NUMBER() OVER (PARTITION by U09_VRNT.ARWU04_CCTSS_VRNT_K, S46.change_id  ORDER by S46.change_id ) as rownum  

  From PARWS46_VA_ADJUSTMENT_DETAILS_INFO  S46
  JOIN dbo.PARWS45_VA_COVER_PAGE_INFO      S45
    ON S45.Processing_ID       = S46.Processing_ID
   AND S45.filename            = S46.filename

 -- Join with Supplier Quote View
  JOIN [dbo].PARWU09_CCTSS_VRNT_SUPL_FLAT   U09_VRNT
    ON U09_VRNT.ARWU31_CTSP_N              = S45.User_Selected_CTSP_N
   AND U09_VRNT.ARWA06_RGN_C               = S45.User_Selected_CTSP_Region_C
   AND U09_VRNT.ARWA03_ENRG_SUB_CMMDTY_X   = S45.User_Selected_ENRG_SUB_CMMDTY_X 
   AND U09_VRNT.ARWU01_BNCHMK_VRNT_N       = S45.User_Selected_BNCMK_VRNT_N
   AND U09_VRNT.ARWA17_SUPL_N              = S45.User_Selected_SUPL_N
   AND U09_VRNT.ARWA17_SUPL_C              = S45.User_Selected_SUPL_C
   AND U09_VRNT.ARWA28_CNTRY_N             = S45.User_Selected_SUPL_CNTRY_N
   AND U09_VRNT.ARWU04_VRNT_N              = S45.User_selected_WALK_VRNT_X

   JOIN [dbo].[PARWU18_BOM_PART] U18
   ON U18.ARWU18_BOM_PART_IX_N       = S46.part_index 
   AND U18.ARWU01_CCTSS_K = U09_VRNT.ARWU01_CCTSS_K

--Design Adjustment Group
  Join PARWU64_CCTSS_VRNT_ADJ_GRP  U64
    ON U64.ARWU04_CCTSS_VRNT_K         = U09_VRNT.ARWU04_CCTSS_VRNT_K
   And U64.ARWU64_CCTSS_VRNT_ADJ_GRP_X = S46.tough_choice_grouping
--Part Change Type
  Join PARWA40_DSGN_ADJ_PART_CHG_TYP  A40
    On A40.ARWA40_DSGN_ADJ_PART_CHG_TYP_X = S46.type_of_change
--Waterfall
	LEFT JOIN PARWV07_LVL1_LVL2_CAT  WF_CAT
	 ON S46.lvl1_waterfall_cat = WF_CAT.ARWA18_LVL1_ADJ_CATG_ABBR_N
	AND S46.lvl2_waterfall_cat = WF_CAT.ARWA19_LVL2_ADJ_CATG_N

 Where S45.Processing_ID               = @GUIDIN
   And S45.Skip_loading_due_to_error_f = 0
   And not exists --Insert if it doesn't already exist
      (Select 'X'
        From PARWU65_CCTSS_VRNT_ADJ U65_check
	   Where U65_check.ARWU04_CCTSS_VRNT_K        = U09_VRNT.ARWU04_CCTSS_VRNT_K 
	     and U65_check.ARWU65_CCTSS_VRNT_ADJ_ID_N = S46.change_id            
      )
) U65_Data
--Level1, Level2 category   
  Join PARWV07_LVL1_LVL2_CAT  V07
    ON U65_Data.lvl1_waterfall_cat   = V07.ARWA18_LVL1_ADJ_CATG_ABBR_N
   And U65_Data.lvl2_waterfall_cat   = V07.ARWA19_LVL2_ADJ_CATG_N
 Where rownum = 1
 )final
;



GO
