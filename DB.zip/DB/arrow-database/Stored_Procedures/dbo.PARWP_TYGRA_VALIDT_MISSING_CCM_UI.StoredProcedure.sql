SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		rwesley2
-- Create date: 01/08/2021
-- Description:	If Tygra CCM + varaint doesn't match Arrow CCM + vairant then create an ERROR. SP used in UI
--              
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- rwesley2   04-20-2021  U2453456 use MAX length when declaring a variable 
-- rwesley    09-30-2021  US2879211 - load Current files. Change CM_NICKNAME to CCM in join
--                        replaced SUBSTRING with CASE 
-- rwesley2   10-22-2021  US2995475 remove P05 join
-- rwesley2   04-05-2022  US3482265 added CM10 - CM25
--                                  commented out NoN_CM part of CASE and CASE on model year 
--                                  changed from WARNING to ERROR when CCM not found    
--                                  new validation that ACT control models must match Arrow program control models
--                                  added new inout parameters 
-- rwesley2   06-02-2022  US3686489  changed logic where ACT and ARROW CMs and program must match.  Get S61 first then check Arrow for match.
-- rwesley2	  06-10-2022  US3283898 DE256424  added case to handle Region mismatch between ACT and ARROW 
-- rwesley2   06-14-2022  US3283898 DE256668 change hardcoded Proc name to use object_name 
-- rwesley2	  06-27-2022  US3283898 remove hardcoded file source and provide file name in catch block
-- =============================================

CREATE OR ALTER   PROCEDURE  [dbo].[PARWP_TYGRA_VALIDT_MISSING_CCM_UI] 
-- Input Parameter
 @processing_id varchar(MAX)
,@CDSID         varchar(MAX)
,@TIME_STAMP DATETIME
,@Program_name varchar(max) 
,@Tygra_file_name varchar(max) 
,@file_source varchar(max) 
,@load_to_pgm_name varchar(max) 

AS

BEGIN TRY
	SET NOCOUNT ON;
--	set @GUID = (select processing_id from ##variant_tbl group by processing_id); 

INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]

Select @file_source              as [ARWE02_SOURCE_C]
      ,z.ccm                     as [ARWE02_ERROR_VALUE]
	  ,'Tygra CCM was not found in Arrow for Program - ' + z.program  as [ARWE02_ERROR_x]
      ,z.Processing_ID           as [ARWE02_PROCESSING_ID]
	  ,z.file_name               as [ARWE02_FILENAME]
	  ,object_name(@@PROCID)     as [ARWE02_PROCEDURE_X]
	  ,@TIME_STAMP               as [ARWE02_CREATE_S]
	  ,@CDSID                    as [ARWE02_CREATE_USER_C]
	  ,@TIME_STAMP               as [ARWE02_LAST_UPDT_S]
	  ,@CDSID                    as [ARWE02_LAST_UPDT_USER_C]
	  ,1                         as [ARWE02_BATCH_ERRORS_REF_K]
	  ,'PARWS61_TYGRA_TITLE_PAGE'   as [ARWE02_STAGING_TABLE_X]
	  ,'ERROR'                 as [ARWE02_ERROR_TYPE_X]
	  ,''                        as [ARWE02_EXCEL_TAB_X]
	  ,''                        as [ARWE02_ROW_IDX]
	  ,''                        as [ARWE02_Part_Index]
	  ,z.program + ': ' + z.ccm as [ARWE02_ARROW_Value]   
from (
select  Processing_ID 
       ,ccm
	   ,file_name
	   ,program
from (
select s61.program
      ,s61.ccm
      ,[ARWA09_PGM_CCM_X]
      ,[ARWA08_CCM_C]
  	  ,s61.processing_id
	  ,s61.file_name
	  ,row_number() OVER (order by s61.program, s61.ccm) as rownum
from PARWS61_TYGRA_TITLE_PAGE s61
left join PARWA09_PGM_CCM_FLAT a09
on CASE WHEN s61.CCM='CCM1' THEN 'CM1'
        WHEN s61.CCM='CCM2' THEN 'CM2'
        WHEN s61.CCM='CCM3' THEN 'CM3'
        WHEN s61.CCM='CCM4' THEN 'CM4'
        WHEN s61.CCM='CCM5' THEN 'CM5'
        WHEN s61.CCM='CCM6' THEN 'CM6'
        WHEN s61.CCM='CCM7' THEN 'CM7'
        WHEN s61.CCM='CCM8' THEN 'CM8'
        WHEN s61.CCM='CCM9' THEN 'CM9'
		WHEN s61.CCM='CCM10' THEN 'CM10'
        WHEN s61.CCM='CCM11' THEN 'CM11'
        WHEN s61.CCM='CCM12' THEN 'CM12'
        WHEN s61.CCM='CCM13' THEN 'CM13'
        WHEN s61.CCM='CCM14' THEN 'CM14'
        WHEN s61.CCM='CCM15' THEN 'CM15' 
		WHEN s61.CCM='CCM16' THEN 'CM16' 
		WHEN s61.CCM='CCM17' THEN 'CM17' 
		WHEN s61.CCM='CCM18' THEN 'CM18' 
		WHEN s61.CCM='CCM19' THEN 'CM19' 
		WHEN s61.CCM='CCM20' THEN 'CM20' 
		WHEN s61.CCM='CCM21' THEN 'CM21' 
		WHEN s61.CCM='CCM22' THEN 'CM22' 
		WHEN s61.CCM='CCM23' THEN 'CM23' 
		WHEN s61.CCM='CCM24' THEN 'CM24' 
		WHEN s61.CCM='CCM25' THEN 'CM25' 	END = A09.ARWA08_CCM_C
 
AND S61.[CM_PROGRAM] = A09.ARWA05_ENRG_PGM_C
AND CASE WHEN S61.Region = 'APO' then 'IMG'
         WHEN S61.Region = 'CH' then 'China'
		 ELSE S61.Region
    END = A09.ARWA06_RGN_C

where s61.processing_ID = @processing_id	

)x
where x.[ARWA08_CCM_C] is NULL
)z
;

 INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]

  Select 
		 @file_source              as [ARWE02_SOURCE_C]
		,substring(err.CCM,2,4)     as [ARWE02_ERROR_VALUE]   --Err.ARWA05_ENRG_PGM_C
		,'ACT control model is not valid for the Arrow program. They must match.' as [ARWE02_ERROR_x]
        ,@processing_id               as [ARWE02_PROCESSING_ID]
		,@Tygra_file_name             as [ARWE02_FILENAME]
		,object_name(@@PROCID)       as [ARWE02_PROCEDURE_X]
	    ,@TIME_STAMP                 as [ARWE02_CREATE_S]
   	    ,@CDSID                      as [ARWE02_CREATE_USER_C]
	    ,@TIME_STAMP                 as [ARWE02_LAST_UPDT_S]
	    ,@CDSID                      as [ARWE02_LAST_UPDT_USER_C]
	    ,1                           as [ARWE02_BATCH_ERRORS_REF_K]
		,'PARWS61_TYGRA_TITLE_PAGE'  as [ARWE02_STAGING_TABLE_X]
        ,'ERROR'                     as [ARWE02_ERROR_TYPE_X] 
		,'Tygra Title Page'          as [ARWE02_EXCEL_TAB_X]
	    ,''                          as [ARWE02_ROW_IDX]
	    ,''                          as [ARWE02_Part_Index]
		,'ACT program:  ' + @Program_name + '   ' + 'Arrow program:  ' +  @load_to_pgm_name as [ARWE02_ARROW_Value]
    FROM
	(


 select * from (
 select program, ccm, CM_PROGRAM, CM_MDLYR  
	     from PARWS61_TYGRA_TITLE_PAGE s61
		 where processing_id = @processing_id  
		 ) s61
 where NOT EXISTS 
      (select 'X'
	     from PARWU35_CTSP_RGN_PGM  u35
        join PARWU34_CTSP_RGN u34
         on u35.ARWU34_CTSP_RGN_K = u34.ARWU34_CTSP_RGN_K
         join PARWU31_CTSP u31
         on u34.ARWU31_CTSP_K = u31.ARWU31_CTSP_K
        join PARWA09_PGM_CCM_FLAT a09
        on u35.ARWA07_PGM_RGN_MDL_YR_K = a09.ARWA07_PGM_RGN_MDL_YR_K
 where u31.ARWU31_CTSP_N = @load_to_pgm_name
   and ARWA08_CCM_C = substring(s61.CCM,2,4)  
   and ARWA05_ENRG_PGM_C = s61.CM_PROGRAM  
   ) 
   ) err
;

END TRY

--CATCH
BEGIN CATCH
    INSERT INTO PARWE02_BATCH_ERRORS
	SELECT  
	     'SYSTEM'                          --source_c
		,'Catch Error'                     --error_value
		,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
        ,@processing_id                             --Processing_id
		,@Tygra_file_name                        --Filename
        ,ERROR_PROCEDURE()                 --Procedure_x
        ,@TIME_STAMP 
		,@CDSID
		,@TIME_STAMP
		,@CDSID
		,''
		,'PARWS61_TYGRA_TITLE_PAGE'
        --ARWE02_BATCH_ERRORS_K Identity key 
		,'ERROR'
		,'SYSTEM'
		,0                             -- row_idx
		,''
		,''
		;

END CATCH;	


GO

