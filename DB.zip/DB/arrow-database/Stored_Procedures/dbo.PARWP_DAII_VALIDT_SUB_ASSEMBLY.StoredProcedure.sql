DROP PROCEDURE [dbo].[PARWP_DAII_VALIDT_SUB_ASSEMBLY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASHAIK12
-- Create date: 06/01/2020
-- Description:	validate SUb Assembly Names against PBOM
-- ================================================
-- CHANGES
-- Date			CDSID		Feature	 Description
-- ----------   --------    -------  -----------
-- 06/11/2020   ASHAIK12             Added Improvement costs to the filter
-- 09/11/2020   Asolosky   US1910882 Switched from E01 error table to E02 to include part_index and arrow_Value
--=================================================
CREATE PROCEDURE [dbo].[PARWP_DAII_VALIDT_SUB_ASSEMBLY] 
	-- Add the parameters for the stored procedure here
     @GUID  varchar(5000) 
	,@CDSID varchar(30)
	,@TIME_STAMP DATETIME
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	  X.[Source_c] as [ARWE02_SOURCE_C],
	  X.sub_assembly_name as [ARWE02_ERROR_VALUE],
	  'Sub Assembly Name Not Found in the PBoM. Please verify if the template Content is Enabled and the file was Saved. Tab Names should match the Config Tab list of Sub Assemblies' as [ARWE02_ERROR_X], -- Get Clarified
	  X.[Processing_ID] as [ARWE02_PROCESSING_ID],
	  X.[filename] as [ARWE02_FILENAME],
	  OBJECT_NAME(@@PROCID) as [ARWE02_PROCEDURE_X],
	  @TIME_STAMP as [ARWE02_CREATE_S],
      @CDSID as [ARWE02_CREATE_USER_C],
	  @TIME_STAMP as [ARWE02_LAST_UPDT_S],
	  @CDSID as [ARWE02_LAST_UPDT_USER_C],
	  ARWS34_DAII_COVER_PAGE_INFO_K as [ARWE02_BATCH_ERRORS_REF_K],
	  'S35,S39-S43' as [ARWE02_STAGING_TABLE_X],
	  'ERROR' as [ARWE02_ERROR_TYPE_X],
	  X.sub_assembly_name as [ARWE02_EXCEL_TAB_X],
	  0 as [ARWE02_ROW_IDX], 
	  '', --No part index
	  ''  --No ARROW Value

	FROM  
	(
select S34.Processing_ID, get_sub_assembly.sub_assembly_name, S34.filename, S34.ARWS34_DAII_COVER_PAGE_INFO_K, S34.Source_c	  
FROM
(
select Processing_ID ,ltrim(rtrim(substring(sheet_name,5,500))) as sub_assembly_name, filename from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO
where Processing_ID=@GUID and sheet_name!='Adjustment Details'
union
select Processing_ID ,ltrim(rtrim(substring(sub_assembly_name,7,500))) as sub_assembly_name, filename from PARWS39_DAII_PURCHASED_PARTS_INFO
where Processing_ID=@GUID and sub_assembly_name  NOT IN ( 'Adjustment Final Assembly','Improvement Final Assembly','Adjustment Details','Adjustment Costs','Improvement Costs')
union
select  Processing_ID ,ltrim(rtrim(substring(sub_assembly_name,7,500))) as sub_assembly_name, filename from PARWS40_DAII_RAW_MATERIALS_INFO
where Processing_ID=@GUID and sub_assembly_name  NOT IN ( 'Adjustment Final Assembly','Improvement Final Assembly','Adjustment Details','Adjustment Costs','Improvement Costs')
union
select  Processing_ID ,ltrim(rtrim(substring(sub_assembly_name,7,500))) as sub_assembly_name, filename from PARWS41_DAII_PROCESSING_PARTS_INFO
where Processing_ID=@GUID and sub_assembly_name  NOT IN ( 'Adjustment Final Assembly','Improvement Final Assembly','Adjustment Details','Adjustment Costs','Improvement Costs')
union
select Processing_ID ,ltrim(rtrim(substring(sub_assembly_name,7,500))) as sub_assembly_name, filename from PARWS42_DAII_ASSEMBLY_PARTS_INFO
where Processing_ID=@GUID and sub_assembly_name  NOT IN ( 'Adjustment Final Assembly','Improvement Final Assembly','Adjustment Details','Adjustment Costs','Improvement Costs')
union
select Processing_ID ,ltrim(rtrim(substring(sub_assembly_name,7,500))) as sub_assembly_name, filename from PARWS43_DAII_MANUFACTURING_MARKUPS_INFO
where Processing_ID=@GUID and sub_assembly_name  NOT IN ( 'Adjustment Final Assembly','Improvement Final Assembly','Adjustment Details','Adjustment Costs','Improvement Costs')
) get_sub_assembly
JOIN [dbo].[PARWS34_DAII_COVER_PAGE_INFO] S34
ON S34.Processing_ID = get_sub_assembly.Processing_ID
AND S34.filename = get_sub_assembly.filename
JOIN [dbo].[PARWU01_CCTSS_FLAT] U01
ON U01.ARWU31_CTSP_N                 =  S34.User_Selected_CTSP_N
AND U01.[ARWA06_RGN_C]                = S34.User_Selected_CTSP_Region_C
AND U01.[ARWA03_ENRG_SUB_CMMDTY_X]    = S34.User_Selected_ENRG_SUB_CMMDTY_X
AND U01.[ARWU01_BNCHMK_VRNT_N]        = s34.User_Selected_BNCMK_VRNT_N
LEFT JOIN PARWU17_BOM_SUB_ASSY             U17
ON U17.ARWU01_CCTSS_K        = U01.ARWU01_CCTSS_K
AND U17.ARWU17_BOM_SUB_ASSY_N = get_sub_assembly.sub_assembly_name
where U17.ARWU17_BOM_SUB_ASSY_N is NULL and get_sub_assembly.sub_assembly_name NOT IN ( 'Adjustment Final Assembly','Improvement Final Assembly')
) X
;
END TRY

BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'S35,S39-S43'
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0
		     ,''  --Part_index
		     ,''  --Arrow value	
END CATCH
;
GO
