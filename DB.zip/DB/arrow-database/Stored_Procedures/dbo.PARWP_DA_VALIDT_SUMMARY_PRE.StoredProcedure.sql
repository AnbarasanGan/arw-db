DROP PROCEDURE [dbo].[PARWP_DA_VALIDT_SUMMARY_PRE]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		ASOLOSKY
-- Create date: 02/03/2021
-- Description:	Consolidated PARWP_DA_VALIDT_ASM_SUMMARY, PARWP_DA_VALIDT_FNL_ASM_SUMMARY, 
--              PARWP_DA_VALIDT_ASM_SUMMARY, PARWP_DA_VALIDT_ASM_SUMMARY, PARWP_DA_VALIDT_ASM_SUMMARY
--              into this procedure
--              Added Markups to the validation verification
--              Markups are a componded total per business rules.  This matched the Excel file formulas
--              Removed S34.Skip_loading_due_to_error_f = 0 from the where clauses. This was present in the original procedures.
-- =============================================
-- Changes
-- =============================================
--                     User
-- Author   Date       Story     Description
-- ------   -----      --------  -----------
-- Asolosky 06/25/2021 US2561600 Added more detail in the error messages to say there may be blank rows in the Excel sheet.
-- =============================================
CREATE PROCEDURE [dbo].[PARWP_DA_VALIDT_SUMMARY_PRE] 
@GUID varchar(5000) ,
@CDSID varchar(30),
@TIME_STAMP DATETIME,
@V_Threshold_A DECIMAL(38,18)

AS
BEGIN TRY

SET NOCOUNT ON
--For DeBugging
--Declare @GUID varchar(5000)           = '5F9B8405-5F5F-4A08-B5DB-B9D507AD35BD';
--Declare @CDSID varchar(30)            = 'Asolosky';
--Declare @TIME_STAMP DATETIME          = GETUTCDATE();
--Declare @V_Threshold_A DECIMAL(38,18) = .01;

DROP TABLE IF EXISTS #PRE_DA_VALIDATION;
CREATE TABLE #PRE_DA_VALIDATION (
 TEMPLATE_SECTION      VARCHAR(MAX)
,STAGING_COST          Decimal(38,19)
,ARROW_CALC_COST       Decimal(38,19) 
,SOURCE_C              VARCHAR(MAX)
,PROCESSING_ID         VARCHAR(MAX)
,FILENAME              VARCHAR(MAX)
,BATCH_ERROR_REF_K     INT
,STAGING_TABLE         VARCHAR(MAX)
,SUB_ASSEMBLY          VARCHAR(MAX)
,SUB_ASSEMBLY_SUBSTR   VARCHAR(MAX)
);

DROP TABLE IF EXISTS #PARWS43_DA_MARKUPS_FLAT;
CREATE TABLE #PARWS43_DA_MARKUPS_FLAT (
 FILENAME                 VARCHAR(MAX)
,Processing_id            VARCHAR(MAX)
,SUB_ASSEMBLY             VARCHAR(MAX)
,SUB_ASSEMBLY_SUBSTR      VARCHAR(MAX)
,Scrap_Markup             Decimal(38,19)
,Scrap_Markup_Tot_amt     Decimal(38,19)
,SGA_TOTAL_Markup         Decimal(38,19)
,SGA_Markup_Tot_amt       Decimal(38,19)
,PROFIT_Markup            Decimal(38,19)
,PROFIT_Tot_amt           Decimal(38,19)
);

--*****************
--Purchased parts
--*****************
INSERT INTO #PRE_DA_VALIDATION 
Select 'Purchased parts'            AS TEMPLATE_SECTION 
      ,S35_purchased_part           AS STAGING_COST 
	  ,S39.S39_unit_cost_usd        AS ARROW_CALC_COST
      ,S35.Source_c 
	  ,S35.Processing_ID
	  ,S35.filename
	  ,S35.ARWS34_DAII_COVER_PAGE_INFO_K
      ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO' AS STAGING_TABLE
      ,S39.sub_assembly_name        AS SUB_ASSEMBLY
	  ,S39_substr_sub_assembly_name AS SUB_ASSEMBLY_SUBSTR
 From
     (
       select SUM(purchased_part) as S35_purchased_part , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K, s35.sheet_name 
	         ,Case When s35.sheet_name like 'ADJ-%'
		           Then ltrim(Rtrim(substring(s35.sheet_name,5,500)))
				   When s35.sheet_name = 'Adjustment Details'
				   Then 'Adjustment Costs'  --Need to replace so the join would work
			       Else s35.sheet_name
		      End as S35_substr_sub_assembly_name
         from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
         JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                      AND S34.filename      = S35.filename
        where S34.Processing_ID               = @GUID
        group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
     ) S35

Join (
        select SUM(CASE WHEN [sub_assembly_name]!='Costs-Directed Parts' THEN ([no_of_pieces])*([purchased_price_per_piece] + [inbound_packaging_costs] + [inbound_logistics_costs] + [tax_duty])*(1 + [purchased_parts_markup_cost])*[exchange_rate] 
     					 ELSE ((([no_of_pieces])*([inbound_packaging_costs] + [inbound_logistics_costs] + [tax_duty]))+(([purchased_price_per_piece] + [inbound_packaging_costs] + [inbound_logistics_costs] + [tax_duty])*[purchased_parts_markup_cost]*[no_of_pieces]))*[exchange_rate]  
				   END) as S39_unit_cost_usd
              , S34.filename
              , S34.Processing_ID
              , S39.sub_assembly_name
        	  , Case When S39.sub_assembly_name like 'Costs-%'
        	         Then ltrim(rtrim(substring(s39.sub_assembly_name,7,500)))
        		     Else S39.sub_assembly_name
        	    End as S39_substr_sub_assembly_name
          FROM PARWS34_DAII_COVER_PAGE_INFO       S34
     	 Join PARWS39_DAII_PURCHASED_PARTS_INFO  S39 ON S39.Processing_ID     = S34.Processing_ID
                                                     and S39.filename          = S34.filename
          where S34.Processing_ID               = @GUID
            and (S39.sub_assembly_name       like 'Costs-%'
			     or
			     S39.sub_assembly_name          = 'Adjustment Costs'
				)
     	 group by S34.filename, S34.Processing_ID, S39.sub_assembly_name
     ) S39
   On S35.filename                 = S39.filename 
  AND S35.Processing_ID            = S39.Processing_ID
  AND S35_substr_sub_assembly_name = S39_substr_sub_assembly_name
Where s35.sheet_name like 'Adj-%'
   Or s35.sheet_name    = 'Adjustment details'
;

--*****************
--Raw materials
--*****************
INSERT INTO #PRE_DA_VALIDATION
Select 'Raw Materials'               AS TEMPLATE_SECTION
      ,S35_raw_material              AS STAGING_COST 
	  ,S40_unit_cost_usd             AS ARROW_CALC_COST
      ,S35.Source_c 
	  ,S35.Processing_ID
	  ,S35.filename
	  ,S35.ARWS34_DAII_COVER_PAGE_INFO_K
      ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
      ,S40.sub_assembly_name         AS SUB_ASSEMBLY
	  ,S40_substr_sub_assembly_name	 AS SUB_ASSEMBLY_SUBSTR
 From
     (
       select SUM(raw_material) as S35_raw_material , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K, S35.sheet_name 
	         ,Case When s35.sheet_name like 'ADJ-%'
		           Then ltrim(Rtrim(substring(s35.sheet_name,5,500)))
				   When s35.sheet_name = 'Adjustment Details'
				   Then 'Adjustment Costs'  --Need to replace so the join would work
			       Else s35.sheet_name
		      End as S35_substr_sub_assembly_name
         from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
         JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                      AND S34.filename      = S35.filename
        where S34.Processing_ID               = @GUID
        group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K, s35.sheet_name
     ) S35

 Join
     (
        select SUM(([no_of_pieces] * [gross_usage_per_piece] 
                    * ([material_price] + [inbound_packaging_costs] + [inbound_logistics_costs] + [tax_duty_per_uom])
                    - ([no_of_pieces] *(([gross_usage_per_piece])*[reclamation_pcntg]*[scrap_price]))
                   ) *[exchange_rate]
     			 ) as S40_unit_cost_usd
              , S34.filename
              , S34.Processing_ID
              , S40.sub_assembly_name
        	  , Case When S40.sub_assembly_name like 'Costs-%'
        	         Then ltrim(rtrim(substring(S40.sub_assembly_name,7,500)))
        		     Else S40.sub_assembly_name
        	    End as S40_substr_sub_assembly_name
          FROM PARWS34_DAII_COVER_PAGE_INFO       S34
     	  Join PARWS40_DAII_RAW_MATERIALS_INFO    S40 ON S40.Processing_ID     = S34.Processing_ID
                                                     and S40.filename          = S34.filename
          where S34.Processing_ID               = @GUID
            and (S40.sub_assembly_name            like 'Costs-%' 
			     or
				 S40.sub_assembly_name            = 'Adjustment Costs'
				)
     	  group by S34.filename, S34.Processing_ID, S40.sub_assembly_name
     ) S40
   On S35.filename                 = S40.filename 
  AND S35.Processing_ID            = S40.Processing_ID
  AND S35_substr_sub_assembly_name = S40_substr_sub_assembly_name
Where s35.sheet_name like 'Adj-%'
   Or s35.sheet_name    = 'Adjustment details'
;

--*****************
--Processing
--*****************
INSERT INTO #PRE_DA_VALIDATION 
Select 'Processing'            AS TEMPLATE_SECTION   
      ,S35_processing          AS STAGING_COST 
	  ,S41_unit_cost_usd       AS ARROW_CALC_COST
      ,S35.Source_c 
	  ,S35.Processing_ID
	  ,S35.filename
	  ,S35.ARWS34_DAII_COVER_PAGE_INFO_K
      ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
      ,S41.sub_assembly_name         AS SUB_ASSEMBLY
	  ,S41_substr_sub_assembly_name	 AS SUB_ASSEMBLY_SUBSTR
 From
     (
       select SUM(processing) as S35_processing , S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K,S35.sheet_name 
	         ,Case When s35.sheet_name like 'ADJ-%'
		           Then ltrim(Rtrim(substring(s35.sheet_name,5,500)))
				   When s35.sheet_name = 'Adjustment Details'
				   Then 'Adjustment Costs'  --Need to replace so the join would work
			       Else s35.sheet_name
		      End as S35_substr_sub_assembly_name
         from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
         JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                      AND S34.filename      = S35.filename
        where S34.Processing_ID               = @GUID
        group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
     ) S35
 Join
     (
        select SUM(CASE WHEN [no_of_pieces_per_cycle]=0 
                        THEN [no_of_pieces_per_subassy] * ([packaging_costs]  + [logistics_cost]  +  [tax_duty_per_piece]  + [licensing_costs])*exchange_rate
     	               ELSE ([no_of_pieces_per_subassy] *
                               (
                                (([cycle_time_sec]*([machinehourly_operation_overhead]/3600))/[no_of_pieces_per_cycle]) 
                            	   + 
                            	   ((([cycle_time_sec]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])/[no_of_pieces_per_cycle] )*(1+[indirect_labor_costs])*(1+[fringes]))
                            	   +  [packaging_costs] + [logistics_cost]  +  [tax_duty_per_piece]  + [licensing_costs] 
                               )
                              ) *[exchange_rate]  
     			   END) as S41_unit_cost_usd
              , S34.filename
              , S34.Processing_ID
              , S41.sub_assembly_name
        	  , Case When S41.sub_assembly_name like 'Costs-%'
        	         Then ltrim(rtrim(substring(S41.sub_assembly_name,7,500)))
        		     Else S41.sub_assembly_name
        	    End as S41_substr_sub_assembly_name
          FROM PARWS34_DAII_COVER_PAGE_INFO       S34
     	 Join PARWS41_DAII_PROCESSING_PARTS_INFO S41 ON S41.Processing_ID     = S34.Processing_ID
                                                     and S41.filename          = S34.filename
          where S34.Processing_ID               = @GUID
            and (S41.sub_assembly_name          like 'Costs-%'
			     or
				 S41.sub_assembly_name          = 'Adjustment Costs'
                )
     	 group by S34.filename, S34.Processing_ID,S41.sub_assembly_name
     ) S41
   On S35.filename                 = S41.filename 
  AND S35.Processing_ID            = S41.Processing_ID
  AND S35_substr_sub_assembly_name = S41_substr_sub_assembly_name
Where s35.sheet_name like 'ADJ-%'    
   or s35.sheet_name    = 'Adjustment details' 
;

--*****************
--Assembly
--*****************
INSERT INTO #PRE_DA_VALIDATION 
Select 'Assembly'                   AS TEMPLATE_SECTION   --'Purchased parts' 
      ,assembly_cost                AS STAGING_COST 
	  ,S42_unit_cost_usd            AS ARROW_CALC_COST
      ,S35.Source_c 
	  ,S35.Processing_ID
	  ,S35.filename
	  ,S35.ARWS34_DAII_COVER_PAGE_INFO_K
      ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
      ,S42.sub_assembly_name        AS SUB_ASSEMBLY
	  ,S35_substr_sub_assembly_name	AS SUB_ASSEMBLY_SUBSTR
 From
     (
       select SUM(assembly) as assembly_cost
             ,S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K, S35.sheet_name 
	         ,Case When s35.sheet_name like 'ADJ-%'
		           Then ltrim(Rtrim(substring(s35.sheet_name,5,500)))
				   When s35.sheet_name = 'Adjustment Details'
				   Then 'Adjustment Costs'  --Need to replace so the join would work
			       Else s35.sheet_name
		      End as S35_substr_sub_assembly_name
         from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
         JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 ON S34.Processing_ID = S35.Processing_ID
                                                      AND S34.filename     = S35.filename
        where S34.Processing_ID               = @GUID
        group by S34.filename,S34.Processing_ID,S34.Source_c,S34.ARWS34_DAII_COVER_PAGE_INFO_K,s35.sheet_name
     ) S35
 Join
     (
        select SUM(IsNUll(([assembly_secs_operation]
                            * ([machinehourly_operation_overhead]/3600)
     				       + (([assembly_secs_operation]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])*(1+[indirect_labor_costs])*(1+[fringes]))
     				       + [packaging_costs]+[logistics_cost]+[tax_duty_per_operation]
     					 ) * [exchange_rate],0)
     			 ) as S42_unit_cost_usd
              , S34.filename
              , S34.Processing_ID
              , s42.sub_assembly_name
        	  , Case When s42.sub_assembly_name like 'Costs-%'
        	         Then ltrim(rtrim(substring(s42.sub_assembly_name,7,500)))
        		     Else s42.sub_assembly_name
        	    End as s42_substr_sub_assembly_name
          FROM PARWS34_DAII_COVER_PAGE_INFO     S34
     	  Join PARWS42_DAII_ASSEMBLY_PARTS_INFO S42 ON S42.Processing_ID     = S34.Processing_ID
                                                   and S42.filename          = S34.filename
          where S34.Processing_ID               = @GUID
            and (S42.sub_assembly_name       like 'Costs-%'
     	        or
     			S42.sub_assembly_name           = 'Adjustment Costs'
     		   )
     	 group by S34.filename, S34.Processing_ID, s42.sub_assembly_name
     ) S42
    On S35.filename                 = S42.filename 
   AND S35.Processing_ID            = S42.Processing_ID	
   AND S35_substr_sub_assembly_name = S42_substr_sub_assembly_name
Where s35.sheet_name like 'ADJ-%'   
   or s35.sheet_name    = 'Adjustment details' 
;

--*****************
--Final assembly
--*****************
INSERT INTO #PRE_DA_VALIDATION
Select 'Adjustment Final Assembly' AS TEMPLATE_SECTION   --'Purchased parts' 
      ,final_assembly_cost         AS STAGING_COST 
	  ,S42_unit_cost_usd           AS ARROW_CALC_COST
      ,S35.Source_c 
	  ,S35.Processing_ID
	  ,S35.filename
	  ,S35.ARWS34_DAII_COVER_PAGE_INFO_K
      ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
      ,S42.sub_assembly_name       AS SUB_ASSEMBLY
	  ,S42.sub_assembly_name 	   AS SUB_ASSEMBLY_SUBSTR  --No Substring needed for Final Assembly
 From
(
  select SUM(final_assembly) as final_assembly_cost 
        ,S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K
    from PARWS35_DAII_ADJUSTMENT_DETAILS_INFO S35
    JOIN PARWS34_DAII_COVER_PAGE_INFO         S34 
	  ON S34.Processing_ID = S35.Processing_ID
     AND S34.filename      =  S35.filename
   where S34.Processing_ID               = @GUID
   group by S34.filename, S34.Processing_ID, S34.Source_c, S34.ARWS34_DAII_COVER_PAGE_INFO_K
) S35
Join
(
   select SUM(IsNUll(([assembly_secs_operation]
                      * ([machinehourly_operation_overhead]/3600)
				      + (([assembly_secs_operation]*([direct_hourly_labor_headcount]/3600)*[direct_headcount])*(1+[indirect_labor_costs])*(1+[fringes]))
				      + [packaging_costs]+[logistics_cost]+[tax_duty_per_operation]
					 )* [exchange_rate],0)
			 ) as S42_unit_cost_usd
		, S34.filename
		, S34.Processing_ID
		, S42.sub_assembly_name
     FROM PARWS34_DAII_COVER_PAGE_INFO     S34
	 Join PARWS42_DAII_ASSEMBLY_PARTS_INFO S42 ON S42.Processing_ID     = S34.Processing_ID
                                              and S42.filename          = S34.filename
     where S34.Processing_ID               = @GUID
	   and S42.sub_assembly_name           = 'Adjustment Final Assembly'
	 group by S34.filename, S34.Processing_ID, S42.sub_assembly_name 
) S42
 On S35.filename      = S42.filename 
AND S35.Processing_ID = S42.Processing_ID
;

--select * from #PRE_DA_VALIDATION;

--*****************
--Setup up the markups From the S43 Staging table so the Scrap, SG&A, Profit and amounts are on one line
--*****************
INSERT INTO #PARWS43_DA_MARKUPS_FLAT
Select FILENAME
      ,Processing_ID
      ,sub_assembly_name                                as SUB_ASSEMBLY
   	  ,Case When sub_assembly_name like 'Costs-%'
   	        Then ltrim(rtrim(substring(sub_assembly_name,7,500)))
   		    Else sub_assembly_name
   	   End as SUB_ASSEMBLY_SUBSTR
      ,Sum(Scrap_Markup)                                as Scrap_Markup
      ,Sum(Scrap_Markup_Tot_amt)                        as Scrap_Markup_Tot_amt
      ,Sum(SGA_TOTAL_Markup)                            as SGA_TOTAL_Markup
      ,Sum(SGA_Markup_Tot_amt)                          as SGA_Markup_Tot_amt
      ,Sum(PROFIT_Markup)                               as PROFIT_Markup
      ,Sum(PROFIT_Tot_amt)                              as PROFIT_Tot_amt
  From
      (
       Select FILENAME
	         ,Processing_ID
             ,sub_assembly_name
             ,Case When manufacturing_markup_desc = 'Scrap'        Then manufacturing_markup_value  ELSE 0 END AS Scrap_Markup 
             ,Case When manufacturing_markup_desc = 'Scrap'        Then unit_cost_usd               ELSE 0 END AS Scrap_Markup_Tot_amt 
             ,Case When manufacturing_markup_desc = 'SG&A - Total' Then manufacturing_markup_value  ELSE 0 END AS SGA_TOTAL_Markup 
             ,Case When manufacturing_markup_desc = 'SG&A - Total' Then unit_cost_usd               ELSE 0 END AS SGA_Markup_Tot_amt  
             ,Case When manufacturing_markup_desc = 'Profit'       Then manufacturing_markup_value  ELSE 0 END AS PROFIT_Markup 
             ,Case When manufacturing_markup_desc = 'Profit'       Then unit_cost_usd               ELSE 0 END AS PROFIT_Tot_amt
         From PARWS43_DAII_MANUFACTURING_MARKUPS_INFO S43
        Where Processing_ID = @GUID
		 and manufacturing_markup_desc in ('Scrap','SG&A - Total','Profit')
		 and sub_assembly_name Not in ('Improvement Costs','Improvement Final Assembly')
      ) MRKUP
group by FILENAME, processing_id, sub_assembly_name;

--select * from #PARWS43_DA_MARKUPS_FLAT

/*****************/
--Staging Table Markups without the ARROW calculated formula cost. ARROW_CALC_COST is set to 0
--Using the markups from the Excel Costs sheets instead of from the Adj sheets
/*****************/
INSERT INTO #PRE_DA_VALIDATION
select 'Manufacturing Markups'                                       AS TEMPLATE_SECTION   
      ,Scrap_Markup_Tot_amt +  SGA_Markup_Tot_amt + PROFIT_Tot_amt   AS STAGING_COST
      ,0                                                             AS ARROW_CALC_COST    --Will update this amount below
      ,S34.Source_c
	  ,S34.Processing_ID
	  ,S34.filename
	  ,S34.ARWS34_DAII_COVER_PAGE_INFO_K
      ,'PARWS43_DAII_MANUFACTURING_MARKUPS_INFO'
      ,S43.SUB_ASSEMBLY 
   	  ,S43.SUB_ASSEMBLY_SUBSTR
  FROM PARWS34_DAII_COVER_PAGE_INFO         S34
  JOIN #PARWS43_DA_MARKUPS_FLAT             S43 ON S43.Processing_ID = S34.Processing_ID
                                               AND S43.filename      = S34.filename
 where S34.Processing_ID               = @GUID
;
--select * from #PRE_DA_VALIDATION

--*****************
--Update ARROW manufacturing markup amount in Pre_Val_Target
--*****************
MERGE INTO #PRE_DA_VALIDATION   Pre_Val_Target
USING
(--Pre_Val_Source
Select TOT.FILENAME
      ,TOT.SUB_ASSEMBLY  
      ,TOT.SUB_ASSEMBLY_SUBSTR
      ,'Manufacturing Markups' AS Template_Section  

	  ,SCRAP_MARKUP_TOT    --For testing purpose only
	  ,SGA_MARKUP_TOT      --For testing purpose only
	  ,PROFIT_MARKUP_TOT   --For testing purpose only
	  ,(SCRAP_MARKUP_TOT + SGA_MARKUP_TOT + PROFIT_MARKUP_TOT) As Grand_Total_Markup --This must match the markup subtotal in the Excel file.
  From
(--TOT
Select Split.FILENAME
      ,Split.SUB_ASSEMBLY
      ,Split.SUB_ASSEMBLY_SUBSTR
	  ,ARROW_Purchased_COST
	  ,ARROW_Raw_COST
	  ,ARROW_Processing_COST
	  ,ARROW_Assembly_COST
	  ,ASM_Process_Raw_A
	  ,Scrap_Markup     * (ASM_Process_Raw_A)                                      as SCRAP_MARKUP_TOT --Markup for Scrap
	  ,SGA_TOTAL_Markup * (ASM_Process_Raw_A + (Scrap_Markup * ASM_Process_Raw_A)) as SGA_MARKUP_TOT   --Markup for SGA is a componded calculation per William Brown
	  ,PROFIT_Markup    * (ASM_Process_Raw_A
	                               + (Scrap_Markup     * (ASM_Process_Raw_A)) --SCRAP_MARKUP
	                               + (SGA_TOTAL_Markup * (ASM_Process_Raw_A + (Scrap_Markup * ASM_Process_Raw_A))) 
								  ) as PROFIT_MARKUP_TOT                                                 --Markup for Profit is a componded calculation per William Brown
  From
(--Split
  Select FILENAME
        ,SUB_ASSEMBLY
        ,SUB_ASSEMBLY_SUBSTR
        ,Sum(ARROW_Purchased_COST)          as ARROW_Purchased_COST
        ,Sum(ARROW_Raw_COST)                as ARROW_Raw_COST
        ,Sum(ARROW_Processing_COST)         as ARROW_Processing_COST
        ,Sum(ARROW_Assembly_COST)           as ARROW_Assembly_COST
        ,Sum(ARROW_Final_Assembly_COST)     as ARROW_Final_Assembly_COST
		,Case When SUB_ASSEMBLY = 'Adjustment Final assembly'                                      --Adjusment Final Assembly doesn't have Raw, Processing, Assembly
		      Then Sum(ARROW_Final_Assembly_COST)                                                  --Amount used for markup calc
			  Else Sum(ARROW_Assembly_COST)   + Sum(ARROW_Processing_COST)   + Sum(ARROW_Raw_COST) --Amount used for markup calc
		 End  ASM_Process_Raw_a
  From
      (--PRE
       --Need to get all the totals already inserted into the temp #PRE_VALIDATION table which will be used to calculate the markups.
       Select FILENAME
             ,SUB_ASSEMBLY
             ,SUB_ASSEMBLY_SUBSTR
             ,Case When Template_Section = 'Purchased parts'            Then ARROW_CALC_COST ELSE 0 END AS ARROW_Purchased_COST 
             ,Case When Template_Section = 'Raw materials'              Then ARROW_CALC_COST ELSE 0 END AS ARROW_Raw_COST
             ,Case When Template_Section = 'Processing'                 Then ARROW_CALC_COST ELSE 0 END AS ARROW_Processing_COST
             ,Case When Template_Section = 'Assembly'                   Then ARROW_CALC_COST ELSE 0 END AS ARROW_Assembly_COST
             ,Case When Template_Section = 'Adjustment Final Assembly'  Then ARROW_CALC_COST ELSE 0 END AS ARROW_Final_Assembly_COST
       
        From #PRE_DA_VALIDATION
	   Where Sub_Assembly like 'Costs-%'
	      or Sub_Assembly in ('Adjustment Final Assembly','Adjustment Costs')  --Not using Purchased parts for markups but still bringing along for debugging purpose  
      ) PRE
  group by FILENAME, SUB_ASSEMBLY ,SUB_ASSEMBLY_SUBSTR  
) SPLIT
Join #PARWS43_DA_MARKUPS_FLAT S43_FLAT on S43_FLAT.filename     = Split.filename 
                                      and S43_FLAT.SUB_ASSEMBLY = Split.SUB_ASSEMBLY
) TOT
)  Pre_Val_Source

ON (Pre_Val_Target.FILENAME             = Pre_Val_Source.FILENAME      AND
    Pre_Val_Target.SUB_ASSEMBLY_SUBSTR  = Pre_Val_Source.SUB_ASSEMBLY_SUBSTR  AND  
	Pre_Val_Target.Template_Section     = Pre_Val_Source.Template_Section
   )
when MATCHED THEN
UPDATE SET          
 	Pre_Val_Target.ARROW_CALC_COST = Pre_Val_Source.Grand_Total_Markup
;

--Select * From #PRE_DA_VALIDATION;
--Select * from #PARWS43_DA_MARKUPS_FLAT;



/*****************/
--ERRORS
/*****************/
INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
select 
       Source_c
      ,CAST(STAGING_COST as Varchar(50)) as ARWE02_ERROR_VALUE
--	  ,TEMPLATE_SECTION
      ,Case When TEMPLATE_SECTION = 'Purchased parts' Then
      	         'Purchased Parts total in Supplier Quote Summary does not match calculated Purchased Parts total. Please verify that the formulas have not been changed in column N of the Adj sheet and/or column Z/AB of Purchased Parts in the Cost sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Raw materials' Then
			     'Raw Materials total in Supplier Quote Summary does not match calculated Raw Materials total. Please verify that the formulas have not changed in column O of the Adj sheet and/or column Z/AB of Raw Materials section in the Cost sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Processing' Then
                 'Processing total in Supplier Quote Summary does not match calculated Processing total. Please verify that the formulas have not changed in column P of the Adj sheet and/or column Z/AB of Processing section in the Cost sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Assembly' Then
                 'Assembly total in Supplier Quote Summary does not match calculated Assembly total. Please verify that the formulas have not changed in column Q of the Adj sheet and/or column Z/AB of Assembly section in the Cost sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Adjustment Final assembly' Then
                 'Final Assembly total in Supplier Quote Summary does not match calculated Final Assembly total. Please verify that the formulas have not changed in column S of the Adj sheet and/or column X/Z of Adjustment Final Assembly sheet. Also remove any blank rows between parts. The system will stop reading the data when it finds 2 blank rows.' 
			When TEMPLATE_SECTION = 'Manufacturing markups' AND SUB_ASSEMBLY = 'Adjustment Final assembly' Then  --Final assembly has a different column than the rest of the markups.
                 'Manufacturing markup total does not match calculated Manufacturing markup total. Please verify that the formulas have not been changed in column Z of the Total Markup per Piece section. Also remove any blank rows between markups. The system will stop reading the data when it finds 2 blank rows.'
			When TEMPLATE_SECTION = 'Manufacturing markups' Then
                 'Manufacturing markup total does not match calculated Manufacturing markup total. Please verify that the formulas have not been changed in column AB of the Total Markup per Piece section. Also remove any blank rows between markups. The system will stop reading the data when it finds 2 blank rows.'
            Else TEMPLATE_SECTION + ' Unknown Template Section. Contact ARROW Support'
       End as ARWE02_ERROR_X

      ,Processing_ID
      ,filename
      ,OBJECT_NAME(@@PROCID)  as [ARWE02_PROCEDURE_X]
      ,@TIME_STAMP  as [ARWE02_CREATE_S]
      ,@CDSID       as [ARWE02_CREATE_USER_C]
      ,@TIME_STAMP  as [ARWE02_LAST_UPDT_S]
      ,@CDSID       as [ARWE02_LAST_UPDT_USER_C]
      ,BATCH_ERROR_REF_K
      ,STAGING_TABLE
      ,'ERROR'
      ,SUB_ASSEMBLY
      ,0                               as ARWE02_ROW_IDX
      ,''       --Part_index
      ,CAST(ARROW_CALC_COST as varchar(50)) as ARWE02_ARROW_Value
 FROM #PRE_DA_VALIDATION
Where 
  (
      ABS(ARROW_CALC_COST) <  ABS(STAGING_COST) - @V_Threshold_A
	  or 
	  ABS(ARROW_CALC_COST) >  ABS(STAGING_COST) + @V_Threshold_A
   )
;
DROP TABLE IF EXISTS #PRE_DA_VALIDATION;
DROP TABLE IF EXISTS #PARWS43_DA_MARKUPS_FLAT;

END TRY

BEGIN CATCH

DROP TABLE IF EXISTS #PRE_DA_VALIDATION;
DROP TABLE IF EXISTS #PARWS43_DA_MARKUPS_FLAT;

INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS35_DAII_ADJUSTMENT_DETAILS_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
			 ,'ERROR'
			 ,'SYSTEM'
			 ,0                                 --row_idx
		     ,''  --Part_index
		     ,''  --Arrow value
END CATCH;
GO
