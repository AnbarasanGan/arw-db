DROP PROCEDURE [dbo].[PARWP_VA_VALIDT_PURCH_CMMDTY]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		rwesley2
-- Create date: 07/26/2019
-- Description:	Stored Procedure to Validate Purchasing commodity code from the database (what the users set up) to what's on the cover page.
-- =============================================
-- Changes
-- =============================================
-- Author     Date        Description
-- ------     -----       -----------
-- asamriya  09/11/2019   Added row_idx
-- ashaik12  12/25/2019   Removed left join
-- Ashaik12  01/14/2020   Added Time_Stamp parameter and removed filter on Processing Status
-- Ashaik12  09/30/2020   US1910884  Switched from E01 error table to E02 to include part_index and arrow_Value
-- =============================================

CREATE PROCEDURE [dbo].[PARWP_VA_VALIDT_PURCH_CMMDTY] 
	-- Add the parameters for the stored procedure here
	   @GUID  varchar(500)
	  ,@CDSID varchar(30)
	  ,@TIME_STAMP DATETIME
AS
-- Declare	@v_procedure varchar(5000) = 'PARWP_CCS_VALIDT_PURCH_CMMDTY' ;
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	INSERT INTO [dbo].[PARWE02_BATCH_ERRORS]
      SELECT
	         Validate.[Source_c]                    as [ARWE02_SOURCE_C],
	         case when Purch_Cmmdty_C = '' then '"No Purchasing Commodity entered"' else  Purch_Cmmdty_C end                        as [ARWE02_ERROR_VALUE],
	          'Purchasing Commodity Code on the cover page does not match the purchasing commodity that was set up for the program' as [ARWE02_ERROR_X],

	         Validate.[Processing_ID]                as [ARWE02_PROCESSING_ID],
	         Validate.[filename]                     as [ARWE02_FILENAME],
	         OBJECT_NAME(@@PROCID)                   as [ARWE02_PROCEDURE_X],
	         @TIME_STAMP                            as [ARWE02_CREATE_S],
	         @CDSID                                  as [ARWE02_CREATE_USER_C],
	         @TIME_STAMP                            as [ARWE02_LAST_UPDT_S],
	         @CDSID                                  as [ARWE02_LAST_UPDT_USER_C],
	         Validate.[ARWS45_VA_COVER_PAGE_INFO_K]  as [ARWE02_BATCH_ERRORS_REF_K],
	         'PARWS45_VA_COVER_PAGE_INFO'          as [ARWE02_STAGING_TABLE_X],
	         'WARNING'                               as [ARWE02_ERROR_TYPE_X],
	         'Cover'                                 as [ARWE02_EXCEL_TAB_X],
			 0										 as [ARWE02_ROW_IDX],
			 '',
			 ARWA15_PCHSNG_CMMDTY_C
       FROM 
       (
	   --Find all staging records where the supplier is not in the Arrow A17 table
        SELECT 
          Processing_ID,
          Purch_Cmmdty_C,
		  ARWA15_PCHSNG_CMMDTY_C,
		  Processing_Status_x,
		  Source_c,
		  filename,
          [ARWS45_VA_COVER_PAGE_INFO_K]
        FROM [dbo].[PARWS45_VA_COVER_PAGE_INFO] s45
         Join PARWA03_ENRG_SUB_CMMDTY     A03 on A03.ARWA03_ENRG_SUB_CMMDTY_X = S45.User_Selected_ENRG_SUB_CMMDTY_X
         Join PARWA15_PCHSNG_CMMDTY       A15 on A15.ARWA15_PCHSNG_CMMDTY_K   = A03.ARWA15_PCHSNG_CMMDTY_K
        WHERE Processing_ID       = @GUID
		  and S45.Purch_Cmmdty_C != A15.ARWA15_PCHSNG_CMMDTY_C			                      
       ) Validate
    ;
END TRY
BEGIN CATCH
INSERT INTO [dbo].PARWE02_BATCH_ERRORS
       SELECT  
              'SYSTEM'                              --source_c
             ,'Catch Error'                     --error_value
             ,'Line: ' + cast(ERROR_LINE() as varchar(50)) + ' Message: ' + Substring(ERROR_MESSAGE(),1,4900) --error_x
             ,@GUID                 --Processing_id
             ,'UNKNOWN'                         --Filename
             ,ERROR_PROCEDURE()                 --Procedure_x
             ,@TIME_STAMP 
             ,@CDSID
             ,@TIME_STAMP
             ,@CDSID
			 ,''
			 ,'PARWS45_VA_COVER_PAGE_INFO'
			 --ARWE02_BATCH_ERRORS_K Identity key
             ,'ERROR' 	
             ,'SYSTEM'
			 ,0                               -- row_idx
			 ,''
			 ,''
END CATCH;


GO
