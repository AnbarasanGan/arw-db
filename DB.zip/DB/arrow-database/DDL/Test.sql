select * from [dbo].[PARWA37_MRKP_RGN]
