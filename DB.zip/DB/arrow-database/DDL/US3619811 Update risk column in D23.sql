-- Run this after running the previous script to add the new column
-- to be consistent with other fields in D23, the column should be 19,9 and it does not need any constraint.
ALTER TABLE [dbo].[PARWD23_DC_VRNT_SUP_COST] ALTER COLUMN [ARWUD1_CCTSS_VRNT_RISK_A] DECIMAL(19,9) 

ALTER TABLE [dbo].[PARWD23_DC_VRNT_SUP_COST] DROP CONSTRAINT DF_ARWUD1_CCTSS_VRNT_RISK_A;
