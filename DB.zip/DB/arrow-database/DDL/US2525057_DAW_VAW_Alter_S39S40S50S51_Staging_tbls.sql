ALTER TABLE PARWS39_DAII_PURCHASED_PARTS_INFO Alter Column no_of_pieces decimal(38,18);
ALTER TABLE PARWS40_DAII_RAW_MATERIALS_INFO Alter Column no_of_pieces decimal(38,18);
ALTER TABLE PARWS50_VA_PURCHASED_PARTS_INFO Alter Column no_of_pieces decimal(38,18);
ALTER TABLE PARWS51_VA_RAW_MATERIALS_INFO Alter Column no_of_pieces decimal(38,18);
