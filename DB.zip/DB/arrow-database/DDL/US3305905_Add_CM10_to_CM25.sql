

ALTER TABLE [dbo].[PARWS62_TYGRA_SUMMARY] 
ADD 
 [CM10] [varchar](5000) NULL
,[CM11]	[varchar](5000) NULL
,[CM12]	[varchar](5000) NULL
,[CM13]	[varchar](5000) NULL
,[CM14]	[varchar](5000) NULL
,[CM15]	[varchar](5000) NULL
,[CM16]	[varchar](5000) NULL
,[CM17]	[varchar](5000) NULL
,[CM18]	[varchar](5000) NULL
,[CM19]	[varchar](5000) NULL
,[CM20]	[varchar](5000) NULL
,[CM21]	[varchar](5000) NULL
,[CM22]	[varchar](5000) NULL
,[CM23]	[varchar](5000) NULL
,[CM24]	[varchar](5000) NULL
,[CM25]	[varchar](5000) NULL


